"use client";
import { useActionState, useState } from "react";
import { instructorDeparts } from "@/app/actions/studio";
import type { FormState } from "@/lib/forms";
import SubmitButton from "@/components/SubmitButton";
import Alert from "@/components/Alert";

const initial: FormState = {};

export default function DepartForm({ instructorId }: { instructorId: string }) {
  const [open, setOpen] = useState(false);
  const [noticeState, notice] = useActionState(
    instructorDeparts.bind(null, instructorId, false), initial
  );
  const [causeState, cause] = useActionState(
    instructorDeparts.bind(null, instructorId, true), initial
  );

  if (noticeState.ok || causeState.ok) {
    return (
      <Alert kind="success">
        {noticeState.message ?? causeState.message}
      </Alert>
    );
  }

  if (!open) {
    return (
      <div className="app__decide">
        <button className="btn btn--line" onClick={() => setOpen(true)}>
          Record a departure
        </button>
      </div>
    );
  }

  return (
    <div className="app__decide" style={{ flexDirection: "column", alignItems: "stretch" }}>
      <form action={notice} className="ctools__inline">
        <label className="field" style={{ maxWidth: 340 }}>
          <span className="field__label">They gave notice</span>
          <input name="note" placeholder="Anything worth recording" />
          <span className="field__hint">
            30 days&rsquo; notice, then 90 days of learner access.
          </span>
        </label>
        <SubmitButton>Record notice</SubmitButton>
      </form>

      <form action={cause} className="ctools__inline" style={{ marginTop: 8 }}>
        <label className="field" style={{ maxWidth: 340 }}>
          <span className="field__label">Suspend for cause</span>
          <input name="note" placeholder="Reason — required" required />
          <span className="field__hint">
            Immediate. Open reviews move to the queue straight away.
          </span>
        </label>
        <SubmitButton>Suspend</SubmitButton>
      </form>

      {(noticeState.error || causeState.error) && (
        <Alert kind="error">{noticeState.error ?? causeState.error}</Alert>
      )}
      <button className="btn btn--line" style={{ alignSelf: "flex-start" }} onClick={() => setOpen(false)}>
        Cancel
      </button>
    </div>
  );
}
