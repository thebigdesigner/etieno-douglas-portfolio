"use client";
import Link from "next/link";
import { useActionState } from "react";
import { saveIntro } from "@/app/actions/studio";
import type { FormState } from "@/lib/forms";
import SubmitButton from "@/components/SubmitButton";
import Alert from "@/components/Alert";

const initial: FormState = {};

export default function IntroForm() {
  const [state, action] = useActionState(saveIntro, initial);

  return (
    <form action={action} className="auth__form" style={{ marginTop: 32 }}>
      <label className="field">
        <span className="field__label">Anything you want learners to know (optional)</span>
        <textarea name="bio" rows={4} />
      </label>

      <label className="field">
        <span className="field__label">Taught before?</span>
        <select name="experience" defaultValue="">
          <option value="">Rather not say</option>
          <option value="none">Never</option>
          <option value="informal">Informally — colleagues, juniors, workshops</option>
          <option value="online">Yes, online</option>
          <option value="formal">Yes, formally</option>
        </select>
        <span className="field__hint">
          It changes nothing about your access. It tells us who to offer help to.
        </span>
      </label>

      {state.error && <Alert kind="error">{state.error}</Alert>}
      <SubmitButton>Take me to the studio</SubmitButton>

      <p className="auth__fine">
        Never taught online before? There is a{" "}
        <Link href="/studio/creator-course">short course on making a good one</Link> —
        entirely optional.
      </p>
    </form>
  );
}
