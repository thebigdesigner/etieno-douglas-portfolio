"use client";

import { useEffect, useRef, useState } from "react";
import { createPortal } from "react-dom";

type Kind = "error" | "success" | "warning" | "info";

const DEFAULT_TITLE: Record<Kind, string> = {
  error: "That did not work",
  success: "Done",
  warning: "Worth checking",
  info: "For your information",
};

const GLYPH: Record<Kind, string> = {
  error: "✕",
  success: "✓",
  warning: "!",
  info: "i",
};

/** Errors get longer, because they usually have to be read and acted on. */
const LIFETIME: Record<Kind, number> = {
  error: 8000,
  success: 4000,
  warning: 7000,
  info: 5000,
};

/**
 * Toasts stack in one fixed column. Every call site renders its own
 * <Alert> inline, so without a shared container they would all sit at the
 * same fixed coordinates and cover each other. This portals them into a
 * single list instead, created on first use.
 */
function toastRoot(): HTMLElement | null {
  if (typeof document === "undefined") return null;
  let el = document.getElementById("splari-toasts");
  if (!el) {
    el = document.createElement("div");
    el.id = "splari-toasts";
    el.className = "toasts";
    el.setAttribute("aria-live", "polite");
    document.body.appendChild(el);
  }
  return el;
}

export default function Alert({
  kind = "error",
  title,
  children,
  className = "",
}: {
  kind?: Kind;
  title?: string;
  children: React.ReactNode;
  /** Kept for call-site compatibility; toasts do not take layout classes. */
  dismissible?: boolean;
  className?: string;
}) {
  const [open, setOpen] = useState(true);
  const [leaving, setLeaving] = useState(false);
  const [root, setRoot] = useState<HTMLElement | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  // A new message on an already-mounted Alert must restart the clock,
  // otherwise the second error never shows — the timer already fired.
  const signature = typeof children === "string" ? children : String(children);

  useEffect(() => { setRoot(toastRoot()); }, []);

  useEffect(() => {
    function close() {
      setLeaving(true);
      setTimeout(() => setOpen(false), 180);
    }
    setOpen(true);
    setLeaving(false);
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(close, LIFETIME[kind]);
    return () => { if (timer.current) clearTimeout(timer.current); };
  }, [signature, kind]);

  if (!open || !root) return null;

  function dismiss() {
    setLeaving(true);
    setTimeout(() => setOpen(false), 180);
  }

  return createPortal(
    <div
      className={`toast toast--${kind}${leaving ? " is-out" : ""} ${className}`.trim()}
      role={kind === "error" ? "alert" : "status"}
      // Hovering pauses the countdown. A message that vanishes while it is
      // being read is worse than one that lingers.
      onMouseEnter={() => { if (timer.current) clearTimeout(timer.current); }}
      onMouseLeave={() => {
        if (timer.current) clearTimeout(timer.current);
        timer.current = setTimeout(dismiss, LIFETIME[kind]);
      }}
    >
      <span className="toast__ico" aria-hidden="true">{GLYPH[kind]}</span>
      <span className="toast__b">
        <span className="toast__t">{title ?? DEFAULT_TITLE[kind]}</span>
        <span className="toast__m">{children}</span>
      </span>
      <button className="toast__x" onClick={dismiss} aria-label="Dismiss">✕</button>
      <span className="toast__bar" style={{ animationDuration: `${LIFETIME[kind]}ms` }} />
    </div>,
    root
  );
}
