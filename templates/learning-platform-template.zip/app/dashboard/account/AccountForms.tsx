"use client";

import { useActionState, useState } from "react";
import { profileProgress } from "@/lib/profile-progress";
import Link from "next/link";
import {
  updateProfile, changePassword, claimEmail, exportMyData, requestDeletion,
  uploadAvatar, removeAvatar, setPurchaseVisibility } from "@/app/actions/account";
import type { FormState } from "@/lib/forms";
import SubmitButton from "@/components/SubmitButton";
import Avatar from "@/components/Avatar";
import FileDrop from "@/components/FileDrop";
import Alert from "@/components/Alert";

const initial: FormState = {};

const ROLE_LABEL: Record<string, string> = {
  learner: "Learner",
  instructor: "Instructor",
  institution_admin: "Institution admin",
  operator: "Your Brand staff",
};

export default function AccountForms({
  displayName, email, accountType, subscribed,
  avatarPath, role, memberSince, certificates, enrolments, showPurchases,
}: {
  displayName: string; email: string | null;
  accountType: string; subscribed: boolean;
  avatarPath: string | null; role: string;
  memberSince: string | null; certificates: number; enrolments: number;
  showPurchases: boolean;
}) {
  const [profileState, saveProfile] = useActionState(updateProfile, initial);
  const [pwState, savePassword] = useActionState(changePassword, initial);
  const [emailState, saveEmail] = useActionState(claimEmail, initial);
  const [delState, doDelete] = useActionState(requestDeletion, initial);
  const [avatarState, saveAvatar] = useActionState(uploadAvatar, initial);
  const [buyerState, saveBuyerVisibility] = useActionState(setPurchaseVisibility, initial);

  const [editInfo, setEditInfo] = useState(false);
  const [editPw, setEditPw] = useState(false);
  const [showDelete, setShowDelete] = useState(false);
  const [exporting, setExporting] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);
  const [picErr, setPicErr] = useState<string | null>(null);

  async function runExport() {
    setExporting(true);
    const result = await exportMyData();
    setExporting(false);
    if (!result.ok || !result.message) return;

    const url = URL.createObjectURL(new Blob([result.message], { type: "application/json" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = "splari-my-data.json";
    a.click();
    URL.revokeObjectURL(url);
  }

  // The checklist is computed from what is actually true of the account,
  // never hand-set — a checklist that can drift from reality is decoration.
  // Shared with the dashboard card, so the two cannot drift apart.
  const { steps, pct: complete } = profileProgress({
    displayName, email, avatarPath, enrolments, subscribed, certificates,
  });

  return (
    <>
      <div className="dash__bar">
        <div>
          <div className="eyebrow">Account</div>
          <h1 className="dash__title">Edit profile</h1>
        </div>
      </div>

      <div className="pan">
        <div className="pan__col">
          {/* Photo */}
          <div className="card">
            <div className="pav">
              {preview
                ? <img className="avatar" src={preview} alt="" style={{ width: 84, height: 84 }} />
                : <Avatar name={displayName} path={avatarPath} size={84} />}
              <div className="pav__body">
                <form action={saveAvatar}>
                  <FileDrop
                    name="avatar" preview
                    accept="image/jpeg,image/png,image/webp"
                    maxBytes={3 * 1024 * 1024}
                    hint="JPEG, PNG or WebP, up to 3MB. Square works best."
                    onError={setPicErr}
                  />
                  <div className="pav__row" style={{ marginTop: 12 }}>
                    <SubmitButton>Upload</SubmitButton>
                    {avatarPath && (
                      <button type="button" className="pav__rm"
                        onClick={() => { setPreview(null); removeAvatar(); }}>
                        Remove
                      </button>
                    )}
                  </div>
                </form>
                {picErr && <Alert kind="error">{picErr}</Alert>}
                {avatarState.error && <Alert kind="error">{avatarState.error}</Alert>}
                {avatarState.ok && <Alert kind="success">{avatarState.message}</Alert>}
              </div>
            </div>
          </div>

          {/* Personal info */}
          <div className="card">
            <div className="card__head">
              <div className="card__h">Personal info</div>
              <button className="pcard__edit" onClick={() => setEditInfo(!editInfo)}>
                {editInfo ? "Cancel" : "Edit"}
              </button>
            </div>

            {!editInfo ? (
              <div className="pgrid">
                <div>
                  <div className="pgrid__k">Full name</div>
                  <div className="pgrid__v">{displayName || "—"}</div>
                </div>
                <div>
                  <div className="pgrid__k">Email</div>
                  <div className="pgrid__v">{email ?? "None yet"}</div>
                </div>
                <div>
                  <div className="pgrid__k">Role</div>
                  <div className="pgrid__v">{ROLE_LABEL[role] ?? role}</div>
                </div>
                <div>
                  <div className="pgrid__k">Member since</div>
                  <div className="pgrid__v">
                    {memberSince
                      ? new Date(memberSince).toLocaleDateString(undefined, { month: "long", year: "numeric" })
                      : "—"}
                  </div>
                </div>
              </div>
            ) : (
              <form action={saveProfile} className="auth__form" style={{ maxWidth: 460 }}>
                <label className="field">
                  <span className="field__label">Name</span>
                  <input name="display_name" defaultValue={displayName} required />
                  <span className="field__hint">
                    This is the name that goes on a certificate. Certificates already
                    issued keep the name they were signed with.
                  </span>
                </label>
                {profileState.error && <Alert kind="error">{profileState.error}</Alert>}
                {profileState.ok && <Alert kind="success">{profileState.message}</Alert>}
                <SubmitButton>Save changes</SubmitButton>
              </form>
            )}
          </div>

          {/* Sign-in */}
          {email === null ? (
            <div className="card">
              <div className="card__head"><div className="card__h">Add an email address</div></div>
              <p className="studio__hint" style={{ marginTop: 0 }}>
                You joined through your school with a username and PIN. Adding an email
                lets you keep your certificates after the class ends.
              </p>
              <form action={saveEmail} className="auth__form" style={{ maxWidth: 420, marginTop: 14 }}>
                <label className="field">
                  <span className="field__label">Email</span>
                  <input name="email" type="email" required />
                </label>
                {emailState.error && <Alert kind="error">{emailState.error}</Alert>}
                {emailState.ok && <Alert kind="success">{emailState.message}</Alert>}
                <SubmitButton>Add it</SubmitButton>
              </form>
            </div>
          ) : (
            <div className="card">
              <div className="card__head">
                <div className="card__h">Password</div>
                <button className="pcard__edit" onClick={() => setEditPw(!editPw)}>
                  {editPw ? "Cancel" : "Change"}
                </button>
              </div>
              {!editPw ? (
                <div className="pgrid">
                  <div>
                    <div className="pgrid__k">Sign-in email</div>
                    <div className="pgrid__v">{email}</div>
                  </div>
                  <div>
                    <div className="pgrid__k">Password</div>
                    <div className="pgrid__v">••••••••</div>
                  </div>
                </div>
              ) : (
                <form action={savePassword} className="auth__form" style={{ maxWidth: 420 }}>
                  <label className="field">
                    <span className="field__label">New password</span>
                    <input name="password" type="password" autoComplete="new-password" minLength={8} required />
                  </label>
                  <label className="field">
                    <span className="field__label">Type it again</span>
                    <input name="confirm" type="password" autoComplete="new-password" minLength={8} required />
                  </label>
                  {pwState.error && <Alert kind="error">{pwState.error}</Alert>}
                  {pwState.ok && <Alert kind="success">{pwState.message}</Alert>}
                  <SubmitButton>Change password</SubmitButton>
                </form>
              )}
            </div>
          )}

          {/* Billing. There is nothing recurring to show — a course is
              bought once — so this says what it is rather than pretending
              to be a subscription panel with nothing in it. */}
          <div className="card">
            <div className="card__head"><div className="card__h">Billing</div></div>
            <div className="acct__row" style={{ marginTop: 0 }}>
              <div>
                <div className="acct__k">{subscribed ? "Nothing recurring" : "No purchases yet"}</div>
                <p className="acct__v">
                  {subscribed
                    ? "Courses you have bought stay yours. There is no renewal date and nothing to cancel."
                    : "The first module of each course is free. Buying a course opens the rest and includes the assessment of your project."}
                </p>
              </div>
              <Link className="btn btn--fill" href={subscribed ? "/dashboard/courses" : "/courses"}>
                {subscribed ? "My courses" : "Browse courses"}
              </Link>
            </div>
          </div>

          {/* Data + deletion */}
          <div className="card">
            <div className="card__head"><div className="card__h">Your data</div></div>
            <div className="acct__row" style={{ marginTop: 0 }}>
              <div>
                <div className="acct__k">Take a copy</div>
                <p className="acct__v">
                  Everything we hold about you — progress, submissions, certificates — as a file.
                </p>
              </div>
              <button className="btn btn--line" onClick={runExport} disabled={exporting}>
                {exporting ? "Preparing…" : "Download"}
              </button>
            </div>

            {/*
              Buying something is not publishing it. This is on by default
              because initials alone, on an item several people own, say
              very little — but it is a disclosure, so it has to be
              findable and switchable, and turning it off is retroactive.
            */}
            <form action={saveBuyerVisibility} className="acct__row">
              <div>
                <div className="acct__k">Show my initials on things I buy</div>
                <p className="acct__v">
                  Marketplace items can show the initials of a few recent buyers. Never your name, never a
                  link, and never on an item only a couple of people own. Turn this off and you are left out
                  of it entirely, including things you have already bought.
                </p>
                {buyerState.error && <Alert kind="error">{buyerState.error}</Alert>}
                {buyerState.ok && buyerState.message && <Alert kind="success">{buyerState.message}</Alert>}
              </div>
              <label className="acct__switch">
                <input type="checkbox" name="show_purchases" defaultChecked={showPurchases} />
                <SubmitButton>Save</SubmitButton>
              </label>
            </form>

            <div className="acct__danger">
              <div className="acct__k">Delete your account</div>
              <p className="acct__v">
                This locks the account immediately and withdraws any certificates you have
                earned, so their public pages stop working. We finish the erasure within 30
                days. It cannot be undone.
              </p>

              {delState.ok ? (
                <Alert kind="success">{delState.message}</Alert>
              ) : !showDelete ? (
                <button className="btn btn--line" style={{ marginTop: 14 }} onClick={() => setShowDelete(true)}>
                  Delete my account
                </button>
              ) : (
                <form action={doDelete} className="auth__form" style={{ maxWidth: 380, marginTop: 16 }}>
                  <label className="field">
                    <span className="field__label">Type DELETE to confirm</span>
                    <input name="confirm" required autoComplete="off" />
                  </label>
                  {delState.error && <Alert kind="error">{delState.error}</Alert>}
                  <div className="appeal__btns">
                    <SubmitButton>Delete permanently</SubmitButton>
                    <button type="button" className="btn btn--line" onClick={() => setShowDelete(false)}>
                      Keep my account
                    </button>
                  </div>
                </form>
              )}
            </div>
          </div>

          <p className="studio__hint">Account type: {accountType}</p>
        </div>

        {/* Right column — completion, like the reference */}
        <div className="pan__col">
          <div className="card">
            <div className="card__head"><div className="card__h">Complete your profile</div></div>
            <div className="donut" style={{ "--pct": complete } as React.CSSProperties}>
              <span className="donut__ring" aria-hidden="true" />
              <span className="donut__n num">{complete}%</span>
            </div>
            <ul className="plist">
              {steps.map((s) => (
                <li key={s.label} className={s.done ? "is-done" : ""}>
                  <span className="plist__mark" aria-hidden="true">{s.done ? "✓" : "✕"}</span>
                  <span className="plist__t">{s.label}</span>
                  <span className={`plist__pct num${s.done ? "" : " is-todo"}`}>
                    {s.done ? `${s.pct}%` : `+${s.pct}%`}
                  </span>
                </li>
              ))}
            </ul>
          </div>

          <div className="card card--tint">
            <div className="card__h">Why the name matters</div>
            <p className="card__meta" style={{ marginTop: 8, lineHeight: 1.6 }}>
              Your name here is the name a practitioner signs on your certificate.
              Set it the way you want an employer to read it.
            </p>
          </div>
        </div>
      </div>
    </>
  );
}
