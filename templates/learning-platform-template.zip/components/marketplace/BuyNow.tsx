"use client";

import { useState, useTransition } from "react";
import { claimFreeItem, startMarketplaceCheckout } from "@/app/actions/marketplace-checkout";
import MkIcon from "@/components/marketplace/MkIcon";

/**
 * Buy this one item, or claim it if it is free. Reads the licence from the
 * radio group it sits inside, so the form stays server-rendered.
 * Prices are re-read on the server; nothing here is trusted.
 */
export default function BuyNow({ slug, free, libraryHref }: { slug: string; free: boolean; libraryHref: string }) {
  const [pending, start] = useTransition();
  const [error, setError] = useState<string | null>(null);

  const go = (e: React.MouseEvent<HTMLButtonElement>) => {
    const form = e.currentTarget.form;
    const picked = form?.querySelector<HTMLInputElement>('input[name="licence"]:checked')?.value;
    const provider = form?.querySelector<HTMLInputElement>('input[name="provider"]:checked')?.value
      ?? form?.querySelector<HTMLInputElement>('input[name="provider"]')?.value;
    const licence = picked === "commercial" ? "commercial" : "personal";
    start(async () => {
      setError(null);
      if (free) {
        const res = await claimFreeItem(slug);
        if ("error" in res) { setError(res.error); return; }
        window.location.href = `/api/marketplace/download?item=${encodeURIComponent(slug)}`;
        return;
      }
      const res = await startMarketplaceCheckout([{ slug, licence }], provider);
      if ("error" in res) { setError(res.error); return; }
      window.location.href = "url" in res ? res.url : libraryHref;
    });
  };

  return (
    <>
      <button type="button" className="mk-btn mk-btn--fill mk-btn--wide" onClick={go} disabled={pending}>
        <MkIcon name={free ? "download" : "bag"} size={18} />
        {pending ? (free ? "Preparing…" : "Opening checkout…") : free ? "Download" : "Buy licence"}
      </button>
      {error && <p className="mk-buy__note" role="alert">{error}</p>}
    </>
  );
}
