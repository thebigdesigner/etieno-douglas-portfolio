/**
 * One call site for the assistant's model, so switching provider is an
 * environment change rather than a code change.
 *
 * Gemini wins when GEMINI_API_KEY is set, because it is the one with a
 * genuine free tier. Anthropic is used when only ANTHROPIC_API_KEY is set.
 * Neither set means the assistant reports itself unconfigured, which the
 * route already handles.
 *
 * Model IDs on Google's free tier move often — models get added, renamed
 * and dropped from the free row without much notice. So the id is an env
 * var with a default, and a rename costs a redeploy rather than a patch.
 */

export type Turn = { role: "user" | "assistant"; content: string };

export type AskResult = { text: string; outputTokens: number | null };

export function configuredProvider(): "gemini" | "anthropic" | null {
  if (process.env.GEMINI_API_KEY) return "gemini";
  if (process.env.ANTHROPIC_API_KEY) return "anthropic";
  return null;
}

export async function askModel(
  { system, history, question, maxTokens = 600 }:
  { system: string; history: Turn[]; question: string; maxTokens?: number }
): Promise<AskResult> {
  const provider = configuredProvider();
  if (provider === "gemini") return askGemini({ system, history, question, maxTokens });
  if (provider === "anthropic") return askAnthropic({ system, history, question, maxTokens });
  throw new Error("No model provider configured");
}

/* ------------------------------------------------------------------ */
/* Google Gemini                                                       */
/* ------------------------------------------------------------------ */
async function askGemini(
  { system, history, question, maxTokens }:
  { system: string; history: Turn[]; question: string; maxTokens: number }
): Promise<AskResult> {
  const key = process.env.GEMINI_API_KEY!;
  const model = process.env.GEMINI_MODEL || "gemini-2.5-flash";

  // Gemini calls the assistant "model", and requires the conversation to
  // start with a user turn. A truncated history can begin mid-exchange, so
  // any leading assistant turns are dropped rather than sent and rejected.
  const turns = [...history];
  while (turns.length && turns[0].role === "assistant") turns.shift();

  const contents = [
    ...turns.map((t) => ({
      role: t.role === "assistant" ? "model" : "user",
      parts: [{ text: t.content }],
    })),
    { role: "user", parts: [{ text: question }] },
  ];

  const res = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`,
    {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-goog-api-key": key },
      body: JSON.stringify({
        system_instruction: { parts: [{ text: system }] },
        contents,
        generationConfig: { maxOutputTokens: maxTokens, temperature: 0.4 },
      }),
    }
  );

  if (!res.ok) {
    const detail = await res.text();
    console.error("gemini upstream", res.status, detail);
    // 429 on the free tier means the daily or per-minute quota is spent —
    // worth distinguishing, because it is not a fault, just a limit.
    throw Object.assign(new Error("gemini failed"), { status: res.status });
  }

  const data = await res.json();
  const candidate = data.candidates?.[0];

  const text = (candidate?.content?.parts ?? [])
    .map((p: { text?: string }) => p.text ?? "")
    .join("")
    .trim();

  return { text, outputTokens: data.usageMetadata?.candidatesTokenCount ?? null };
}

/* ------------------------------------------------------------------ */
/* Anthropic                                                           */
/* ------------------------------------------------------------------ */
async function askAnthropic(
  { system, history, question, maxTokens }:
  { system: string; history: Turn[]; question: string; maxTokens: number }
): Promise<AskResult> {
  const key = process.env.ANTHROPIC_API_KEY!;
  const model = process.env.ANTHROPIC_MODEL || "claude-haiku-4-5-20251001";

  const res = await fetch("https://api.anthropic.com/v1/messages", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "x-api-key": key,
      "anthropic-version": "2023-06-01",
    },
    body: JSON.stringify({
      model,
      max_tokens: maxTokens,
      system,
      messages: [...history, { role: "user", content: question }],
    }),
  });

  if (!res.ok) {
    console.error("anthropic upstream", res.status, await res.text());
    throw Object.assign(new Error("anthropic failed"), { status: res.status });
  }

  const data = await res.json();
  const text = (data.content ?? [])
    .filter((b: { type: string }) => b.type === "text")
    .map((b: { text: string }) => b.text)
    .join("\n")
    .trim();

  return { text, outputTokens: data.usage?.output_tokens ?? null };
}
