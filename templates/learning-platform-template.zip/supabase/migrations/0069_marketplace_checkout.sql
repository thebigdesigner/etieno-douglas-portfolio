-- =====================================================================
-- Marketplace checkout: paying for items, and the wallet credit that
-- follows. Orders are written before the buyer leaves for the payment
-- page (status 'pending'), then settled here once the payment verifies.
-- =====================================================================

-- 0063 allowed only course and licence intents, on purpose: an intent kind
-- nothing fulfils would take money and grant nothing. Marketplace carts
-- are a third kind, fulfilled by mk_record_purchase below.
do $$ begin
  if exists (select 1 from pg_constraint where conname = 'checkout_intents_kind_shape') then
    alter table checkout_intents drop constraint checkout_intents_kind_shape;
  end if;
  alter table checkout_intents add constraint checkout_intents_kind_shape
    check (
      (kind = 'courses'     and plan is null and cardinality(course_ids) > 0) or
      (kind = 'licences'    and plan is null and cardinality(course_ids) > 0
                            and institution_id is not null) or
      (kind = 'marketplace' and plan is null) or
      (kind = 'plan'        and completed_at is not null)
    ) not valid;
end $$;

-- Downloads of free items have no order.
alter table mk_downloads alter column order_id drop not null;

-- One pending order per item per checkout; a retry writes a new tx_ref.
create index if not exists mk_orders_tx_idx on mk_orders (tx_ref);

-- ---------------------------------------------------------------------
-- Settle a paid marketplace cart.
--
-- Idempotent twice over: only 'pending' rows are touched, and the wallet
-- credit itself is unique per order. Payment webhooks retry, and the
-- return page fulfils as well, so this will be called more than once for
-- the same cart as a matter of course.
--
-- The caller has already verified the payment with the provider and
-- checked the amount against the intent; this function does not take
-- anyone's word for what was paid.
-- ---------------------------------------------------------------------
create or replace function mk_record_purchase(p_tx_ref text, p_hold_days integer default 7)
returns integer language plpgsql security definer set search_path = public as $$
declare
  v_order record;
  v_count integer := 0;
begin
  for v_order in
    select id, product_id from mk_orders where tx_ref = p_tx_ref and status = 'pending' for update
  loop
    update mk_orders set status = 'paid', paid_at = now() where id = v_order.id;
    perform mk_record_sale(v_order.id, p_hold_days);
    -- Inside the loop, which only sees rows that were still pending, so a
    -- webhook retry cannot inflate the count a listing shows.
    update mk_products set downloads = downloads + 1 where id = v_order.product_id;
    v_count := v_count + 1;
  end loop;

  return v_count;
end;
$$;

-- Free downloads have no order to settle, so they count themselves.
create or replace function mk_bump_downloads(p_product uuid)
returns void language sql security definer set search_path = public as $$
  update mk_products set downloads = downloads + 1 where id = p_product;
$$;
