-- =====================================================================
-- Sprint 2 — learning engine
-- =====================================================================

-- ---------------------------------------------------------------------
-- Published course content is world-readable. Drafts are not.
-- ---------------------------------------------------------------------
alter table modules    enable row level security;
alter table topics     enable row level security;
alter table quiz_items enable row level security;

create policy public_modules on modules for select using (
  exists (select 1 from courses c where c.id = modules.course_id and c.state = 'published')
);

create policy public_topics on topics for select using (
  exists (
    select 1 from modules m join courses c on c.id = m.course_id
     where m.id = topics.module_id and c.state = 'published'
  )
);

-- Quiz prompts are readable; the answer key is never selected client-side.
-- Grading runs server-side with the service role.
create policy public_quiz_items on quiz_items for select using (
  exists (
    select 1 from topics t join modules m on m.id = t.module_id
      join courses c on c.id = m.course_id
     where t.id = quiz_items.topic_id and c.state = 'published'
  )
);

create policy own_topic_completions on topic_completions for select using (
  exists (select 1 from enrolments e
           where e.id = topic_completions.enrolment_id and e.user_id = auth.uid())
);

create policy own_quiz_attempts on quiz_attempts for select using (
  exists (select 1 from enrolments e
           where e.id = quiz_attempts.enrolment_id and e.user_id = auth.uid())
);

-- ---------------------------------------------------------------------
-- Ordered topic list for a course, with the gate state resolved.
-- A topic unlocks when the previous topic's quiz has been passed.
-- ---------------------------------------------------------------------
create or replace function public.course_outline(p_course_id uuid, p_user_id uuid)
returns table (
  topic_id     uuid,
  module_title text,
  topic_title  text,
  pos          int,
  is_free      boolean,
  has_quiz     boolean,
  completed    boolean,
  unlocked     boolean
)
language sql
stable
security definer set search_path = public
as $$
  with ordered as (
    select t.id,
           m.title as module_title,
           t.title as topic_title,
           row_number() over (order by m.position, t.position)::int as pos,
           t.is_free,
           exists (select 1 from quiz_items q where q.topic_id = t.id) as has_quiz
      from topics t
      join modules m on m.id = t.module_id
     where m.course_id = p_course_id
  ),
  done as (
    select tc.topic_id
      from topic_completions tc
      join enrolments e on e.id = tc.enrolment_id
     where e.user_id = p_user_id and e.course_id = p_course_id
  )
  select o.id,
         o.module_title,
         o.topic_title,
         o.pos,
         o.is_free,
         o.has_quiz,
         (o.id in (select topic_id from done)) as completed,
         (
           o.pos = 1
           or o.is_free
           or (select count(*) from ordered o2
                where o2.pos < o.pos
                  and o2.id not in (select topic_id from done)) = 0
         ) as unlocked
    from ordered o
   order by o.pos;
$$;

-- ---------------------------------------------------------------------
-- Cooldown: two consecutive failures locks retakes for 30 minutes.
-- Stops brute-forcing a four-option quiz.
-- ---------------------------------------------------------------------
create or replace function public.quiz_cooldown_until(p_enrolment_id uuid, p_topic_id uuid)
returns timestamptz
language sql
stable
security definer set search_path = public
as $$
  select case
    when count(*) filter (where not passed) = 2 then max(attempted_at) + interval '30 minutes'
    else null
  end
  from (
    select passed, attempted_at
      from quiz_attempts
     where enrolment_id = p_enrolment_id and topic_id = p_topic_id
     order by attempted_at desc
     limit 2
  ) recent;
$$;

-- ---------------------------------------------------------------------
-- Seed: one published course so there is something to click through.
-- Delete this block before launch.
-- ---------------------------------------------------------------------
do $$
declare
  c_id uuid;
  m1   uuid;
  m2   uuid;
  t1   uuid; t2 uuid; t3 uuid; t4 uuid;
begin
  if exists (select 1 from courses where slug = 'reading-a-set-of-accounts') then
    return;
  end if;

  insert into courses (slug, title, summary, subject, segment, project_brief, state, published_at)
  values (
    'reading-a-set-of-accounts',
    'Reading a set of accounts',
    'Open a profit and loss statement, a balance sheet and a cash flow statement and know what you are looking at — and what to be suspicious of.',
    'Business Skills',
    'Business Owners',
    'Take the three statements provided for a small retail business and write a one-page assessment for its owner: what the numbers say about the health of the business, the two things you would investigate first, and one decision you would change.',
    'published',
    now()
  ) returning id into c_id;

  insert into modules (course_id, position, title)
  values (c_id, 1, 'What the statements are') returning id into m1;
  insert into modules (course_id, position, title)
  values (c_id, 2, 'Reading them together') returning id into m2;

  insert into topics (module_id, position, title, body, is_free) values
  (m1, 1, 'Why three statements, not one',
   E'A business can be profitable and still run out of money. It can hold valuable assets and still be unable to pay a supplier on Friday.\n\nThat is why there are three statements rather than one. Each answers a different question.\n\n**The profit and loss statement** asks: over a period of time, did we make more than we spent? It covers a span — a month, a quarter, a year.\n\n**The balance sheet** asks: at one moment, what do we own and what do we owe? It is a photograph, not a film. It is always dated "as at" a particular day.\n\n**The cash flow statement** asks: over that same period, what actually moved in and out of the bank?\n\nThe gap between the first and the third is where most small businesses get into trouble. A sale recorded in March that is paid in June appears as profit in March and as cash in June. A business growing quickly can show rising profit and falling cash at the same time, and the profit statement alone will not warn you.',
   true) returning id into t1;

  insert into topics (module_id, position, title, body) values
  (m1, 2, 'The profit and loss statement, line by line',
   E'Read it top to bottom, because the order tells a story.\n\n**Revenue** is what you sold, not what you were paid.\n\n**Cost of sales** is what those specific sales cost you — materials, the goods themselves, direct labour. Subtract it and you have **gross profit**. This is the number that tells you whether the thing you sell makes money at all. If gross margin is thin, no amount of cost-cutting elsewhere will save the business.\n\n**Operating expenses** are the costs of being open regardless of what you sold — rent, salaries, software, insurance. Subtract these and you have **operating profit**, which tells you whether the business as a whole works.\n\nBelow that sit interest and tax, and finally **net profit**.\n\nThe useful habit is to read each line as a percentage of revenue rather than an amount. A business whose gross margin falls from 40% to 32% over a year has a serious problem, even if revenue grew and net profit looks similar.')
  returning id into t2;

  insert into topics (module_id, position, title, body) values
  (m2, 1, 'What the balance sheet is really telling you',
   E'Assets equal liabilities plus equity. That always balances, which is why the statement is named as it is — and why balancing proves nothing about health.\n\nWhat matters is the composition.\n\n**Current assets** are things that become cash within a year: the bank balance, money owed to you, stock on the shelf. **Current liabilities** are what you owe within a year. If current liabilities exceed current assets, the business cannot meet its obligations from what it holds, and something has to give.\n\nTwo lines deserve suspicion whenever they grow faster than revenue.\n\n**Receivables** growing faster than sales means you are selling to people who are not paying. Revenue looks fine; the bank does not.\n\n**Inventory** growing faster than sales means you are buying stock you cannot sell. Cash has turned into things on a shelf.\n\nNeither shows up as a problem on the profit statement. Both show up here first.')
  returning id into t3;

  insert into topics (module_id, position, title, body) values
  (m2, 2, 'Three questions to ask of any set of accounts',
   E'You do not need ratios to start. You need three questions.\n\n**Is the gap between profit and cash getting wider?** Compare net profit to cash generated from operations across two or three periods. A widening gap means profit is being recorded but not collected. This is the single most common way a growing business fails.\n\n**What is the trend in gross margin?** Not the level — the trend. Falling gross margin means either your costs are rising or you are discounting, and both need a decision.\n\n**Can it survive a slow month?** Cash in the bank divided by monthly operating expenses gives you the number of months the business can continue if revenue stopped. Under three is uncomfortable. Under one is an emergency.\n\nEverything else in financial analysis is elaboration on these three.')
  returning id into t4;

  insert into quiz_items (topic_id, prompt, options, correct, explanation) values
  (t2,
   'Gross margin has fallen from 40% to 32% while revenue grew 15%. What does this most likely indicate?',
   '[{"id":"a","text":"The business is performing well because revenue grew"},
     {"id":"b","text":"Either input costs rose or prices were discounted to win sales"},
     {"id":"c","text":"Operating expenses are too high"},
     {"id":"d","text":"The business has too much debt"}]'::jsonb,
   '["b"]'::jsonb,
   'Gross margin sits above operating expenses, so it is unaffected by rent or salaries. A fall means the cost of what you sell rose, or you sold it for less.'),

  (t2,
   'Which of these appears in cost of sales rather than operating expenses?',
   '[{"id":"a","text":"Office rent"},
     {"id":"b","text":"The accounting software subscription"},
     {"id":"c","text":"Materials used to make the products sold"},
     {"id":"d","text":"The bookkeeper''s salary"}]'::jsonb,
   '["c"]'::jsonb,
   'Cost of sales covers costs tied directly to the specific goods sold. The rest are costs of being open regardless of sales.'),

  (t3,
   'Receivables grew 60% while revenue grew 10%. What should you investigate first?',
   '[{"id":"a","text":"Whether customers are paying on time"},
     {"id":"b","text":"Whether the business is overstaffed"},
     {"id":"c","text":"Whether interest rates have risen"},
     {"id":"d","text":"Whether stock is priced correctly"}]'::jsonb,
   '["a"]'::jsonb,
   'Receivables are money owed to you. Growing far faster than sales means invoices are not being collected — profit is recorded but cash is not arriving.'),

  (t4,
   'A business shows rising net profit and falling cash. Which is the most likely explanation?',
   '[{"id":"a","text":"The accounts contain an error"},
     {"id":"b","text":"Sales are being made but not collected, or cash is tied up in stock"},
     {"id":"c","text":"The business is paying too much tax"},
     {"id":"d","text":"Depreciation has been calculated incorrectly"}]'::jsonb,
   '["b"]'::jsonb,
   'Profit is recorded when a sale is made; cash moves when it is paid. A widening gap points to uncollected invoices or inventory build-up.'),

  (t4,
   'Cash in the bank is 45,000 and monthly operating expenses are 30,000. How would you describe the position?',
   '[{"id":"a","text":"Comfortable — well over a year of cover"},
     {"id":"b","text":"About six months of cover, which is adequate"},
     {"id":"c","text":"Around 1.5 months of cover, which is uncomfortably thin"},
     {"id":"d","text":"Cannot be assessed without the profit statement"}]'::jsonb,
   '["c"]'::jsonb,
   '45,000 divided by 30,000 is 1.5 months. Under three months is uncomfortable; this leaves very little room if revenue slows.');

  insert into rubric_criteria (course_id, position, title, descriptor, max_score) values
  (c_id, 1, 'Reads the statements correctly',
   'Identifies what each statement shows and draws accurate conclusions from the figures given, without misreading a line or confusing profit with cash.', 5),
  (c_id, 2, 'Identifies the right priorities',
   'The two items chosen for investigation are the ones that most affect the health of this business, with a reason given for each.', 5),
  (c_id, 3, 'Written for the owner, not an accountant',
   'Plain language, no unexplained jargon, and a clear recommendation the owner could act on this week.', 5);
end $$;
