"use server";

import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import type { FormState } from "@/lib/forms";

/**
 * Leaving, editing and removing a review.
 *
 * The writes go through the *user's* client, not the admin one, so the
 * row-level policy from 0073 is what decides whether this person owns
 * the item. Checking ownership here as well and then writing as admin
 * would move the rule into application code, where a future caller can
 * forget it.
 */

function ratingOf(fd: FormData): number | null {
  const n = Number(String(fd.get("rating") ?? ""));
  return Number.isInteger(n) && n >= 1 && n <= 5 ? n : null;
}

async function slugOf(productId: string): Promise<string | null> {
  const { data } = await createAdminClient()
    .from("mk_products").select("slug").eq("id", productId).maybeSingle();
  return (data?.slug as string) ?? null;
}

export async function saveReview(_prev: FormState, fd: FormData): Promise<FormState> {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { error: "Sign in to leave a review." };

  const productId = String(fd.get("product_id") ?? "");
  if (!/^[0-9a-f-]{36}$/i.test(productId)) return { error: "That item does not exist." };

  const rating = ratingOf(fd);
  if (rating === null) return { error: "Choose a rating from one to five stars." };

  const raw = String(fd.get("body") ?? "").trim();
  if (raw.length > 1500) return { error: "Keep the review under 1,500 characters." };
  // A rating on its own is fine. An empty string is stored as nothing
  // rather than as a blank paragraph the item page would render.
  const body = raw.length ? raw : null;

  const { error } = await supabase
    .from("mk_reviews")
    .upsert({ product_id: productId, user_id: user.id, rating, body }, { onConflict: "product_id,user_id" });

  if (error) {
    // 42501 is the policy refusing: this person does not own the item.
    if (error.code === "42501") return { error: "You can review an item once you own it." };
    console.error("reviews: save", error.message);
    return { error: "Could not save your review. Try again." };
  }

  const slug = await slugOf(productId);
  if (slug) revalidatePath(`/marketplace/item/${slug}`);
  revalidatePath("/marketplace/library");
  return { ok: true, message: "Thank you — your review is on the item page." };
}

export async function removeReview(_prev: FormState, fd: FormData): Promise<FormState> {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { error: "Sign in first." };

  const productId = String(fd.get("product_id") ?? "");
  const { error } = await supabase.from("mk_reviews").delete()
    .eq("product_id", productId).eq("user_id", user.id);
  if (error) return { error: "Could not remove it. Try again." };

  const slug = await slugOf(productId);
  if (slug) revalidatePath(`/marketplace/item/${slug}`);
  return { ok: true, message: "Removed." };
}
