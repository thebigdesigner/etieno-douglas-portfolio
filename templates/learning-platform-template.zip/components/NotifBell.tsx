"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import NavIcon from "@/components/NavIcon";
import { markNotificationsSeen } from "@/app/actions/account";

export type Notif = {
  kind: string; title: string; body: string; at: string; href: string;
};

function ago(iso: string) {
  const mins = Math.round((Date.now() - new Date(iso).getTime()) / 60000);
  if (mins < 1) return "just now";
  if (mins < 60) return `${mins}m ago`;
  const h = Math.round(mins / 60);
  if (h < 24) return `${h}h ago`;
  const d = Math.round(h / 24);
  return d < 30 ? `${d}d ago` : new Date(iso).toLocaleDateString();
}

/**
 * The list is derived from real events — verdicts returned, certificates
 * issued, projects still with a reviewer. Nothing here is generated for
 * the sake of having something in the bell.
 */
export default function NotifBell({
  items, unread,
}: { items: Notif[]; unread: number }) {
  const [open, setOpen] = useState(false);
  const [dot, setDot] = useState(unread);
  const box = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (!open) return;
    function onDown(e: MouseEvent) {
      if (box.current && !box.current.contains(e.target as Node)) setOpen(false);
    }
    function onKey(e: KeyboardEvent) { if (e.key === "Escape") setOpen(false); }
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  function toggle() {
    const next = !open;
    setOpen(next);
    // Clear the dot as soon as it is opened, and record it server-side so
    // it stays cleared on the next page load.
    if (next && dot > 0) {
      setDot(0);
      void markNotificationsSeen();
    }
  }

  return (
    <div className="nbell" ref={box}>
      <button
        className="topbar__icon"
        onClick={toggle}
        aria-expanded={open}
        aria-label={dot > 0 ? `Notifications, ${dot} new` : "Notifications"}
      >
        <NavIcon name="bell" size={19} />
        {dot > 0 && <span className="nbell__dot num" aria-hidden="true">{dot > 9 ? "9+" : dot}</span>}
      </button>

      {open && (
        <div className="nbell__pop">
          <div className="nbell__head">Notifications</div>
          {items.length === 0 ? (
            <p className="nbell__empty">
              Nothing yet. Verdicts and certificates show up here.
            </p>
          ) : (
            items.map((n, i) => (
              <Link className="nbell__row" key={`${n.at}-${i}`} href={n.href} onClick={() => setOpen(false)}>
                <span className={`nbell__ico nbell__ico--${n.kind}`} aria-hidden="true">
                  <NavIcon
                    name={n.kind === "certificate" ? "award" : n.kind === "review" ? "inbox" : "clock"}
                    size={15}
                  />
                </span>
                <span className="nbell__body">
                  <span className="nbell__t">{n.title}</span>
                  <span className="nbell__s">{n.body}</span>
                </span>
                <span className="nbell__when">{ago(n.at)}</span>
              </Link>
            ))
          )}
        </div>
      )}
    </div>
  );
}
