"use client";

import { useActionState } from "react";
import { uploadThumbnail } from "@/app/actions/studio";
import type { FormState } from "@/lib/forms";
import SubmitButton from "@/components/SubmitButton";
import CourseThumb from "@/components/CourseThumb";
import FileDrop from "@/components/FileDrop";
import Alert from "@/components/Alert";

const initial: FormState = {};

export default function Thumbnail({
  courseId, slug, path, alt, subject, title, readonly,
}: {
  courseId: string; slug: string;
  path: string | null; alt: string | null;
  subject: string; title: string; readonly: boolean;
}) {
  const [state, action] = useActionState(
    uploadThumbnail.bind(null, courseId, slug), initial
  );

  return (
    <div className="thumbedit">
      <div className="thumbedit__preview">
        <CourseThumb path={path} title={title} subject={subject} />
      </div>

      {!readonly && (
        <form action={action} className="auth__form thumbedit__form">
          <div className="field">
            <span className="field__label">{path ? "Replace it" : "Upload one"}</span>
            <FileDrop
              name="thumbnail" required preview
              accept="image/jpeg,image/png,image/webp"
              maxBytes={5 * 1024 * 1024}
              hint="JPEG, PNG or WebP, up to 5MB. Landscape works best — roughly 16:9."
            />
          </div>
          <label className="field">
            <span className="field__label">What is in the image?</span>
            <input name="alt" defaultValue={alt ?? ""} required minLength={5}
              placeholder="A profit and loss statement on a desk" />
            <span className="field__hint">
              Screen readers and search both use this.
            </span>
          </label>
          {state.error && <Alert kind="error">{state.error}</Alert>}
          {state.ok && <Alert kind="success">{state.message}</Alert>}
          <SubmitButton>{path ? "Replace" : "Upload"}</SubmitButton>
        </form>
      )}
    </div>
  );
}
