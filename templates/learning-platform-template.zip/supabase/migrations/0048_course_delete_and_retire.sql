-- =====================================================================
-- 0048 — deleting a course, and the rule that was never written
--
-- 0032 fixed the structure of a published course in place and said, of
-- the course row itself:
--
--   "The course itself going means everything under it goes with it;
--    that is a course delete, not a structure edit, and it has its own
--    rule."
--
-- That rule was never written. Nothing in the product deletes a course,
-- so the gap has never been reached — but the protection is absent at
-- the level where it matters, and the cascade behind it is severe:
--
--   courses -> enrolments (cascade) -> certificates (cascade)
--
-- Deleting a published course would erase the certificates it issued.
-- Not revoke them, which is a recorded act with a reason attached and a
-- verify page that explains it — erase them, so the code on somebody's
-- CV resolves to nothing and no record survives that it ever existed.
-- The same cascade takes topic_completions with it, and the royalty
-- pool divides by completed topics, so it would also silently rewrite
-- what instructors earned in past months.
--
-- Two doors instead of one, matching how 0032/0033 handled topics:
--
--   delete   — only a draft nobody has touched. Nothing to lose.
--   retire   — a live course stops being sold and stops being listed,
--              and everything already issued stays exactly as it was.
--
-- The enum already carries 'unpublished' for the second, and 0019 has
-- owner_unpublish_course, which nothing ever called.
-- =====================================================================

-- ---------------------------------------------------------------------
-- The rule, at the level where it cannot be forgotten.
-- ---------------------------------------------------------------------
create or replace function public.refuse_unsafe_course_delete()
returns trigger
language plpgsql
as $$
declare
  v_enrolments int;
  v_certs      int;
begin
  if old.state not in ('draft', 'revision_requested') then
    raise exception 'course_not_draft'
      using hint = 'Only a draft can be deleted. Retire the course instead — that keeps every certificate it has already issued.';
  end if;

  select count(*) into v_enrolments from enrolments where course_id = old.id;

  select count(*) into v_certs
    from certificates c
    join enrolments e on e.id = c.enrolment_id
   where e.course_id = old.id;

  -- Belt and braces: a draft should not have either, but the cascade is
  -- destructive enough that it is worth asking rather than assuming.
  if v_certs > 0 then
    raise exception 'course_has_certificates'
      using hint = 'This course has issued certificates. It cannot be deleted at all — retire it.';
  end if;

  if v_enrolments > 0 then
    raise exception 'course_has_learners'
      using hint = 'Somebody has started this course. Retire it rather than deleting it.';
  end if;

  return old;
end;
$$;

drop trigger if exists refuse_unsafe_course_delete on courses;
create trigger refuse_unsafe_course_delete
  before delete on courses
  for each row execute function refuse_unsafe_course_delete();

-- ---------------------------------------------------------------------
-- Deleting a draft.
--
-- Returns a reason rather than raising, so the surface can say what
-- happened. The trigger above is still the thing that enforces it —
-- this is the polite door, not the lock.
-- ---------------------------------------------------------------------
create or replace function public.delete_draft_course(p_course_id uuid)
returns table (ok boolean, reason text)
language plpgsql security definer set search_path = public as $$
declare
  v_course courses%rowtype;
  v_count  int;
begin
  select * into v_course from courses where id = p_course_id;
  if not found then
    return query select false, 'no_course'; return;
  end if;

  if v_course.state not in ('draft','revision_requested') then
    return query select false, 'not_draft'; return;
  end if;

  select count(*) into v_count from enrolments where course_id = p_course_id;
  if v_count > 0 then return query select false, 'has_learners'; return; end if;

  select count(*) into v_count from course_purchases where course_id = p_course_id;
  if v_count > 0 then return query select false, 'has_purchases'; return; end if;

  select count(*) into v_count
    from institution_licences where course_id = p_course_id and refunded_at is null;
  if v_count > 0 then return query select false, 'has_licences'; return; end if;

  delete from courses where id = p_course_id;
  return query select true, null::text;
end; $$;

-- ---------------------------------------------------------------------
-- Retiring a live one.
--
-- 'unpublished' already drops the course out of course_cards, search
-- and the public page, all of which filter on state = 'published'. The
-- people part-way through keep their enrolment and their certificate;
-- nothing is deleted, which is the whole point.
-- ---------------------------------------------------------------------
create or replace function public.retire_course(p_course_id uuid, p_actor uuid)
returns table (ok boolean, reason text)
language plpgsql security definer set search_path = public as $$
declare
  v_state course_state;
begin
  select state into v_state from courses where id = p_course_id;
  if v_state is null then return query select false, 'no_course'; return; end if;

  if v_state = 'unpublished' then
    return query select false, 'already_retired'; return;
  end if;
  if v_state <> 'published' then
    return query select false, 'not_published'; return;
  end if;

  update courses set state = 'unpublished' where id = p_course_id;

  -- Cart rows for a course nobody can buy any more would fail at
  -- checkout with nothing to explain why.
  delete from cart_items where course_id = p_course_id;

  perform log_admin_action(p_actor, 'retire_course', 'course', p_course_id::text,
                           'Retired from a studio surface', null);
  return query select true, null::text;
end; $$;

revoke all on function public.delete_draft_course(uuid) from public, anon, authenticated;
revoke all on function public.retire_course(uuid, uuid) from public, anon, authenticated;
grant execute on function public.delete_draft_course(uuid) to service_role;
grant execute on function public.retire_course(uuid, uuid) to service_role;
