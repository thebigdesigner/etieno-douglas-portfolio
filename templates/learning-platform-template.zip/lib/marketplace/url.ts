import { headers } from "next/headers";
import { isMarketplaceHost } from "./href";

/**
 * Where the marketplace lives in the URL.
 *
 * The same deployment answers on yourbrand.com and marketplace.yourbrand.com.
 * middleware.ts rewrites the subdomain onto /marketplace, so on the
 * subdomain a page at app/marketplace/fonts is reached as /fonts and every
 * link has to be written without the prefix. On the main domain (and on
 * localhost) it is reached as /marketplace/fonts, prefix included.
 *
 * Links are built from this base rather than hardcoded either way, because
 * a hardcoded /marketplace on the subdomain becomes /marketplace/marketplace
 * after the rewrite.
 */
export async function marketBase(): Promise<string> {
  const h = await headers();
  const host = h.get("x-forwarded-host") ?? h.get("host");
  return isMarketplaceHost(host) ? "" : "/marketplace";
}

export { mk, isMarketplaceHost } from "./href";
