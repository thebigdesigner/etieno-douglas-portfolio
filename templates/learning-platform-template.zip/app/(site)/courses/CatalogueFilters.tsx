"use client";

import { useEffect, useRef, useState, useTransition } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { SUBJECTS, LEVELS, LEVEL_LABEL } from "@/lib/subjects";
import SearchSuggest from "@/components/SearchSuggest";

type Option = { value: string | null; label: string };

/**
 * One dropdown. Closes on outside click and on Escape, and returns focus to
 * the button so keyboard use does not end up at the top of the document.
 */
function Picker({
  label, options, value, onPick,
}: {
  label: string;
  options: Option[];
  value: string | null;
  onPick: (v: string | null) => void;
}) {
  const [open, setOpen] = useState(false);
  const root = useRef<HTMLDivElement>(null);
  const btn = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!open) return;
    const away = (e: MouseEvent) => {
      if (root.current && !root.current.contains(e.target as Node)) setOpen(false);
    };
    const esc = (e: KeyboardEvent) => {
      if (e.key === "Escape") { setOpen(false); btn.current?.focus(); }
    };
    document.addEventListener("mousedown", away);
    document.addEventListener("keydown", esc);
    return () => {
      document.removeEventListener("mousedown", away);
      document.removeEventListener("keydown", esc);
    };
  }, [open]);

  const chosen = options.find((o) => o.value === value) ?? options[0];
  const set = value !== null;

  return (
    <div className="fsel" ref={root}>
      <button
        ref={btn}
        type="button"
        className={`fsel__btn${set ? " is-set" : ""}`}
        aria-expanded={open}
        aria-haspopup="listbox"
        onClick={() => setOpen((o) => !o)}
      >
        <span className="fsel__lbl">{label}</span>
        <span className="fsel__val">{chosen.label}</span>
        <svg className="fsel__chev" viewBox="0 0 20 20" fill="none" aria-hidden="true">
          <path d="M5.5 8L10 12.5L14.5 8" stroke="currentColor" strokeWidth="1.8"
            strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </button>

      {open && (
        <div className="fsel__pop" role="listbox" aria-label={label}>
          {options.map((o) => (
            <button
              key={o.label}
              type="button"
              role="option"
              aria-selected={o.value === value}
              className={`fsel__opt${o.value === value ? " is-on" : ""}`}
              onClick={() => { onPick(o.value); setOpen(false); btn.current?.focus(); }}
            >
              {o.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}

/**
 * Catalogue filters.
 *
 * These were three rows of chips in a sticky rail — eleven controls, all
 * visible at once, which on a narrow column wrapped into a wall that pushed
 * the first course card most of a screen down. Three dropdowns say the same
 * thing in one row and keep their height whatever is selected, so choosing a
 * subject no longer moves the results.
 *
 * Every change navigates inside a transition. The previous results stay on
 * screen, dimmed, while the new query runs, instead of the list emptying and
 * the page jumping to the top.
 */
export default function CatalogueFilters() {
  const router = useRouter();
  const params = useSearchParams();
  const [pending, startTransition] = useTransition();

  const subject = params.get("subject");
  const level = params.get("level");
  const free = params.get("free") === "1";

  function push(next: URLSearchParams) {
    const qs = next.toString();
    startTransition(() => router.push(qs ? `/courses?${qs}` : "/courses", { scroll: false }));
  }

  function set(key: string, value: string | null) {
    const next = new URLSearchParams(params.toString());
    if (value) next.set(key, value);
    else next.delete(key);
    push(next);
  }

  const active = [subject, level, free ? "1" : null].filter(Boolean).length;

  return (
    <div className="fbar" data-pending={pending ? "" : undefined}>
      <SearchSuggest
        className="csearch"
        placeholder="What do you want to learn?"
        defaultValue={params.get("q") ?? ""}
        onSubmitExtra={() => {
          const next = new URLSearchParams(params.toString());
          next.delete("q");
          return next;
        }}
      />

      <div className="fbar__row">
        <Picker
          label="Subject"
          value={subject}
          onPick={(v) => set("subject", v)}
          options={[
            { value: null, label: "Any subject" },
            ...SUBJECTS.map((s) => ({ value: s as string, label: s as string })),
          ]}
        />
        <Picker
          label="Level"
          value={level}
          onPick={(v) => set("level", v)}
          options={[
            { value: null, label: "Any level" },
            ...LEVELS.map((l) => ({ value: l as string, label: LEVEL_LABEL[l] })),
          ]}
        />
        <Picker
          label="Access"
          value={free ? "1" : null}
          onPick={(v) => set("free", v)}
          options={[
            { value: null, label: "All courses" },
            { value: "1", label: "Free courses" },
          ]}
        />

        {(active > 0 || params.get("q")) && (
          <button
            type="button"
            className="fbar__clear"
            onClick={() => startTransition(() => router.push("/courses", { scroll: false }))}
          >
            Clear
          </button>
        )}
      </div>
    </div>
  );
}
