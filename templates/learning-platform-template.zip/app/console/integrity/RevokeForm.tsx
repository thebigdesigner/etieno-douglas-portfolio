"use client";
import { useActionState } from "react";
import { revokeCertificate } from "@/app/actions/console";
import type { FormState } from "@/lib/forms";
import SubmitButton from "@/components/SubmitButton";
import Alert from "@/components/Alert";

const initial: FormState = {};

export default function RevokeForm() {
  const [state, action] = useActionState(revokeCertificate, initial);

  return (
    <form action={action} className="auth__form" style={{ maxWidth: 560, marginTop: 18 }}>
      <label className="field">
        <span className="field__label">Certificate code</span>
        <input name="code" placeholder="SPL-4K2M-90XB" required />
      </label>
      <label className="field">
        <span className="field__label">Reason</span>
        <textarea name="reason" rows={3} required minLength={10} />
        <span className="field__hint">
          Recorded against your name. If the holder asks why, this is the answer.
        </span>
      </label>
      {state.error && <Alert kind="error">{state.error}</Alert>}
      {state.ok && <Alert kind="success">{state.message}</Alert>}
      <SubmitButton>Revoke</SubmitButton>
    </form>
  );
}
