"use client";

import { useActionState, useState } from "react";
import { chooseIntent } from "@/app/actions/auth";
import type { FormState } from "@/lib/forms";
import SubmitButton from "@/components/SubmitButton";
import Alert from "@/components/Alert";

const initial: FormState = {};

const INTENTS = [
  {
    value: "learner",
    title: "I want to learn",
    detail: "Take courses and earn a certificate assessed by somebody who does the work.",
  },
  {
    value: "instructor",
    title: "I want to teach",
    detail: "Build a course, and assess the projects people submit against your rubric.",
  },
  {
    value: "institution",
    title: "I'm enrolling a group",
    detail: "A school, NGO or training provider putting a cohort of learners through.",
  },
];

export default function IntentPicker({ preset }: { preset: string | null }) {
  const [state, action] = useActionState(chooseIntent, initial);
  const [intent, setIntent] = useState(preset ?? "");

  return (
    <form action={action} className="auth__form">
      <fieldset className="intent">
        <legend className="sr">What brings you here?</legend>
        <div className="intent__opts">
          {INTENTS.map((i) => (
            <label key={i.value} className={`intent__o${intent === i.value ? " is-on" : ""}`}>
              <input
                type="radio" name="intent" value={i.value} required
                checked={intent === i.value}
                onChange={() => setIntent(i.value)}
              />
              <span>
                <strong>{i.title}</strong>
                <em>{i.detail}</em>
              </span>
            </label>
          ))}
        </div>
      </fieldset>

      {state.error && <Alert kind="error">{state.error}</Alert>}

      <SubmitButton>Continue</SubmitButton>
    </form>
  );
}
