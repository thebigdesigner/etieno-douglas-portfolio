import { createAdminClient } from "@/lib/supabase/admin";
import { requireProfile } from "@/lib/guard";
import { institutionNav } from "@/lib/app-nav";
import AppShell from "@/components/AppShell";

export default async function InstitutionLayout({ children }: { children: React.ReactNode }) {
  const { user, profile } = await requireProfile(["institution_admin", "operator"], {
    next: "/institution",
  });

  const admin = createAdminClient();
  const { data: member } = await admin
    .from("institution_members").select("institution_id").eq("user_id", user.id).maybeSingle();

  const { data: institution } = member
    ? await admin.from("institutions").select("verification").eq("id", member.institution_id).maybeSingle()
    : { data: null };

  return (
    <AppShell
      searchPlaceholder="Search cohorts and learners…"
      brand="Institution"
      name={profile.display_name}
      profile={{ name: profile.display_name ?? "Admin", id: user.id, avatarPath: profile.avatar_path }}
      email={profile.email}
      homeHref="/institution"
      groups={institutionNav(institution?.verification !== "verified")}
    >
      {children}
    </AppShell>
  );
}
