import { createAdminClient } from "@/lib/supabase/admin";
import { requireProfile } from "@/lib/guard";
import { studioNav } from "@/lib/app-nav";
import AppShell from "@/components/AppShell";

export default async function StudioLayout({ children }: { children: React.ReactNode }) {
  const { user, profile } = await requireProfile(["instructor", "operator"], {
    next: "/studio", to: "/signup?intent=instructor",
  });

  const admin = createAdminClient();
  const { count: queue } = await admin
    .from("review_queue_status").select("submission_id", { count: "exact", head: true })
    .eq("assigned_reviewer_id", user.id);


  /* The bell was mounted on the learner dashboard and nowhere else, so
     everything waiting on a person here was invisible unless somebody
     opened the right page — including the two promises with clocks on
     them, the four-day assessment and the thirty-day erasure. */
  const { data: notifications } = await createAdminClient()
    .rpc("instructor_notifications", { p_user_id: user.id });
  const seenAt = profile?.notifications_seen_at
    ? new Date(profile.notifications_seen_at).getTime() : 0;
  const unread = (notifications ?? [])
    .filter((n: { at: string }) => new Date(n.at).getTime() > seenAt).length;

  return (
    <AppShell
      notifications={notifications ?? []}
      unread={unread}
      searchPlaceholder="Search your courses and queue…"
      brand="Instructor"
      name={profile.display_name}
      profile={{ name: profile.display_name ?? "Instructor", id: user.id, avatarPath: profile.avatar_path }}
      email={profile.email}
      homeHref="/studio"
      helpHref="/studio/help"
      groups={studioNav(queue ?? 0)}
    >
      {children}
    </AppShell>
  );
}
