/** Returns the signed-in customer, or null. The page asks this on load; it never trusts client state. */
import { customerFrom } from './session.js';

export default async function handler(req, res) {
  const secret = process.env.SESSION_SECRET;
  const clientId = process.env.GOOGLE_CLIENT_ID || null;
  const emailSignIn = Boolean(secret && process.env.RESEND_API_KEY && process.env.TICKET_FROM && process.env.SUPABASE_URL);
  if (!secret) return res.status(200).json({ user: null, clientId, emailSignIn: false });
  const user = customerFrom(req, secret);
  res.setHeader('Cache-Control', 'no-store');
  return res.status(200).json({
    clientId, emailSignIn,
    user: user ? { name: user.name, email: user.email, picture: user.picture } : null
  });
}
