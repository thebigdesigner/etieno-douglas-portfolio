import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import IntroForm from "./IntroForm";

export const metadata = { title: "Welcome" };
export const dynamic = "force-dynamic";

export default async function StartPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login?next=/studio");

  const admin = createAdminClient();
  const { data: instructor } = await admin
    .from("instructors").select("proposed_course").eq("id", user.id).maybeSingle();

  // proposed_course holds the teaching-experience answer, so a value here means
  // they have already been through this.
  if (instructor?.proposed_course) redirect("/studio");

  return (
    <>
        <h1 className="sec__h" style={{ fontSize: 32, marginTop: 40 }}>
          Two more things, then you are in
        </h1>
        <p className="sec__meta">
          Neither is an application. You can start building straight away — we review the
          course when you submit it, not you.
        </p>
        <IntroForm />
      </>
  );
}
