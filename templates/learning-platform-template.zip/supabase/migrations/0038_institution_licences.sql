-- =====================================================================
-- 0038 — institutions buy instructor courses for their cohorts
--
-- Until now a cohort learner could open anything: their institution pays
-- per active learner, and that was taken to cover the whole catalogue.
-- That worked while the catalogue was one economy. It does not now — an
-- instructor course is bought, and a school putting fifty learners
-- through one would pay its author nothing.
--
-- So an institution buys a licence for a course, and its cohort learners
-- are entitled through that licence rather than through seat billing
-- alone. Your Brand and institution courses stay covered by the seats, as
-- before; only priced instructor courses need buying.
--
-- Shipped together with the buying page on purpose. Changing the rule
-- without a way to satisfy it would lock cohort learners out of courses
-- they can currently open, with no remedy.
-- =====================================================================

create table if not exists institution_licences (
  id             uuid primary key default gen_random_uuid(),
  institution_id uuid not null references institutions(id) on delete cascade,
  course_id      uuid not null references courses(id) on delete restrict,
  -- Copied, not joined: an instructor raising their price later must not
  -- change what an institution already paid, and the split has to be
  -- reconstructable from the row.
  price_cents    int  not null,
  currency       text not null,
  tx_ref         text,
  instructor_cents int not null default 0,
  platform_cents   int not null default 0,
  assessment_cents int not null default 0,
  purchased_at   timestamptz not null default now(),
  refunded_at    timestamptz,
  unique (institution_id, course_id)
);

create index if not exists institution_licences_course
  on institution_licences (course_id, purchased_at desc);

alter table institution_licences enable row level security;

drop policy if exists own_institution_licences on institution_licences;
create policy own_institution_licences on institution_licences for select to authenticated
  using (
    -- profiles has no institution_id; membership lives in institution_members
    -- for staff and through cohort_seats -> cohorts for learners.
    exists (
      select 1 from institution_members m
       where m.user_id = auth.uid() and m.institution_id = institution_licences.institution_id
    )
    or exists (
      select 1 from cohort_seats s join cohorts co on co.id = s.cohort_id
       where s.user_id = auth.uid() and co.institution_id = institution_licences.institution_id
    )
  );

-- ---------------------------------------------------------------------
-- Entitlement, with the cohort clause corrected.
--
-- A cohort learner is entitled to anything covered by their institution's
-- seats, and to a priced course only where the institution holds a
-- licence for it. Everything else is unchanged from 0031.
-- ---------------------------------------------------------------------
create or replace function public.course_entitlement(p_user_id uuid, p_course_id uuid)
returns table (
  allowed     boolean,
  reason      text,      -- free | purchased | subscription | cohort | licensed
                         -- | needs_purchase | needs_plan | needs_licence
  needs_price int
)
language plpgsql
stable
security definer set search_path = public
as $$
declare
  v_course      courses%rowtype;
  v_owned       boolean;
  v_cohort      boolean;
  v_institution uuid;
  v_licensed    boolean;
begin
  select * into v_course from courses where id = p_course_id;
  if not found then
    return query select false, 'no_course'::text, null::int; return;
  end if;

  if v_course.is_free then
    return query select true, 'free'::text, null::int; return;
  end if;

  select exists (
    select 1 from enrolments e
     where e.user_id = p_user_id and e.course_id = p_course_id and e.source = 'cohort'
  ) into v_cohort;

  -- A priced course needs buying by somebody. For a cohort learner that is
  -- their institution; for anyone else it is themselves.
  if v_course.owner_kind = 'instructor' and v_course.price_cents is not null then
    if v_cohort then
      -- A learner reaches their institution through the seat they claimed.
      select co.institution_id into v_institution
        from cohort_seats s join cohorts co on co.id = s.cohort_id
       where s.user_id = p_user_id
       limit 1;

      select exists (
        select 1 from institution_licences l
         where l.institution_id = v_institution
           and l.course_id = p_course_id
           and l.refunded_at is null
      ) into v_licensed;

      if v_licensed then
        return query select true, 'licensed'::text, null::int; return;
      end if;
      -- The learner cannot fix this; their administrator can.
      return query select false, 'needs_licence'::text, v_course.price_cents; return;
    end if;

    select exists (
      select 1 from course_purchases cp
       where cp.user_id = p_user_id and cp.course_id = p_course_id and cp.refunded_at is null
    ) into v_owned;

    if v_owned then
      return query select true, 'purchased'::text, null::int; return;
    end if;
    return query select false, 'needs_purchase'::text, v_course.price_cents; return;
  end if;

  -- Not priced: the seats cover it for a cohort learner, a plan for anyone
  -- else.
  if v_cohort then
    return query select true, 'cohort'::text, null::int; return;
  end if;

  if has_live_subscription(p_user_id) then
    return query select true, 'subscription'::text, null::int; return;
  end if;

  return query select false, 'needs_plan'::text, null::int;
end;
$$;

-- ---------------------------------------------------------------------
-- Recording a licence purchase, mirroring record_course_purchases.
-- ---------------------------------------------------------------------
alter table checkout_intents
  add column if not exists institution_id uuid references institutions(id) on delete cascade;

do $$ begin
  if exists (select 1 from pg_constraint where conname = 'checkout_intents_kind_shape') then
    alter table checkout_intents drop constraint checkout_intents_kind_shape;
  end if;
  alter table checkout_intents add constraint checkout_intents_kind_shape
    check (
      (kind = 'plan'      and plan is not null and cardinality(course_ids) = 0) or
      (kind = 'courses'   and plan is null     and cardinality(course_ids) > 0) or
      (kind = 'licences'  and plan is null     and cardinality(course_ids) > 0
                          and institution_id is not null)
    );
end $$;

create or replace function public.record_institution_licences(p_tx_ref text)
returns int
language plpgsql
security definer set search_path = public
as $$
declare
  v_intent checkout_intents%rowtype;
  v_course courses%rowtype;
  v_assess int := 1885;
  v_rest   int;
  v_made   int := 0;
  v_id     uuid;
begin
  select * into v_intent from checkout_intents where tx_ref = p_tx_ref;
  if not found or v_intent.kind <> 'licences' then return 0; end if;

  foreach v_id in array v_intent.course_ids loop
    select * into v_course from courses where id = v_id;
    continue when not found or v_course.price_cents is null;

    v_rest := greatest(v_course.price_cents - v_assess, 0);

    insert into institution_licences (
      institution_id, course_id, price_cents, currency, tx_ref,
      assessment_cents, instructor_cents, platform_cents
    )
    values (
      v_intent.institution_id, v_course.id, v_course.price_cents,
      v_intent.currency, p_tx_ref,
      least(v_assess, v_course.price_cents),
      floor(v_rest * 0.70)::int,
      v_rest - floor(v_rest * 0.70)::int
    )
    on conflict (institution_id, course_id) do nothing;

    if found then v_made := v_made + 1; end if;
  end loop;

  update checkout_intents set completed_at = now() where tx_ref = p_tx_ref;
  return v_made;
end;
$$;

-- What an institution can buy, and what it already holds.
create or replace function public.institution_catalogue(p_institution_id uuid)
returns table (
  course_id   uuid,
  slug        text,
  title       text,
  subject     text,
  price_cents int,
  licensed    boolean
)
language sql
stable
security definer set search_path = public
as $$
  select c.id, c.slug, c.title, c.subject, c.price_cents,
         exists (
           select 1 from institution_licences l
            where l.institution_id = p_institution_id
              and l.course_id = c.id and l.refunded_at is null
         )
    from courses c
   where c.state = 'published'
     and c.owner_kind = 'instructor'
     and c.price_cents is not null
     and not c.is_free
   order by c.title;
$$;
