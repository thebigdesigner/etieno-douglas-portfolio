import { marketBase, mk } from "@/lib/marketplace/url";
import { studioReady, studioViewer } from "@/lib/marketplace/studio";
import { StudioNotice } from "@/components/marketplace/studio/views";

/**
 * Every studio page starts the same way: are the tables there, is anyone
 * signed in, do they have a shop. Returns either the screen to show
 * instead, or what the page needs.
 */
export async function studioGate(path: string) {
  const base = await marketBase();
  if (!(await studioReady())) {
    return { block: (
      <StudioNotice icon="clock" title="The studio is not switched on yet">
        It needs database migrations 0065 and 0066. Once they have run, this page is where creators upload what they sell.
      </StudioNotice>
    ) } as const;
  }
  const viewer = await studioViewer();
  if (!viewer) {
    return { block: (
      <StudioNotice icon="users" title="Sign in to sell on Your Brand"
        action={<a className="mk-btn mk-btn--fill" href={mk(base, `/login?next=${encodeURIComponent(path)}`)}>Sign in</a>}>
        Use your Your Brand account, the same one as the Academy. If you do not have one, creating it is free and takes a minute.
      </StudioNotice>
    ) } as const;
  }
  return { base, viewer } as const;
}
