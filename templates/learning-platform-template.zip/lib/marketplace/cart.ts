"use client";

import { useSyncExternalStore } from "react";
import type { Product } from "@/lib/marketplace/types";

/**
 * The cart lives in the browser until checkout exists. That keeps it
 * working for visitors who have not signed in — most people browse a
 * shop before they have an account — and costs nothing to run.
 *
 * Each line keeps a copy of the item as it was when added, so the cart can
 * draw its cover and title without a round trip. The price shown here is
 * only a guide: checkout must re-read prices from the database, never
 * trust this copy, or anyone could edit localStorage and pay less.
 */
export type Licence = "personal" | "commercial";
export type CartLine = { slug: string; licence: Licence; product: Product; added: number };

const KEY = "splari.mk.cart";
const EVT = "splari:cart";
const EMPTY: CartLine[] = [];

let cache: CartLine[] | null = null;
let cacheRaw: string | null = null;

function read(): CartLine[] {
  if (typeof window === "undefined") return EMPTY;
  let raw: string | null = null;
  try { raw = window.localStorage.getItem(KEY); } catch { return EMPTY; }
  if (raw === cacheRaw && cache) return cache;
  cacheRaw = raw;
  try {
    const v = raw ? JSON.parse(raw) : [];
    cache = Array.isArray(v) ? v.filter((l) => l && typeof l.slug === "string" && l.product) : EMPTY;
  } catch { cache = EMPTY; }
  return cache;
}

function write(lines: CartLine[]) {
  try { window.localStorage.setItem(KEY, JSON.stringify(lines)); } catch { /* private mode: cart lasts the page */ }
  cache = lines; cacheRaw = JSON.stringify(lines);
  window.dispatchEvent(new Event(EVT));
}

function subscribe(fn: () => void) {
  // Our own writes fire EVT; another tab's fire "storage".
  window.addEventListener(EVT, fn);
  window.addEventListener("storage", fn);
  return () => { window.removeEventListener(EVT, fn); window.removeEventListener("storage", fn); };
}

export function useCart(): CartLine[] {
  return useSyncExternalStore(subscribe, read, () => EMPTY);
}

/** A licence is one line: adding the same item twice replaces the licence rather than doubling it. */
export function addToCart(product: Product, licence: Licence) {
  const lines = read().filter((l) => l.slug !== product.slug);
  write([...lines, { slug: product.slug, licence, product, added: Date.now() }]);
}

export function removeFromCart(slug: string) {
  write(read().filter((l) => l.slug !== slug));
}

export function lineCents(l: CartLine): number {
  return l.licence === "commercial" && l.product.commercialCents ? l.product.commercialCents : l.product.priceCents;
}

/** After a completed purchase. Not called on a cancelled payment. */
export function clearCart() {
  write([]);
}
