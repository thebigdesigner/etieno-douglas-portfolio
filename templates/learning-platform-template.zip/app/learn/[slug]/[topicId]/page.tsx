import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { resolveVideo } from "@/lib/video";
import NavIcon from "@/components/NavIcon";
import LessonPanel from "@/components/LessonPanel";
import Player from "./Player";
import Notes from "./Notes";
import { renderBody } from "@/lib/markdown";
import { isBeyondFreeModule } from "@/lib/access";
import { addToCart } from "@/app/actions/cart";
import { track } from "@/lib/track";
import Quiz from "./Quiz";
import CompleteButton from "./CompleteButton";

export const dynamic = "force-dynamic";

type Params = Promise<{ slug: string; topicId: string }>;

type OutlineRow = {
  topic_id: string; module_title: string; topic_title: string;
  pos: number; is_free: boolean; has_quiz: boolean;
  completed: boolean; unlocked: boolean;
};

export default async function LearnPage({ params }: { params: Params }) {
  const { slug, topicId } = await params;
  const supabase = await createClient();

  const { data: course } = await supabase
    .from("courses").select("id, title, owner_kind, price_cents, is_free").eq("slug", slug).eq("state", "published").maybeSingle();
  if (!course) notFound();

  const { data: topic } = await supabase
    .from("topics").select("id, title, body, video_uid, transcript, is_free").eq("id", topicId).maybeSingle();
  if (!topic) notFound();

  const { data: { user } } = await supabase.auth.getUser();

  // A course that is bought has no free sample: the price is for the whole
  // thing, so topic.is_free does not open it.
  // Anything priced is sold, whoever wrote it. Your Brand-authored courses
  // joined instructor courses here in 0063; before that they were covered
  // by the subscription and carried no price.
  const forSale =
    course.price_cents != null && !course.is_free;

  // The free first topic is readable without an account, except on a sold
  // course, where there is nothing free to read.
  if (!user && (forSale || !topic.is_free)) redirect(`/login?next=/learn/${slug}/${topicId}`);

  const admin = createAdminClient();
  const { data: outlineRaw } = await admin.rpc("course_outline", {
    p_course_id: course.id,
    p_user_id: user?.id ?? "00000000-0000-0000-0000-000000000000",
  });
  const outline = (outlineRaw ?? []) as OutlineRow[];
  const here = outline.find((t) => t.topic_id === topicId);

  if (user && here && !here.unlocked) {
    const firstOpen = outline.find((t) => t.unlocked && !t.completed);
    redirect(firstOpen ? `/learn/${slug}/${firstOpen.topic_id}` : `/courses/${slug}`);
  }

  /* The gate.
   *
   * course_entitlement answers the real question — this person, this course
   * — and returns why, which is what decides which of the three walls below
   * is shown. Its predecessor, hasAccess(), only ever asked whether there
   * was a live subscription, which let a subscriber read a $49 course for
   * nothing and made the cart decorative.
   */
  let paywalled = false;
  let gate: { reason: string; needs_price: number | null } | null = null;

  if (user) {
    // On a sold course the sample is off, so even the first topic is gated.
    const sampleApplies = !forSale && topic.is_free;

    if (!sampleApplies) {
      // Everything else still opens at the end of module one, as before.
      const beyond = forSale || (await isBeyondFreeModule(course.id, topicId));
      if (beyond) {
        const { data: rows } = await admin.rpc("course_entitlement", {
          p_user_id: user.id, p_course_id: course.id,
        });
        const row = Array.isArray(rows) ? rows[0] : rows;

        paywalled = !row?.allowed;
        gate = row ? { reason: row.reason, needs_price: row.needs_price } : null;

        if (paywalled) {
          await track("paywall_shown", user.id, { slug, topicId });
        }
      }
    }
  }

  const needsPurchase = gate?.reason === "needs_purchase";
  // A cohort learner cannot buy anything — their institution licenses
  // courses on their behalf. Showing them a price would be advice they
  // cannot act on.
  const needsLicence = gate?.reason === "needs_licence";

  const { data: rawMaterials } = await admin
    .from("topic_materials")
    .select("id, kind, title, path, url, size_bytes")
    .eq("topic_id", topicId).order("position");

  // Private bucket: uploads are served through short-lived signed links.
  const materials = await Promise.all(
    (rawMaterials ?? []).map(async (m) => {
      if (!m.path) return { ...m, href: m.url };
      const { data } = await admin.storage.from("materials").createSignedUrl(m.path, 3600);
      return { ...m, href: data?.signedUrl ?? null };
    })
  );

  const videoMaterial = materials.find((m) => m.kind === "video");

  const { data: enrolmentRow } = user
    ? await admin.from("enrolments").select("id")
        .eq("user_id", user.id).eq("course_id", course.id).maybeSingle()
    : { data: null };

  const { data: position } = enrolmentRow
    ? await admin.from("topic_progress").select("seconds")
        .eq("enrolment_id", enrolmentRow.id).eq("topic_id", topicId).maybeSingle()
    : { data: null };

  const { data: note } = user
    ? await admin.from("topic_notes").select("body")
        .eq("user_id", user.id).eq("topic_id", topicId).maybeSingle()
    : { data: null };

  const { data: items } = await admin
    .from("quiz_items").select("id, prompt, options").eq("topic_id", topicId);

  // Deterministic shuffle per learner and topic: stable across reloads,
  // different between learners.
  const seed = `${user?.id ?? "anon"}:${topicId}`;
  const questions = shuffle(items ?? [], seed).map((q) => ({
    id: q.id,
    prompt: q.prompt,
    options: shuffle(q.options as { id: string; text: string }[], seed + q.id),
  }));

  // Resolved after the paywall check above, so a signed URL is only ever
  // minted for somebody entitled to watch. One hour is long enough for a
  // lesson and short enough that a leaked link expires.
  const resolved = resolveVideo(videoMaterial?.url ?? topic.video_uid);
  let video: { kind: "iframe" | "file"; src: string } | null = null;
  if (resolved && !paywalled) {
    if (resolved.kind === "storage") {
      const { data: signed } = await admin.storage
        .from("videos").createSignedUrl(resolved.path, 3600);
      if (signed?.signedUrl) video = { kind: "file", src: signed.signedUrl };
    } else {
      video = resolved;
    }
  }
  const done = outline.filter((t) => t.completed).length;
  const pct = outline.length ? Math.round((done / outline.length) * 100) : 0;
  const idx = outline.findIndex((t) => t.topic_id === topicId);
  const next = outline[idx + 1];

  // Where the last topic leads. Finishing the final topic used to drop the
  // learner back on the course page to work out what came next for
  // themselves; now it carries straight on to the exam, which is the actual
  // next thing on every course that has one.
  const { data: examItems } = await admin
    .from("exam_items").select("id").eq("course_id", course.id).limit(1);
  const hasExam = (examItems ?? []).length > 0;

  const afterHref = next
    ? `/learn/${slug}/${next.topic_id}`
    : hasExam
      ? `/learn/${slug}/exam`
      : `/courses/${slug}`;
  const afterLabel = next ? "Next topic" : hasExam ? "Take the final exam" : "Back to the course";

  return (
    <main className="learn">
      <header className="learn__bar">
        <div className="learn__barin">
          {/* A signed-in learner's home is the dashboard, not the marketing
              page. The lesson chrome is deliberately sparse, but "sparse"
              should not mean there is no way back. */}
          {user && (
            <>
              <Link className="learn__exit" href="/dashboard">
                <NavIcon name="chevron" size={16} />
                <span>Dashboard</span>
              </Link>
              <span className="learn__sep" aria-hidden="true" />
            </>
          )}
          <Link className="logo" href={user ? "/dashboard" : "/"}>Your Brand<span>.</span></Link>
          <span className="learn__sep" aria-hidden="true" />
          <div className="learn__crumb">
            <Link href={`/courses/${slug}`}>{course.title}</Link>
          </div>
          <div className="learn__prog">
            <div className="learn__bar2"><span style={{ width: `${pct}%` }} /></div>
            <span className="num">{pct}%</span>
          </div>
        </div>
      </header>

      <div className="learn__in">
        <article className="learn__main">
          {/* Player first, like a lesson should open. The title used to sit
              above it, pushing the thing you came for below the fold. */}
          {video ? (
            <Player
              src={video.src}
              kind={video.kind}
              title={topic.title}
              topicId={topicId}
              startAt={position?.seconds ?? 0}
            />
          ) : !paywalled ? (
            <div className="learn__novideo">
              <NavIcon name="book" size={22} />
              <span>This topic is written rather than filmed.</span>
            </div>
          ) : null}

          <div className="learn__head">
            <div>
              <div className="eyebrow">{here?.module_title}</div>
              <h1 className="learn__h">{topic.title}</h1>
            </div>
            <div className="learn__headmeta">
              {here?.completed && <span className="tag tag--go">Completed</span>}
              {topic.is_free && <span className="tag">Free topic</span>}
              {(next || hasExam) && (
                <Link className="btn btn--line" href={afterHref}>{afterLabel}</Link>
              )}
            </div>
          </div>

          {paywalled ? (
            <div className="paywall">
              {/* Three walls, because there are three reasons to be stopped,
                  and only one of them is something the reader can act on.
                  A cohort learner has nothing to buy; an unpriced course is
                  our mistake, not theirs. Offering a price in either case
                  would read as broken. */}
              {needsLicence ? (
                <>
                  <div className="paywall__badge">Ask your school</div>
                  <h2 className="paywall__h">This one is not in your licence yet</h2>
                  <p className="paywall__p">
                    Most of the catalogue is covered by your school&rsquo;s account. This
                    course was written by an outside practitioner, so it is licensed
                    separately — and that is something only your teacher or
                    administrator can arrange.
                  </p>
                  <ul className="paywall__list">
                    <li>Nothing for you to buy, and nothing to pay</li>
                    <li>Your progress on everything else is untouched</li>
                    <li>Once it is licensed, it opens for your whole class</li>
                  </ul>
                  <div className="paywall__btns">
                    <Link className="btn btn--lg btn--fill" href="/dashboard/courses">
                      Back to my courses
                    </Link>
                    <Link className="btn btn--lg btn--line" href="/courses">
                      Browse what is open to you
                    </Link>
                  </div>
                </>
              ) : needsPurchase ? (
                <>
                  <div className="paywall__badge">This course is bought once</div>
                  <h2 className="paywall__h">
                    {gate?.needs_price != null
                      ? `Yours for $${(gate.needs_price / 100).toFixed(2)}`
                      : "Buy this course to continue"}
                  </h2>
                  <p className="paywall__p">
                    Paid once. The price includes the assessment of your final project
                    by a working practitioner, so there is nothing further to pay when
                    you submit — and nothing to renew afterwards.
                  </p>
                  <ul className="paywall__list">
                    <li>Every topic, the final exam, and the project</li>
                    <li>One assessment by a working practitioner, included</li>
                    <li>A certificate anyone can verify with a code</li>
                    <li>Yours to keep, with no renewal date</li>
                  </ul>
                  <div className="paywall__btns">
                    <form action={addToCart.bind(null, slug)}>
                      <button className="btn btn--lg btn--fill">Add to cart</button>
                    </form>
                    <Link className="btn btn--lg btn--line" href={`/courses/${slug}`}>
                      Back to the course
                    </Link>
                  </div>
                </>
              ) : (
                <>
                  <div className="paywall__badge">Not available yet</div>
                  <h2 className="paywall__h">This course is not open for enrolment</h2>
                  <p className="paywall__p">
                    It has no price set and is not marked free, so there is no way to
                    buy it — which is our fault rather than yours. Nothing you do here
                    will fix it, and nothing you have already done is lost.
                  </p>
                  <ul className="paywall__list">
                    <li>Your progress on this course is saved</li>
                    <li>Nothing has been charged to you</li>
                    <li>It will open here once the price is set</li>
                  </ul>
                  <div className="paywall__btns">
                    <Link className="btn btn--lg btn--fill" href="/courses">
                      Browse the catalogue
                    </Link>
                    <Link className="btn btn--lg btn--line" href="/contact">
                      Tell us about it
                    </Link>
                  </div>
                </>
              )}
              <p className="paywall__fine">
                Your progress so far is saved. Nothing is lost if you decide later.
              </p>
            </div>
          ) : (
          <>
          {topic.body && (
            <div className="prose" dangerouslySetInnerHTML={{ __html: renderBody(topic.body) }} />
          )}

          {user && <Notes topicId={topicId} existing={note?.body ?? null} />}

          {!user && topic.is_free ? (
            <div className="gate">
              <p className="gate__h">Enjoying it? Create an account to keep going.</p>
              <p className="gate__p">
                Your progress is saved to the account, and buying the course later
                picks up exactly where you stopped.
              </p>
              <div className="gate__btns">
                <Link className="btn btn--fill btn--lg" href="/signup">Create an account</Link>
                <Link className="btn btn--line btn--lg" href="/login">Log in</Link>
              </div>
            </div>
          ) : questions.length > 0 ? (
            <Quiz
              slug={slug}
              topicId={topicId}
              questions={questions}
              alreadyPassed={!!here?.completed}
              nextHref={afterHref}
              nextLabel={afterLabel}
            />
          ) : (
            <CompleteButton
              slug={slug}
              topicId={topicId}
              completed={!!here?.completed}
              nextHref={afterHref}
            />
          )}
          </>
          )}
        </article>

        <LessonPanel
          rows={outline}
          slug={slug}
          currentId={topicId}
          materials={materials
            .filter((m) => m.kind !== "video")
            .map((m) => ({
              id: m.id, kind: m.kind, title: m.title,
              href: m.href ?? null, size_bytes: m.size_bytes,
            }))}
          transcript={topic.transcript}
        />
      </div>
    </main>
  );
}

/** Deterministic shuffle from a string seed. */
function shuffle<T>(arr: T[], seed: string): T[] {
  let h = 2166136261;
  for (let i = 0; i < seed.length; i++) {
    h ^= seed.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  const rand = () => {
    h ^= h << 13; h ^= h >>> 17; h ^= h << 5;
    return Math.abs(h) / 2147483647;
  };
  const out = arr.slice();
  for (let i = out.length - 1; i > 0; i--) {
    const j = Math.floor(rand() * (i + 1));
    [out[i], out[j]] = [out[j], out[i]];
  }
  return out;
}
