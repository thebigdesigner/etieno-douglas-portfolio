-- =====================================================================
-- 0042 — an assessor is a person, not necessarily a practitioner
--
-- 0040 decided that Your Brand-owned courses are assessed by "any active
-- instructor, or a member of staff", and 0041 let institutions name a
-- member of their own organisation. Both put that person's id in
-- courses.instructor_id — which still carried its 0001 foreign key to
-- the instructors table, where staff and institution members have no
-- row.
--
-- So creating a Your Brand or institution course with anyone but an active
-- practitioner failed on the foreign key, and the studio action masked
-- it as "Could not create the course." The same shape as every bug in
-- this codebase's history: valid at creation, fatal at execution. In a
-- database where nobody holds the instructor role, that meant no course
-- could be created from the console at all.
--
-- The key was not the only one. The whole assessment chain assumed the
-- reviewer is a practitioner, and each link would have failed later and
-- more quietly than the last:
--
--   courses.instructor_id            → fails when the course is created
--   submissions.assigned_reviewer_id → fails at the first submission
--   reviews.reviewer_id              → fails when the review is filed
--   earnings_entries.instructor_id   → fails crediting the $18.85 fee
--   payout_runs.instructor_id        → fails at the payout sweep
--   appeals.second_reviewer_id       → fails assigning an appeal
--   appeals.decided_by               → fails recording the decision
--
-- Every one is retargeted at profiles(id). instructors.id is itself a
-- profiles(id), so this strictly widens each key: every existing row
-- stays valid, and no data is rewritten. Delete behaviours are kept
-- exactly as they were.
--
-- instructor_applications.instructor_id keeps its key to instructors —
-- an application really is about a practitioner record.
--
-- What is NOT loosened: who may be named. eligible_assessors() and
-- institution_assessors() still decide that, and createCourse verifies
-- the picked id against them. The keys below only stop enforcing a
-- claim — "every assessor is a practitioner" — that 0040 deliberately
-- retired.
-- =====================================================================

alter table courses
  drop constraint courses_instructor_id_fkey,
  add  constraint courses_instructor_id_fkey
       foreign key (instructor_id) references profiles(id) on delete restrict;

alter table submissions
  drop constraint submissions_assigned_reviewer_id_fkey,
  add  constraint submissions_assigned_reviewer_id_fkey
       foreign key (assigned_reviewer_id) references profiles(id) on delete set null;

alter table reviews
  drop constraint reviews_reviewer_id_fkey,
  add  constraint reviews_reviewer_id_fkey
       foreign key (reviewer_id) references profiles(id) on delete restrict;

alter table appeals
  drop constraint appeals_second_reviewer_id_fkey,
  add  constraint appeals_second_reviewer_id_fkey
       foreign key (second_reviewer_id) references profiles(id) on delete set null;

alter table appeals
  drop constraint appeals_decided_by_fkey,
  add  constraint appeals_decided_by_fkey
       foreign key (decided_by) references profiles(id);

-- Money is owed to a person. A staff assessor earns the review fee —
-- the console form has promised them that since 0040 — and these two
-- keys were what made paying it impossible.
alter table earnings_entries
  drop constraint earnings_entries_instructor_id_fkey,
  add  constraint earnings_entries_instructor_id_fkey
       foreign key (instructor_id) references profiles(id) on delete cascade;

alter table payout_runs
  drop constraint payout_runs_instructor_id_fkey,
  add  constraint payout_runs_instructor_id_fkey
       foreign key (instructor_id) references profiles(id) on delete cascade;

comment on column courses.instructor_id is
  'Who assesses this course''s projects, and — on an instructor-owned course — who wrote it. References profiles, not instructors: a Your Brand course may name a member of staff, an institution course a member of the organisation. eligible_assessors() / institution_assessors() decide who may be named.';
