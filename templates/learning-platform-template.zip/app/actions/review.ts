"use server";

import { redirect } from "next/navigation";
import { siteUrl } from "@/lib/site";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { isOwnerEmail } from "@/lib/owner";
import type { FormState } from "@/lib/forms";
import { track } from "@/lib/track";
import { sendEmail } from "@/lib/email";
import {
  submissionReceived, newSubmission, reviewPassed, reviewRevise,
} from "@/lib/notifications";

const MAX_FILE_BYTES = 20 * 1024 * 1024;
const ALLOWED = [
  "application/pdf",
  "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
  "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  "text/plain",
  "image/png",
  "image/jpeg",
];

const SUBMIT_ERRORS: Record<string, string> = {
  not_enrolled: "You are not enrolled on this course.",
  topics_incomplete: "Finish every topic before submitting your project.",
  already_under_review: "Your project is already with a reviewer.",
  already_passed: "You have already passed this course.",
  exam_not_passed:
    "Pass the final exam first — the project opens as soon as you do.",
  no_plan: "You need an active plan to have your project assessed.",
  allowance_spent:
    "You have used all the certifications included in your plan this year. Move up a plan, or buy an extra assessment.",
};

/* ------------------------------------------------------------------ */
/* Submit a final project                                              */
/* ------------------------------------------------------------------ */
export async function submitProject(
  slug: string,
  _prev: FormState,
  formData: FormData
): Promise<FormState> {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect(`/login?next=/courses/${slug}/submit`);

  const body = String(formData.get("body") ?? "").trim();
  if (body.length < 120) {
    return { error: "Write at least a couple of paragraphs so your reviewer has something to assess." };
  }

  const admin = createAdminClient();
  const { data: course } = await admin
    .from("courses").select("id").eq("slug", slug).eq("state", "published").maybeSingle();
  if (!course) return { error: "That course is not available." };

  // Files are optional; the written response is not.
  const files = formData.getAll("files").filter((f): f is File => f instanceof File && f.size > 0);
  const paths: string[] = [];

  for (const file of files) {
    if (file.size > MAX_FILE_BYTES) {
      return { error: `${file.name} is larger than 20MB. Please compress it or split it up.` };
    }
    if (!ALLOWED.includes(file.type)) {
      return { error: `${file.name} is not a supported file type. Use PDF, Word, Excel, text or an image.` };
    }

    const safeName = file.name.replace(/[^a-zA-Z0-9._-]/g, "_").slice(-80);
    const path = `${user.id}/${course.id}/${Date.now()}-${safeName}`;

    const { error } = await admin.storage
      .from("submissions")
      .upload(path, file, { contentType: file.type, upsert: false });

    if (error) return { error: `Could not upload ${file.name}. Please try again.` };
    paths.push(path);
  }

  const { data, error } = await admin.rpc("create_submission", {
    p_user_id: user.id,
    p_course_id: course.id,
    p_body: body,
    p_files: paths,
  });

  if (error) return { error: "Something went wrong submitting your project. Please try again." };

  const row = (data ?? [])[0] as { submission_id: string | null; error: string | null } | undefined;
  if (!row || row.error) {
    return { error: SUBMIT_ERRORS[row?.error ?? ""] ?? "Your project could not be submitted." };
  }

  await track("project_submitted", user.id, { slug, submissionId: row.submission_id });
  await notifyOnSubmission(row.submission_id!, user.id, course.id, slug);

  revalidatePath(`/courses/${slug}`);
  redirect(`/courses/${slug}?submitted=1`);
  return {};
}

/** Both sides hear about it: the learner gets the promise in writing, the
 *  reviewer gets the deadline. */
async function notifyOnSubmission(
  submissionId: string, userId: string, courseId: string, slug: string
) {
  const admin = createAdminClient();

  const [{ data: sub }, { data: course }, { data: learner }] = await Promise.all([
    admin.from("submissions").select("deadline_at, assigned_reviewer_id").eq("id", submissionId).maybeSingle(),
    admin.from("courses").select("title").eq("id", courseId).maybeSingle(),
    admin.from("profiles").select("display_name, email").eq("id", userId).maybeSingle(),
  ]);
  if (!sub || !course) return;

  const deadline = new Date(sub.deadline_at);

  if (learner?.email && !learner.email.endsWith("@cohort.splari.internal")) {
    await sendEmail({
      to: learner.email,
      ...submissionReceived({
        name: learner.display_name ?? "there",
        course: course.title,
        deadline,
        url: `${siteUrl()}/dashboard/submissions`,
      }),
    });
  }

  if (sub.assigned_reviewer_id) {
    const { data: reviewer } = await admin
      .from("profiles").select("display_name, email").eq("id", sub.assigned_reviewer_id).maybeSingle();

    if (reviewer?.email) {
      await sendEmail({
        to: reviewer.email,
        ...newSubmission({
          reviewer: reviewer.display_name ?? "there",
          course: course.title,
          deadline,
          url: `${siteUrl()}/review`,
        }),
      });
    }
  }
}

/* ------------------------------------------------------------------ */
/* Record a verdict                                                    */
/* ------------------------------------------------------------------ */
export async function recordReview(
  submissionId: string,
  _prev: FormState,
  formData: FormData
): Promise<FormState> {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login?next=/review");

  const admin = createAdminClient();
  const { data: profile } = await admin
    .from("profiles").select("role").eq("id", user.id).maybeSingle();

  /* Who may file a verdict.
   *
   * The review pages were opened to institution assessors and to the
   * allowlisted owner, and this gate was not — so one of them could read
   * a submission, write the feedback, press the button and be told they
   * had no access. Half a fix is worse than none: it invites the work
   * and then throws it away.
   *
   * Standing in for a reviewer is the operator's job, and an allowlisted
   * address counts as one here for the same reason it does everywhere
   * else — the console gate is the environment, not the role column. */
  const isOperator = profile?.role === "operator" || isOwnerEmail(user.email);
  const mayReview =
    isOperator ||
    profile?.role === "instructor" ||
    profile?.role === "institution_admin";

  if (!mayReview) {
    return { error: "You do not have access to the review queue." };
  }

  // A role alone isn't enough: this specific submission has to actually be
  // assigned to the person grading it, or an operator standing in for one.
  if (!isOperator) {
    const { data: sub } = await admin
      .from("submissions").select("assigned_reviewer_id").eq("id", submissionId).maybeSingle();
    if (!sub || sub.assigned_reviewer_id !== user.id) {
      return { error: "This submission is not assigned to you." };
    }
  }

  /* A certificate has to carry a name.
   *
   * record_review writes coalesce(display_name, 'Your Brand reviewer') onto
   * the certificate. An assessor with no display name would therefore
   * sign every one of them "Your Brand reviewer" — the single claim the
   * credential cannot make, discovered only by whoever received it.
   * Refused before the verdict is recorded, not after. */
  const { data: me } = await admin
    .from("profiles").select("display_name").eq("id", user.id).maybeSingle();

  if (!me?.display_name?.trim()) {
    return {
      error:
        "Add your name to your account before assessing anything. It goes on the certificate, and without it the certificate would be signed \"Your Brand reviewer\" — which is the one thing it must never say.",
    };
  }

  const outcome = String(formData.get("outcome") ?? "");
  const feedback = String(formData.get("feedback") ?? "").trim();

  if (outcome !== "pass" && outcome !== "revise") {
    return { error: "Choose whether this passes or needs changes." };
  }
  if (feedback.length < 80) {
    return {
      error:
        "Feedback needs to be specific to the work in front of you. A generic paragraph is not a review.",
    };
  }

  const scores: Record<string, number> = {};
  for (const [key, value] of formData.entries()) {
    if (key.startsWith("score_")) scores[key.slice(6)] = Number(value);
  }

  const { data, error } = await admin.rpc("record_review", {
    p_submission_id: submissionId,
    p_reviewer_id: user.id,
    p_outcome: outcome,
    p_feedback: feedback,
    p_scores: scores,
  });

  if (error) {
    /* The message stays calm, but the cause must not vanish.
     *
     * "Could not save your review" hid a database exception behind a
     * retry suggestion, so the same failure could repeat forever with
     * nothing anywhere naming it. This is the fourth place in this
     * codebase where a generic string swallowed the only useful
     * information about a bug. */
    console.error("record_review failed", {
      submissionId, reviewerId: user.id, outcome,
      code: error.code, message: error.message, details: error.details, hint: error.hint,
    });
    return {
      error:
        "Could not save your review — nothing was recorded, so your feedback is safe to submit again. If it happens twice, send us this: " +
        (error.code ?? "unknown"),
    };
  }

  const row = (data ?? [])[0] as { error: string | null } | undefined;
  if (row?.error === "already_decided") {
    return { error: "Somebody has already assessed this submission." };
  }

  const certCode = (data ?? [])[0]?.certificate_code as string | undefined;
  await track("review_completed", user.id, { submissionId, outcome });
  if (certCode) await track("certificate_issued", user.id, { submissionId, code: certCode });
  await notifyOnVerdict(submissionId, outcome, certCode ?? null, user.id);

  revalidatePath("/review");
  redirect("/review?done=1");
  return {};
}

async function notifyOnVerdict(
  submissionId: string,
  outcome: string,
  certCode: string | null,
  reviewerId: string
) {
  const admin = createAdminClient();

  const { data: sub } = await admin
    .from("submissions").select("enrolment_id, attempt_no").eq("id", submissionId).maybeSingle();
  if (!sub) return;

  const { data: enrolment } = await admin
    .from("enrolments").select("user_id, course_id").eq("id", sub.enrolment_id).maybeSingle();
  if (!enrolment) return;

  const [{ data: learner }, { data: course }, { data: reviewer }] = await Promise.all([
    admin.from("profiles").select("display_name, email").eq("id", enrolment.user_id).maybeSingle(),
    admin.from("courses").select("title").eq("id", enrolment.course_id).maybeSingle(),
    admin.from("profiles").select("display_name").eq("id", reviewerId).maybeSingle(),
  ]);

  if (!learner?.email || learner.email.endsWith("@cohort.splari.internal")) return;
  if (!course) return;

  const mail = outcome === "pass"
    ? reviewPassed({
        name: learner.display_name ?? "there",
        course: course.title,
        reviewer: reviewer?.display_name ?? "Your reviewer",
        code: certCode ?? "",
        url: `${siteUrl()}/dashboard/submissions`,
        certUrl: `${siteUrl()}/dashboard/certificates`,
      })
    : reviewRevise({
        name: learner.display_name ?? "there",
        course: course.title,
        reviewer: reviewer?.display_name ?? "Your reviewer",
        url: `${siteUrl()}/dashboard/submissions`,
        free: sub.attempt_no === 1,
      });

  await sendEmail({ to: learner.email, ...mail });

  // The passing email already says the certificate exists, so mark it as
  // told. Without this the sweep in /api/cron/certificates would send a
  // second one within the quarter hour.
  if (outcome === "pass" && certCode) {
    await admin.rpc("mark_certificate_notified", { p_code: certCode });
  }
}

/* ------------------------------------------------------------------ */
/* Appeal a verdict                                                    */
/* ------------------------------------------------------------------ */
export async function openAppeal(
  submissionId: string,
  _prev: FormState,
  formData: FormData
): Promise<FormState> {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const grounds = String(formData.get("grounds") ?? "").trim();
  if (grounds.length < 60) {
    return { error: "Explain which part of the rubric you think was applied wrongly." };
  }

  const admin = createAdminClient();

  // The submission must belong to the person appealing.
  const { data: owned } = await admin
    .from("submissions")
    .select("id, enrolments!inner(user_id)")
    .eq("id", submissionId)
    .eq("enrolments.user_id", user.id)
    .maybeSingle();
  if (!owned) return { error: "That submission is not yours." };

  const { data: ok } = await admin.rpc("open_appeal", {
    p_submission_id: submissionId,
    p_grounds: grounds,
  });

  if (!ok) {
    return {
      error:
        "An appeal has already been opened for this submission, or it is not in a state that can be appealed.",
    };
  }

  await track("appeal_opened", user.id, { submissionId });
  return { ok: true, message: "Your appeal is with us. A second reviewer will look at it." };
}

/* ------------------------------------------------------------------ */
/* Appeal routing                                                      */
/* ------------------------------------------------------------------ */
export async function assignAppeal(
  appealId: string,
  _prev: FormState,
  formData: FormData
): Promise<FormState> {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const admin = createAdminClient();
  const { data: profile } = await admin
    .from("profiles").select("role").eq("id", user.id).maybeSingle();
  if (profile?.role !== "operator") return { error: "Operators only." };

  const reviewerId = String(formData.get("reviewer_id") ?? "");
  if (!reviewerId) return { error: "Choose a second reviewer." };

  const { data } = await admin.rpc("assign_appeal", {
    p_appeal_id: appealId, p_reviewer_id: reviewerId,
  });
  const row = (data ?? [])[0] as { ok: boolean; reason: string | null } | undefined;

  if (!row?.ok) {
    if (row?.reason === "same_reviewer") {
      return { error: "That is the person who gave the original verdict. Pick somebody else." };
    }
    return { error: "Could not assign this appeal." };
  }

  revalidatePath("/admin/appeals");
  return { ok: true, message: "Assigned. They will not see the original verdict." };
}

export async function resolveAppeal(
  appealId: string,
  _prev: FormState,
  formData: FormData
): Promise<FormState> {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const outcome = String(formData.get("outcome") ?? "");
  const feedback = String(formData.get("feedback") ?? "").trim();

  if (outcome !== "pass" && outcome !== "revise") {
    return { error: "Choose whether this passes on a second reading." };
  }
  if (feedback.length < 80) {
    return { error: "Explain your reasoning against the rubric. The learner sees this." };
  }

  const admin = createAdminClient();
  const { data } = await admin.rpc("resolve_appeal", {
    p_appeal_id: appealId,
    p_reviewer_id: user.id,
    p_outcome: outcome,
    p_feedback: feedback,
  });

  const row = (data ?? [])[0] as
    { ok: boolean; certificate_code: string | null; reason: string | null } | undefined;

  if (!row?.ok) {
    if (row?.reason === "not_assigned") return { error: "This appeal is not assigned to you." };
    return { error: "Could not record your decision." };
  }

  await track("review_completed", user.id, { appealId, outcome, appeal: true });
  if (row.certificate_code) {
    await track("certificate_issued", user.id, { appealId, code: row.certificate_code });
  }

  revalidatePath("/review");
  redirect("/review?appeal=done");
  return {};
}
