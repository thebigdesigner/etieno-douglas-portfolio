-- ============================================================================
-- Data integrity sweep -- read-only. Run it any time.
-- ============================================================================
-- Every row returned is something that should not be true. An empty result from
-- all of them is the pass condition. Nothing here writes; fixes belong in
-- db/repair-stale-seats.sql or in the app.
--
-- This is the generalised form of the bug that made seats unsellable: a table
-- said one thing, another said the opposite, and no screen showed the conflict.

\echo '== 1. Seats free in trip_seats but still held by a live passenger row =='
select t.depart_date, t.depart_time, ts.seat_no, p.status as passenger_status, b.reference
  from trip_seats ts
  join trips t      on t.id = ts.trip_id
  join passengers p on p.trip_id = ts.trip_id and p.seat_no = ts.seat_no
  left join bookings b on b.id = p.booking_id
 where ts.state = 'free'
   and p.status in ('reserved','confirmed','checked_in','boarded')
   and t.depart_date >= current_date;

\echo '== 2. Seats held or sold against a booking that is no longer live =='
select t.depart_date, t.depart_time, ts.seat_no, ts.state, b.status as booking_status, b.reference
  from trip_seats ts
  join trips t    on t.id = ts.trip_id
  join bookings b on b.id = ts.booking_id
 where ts.state in ('held','sold')
   and b.status in ('cancelled','expired','refunded');

\echo '== 3. Holds that lapsed and were never swept (the cron may be down) =='
select b.reference, b.hold_expires_at, count(ts.seat_no) as seats_still_held
  from bookings b
  left join trip_seats ts on ts.booking_id = b.id and ts.state = 'held'
 where b.status = 'pending'
   and b.hold_expires_at is not null
   and b.hold_expires_at < now() - interval '5 minutes'
 group by b.reference, b.hold_expires_at;

\echo '== 4. Confirmed bookings whose payments do not cover the fare =='
-- A refund is a negative row, so a cancelled or refunded booking netting to zero
-- is correct and excluded. This is for bookings still treated as sold.
select b.reference, b.status, b.total_kobo,
       coalesce(sum(p.amount_kobo) filter (where p.status = 'success'), 0) as paid_kobo
  from bookings b
  left join payments p on p.booking_id = b.id
 where b.status = 'confirmed'
 group by b.reference, b.status, b.total_kobo
having coalesce(sum(p.amount_kobo) filter (where p.status = 'success'), 0) <> b.total_kobo;

\echo '== 5. Money recorded against a booking that does not exist =='
select p.id, p.amount_kobo, p.status, p.created_at
  from payments p
  left join bookings b on b.id = p.booking_id
 where p.booking_id is not null and b.id is null;

\echo '== 6. Two live passengers in the same seat on the same departure =='
select trip_id, seat_no, count(*) as live_rows
  from passengers
 where status in ('reserved','confirmed','checked_in','boarded')
 group by trip_id, seat_no
having count(*) > 1;

\echo '== 7. Passengers sitting in a seat the vehicle does not have =='
select t.depart_date, t.depart_time, p.seat_no, t.capacity, b.reference
  from passengers p
  join trips t    on t.id = p.trip_id
  join bookings b on b.id = p.booking_id
 where p.seat_no > t.capacity or p.seat_no < 1;

\echo '== 8. Duplicate booking references within a tenant =='
select tenant_id, reference, count(*) from bookings
 group by tenant_id, reference having count(*) > 1;

\echo '== 9. Departures on sale with no vehicle or no driver =='
select depart_date, depart_time,
       case when vehicle_id is null and driver_id is null then 'neither'
            when vehicle_id is null then 'no vehicle' else 'no driver' end as missing
  from trips
 where status = 'scheduled' and depart_date between current_date and current_date + 2
   and (vehicle_id is null or driver_id is null)
 order by depart_date, depart_time;

\echo '== 10. How far ahead the site can still sell (want ~45 days) =='
select max(depart_date) as horizon,
       max(depart_date) - current_date as days_left
  from trips where status <> 'cancelled';

\echo '== 11. Credits spent more than once, or spent and still marked unused =='
select c.code, c.redeemed_at, c.booking_id,
       (select count(*) from payments p where p.booking_id = c.booking_id and p.channel = 'coupon') as coupon_rows
  from coupons c
 where c.redeemed_at is not null
   and (c.booking_id is null
        or (select count(*) from payments p where p.booking_id = c.booking_id and p.channel = 'coupon') > 1);

\echo '== 12. Loyalty balances that have gone negative =='
select tenant_id, lower(customer_email) as customer, sum(points) as balance
  from loyalty_ledger
 group by tenant_id, lower(customer_email)
having sum(points) < 0;

\echo '== 13. Staff rows archived but still marked active =='
select name, email, role, active, archived_at from staff
 where archived_at is not null and active is true;

\echo '== 14. Rows belonging to no tenant (multi-tenancy leak check) =='
select 'bookings' as table_name, count(*) from bookings where tenant_id is null
union all select 'payments', count(*) from payments where tenant_id is null
union all select 'trips', count(*) from trips where tenant_id is null
union all select 'staff', count(*) from staff where tenant_id is null
union all select 'feedback', count(*) from feedback where tenant_id is null;
