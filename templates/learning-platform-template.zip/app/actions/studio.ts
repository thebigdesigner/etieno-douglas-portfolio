"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { isOwnerEmail } from "@/lib/owner";
import type { FormState } from "@/lib/forms";

async function requireRole(roles: string[]) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const admin = createAdminClient();
  const { data: profile } = await admin
    .from("profiles").select("role").eq("id", user.id).maybeSingle();

  // An allowlisted address counts as an operator here, because it already
  // counts as one at the console door. Without this the two gates disagree:
  // requireOwner lets an owner into the console, and this bounced them to
  // the learner dashboard the moment they tried to do anything — which is
  // exactly what "Create and start writing" did.
  const owner = isOwnerEmail(user.email);
  const effective = owner && roles.includes("operator") ? "operator" : profile?.role;

  if (!effective || !roles.includes(effective)) redirect("/dashboard");

  return { userId: user.id, role: effective };
}

/**
 * Role AND ownership. A role check alone lets any instructor edit any
 * course, since the course/module/topic/material id is just a client-
 * supplied identifier once past that gate. Operators can act on any course.
 */
/**
 * Yours, and still editable.
 *
 * A course is written during creation and fixed once it leaves. The editor
 * already hid its inputs on a published course, but this — the server side —
 * only checked ownership, so a crafted request could still rewrite a course
 * people had bought. Both halves of the rule live here now, because the half
 * in the UI was never the one enforcing anything.
 *
 * revision_requested counts as editable: that state exists precisely to send
 * a course back for changes.
 */
const EDITABLE_STATES = ["draft", "revision_requested"];

async function requireCourseAccess(
  courseId: string,
  opts: { allowPublished?: boolean } = {},
): Promise<{ userId: string; role: string }> {
  const { userId, role } = await requireRole(["instructor", "operator", "institution_admin"]);

  const admin = createAdminClient();
  const { data: course } = await admin
    .from("courses").select("id, instructor_id, state").eq("id", courseId).maybeSingle();

  // An operator bounced out of an edit belongs back in the console, not in
  // a studio they do not use.
  const backTo = role === "operator" ? "/console/catalogue"
    : role === "institution_admin" ? "/institution/courses"
    : "/studio";
  if (!course) redirect(backTo);

  // An operator can reach any course, but not edit a live one either — the
  // point of the rule is that a published course does not change underneath
  // the people who bought it.
  // An institution admin owns their organisation's courses without being
  // the named assessor on them, so ownership is checked by institution.
  if (role === "institution_admin") {
    const { data: mine } = await admin
      .from("institution_members").select("institution_id").eq("user_id", userId).maybeSingle();
    const { data: full } = await admin
      .from("courses").select("institution_id").eq("id", courseId).maybeSingle();
    if (!mine || full?.institution_id !== mine.institution_id) redirect(backTo);
  } else if (role !== "operator" && course.instructor_id !== userId) {
    redirect(backTo);
  }
  /* Archiving is the exception to the editable-state rule, and the
   * reason 0032/0033 exist: a published course cannot be edited, but a
   * module can be withdrawn from it without changing what anyone who
   * already started is reading. Everything else still refuses. */
  if (!opts.allowPublished && !EDITABLE_STATES.includes(course.state)) {
    redirect(`${backTo}?error=locked`);
  }

  return { userId, role };
}

/**
 * Ownership for removal.
 *
 * requireCourseAccess cannot be used here: it refuses anything that is not
 * a draft, and retiring a published course is exactly the case that needs
 * to pass. So this checks who owns the course and nothing about its state
 * — the state rules live in delete_draft_course and retire_course.
 */
async function requireCourseRemoval(courseId: string): Promise<{ userId: string; role: string }> {
  const { userId, role } = await requireRole(["instructor", "operator", "institution_admin"]);
  const admin = createAdminClient();

  const { data: course } = await admin
    .from("courses").select("instructor_id, institution_id").eq("id", courseId).maybeSingle();
  if (!course) redirect("/studio");

  if (role === "institution_admin") {
    const { data: mine } = await admin
      .from("institution_members").select("institution_id").eq("user_id", userId).maybeSingle();
    if (!mine || course.institution_id !== mine.institution_id) redirect("/institution/courses");
  } else if (role !== "operator" && course.instructor_id !== userId) {
    redirect("/studio");
  }

  return { userId, role };
}

async function courseIdForModule(moduleId: string): Promise<string> {
  const admin = createAdminClient();
  const { data } = await admin.from("modules").select("course_id").eq("id", moduleId).maybeSingle();
  if (!data) redirect("/studio");
  return data.course_id;
}

async function courseIdForTopic(topicId: string): Promise<string> {
  const admin = createAdminClient();
  const { data: topic } = await admin
    .from("topics").select("module_id").eq("id", topicId).maybeSingle();
  if (!topic) redirect("/studio");
  return courseIdForModule(topic.module_id);
}

async function courseIdForMaterial(materialId: string): Promise<string> {
  const admin = createAdminClient();
  const { data: material } = await admin
    .from("topic_materials").select("topic_id").eq("id", materialId).maybeSingle();
  if (!material) redirect("/studio");
  return courseIdForTopic(material.topic_id);
}

/* ------------------------------------------------------------------ */
/* Applying to teach                                                   */
/* ------------------------------------------------------------------ */
export async function saveIntro(_prev: FormState, formData: FormData): Promise<FormState> {
  const { userId } = await requireRole(["instructor", "operator"]);

  const bio = String(formData.get("bio") ?? "").trim();
  const experience = String(formData.get("experience") ?? "").trim();

  const admin = createAdminClient();
  const { data: existing } = await admin
    .from("instructors").select("headline").eq("id", userId).maybeSingle();

  await admin.rpc("save_instructor_intro", {
    p_user_id: userId,
    p_headline: existing?.headline ?? "",
    p_bio: bio,
    p_experience: experience,
  });

  revalidatePath("/studio");
  redirect("/studio");
  return {};
}

export async function setNudge(off: boolean): Promise<void> {
  const { userId } = await requireRole(["instructor", "operator"]);
  const admin = createAdminClient();
  await admin.rpc("set_nudge", { p_user_id: userId, p_nudge: off ? "off" : "weekly" });
  revalidatePath("/studio");
}

export async function dismissNudge(): Promise<void> {
  const { userId } = await requireRole(["instructor", "operator"]);
  const admin = createAdminClient();
  await admin.rpc("mark_nudge_shown", { p_user_id: userId });
  revalidatePath("/studio");
}

export async function completeCreatorCourse(): Promise<void> {
  const { userId } = await requireRole(["instructor", "operator"]);
  const admin = createAdminClient();
  await admin.from("instructors")
    .update({ creator_course_done_at: new Date().toISOString() }).eq("id", userId);
  revalidatePath("/studio");
}

export async function decideApplication(
  instructorId: string,
  approve: boolean,
  _prev: FormState,
  formData: FormData
): Promise<FormState> {
  const { userId } = await requireRole(["operator"]);
  const note = String(formData.get("note") ?? "").trim();

  const admin = createAdminClient();
  const { data: ok } = await admin.rpc("decide_application", {
    p_instructor_id: instructorId,
    p_operator_id: userId,
    p_approve: approve,
    p_note: note || null,
  });

  if (!ok) return { error: "That application has already been decided." };

  revalidatePath("/admin/applications");
  return { ok: true, message: approve ? "Approved." : "Declined." };
}

/* ------------------------------------------------------------------ */
/* Curriculum                                                          */
/* ------------------------------------------------------------------ */
export async function createCourse(_prev: FormState, formData: FormData): Promise<FormState> {
  const { userId, role } = await requireRole(["instructor", "operator", "institution_admin"]);

  const title = String(formData.get("title") ?? "").trim();
  const subject = String(formData.get("subject") ?? "").trim();
  const level = String(formData.get("level") ?? "beginner");
  const hoursLow = Number(formData.get("hours_low") ?? 0);
  const hoursHigh = Number(formData.get("hours_high") ?? 0);
  const summary = String(formData.get("summary") ?? "").trim();
  // The shape picker is gone; a course starts empty and the instructor builds
  // it on the next screen. The column and the lookup stay so existing
  // template-seeded courses keep working and the picker can come back.
  const templateId = String(formData.get("template") ?? "blank");

  /* Who owns it, and who assesses it.
   *
   * Only an operator gets the choice; an instructor creating a course owns
   * it and assesses it, which is the whole arrangement. Read from the role
   * rather than the form — a hidden field saying "splari" would otherwise be
   * a way for anyone to publish under Your Brand's name and skip the price.
   */
  const isOperator = role === "operator";
  const isInstitution = role === "institution_admin";

  // An institution admin only ever authors for their institution — there is
  // no second option to offer, so there is no form field to trust.
  let institutionId: string | null = null;
  if (isInstitution) {
    const { data: member } = await createAdminClient()
      .from("institution_members").select("institution_id")
      .eq("user_id", userId).maybeSingle();
    if (!member) return { error: "Your account is not attached to an organisation." };
    institutionId = member.institution_id as string;
  }

  const ownerKind = isInstitution
    ? "institution"
    : isOperator && formData.get("owner") === "splari"
      ? "splari" : "instructor";

  let assessorId = userId;
  if (ownerKind === "institution") {
    const picked = String(formData.get("assessor") ?? "").trim();
    if (!picked) return { error: "Choose who assesses this course." };

    const { data: eligible } = await createAdminClient()
      .rpc("institution_assessors", { p_institution_id: institutionId });
    if (!(eligible ?? []).some((a: { id: string }) => a.id === picked)) {
      return { error: "That person cannot be assigned as an assessor." };
    }
    assessorId = picked;
  } else if (ownerKind === "splari") {
    const picked = String(formData.get("assessor") ?? "").trim();
    if (!picked) return { error: "Choose who assesses this course." };

    // Verified against the list rather than trusted: instructor_id decides
    // who is assigned every submission and whose name goes on the
    // certificate, so it cannot be an arbitrary id from a form.
    //
    // One person the list cannot vouch for: the caller themself. An
    // allowlisted owner counts as an operator here, but eligible_assessors
    // reads the role column and the allowlist lives in the environment —
    // so the RPC returns nothing in a database with no practitioners and
    // no operator profiles, and this check rejected the only assessor
    // available. Naming yourself widens nothing: requireRole has already
    // established who you are, and you can still only reach beyond the
    // list to your own id, never to an arbitrary one.
    const { data: eligible } = await createAdminClient().rpc("eligible_assessors");
    const listed = (eligible ?? []).some((a: { id: string }) => a.id === picked);
    if (!listed && picked !== userId) {
      return { error: "That person cannot be assigned as an assessor." };
    }
    assessorId = picked;
  }

  if (title.length < 6) return { error: "Give the course a fuller title." };
  if (!subject) return { error: "Choose a subject." };


  const slug =
    title.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "").slice(0, 60) +
    "-" + Math.random().toString(36).slice(2, 6);

  const admin = createAdminClient();
  const { data: template } = await admin
    .from("course_templates").select("*").eq("id", templateId).maybeSingle();

  const { data, error } = await admin
    .from("courses")
    .insert({
      instructor_id: assessorId, slug, title, subject,
      level,
      state: "draft", template_id: templateId,
      project_brief: template?.brief_hint ?? null,
      // Written by a practitioner, so it is theirs to sell. A price set here
      // is a proposal — it is looked at with the course before either goes
      // live, which is what price_state records.
      owner_kind: ownerKind,
      institution_id: institutionId,
    })
    .select("id, slug").maybeSingle();

  if (error || !data) {
    // The user-facing message stays generic, but the cause must not vanish:
    // a foreign-key violation hid behind this exact string for weeks and
    // presented as "creating a course silently doesn't work".
    console.error("createCourse: insert failed", {
      ownerKind, assessorId, code: error?.code, message: error?.message, details: error?.details,
    });
    return { error: "Could not create the course. Please try again." };
  }

  // Seed the shape. An empty course is the thing that stops people finishing.
  const shape = (template?.shape ?? []) as { module: string; topics: string[] }[];
  for (let mi = 0; mi < shape.length; mi++) {
    const { data: mod } = await admin
      .from("modules")
      .insert({ course_id: data.id, position: mi + 1, title: shape[mi].module })
      .select("id").maybeSingle();
    if (!mod) continue;

    const rows = shape[mi].topics.map((t, ti) => ({
      module_id: mod.id, position: ti + 1, title: t, body: "",
    }));
    if (rows.length) await admin.from("topics").insert(rows);
  }

  const criteria = (template?.criteria ?? []) as { title: string; descriptor: string }[];
  if (criteria.length) {
    await admin.from("rubric_criteria").insert(
      criteria.map((c, i) => ({
        course_id: data.id, position: i + 1,
        title: c.title, descriptor: c.descriptor, max_score: 5,
      }))
    );
  }

  // Back to the surface they came from. An operator who started in the
  // console should not land in the studio to finish the job.
  // Back to whichever surface they authored from.
  redirect(
    ownerKind === "institution" ? `/institution/courses/${data.slug}`
      : ownerKind === "splari"   ? `/console/catalogue/${data.slug}`
      : `/studio/${data.slug}`
  );
  return {};
}

export async function saveCourseDetails(
  courseId: string, slug: string, _prev: FormState, formData: FormData
): Promise<FormState> {
  await requireCourseAccess(courseId);
  const admin = createAdminClient();

  const patch = {
    title: String(formData.get("title") ?? "").trim(),
    summary: String(formData.get("summary") ?? "").trim(),
    project_brief: String(formData.get("project_brief") ?? "").trim(),
  };
  if (patch.title.length < 6) return { error: "Give the course a fuller title." };

  const { error } = await admin.from("courses").update(patch).eq("id", courseId);
  if (error) return { error: "Could not save. Please try again." };

  revalidatePath(`/studio/${slug}`);
  return { ok: true, message: "Saved." };
}

/**
 * The listing: what a learner sees before they decide, and what it costs.
 *
 * Moved off the creation form, where it was being asked before a single topic
 * existed. Autosaves like the rest of the editor, which is also why price and
 * is_free are handled together — they are mutually exclusive in the database,
 * so a save that set one has to clear the other or the write is rejected.
 */
export async function saveListing(
  courseId: string, slug: string, _prev: FormState, formData: FormData
): Promise<FormState> {
  await requireCourseAccess(courseId);

  const admin = createAdminClient();

  // An institution course cannot carry a price — it is written by an
  // organisation for its own people and reached through membership, and
  // the check constraint refuses one. Writing the fields anyway made this
  // save fail whole, taking the hours and outcomes down with it, behind a
  // generic "could not save".
  //
  // Your Brand-authored courses ARE sellable as of 0063. They were excluded
  // here when the subscription covered them; leaving that in place would
  // mean the price field never appears on one, and 0064 then refuses to
  // publish it — a course that can never go live and no way to see why.
  const { data: owned } = await admin
    .from("courses").select("owner_kind").eq("id", courseId).maybeSingle();
  const sellable = owned?.owner_kind !== "institution";

  const hoursLow = Number(formData.get("hours_low") ?? 0);
  const hoursHigh = Number(formData.get("hours_high") ?? 0);
  const isFree = formData.get("is_free") === "on";

  const priceRaw = String(formData.get("price") ?? "").trim();
  const priceCents = priceRaw
    ? Math.round(Number(priceRaw.replace(/[^0-9.]/g, "")) * 100)
    : null;

  const outcomes = formData.getAll("outcome").map(String).map((v) => v.trim()).filter(Boolean);
  const includes = formData.getAll("include").map(String).map((v) => v.trim()).filter(Boolean);

  if (hoursLow && hoursHigh && hoursHigh < hoursLow) {
    return { error: "Hours: lowest first." };
  }
  if (sellable && !isFree && priceCents !== null) {
    if (!Number.isFinite(priceCents) || priceCents < 3000) {
      return { error: "The lowest price is $30 — a sale has to cover the assessment inside it." };
    }
  }

  const { error } = await admin.from("courses").update({
    hours_low: hoursLow || null,
    hours_high: hoursHigh || null,
    outcomes, includes,
    ...(sellable
      ? {
          is_free: isFree,
          // Free and priced cannot both be true; the constraint refuses it,
          // so the save decides rather than leaving the two to disagree.
          price_cents: isFree ? null : priceCents,
          price_state: isFree || priceCents === null ? "unset" : "proposed",
        }
      : {}),
  }).eq("id", courseId);

  if (error) {
    console.error("saveListing: update failed", { courseId, code: error.code, message: error.message });
    return { error: "Could not save that." };
  }
  revalidatePath(`/studio/${slug}`);
  revalidatePath(`/courses/${slug}`);
  return { ok: true };
}

export async function addModule(courseId: string, slug: string): Promise<void> {
  await requireCourseAccess(courseId);
  const admin = createAdminClient();

  const { count } = await admin
    .from("modules").select("id", { count: "exact", head: true }).eq("course_id", courseId);

  await admin.from("modules").insert({
    course_id: courseId, position: (count ?? 0) + 1, title: `Module ${(count ?? 0) + 1}`,
  });
  revalidatePath(`/studio/${slug}`);
}

export async function addTopic(moduleId: string, slug: string): Promise<void> {
  await requireCourseAccess(await courseIdForModule(moduleId));
  const admin = createAdminClient();

  const { count } = await admin
    .from("topics").select("id", { count: "exact", head: true }).eq("module_id", moduleId);

  await admin.from("topics").insert({
    module_id: moduleId, position: (count ?? 0) + 1, title: "New topic", body: "",
  });
  revalidatePath(`/studio/${slug}`);
}

export async function saveTopic(
  topicId: string, slug: string, _prev: FormState, formData: FormData
): Promise<FormState> {
  await requireCourseAccess(await courseIdForTopic(topicId));

  const title = String(formData.get("title") ?? "").trim();
  const body = String(formData.get("body") ?? "");
  const transcript = String(formData.get("transcript") ?? "").trim() || null;

  if (title.length < 3) return { error: "The topic needs a title." };

  const admin = createAdminClient();

  // Video needs a transcript. It is what makes the topic usable on a weak
  // connection, and the first thing an institutional buyer asks about.
  const { data: video } = await admin
    .from("topic_materials").select("id").eq("topic_id", topicId).eq("kind", "video").limit(1);

  if (video && video.length > 0 && !transcript) {
    return {
      error: "This topic has a video, so it needs a transcript. It is an accessibility commitment, not a nice-to-have.",
    };
  }

  const { error } = await admin
    .from("topics").update({ title, body, transcript }).eq("id", topicId);

  if (error) return { error: "Could not save this topic." };
  revalidatePath(`/studio/${slug}`);
  return { ok: true, message: "Saved." };
}

export async function addQuizItem(
  topicId: string, slug: string, _prev: FormState, formData: FormData
): Promise<FormState> {
  await requireCourseAccess(await courseIdForTopic(topicId));

  const prompt = String(formData.get("prompt") ?? "").trim();
  const explanation = String(formData.get("explanation") ?? "").trim();
  const options = ["a", "b", "c", "d"]
    .map((id) => ({ id, text: String(formData.get(`opt_${id}`) ?? "").trim() }))
    .filter((o) => o.text);
  const correct = String(formData.get("correct") ?? "");

  if (prompt.length < 10) return { error: "Write the question out in full." };
  if (options.length < 2) return { error: "At least two options." };
  if (!options.some((o) => o.id === correct)) return { error: "Mark which option is correct." };

  const admin = createAdminClient();
  const { error } = await admin.from("quiz_items").insert({
    topic_id: topicId, prompt, options, correct: [correct],
    explanation: explanation || null,
  });

  if (error) return { error: "Could not add the question." };
  revalidatePath(`/studio/${slug}`);
  return { ok: true, message: "Question added." };
}

/* ------------------------------------------------------------------ */
/* The final exam                                                      */
/* ------------------------------------------------------------------ */
export async function addExamItem(
  courseId: string, slug: string, _prev: FormState, formData: FormData
): Promise<FormState> {
  await requireCourseAccess(courseId);

  const prompt = String(formData.get("prompt") ?? "").trim();
  const explanation = String(formData.get("explanation") ?? "").trim();
  const options = ["a", "b", "c", "d"]
    .map((id) => ({ id, text: String(formData.get(`opt_${id}`) ?? "").trim() }))
    .filter((o) => o.text);
  const correct = String(formData.get("correct") ?? "");

  if (prompt.length < 10) return { error: "Write the question out in full." };
  if (options.length < 2) return { error: "At least two options." };
  if (!options.some((o) => o.id === correct)) return { error: "Mark which option is correct." };

  const admin = createAdminClient();
  // Appended, so the order an instructor writes them in is the order a
  // learner sits them in.
  const { count } = await admin
    .from("exam_items").select("id", { count: "exact", head: true }).eq("course_id", courseId);

  const { error } = await admin.from("exam_items").insert({
    course_id: courseId, position: (count ?? 0) + 1, prompt, options,
    correct: [correct], explanation: explanation || null,
  });

  if (error) return { error: "Could not add the question." };
  revalidatePath(`/studio/${slug}`);
  return { ok: true, message: "Question added." };
}

/**
 * Archiving, for a course that is already live.
 *
 * The only structural change a published course allows, so it does not go
 * through requireCourseAccess — that refuses anything but a draft, which is
 * the correct rule for every other edit and the wrong one here. Ownership is
 * checked inside the database function instead, which is also where the rule
 * about who may do it belongs.
 */
/* Archiving on a published course.
 *
 * Both of these passed the caller's own id to a function that checks it
 * against the course's instructor_id — the same mistake submitForReview
 * carried. It held only while author and assessor were always the same
 * person. On a Your Brand course with a staff assessor, or an institution
 * course, the person who wrote it could not archive their own module:
 * the RPC answered 'not_yours' and the action swallowed it, so the
 * control did nothing at all and said nothing.
 *
 * requireCourseAccess establishes who may touch this course — including
 * an institution admin, who was missing from the role list entirely —
 * and the course's own assessor id is what the gate function is given.
 */
export async function archiveTopic(topicId: string, slug: string): Promise<void> {
  const courseId = await courseIdForTopic(topicId);
  await requireCourseAccess(courseId, { allowPublished: true });

  const admin = createAdminClient();
  const { data: course } = await admin
    .from("courses").select("instructor_id").eq("id", courseId).maybeSingle();
  if (!course) redirect("/studio");

  const { data } = await admin.rpc("archive_topic", {
    p_topic_id: topicId, p_instructor_id: course.instructor_id,
  });
  const row = (data ?? [])[0] as { ok: boolean; reason: string | null } | undefined;
  if (!row?.ok) console.error("archiveTopic refused", topicId, row?.reason);

  revalidatePath(`/studio/${slug}`);
  revalidatePath(`/courses/${slug}`);
}

export async function archiveModule(moduleId: string, slug: string): Promise<void> {
  const courseId = await courseIdForModule(moduleId);
  await requireCourseAccess(courseId, { allowPublished: true });

  const admin = createAdminClient();
  const { data: course } = await admin
    .from("courses").select("instructor_id").eq("id", courseId).maybeSingle();
  if (!course) redirect("/studio");

  const { data } = await admin.rpc("archive_module", {
    p_module_id: moduleId, p_instructor_id: course.instructor_id,
  });
  const row = (data ?? [])[0] as { ok: boolean; reason: string | null } | undefined;
  if (!row?.ok) console.error("archiveModule refused", moduleId, row?.reason);

  revalidatePath(`/studio/${slug}`);
  revalidatePath(`/courses/${slug}`);
}

export async function removeExamItem(itemId: string, slug: string): Promise<void> {
  const admin = createAdminClient();
  const { data: item } = await admin
    .from("exam_items").select("course_id").eq("id", itemId).maybeSingle();
  if (!item) redirect("/studio");

  await requireCourseAccess(item.course_id);
  await admin.from("exam_items").delete().eq("id", itemId);
  revalidatePath(`/studio/${slug}`);
}

/**
 * The project switch.
 *
 * Turning it off changes what a certificate on this course means — it becomes
 * one that says "passed the examination" with nobody's name on it. That is a
 * real decision, so the UI states it rather than presenting this as a
 * formatting preference.
 */
export async function setRequiresProject(
  courseId: string, slug: string, requires: boolean
): Promise<void> {
  await requireCourseAccess(courseId);
  const admin = createAdminClient();
  await admin.from("courses").update({ requires_project: requires }).eq("id", courseId);
  revalidatePath(`/studio/${slug}`);
}

/* ------------------------------------------------------------------ */
/* Removing things                                                     */
/*                                                                     */
/* Only reachable on a draft, which is what makes them safe: a course   */
/* nobody has started has no completions, notes or quiz attempts to     */
/* cascade into. On a published course the guard above refuses before   */
/* any of this runs.                                                    */
/* ------------------------------------------------------------------ */
export async function removeModule(moduleId: string, slug: string): Promise<void> {
  await requireCourseAccess(await courseIdForModule(moduleId));
  const admin = createAdminClient();
  // Topics, their quiz items and materials go with it, by cascade.
  await admin.from("modules").delete().eq("id", moduleId);
  revalidatePath(`/studio/${slug}`);
}

export async function removeTopic(topicId: string, slug: string): Promise<void> {
  await requireCourseAccess(await courseIdForTopic(topicId));
  const admin = createAdminClient();
  await admin.from("topics").delete().eq("id", topicId);
  revalidatePath(`/studio/${slug}`);
}

export async function removeQuizItem(itemId: string, slug: string): Promise<void> {
  const admin = createAdminClient();
  const { data: item } = await admin
    .from("quiz_items").select("topic_id").eq("id", itemId).maybeSingle();
  if (!item) redirect("/studio");

  await requireCourseAccess(await courseIdForTopic(item.topic_id));
  await admin.from("quiz_items").delete().eq("id", itemId);
  revalidatePath(`/studio/${slug}`);
}

export async function removeCriterion(criterionId: string, slug: string): Promise<void> {
  const admin = createAdminClient();
  const { data: row } = await admin
    .from("rubric_criteria").select("course_id").eq("id", criterionId).maybeSingle();
  if (!row) redirect("/studio");

  await requireCourseAccess(row.course_id);
  await admin.from("rubric_criteria").delete().eq("id", criterionId);
  revalidatePath(`/studio/${slug}`);
}

export async function addCriterion(
  courseId: string, slug: string, _prev: FormState, formData: FormData
): Promise<FormState> {
  await requireCourseAccess(courseId);

  const title = String(formData.get("title") ?? "").trim();
  const descriptor = String(formData.get("descriptor") ?? "").trim();

  if (title.length < 4) return { error: "Name the criterion." };
  if (descriptor.length < 40) {
    return {
      error:
        "Be specific enough that two reviewers would reach the same verdict from it. That is the whole point of the rubric.",
    };
  }

  const admin = createAdminClient();
  const { count } = await admin
    .from("rubric_criteria").select("id", { count: "exact", head: true }).eq("course_id", courseId);

  const { error } = await admin.from("rubric_criteria").insert({
    course_id: courseId, position: (count ?? 0) + 1, title, descriptor, max_score: 5,
  });

  if (error) return { error: "Could not add the criterion." };
  revalidatePath(`/studio/${slug}`);
  return { ok: true, message: "Criterion added." };
}

const GATE_REASONS: Record<string, string> = {
  not_yours: "That course is not yours.",
  wrong_state: "This course is not in a state that can be submitted.",
  no_thumbnail: "Add a thumbnail. A course without one does not get clicked.",
  no_hours: "Set an hours range so learners know what they are committing to.",
  too_few_topics: "A course needs at least three topics.",
  empty_topics: "Every topic needs either some writing or a material attached. Empty pages are the thing learners complain about.",
  too_few_questions: "Add at least three quiz questions across the course.",
  too_few_exam_questions:
    "The final exam needs at least five questions. Four right out of five is what 80% has to mean.",
  no_price:
    "Set a price, or mark the course free. Without one a learner has no way to reach it — it would sit in the catalogue as neither buyable nor readable.",
  price_below_minimum:
    "The lowest price is $30. The assessment inside every sale costs $18.85 to pay for, so anything under that loses money on each certificate it issues.",
  brief_too_short: "The project brief needs to be a proper brief — at least a short paragraph.",
  rubric_too_thin: "Add at least two rubric criteria. This is what makes your assessment defensible.",
  malformed_options:
    "One of your questions has options the exam cannot show — each needs its own label and its own text. Open the question and re-enter the options.",
  duplicate_option_ids:
    "A question has two options sharing the same label, so the right answer is ambiguous. Re-enter that question's options.",
  answer_not_in_options:
    "A question's correct answer is not one of its options, which makes it impossible to pass. Open the exam and mark the answer again.",
};

export async function submitForReview(courseId: string, slug: string): Promise<FormState> {
  await requireCourseAccess(courseId);
  const admin = createAdminClient();

  // The gate function checks the id it is given against the course's own
  // instructor_id, so it must be given the course's own instructor_id.
  // Passing the caller's id worked only while author and assessor were
  // always the same person — a Your Brand course with a staff assessor made
  // the course unsubmittable by the person who wrote it.
  const { data: course } = await admin
    .from("courses").select("instructor_id").eq("id", courseId).maybeSingle();
  if (!course) return { error: "Could not submit." };

  const { data } = await admin.rpc("submit_course_for_review", {
    p_course_id: courseId, p_instructor_id: course.instructor_id,
  });

  const row = (data ?? [])[0] as { ok: boolean; reason: string | null } | undefined;
  if (!row?.ok) return { error: GATE_REASONS[row?.reason ?? ""] ?? "Could not submit." };

  revalidatePath(`/studio/${slug}`);
  return { ok: true, message: "Sent for review. We will come back within five working days." };
}

/**
 * Publish without the review hop, for courses where review would be the
 * author approving themself.
 *
 * The in_review pause exists so Your Brand can read a practitioner's course
 * before it ships under Your Brand's roof. A Your Brand course written from the
 * console is Your Brand reading Your Brand; an institution course is private
 * material Your Brand has no business reviewing at all — and had no path to
 * publish, since decide_course is operator-only. Both now publish
 * directly, through the identical quality gate: submit_course_for_review
 * runs every check (thumbnail, hours, topics, quiz, exam, brief, rubric)
 * and only if it passes does decide_course flip the state. An instructor
 * course is refused here — its road still runs through review.
 */
export async function publishOwnCourse(courseId: string, slug: string): Promise<FormState> {
  const { userId, role } = await requireCourseAccess(courseId);
  const admin = createAdminClient();

  const { data: course } = await admin
    .from("courses").select("instructor_id, owner_kind").eq("id", courseId).maybeSingle();
  if (!course) return { error: "Could not publish." };

  /* Review exists so that Your Brand reads a practitioner's course before it
   * ships under Your Brand's name. Where the author and the only possible
   * reviewer are the same person, that is not a check — it is the author
   * walking to another screen to approve themselves.
   *
   * Three cases where that holds, and the third is narrow on purpose: an
   * operator publishing their OWN instructor course. A practitioner who
   * is not staff still goes through review, because for them the reader
   * is genuinely someone else. The quality gate is identical either way —
   * submit_course_for_review runs every check below before anything is
   * published, so what is skipped is the hop, not the standard. */
  const allowed =
    (course.owner_kind === "splari" && role === "operator") ||
    (course.owner_kind === "institution" && (role === "institution_admin" || role === "operator")) ||
    (course.owner_kind === "instructor" && role === "operator" && course.instructor_id === userId);
  if (!allowed) return { error: "This course goes through review instead." };

  const { data } = await admin.rpc("submit_course_for_review", {
    p_course_id: courseId, p_instructor_id: course.instructor_id,
  });
  const row = (data ?? [])[0] as { ok: boolean; reason: string | null } | undefined;
  if (!row?.ok) return { error: GATE_REASONS[row?.reason ?? ""] ?? "Could not publish." };

  const { data: ok } = await admin.rpc("decide_course", {
    p_course_id: courseId, p_publish: true, p_note: null,
  });
  if (!ok) return { error: "Could not publish. Please try again." };

  revalidatePath(`/studio/${slug}`);
  revalidatePath("/console/catalogue");
  revalidatePath("/institution/courses");
  return { ok: true, message: "Published." };
}

export async function decideCourse(
  courseId: string, publish: boolean, _prev: FormState, formData: FormData
): Promise<FormState> {
  await requireRole(["operator"]);
  const note = String(formData.get("note") ?? "").trim();

  const admin = createAdminClient();
  const { data: ok } = await admin.rpc("decide_course", {
    p_course_id: courseId, p_publish: publish, p_note: note || null,
  });

  if (!ok) return { error: "That course is not awaiting a decision." };

  revalidatePath("/admin/courses");
  return { ok: true, message: publish ? "Published." : "Sent back for revision." };
}

/* ------------------------------------------------------------------ */
/* Removing a course                                                    */
/* ------------------------------------------------------------------ */
const REMOVE_REASONS: Record<string, string> = {
  no_course: "That course no longer exists.",
  not_draft:
    "Only a draft can be deleted. Retire it instead — that stops it being listed or sold and keeps every certificate it has already issued.",
  has_learners:
    "Somebody has already started this course, so deleting it would take their progress with it. Retire it instead.",
  has_purchases: "Somebody has bought this course. Retire it instead of deleting it.",
  has_licences: "An institution holds a licence for this course. Retire it instead.",
  already_retired: "That course is already retired.",
  not_published: "Only a live course can be retired.",
};

/**
 * Delete a draft, retire a live one.
 *
 * Deliberately two verbs rather than one. Deleting a course cascades to
 * enrolments and from there to certificates, so a delete on anything
 * people have touched would erase credentials rather than withdraw a
 * course. 0048 refuses that in the database; these are the doors.
 */
export async function deleteCourse(courseId: string): Promise<FormState> {
  const { userId, role } = await requireCourseRemoval(courseId);
  void userId;
  void role;

  const admin = createAdminClient();
  const { data } = await admin.rpc("delete_draft_course", { p_course_id: courseId });
  const row = (data ?? [])[0] as { ok: boolean; reason: string | null } | undefined;
  if (!row?.ok) return { error: REMOVE_REASONS[row?.reason ?? ""] ?? "Could not delete that course." };

  revalidatePath("/studio");
  revalidatePath("/console/catalogue");
  revalidatePath("/institution/courses");
  return { ok: true, message: "Deleted." };
}

export async function retireCourse(courseId: string): Promise<FormState> {
  const { userId } = await requireCourseRemoval(courseId);

  const admin = createAdminClient();
  const { data } = await admin.rpc("retire_course", {
    p_course_id: courseId, p_actor: userId,
  });
  const row = (data ?? [])[0] as { ok: boolean; reason: string | null } | undefined;
  if (!row?.ok) return { error: REMOVE_REASONS[row?.reason ?? ""] ?? "Could not retire that course." };

  revalidatePath("/studio");
  revalidatePath("/console/catalogue");
  revalidatePath("/institution/courses");
  revalidatePath("/courses");
  return { ok: true, message: "Retired. It is no longer listed, and nothing already issued has changed." };
}

export async function setAvailability(available: boolean): Promise<void> {
  const { userId } = await requireRole(["instructor", "operator"]);
  const admin = createAdminClient();
  await admin.from("instructors").update({ available }).eq("id", userId);
  revalidatePath("/studio");
}

/* ------------------------------------------------------------------ */
/* Departure                                                           */
/* ------------------------------------------------------------------ */
export async function instructorDeparts(
  instructorId: string,
  forCause: boolean,
  _prev: FormState,
  formData: FormData
): Promise<FormState> {
  await requireRole(["operator"]);
  const note = String(formData.get("note") ?? "").trim();

  const admin = createAdminClient();
  const { data: released, error } = await admin.rpc("instructor_departs", {
    p_instructor_id: instructorId,
    p_for_cause: forCause,
  });

  if (error) return { error: "Could not process the departure." };

  await admin.from("instructors").update({ decision_note: note || null }).eq("id", instructorId);

  revalidatePath("/admin/instructors");
  return {
    ok: true,
    message: `Done. ${released ?? 0} open review${released === 1 ? "" : "s"} released back to the queue. Existing learners keep access; courses are closed to new enrolments.`,
  };
}

/* ------------------------------------------------------------------ */
/* Materials — a topic is a video and notes and a worksheet            */
/* ------------------------------------------------------------------ */
const MATERIAL_TYPES: Record<string, string[]> = {
  pdf: ["application/pdf"],
  slides: [
    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    "application/pdf",
  ],
  download: [
    "application/pdf", "text/plain", "text/csv",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/zip",
  ],
  audio: ["audio/mpeg", "audio/mp4", "audio/wav"],
};

const MATERIAL_MAX_BYTES = 100 * 1024 * 1024;

export async function addMaterial(
  topicId: string, slug: string, _prev: FormState, formData: FormData
): Promise<FormState> {
  const { userId } = await requireCourseAccess(await courseIdForTopic(topicId));

  const kind = String(formData.get("kind") ?? "");
  const title = String(formData.get("title") ?? "").trim();
  if (!title) return { error: "Give the material a name learners will understand." };

  const admin = createAdminClient();
  const { count } = await admin
    .from("topic_materials").select("id", { count: "exact", head: true }).eq("topic_id", topicId);
  const position = (count ?? 0) + 1;

  // Links and hosted video are references, not uploads.
  if (kind === "link" || kind === "video") {
    const url = String(formData.get("url") ?? "").trim();
    if (!url) {
      return {
        error: kind === "video"
          ? "Paste the video ID or URL from your video library."
          : "Paste the link.",
      };
    }
    const { error } = await admin.from("topic_materials")
      .insert({ topic_id: topicId, kind, title, url, position });
    if (error) return { error: "Could not add that." };
    revalidatePath(`/studio/${slug}`);
    return { ok: true, message: "Added." };
  }

  const file = formData.get("file");
  if (!(file instanceof File) || file.size === 0) return { error: "Choose a file." };
  if (file.size > MATERIAL_MAX_BYTES) return { error: "That file is over 100MB." };

  const allowed = MATERIAL_TYPES[kind];
  if (!allowed) return { error: "Choose what kind of material this is." };
  if (!allowed.includes(file.type)) {
    return { error: `That file type does not match "${kind}". Check the format.` };
  }

  const safe = file.name.replace(/[^a-zA-Z0-9._-]/g, "_").slice(-80);
  const path = `${userId}/${topicId}/${Date.now()}-${safe}`;

  const { error: upErr } = await admin.storage
    .from("materials").upload(path, file, { contentType: file.type });
  if (upErr) return { error: "Upload failed. Please try again." };

  const { error } = await admin.from("topic_materials").insert({
    topic_id: topicId, kind, title, path, size_bytes: file.size, position,
  });
  if (error) return { error: "Uploaded, but could not be saved. Try again." };

  revalidatePath(`/studio/${slug}`);
  return { ok: true, message: "Added." };
}

export async function removeMaterial(materialId: string, slug: string): Promise<void> {
  await requireCourseAccess(await courseIdForMaterial(materialId));
  const admin = createAdminClient();

  const { data: material } = await admin
    .from("topic_materials").select("path").eq("id", materialId).maybeSingle();

  if (material?.path) await admin.storage.from("materials").remove([material.path]);
  await admin.from("topic_materials").delete().eq("id", materialId);

  revalidatePath(`/studio/${slug}`);
}

/* ------------------------------------------------------------------ */
/* Thumbnails                                                          */
/* ------------------------------------------------------------------ */
const THUMB_TYPES = ["image/jpeg", "image/png", "image/webp"];
const THUMB_MAX = 5 * 1024 * 1024;

/**
 * The alt text on its own, so it can autosave.
 *
 * It used to ride on the upload form, which meant changing a description
 * required re-picking the image. Kept separate from uploadThumbnail rather
 * than made optional there: one function that sometimes uploads and
 * sometimes does not is the kind that eventually clears a thumbnail.
 */
export async function saveThumbnailAlt(
  courseId: string, slug: string, _prev: FormState, formData: FormData
): Promise<FormState> {
  await requireCourseAccess(courseId);

  const alt = String(formData.get("alt") ?? "").trim();
  if (alt && alt.length < 5) return { error: "A few more words — this is read aloud." };

  const admin = createAdminClient();
  const { error } = await admin
    .from("courses").update({ thumbnail_alt: alt || null }).eq("id", courseId);

  if (error) return { error: "Could not save that." };
  revalidatePath(`/studio/${slug}`);
  return { ok: true };
}

export async function uploadThumbnail(
  courseId: string, slug: string, _prev: FormState, formData: FormData
): Promise<FormState> {
  const { userId } = await requireCourseAccess(courseId);

  const file = formData.get("thumbnail");
  const alt = String(formData.get("alt") ?? "").trim();

  if (!(file instanceof File) || file.size === 0) return { error: "Choose an image." };
  if (file.size > THUMB_MAX) return { error: "That image is over 5MB. Compress it and try again." };
  if (!THUMB_TYPES.includes(file.type)) return { error: "JPEG, PNG or WebP." };
  if (alt.length < 5) {
    return { error: "Describe the image in a few words — screen readers and search both use it." };
  }

  const admin = createAdminClient();
  const ext = file.type === "image/png" ? "png" : file.type === "image/webp" ? "webp" : "jpg";
  const path = `${userId}/${courseId}-${Date.now()}.${ext}`;

  const { error: upErr } = await admin.storage
    .from("thumbnails").upload(path, file, { contentType: file.type, upsert: true });
  if (upErr) return { error: "Upload failed. Please try again." };

  // Remove the old one rather than leaving orphans in the bucket.
  const { data: existing } = await admin
    .from("courses").select("thumbnail_path").eq("id", courseId).maybeSingle();
  if (existing?.thumbnail_path) {
    await admin.storage.from("thumbnails").remove([existing.thumbnail_path]);
  }

  const { error } = await admin
    .from("courses").update({ thumbnail_path: path, thumbnail_alt: alt }).eq("id", courseId);
  if (error) return { error: "Uploaded, but could not be saved. Try again." };

  revalidatePath(`/studio/${slug}`);
  return { ok: true, message: "Thumbnail set." };
}
