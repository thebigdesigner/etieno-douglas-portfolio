/**
 * Where a "?next=" may send someone after they sign in.
 *
 * A relative path on this site, or an https URL on yourbrand.com or one of its
 * subdomains (the marketplace lives on one). Anything else — another host,
 * "//evil.com", a javascript: URL — is dropped, because an open redirect on
 * the login page is how phishing links borrow a real domain.
 */
export function safeNext(raw: unknown): string | null {
  if (typeof raw !== "string" || !raw) return null;
  if (raw.startsWith("/") && !raw.startsWith("//") && !raw.startsWith("/\\")) return raw;
  try {
    const u = new URL(raw);
    const root = (process.env.NEXT_PUBLIC_COOKIE_DOMAIN ?? ".yourbrand.com").replace(/^\./, "");
    if (u.protocol === "https:" && (u.hostname === root || u.hostname.endsWith(`.${root}`))) return u.toString();
  } catch { /* not a URL */ }
  return null;
}
