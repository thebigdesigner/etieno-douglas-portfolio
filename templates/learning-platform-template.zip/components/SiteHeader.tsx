import Link from "next/link";
import NavLinks from "@/components/NavLinks";
import MobileMenu from "@/components/MobileMenu";
import AuthNav from "@/components/AuthNav";
import AnnouncementBar from "@/components/AnnouncementBar";

export default function SiteHeader() {
  return (
    <>
      <AnnouncementBar />

      <nav className="nav">
        <div className="nav__in">
          <Link className="logo" href="/">Your Brand<span>.</span></Link>

          <NavLinks />
          <AuthNav />

          <MobileMenu />
        </div>
      </nav>
    </>
  );
}
