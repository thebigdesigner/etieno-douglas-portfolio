import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Browse, { type RawParams } from "@/components/marketplace/Browse";
import { categoryBySlug } from "@/lib/marketplace/categories";
import { marketBase } from "@/lib/marketplace/url";

type Props = { params: Promise<{ category: string }>; searchParams: Promise<RawParams> };

/** "all" is the whole catalogue; every other segment has to be a category. */
export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { category } = await params;
  if (category === "all") return { title: "All items" };
  const cat = categoryBySlug(category);
  return cat ? { title: cat.name, description: cat.blurb } : {};
}

export default async function CategoryPage({ params, searchParams }: Props) {
  const [{ category }, sp, base] = await Promise.all([params, searchParams, marketBase()]);
  if (category === "all") {
    return <Browse base={base} params={sp} title="All items" intro="Everything in the marketplace, most downloaded first." />;
  }
  const cat = categoryBySlug(category);
  if (!cat) notFound();
  return <Browse base={base} category={cat} params={sp} title={cat.name} intro={cat.blurb} />;
}
