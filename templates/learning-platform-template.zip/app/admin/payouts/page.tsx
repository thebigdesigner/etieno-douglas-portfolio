import { createAdminClient } from "@/lib/supabase/admin";
import PayoutForms from "./PayoutForms";

export const metadata = { title: "Pools and payouts" };
export const dynamic = "force-dynamic";

export default async function PayoutsPage() {
  const admin = createAdminClient();

  const { data: pools } = await admin
    .from("pool_periods").select("*").order("period_month", { ascending: false }).limit(8);

  const { data: runs } = await admin
    .from("payout_runs")
    .select("week_start, amount_cents, state, instructor_id")
    .order("week_start", { ascending: false }).limit(30);

  const byWeek = (runs ?? []).reduce<Record<string, { count: number; total: number }>>((acc, r) => {
    acc[r.week_start] ??= { count: 0, total: 0 };
    acc[r.week_start].count += 1;
    acc[r.week_start].total += r.amount_cents;
    return acc;
  }, {});

  return (
    <>
        <h1 className="sec__h" style={{ fontSize: 30, marginTop: 34 }}>Pools and payouts</h1>
        <p className="sec__meta">
          35% of subscription revenue and 30% of institutional, divided by completed
          topics. Instructors can audit this from their own dashboard, so it has to be right.
        </p>

        <PayoutForms />

        <section style={{ marginTop: 46 }}>
          <h2 className="sub__h2">Pools calculated</h2>
          {(!pools || pools.length === 0) ? (
            <p className="studio__hint" style={{ marginTop: 14 }}>None yet.</p>
          ) : (
            <table className="tbl" style={{ marginTop: 18 }}>
              <thead>
                <tr><th>Month</th><th>Source</th><th>Revenue</th><th>Pool</th><th>Completions</th><th>Per completion</th></tr>
              </thead>
              <tbody>
                {pools.map((p) => (
                  <tr key={`${p.period_month}-${p.source}`}>
                    <td>{new Date(p.period_month).toLocaleDateString(undefined, { month: "short", year: "numeric" })}</td>
                    <td>{p.source}</td>
                    <td className="num">${(p.revenue_cents / 100).toFixed(2)}</td>
                    <td className="num">${(p.pool_cents / 100).toFixed(2)}</td>
                    <td className="num">{p.completions}</td>
                    <td className="num">${(Number(p.rate_per_completion_cents) / 100).toFixed(4)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>

        <section style={{ margin: "46px 0 40px" }}>
          <h2 className="sub__h2">Payout runs</h2>
          {Object.keys(byWeek).length === 0 ? (
            <p className="studio__hint" style={{ marginTop: 14 }}>None yet.</p>
          ) : (
            <table className="tbl" style={{ marginTop: 18 }}>
              <thead><tr><th>Week</th><th>Instructors</th><th>Total</th></tr></thead>
              <tbody>
                {Object.entries(byWeek).map(([week, v]) => (
                  <tr key={week}>
                    <td>{new Date(week).toLocaleDateString()}</td>
                    <td className="num">{v.count}</td>
                    <td className="num">${(v.total / 100).toFixed(2)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>
      </>
  );
}
