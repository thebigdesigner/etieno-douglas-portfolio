-- =====================================================================
-- Learner dashboard — the numbers on the stat row and the course rows
-- =====================================================================

-- ---------------------------------------------------------------------
-- One row per learner. Start-to-completion is the honest version of a
-- completion rate: of the courses you began, how many did you finish.
-- ---------------------------------------------------------------------
create or replace view public.learner_stats as
select p.id,
       p.display_name,

       (select count(*) from enrolments e where e.user_id = p.id)              as courses_started,
       (select count(*) from enrolments e
         where e.user_id = p.id and e.state = 'certified')                     as courses_completed,

       round(100.0 * (select count(*) from enrolments e
                       where e.user_id = p.id and e.state = 'certified')
             / nullif((select count(*) from enrolments e where e.user_id = p.id), 0), 0)
                                                                                as completion_pct,

       -- Best attempt per topic, averaged. Retakes are unlimited, so counting
       -- every attempt would punish somebody for practising.
       (select round(avg(best), 0) from (
          select max(qa.score_pct) as best
            from quiz_attempts qa
            join enrolments e on e.id = qa.enrolment_id
           where e.user_id = p.id
           group by qa.topic_id
        ) t)                                                                    as average_score,

       (select count(*) from certificates c
          join enrolments e on e.id = c.enrolment_id
         where e.user_id = p.id and c.revoked_at is null)                      as certificates,

       (select count(*) from saved_courses s where s.user_id = p.id)           as saved,

       (select count(*) from submissions s
          join enrolments e on e.id = s.enrolment_id
         where e.user_id = p.id
           and s.state in ('submitted','assigned','in_review'))                as awaiting_review,

       (select max(tc.completed_at) from topic_completions tc
          join enrolments e on e.id = tc.enrolment_id
         where e.user_id = p.id)                                                as last_active,

       (select count(*) from topic_completions tc
          join enrolments e on e.id = tc.enrolment_id
         where e.user_id = p.id
           and tc.completed_at >= now() - interval '7 days')                    as topics_this_week
  from profiles p;

-- ---------------------------------------------------------------------
-- One row per enrolment, with everything a dashboard row needs: progress,
-- last activity, and an estimate of the time left.
-- ---------------------------------------------------------------------
create or replace view public.learner_courses as
select e.id                                          as enrolment_id,
       e.user_id,
       e.state,
       e.source,
       e.created_at                                  as started_at,
       c.id                                          as course_id,
       c.slug,
       c.title,
       c.subject,
       c.level,
       c.hours_low,
       c.hours_high,
       c.thumbnail_path,
       c.is_free,

       (select count(*) from modules m join topics t on t.module_id = m.id
         where m.course_id = c.id)                                             as topics_total,
       (select count(*) from topic_completions tc where tc.enrolment_id = e.id) as topics_done,

       round(100.0 * (select count(*) from topic_completions tc where tc.enrolment_id = e.id)
             / nullif((select count(*) from modules m join topics t on t.module_id = m.id
                        where m.course_id = c.id), 0), 0)                       as pct,

       (select max(tc.completed_at) from topic_completions tc
         where tc.enrolment_id = e.id)                                          as last_active,

       (select s.state from submissions s
         where s.enrolment_id = e.id order by s.attempt_no desc limit 1)        as submission_state,

       (select cert.code from certificates cert
         where cert.enrolment_id = e.id and cert.revoked_at is null limit 1)    as certificate_code
  from enrolments e
  join courses c on c.id = e.course_id;

create index if not exists topic_completions_enrolment
  on topic_completions (enrolment_id, completed_at desc);
