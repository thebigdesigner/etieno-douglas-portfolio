import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";

export const metadata = { title: "Invoices" };
export const dynamic = "force-dynamic";

export default async function InvoicesPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  const admin = createAdminClient();
  const { data: member } = await admin
    .from("institution_members").select("institution_id").eq("user_id", user!.id).maybeSingle();

  const { data: invoices } = member
    ? await admin.from("invoices").select("*")
        .eq("institution_id", member.institution_id)
        .order("period_month", { ascending: false })
    : { data: [] };

  return (
    <>
        <h1 className="sec__h" style={{ fontSize: 30, marginTop: 34 }}>Invoices</h1>
        <p className="sec__meta">
          Billed monthly in arrears, on learners who completed at least one topic. Seats
          nobody used are itemised and charged at zero.
        </p>

        {(!invoices || invoices.length === 0) ? (
          <div className="empty" style={{ marginTop: 28 }}>
            <p className="empty__h">Nothing invoiced yet</p>
            <p className="empty__p">Your first invoice arrives at the end of the month.</p>
          </div>
        ) : (
          <table className="tbl" style={{ marginTop: 26 }}>
            <thead>
              <tr><th>Month</th><th>Active learners</th><th>Unused seats</th><th>Rate</th><th>Total</th><th>State</th></tr>
            </thead>
            <tbody>
              {invoices.map((i) => (
                <tr key={i.id}>
                  <td>{new Date(i.period_month).toLocaleDateString(undefined, { month: "long", year: "numeric" })}</td>
                  <td className="num">{i.active_count}</td>
                  <td className="num">{i.seats_unused} · $0</td>
                  <td className="num">${(i.unit_cents / 100).toFixed(2)}</td>
                  <td className="num">${(i.amount_cents / 100).toFixed(2)}</td>
                  <td>{i.state}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </>
  );
}
