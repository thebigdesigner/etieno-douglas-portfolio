/**
 * Things a customer can do to their own booking without phoning anyone. Each one is proved the
 * same way Find my booking is — reference plus the phone number it was made with — and wrong
 * guesses share the lookup's rate limit.
 *
 *   apply-credit     pay some or all of an unpaid booking with a Trail-points credit
 *   cancel-request   email a one-time link to the booking's own address; the link cancels it
 */
import crypto from 'node:crypto';
import { select, insert, rpc, tenant, audit, fail, lookupBlocked, lookupMissed } from './db.js';
import { sign } from './auth/session.js';
import { cancellationQuote } from './cancel-policy.js';
import { sendTicketEmail } from './ticket-email.js';

const REF = /^[A-Z]{2,5}-[A-Z0-9]{4,10}(-[A-Z0-9]{2,6})?$/;
const last7 = s => String(s || '').replace(/\D/g, '').slice(-7);
const naira = k => '₦' + Math.round(k / 100).toLocaleString('en-NG');
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

/** Loads the booking behind a reference + phone pair, or answers the request itself. */
async function proven(req, res, select_) {
  const ref = String(req.body?.reference || '').toUpperCase(), phone = String(req.body?.phone || '');
  if (!REF.test(ref)) { fail(res, 400, 'bad_reference', 'Check the reference'); return null; }
  if (last7(phone).length < 7) { fail(res, 400, 'bad_phone', 'Enter the phone number used to book'); return null; }
  if (await lookupBlocked(req, phone)) { fail(res, 429, 'too_many', 'Too many attempts. Please wait a few minutes.'); return null; }
  const t = await tenant();
  const rows = await select('bookings', `tenant_id=eq.${t.id}&reference=eq.${ref}&select=${select_}`);
  if (!rows.length || last7(rows[0].contact_phone) !== last7(phone)) {
    await lookupMissed(req, phone);
    fail(res, 404, 'not_found', 'No booking found for that reference and phone number'); return null;
  }
  return { t, b: rows[0], ref };
}

export async function applyCredit(req, res) {
  const p = await proven(req, res, 'id,reference,status,total_kobo,contact_phone,contact_email,hold_expires_at,payments(status,amount_kobo,channel)');
  if (!p) return;
  const { t, b } = p;
  if (b.status !== 'pending') return fail(res, 409, 'not_payable', b.status === 'confirmed' ? 'This booking is already paid.' : `This booking is ${b.status}.`);
  if (b.hold_expires_at && Date.parse(b.hold_expires_at) < Date.now()) return fail(res, 409, 'hold_expired', 'The seat hold expired. Please choose your trip again.');

  const code = String(req.body?.code || '').trim().toUpperCase();
  if (!code) return fail(res, 400, 'no_code', 'Enter the code from your credit email');
  const info = await rpc('check_coupon', { p_tenant: t.id, p_code: code });
  if (!info?.code) return fail(res, 404, 'no_coupon', 'No credit with that code');
  if (info.used) return fail(res, 409, 'used', 'That credit has already been used');
  if (info.expired) return fail(res, 409, 'expired', 'That credit has expired');
  /* A credit is earned by one customer and sent to their email. It pays for a booking made with
     that same address, so a code read off someone else's screen is no use to anyone else. */
  if (String(info.email || '').toLowerCase() !== String(b.contact_email || '').toLowerCase())
    return fail(res, 403, 'not_yours', 'That credit belongs to a different email address. Book with the email the credit was sent to.');

  const paid = (b.payments || []).filter(x => x.status === 'success').reduce((a, x) => a + x.amount_kobo, 0);
  const due = b.total_kobo - paid;
  if (due <= 0) return fail(res, 409, 'nothing_due', 'Nothing is left to pay on this booking');

  let credit;
  try { credit = await rpc('redeem_coupon', { p_tenant: t.id, p_code: code, p_booking: b.id, p_max_kobo: due }); }
  catch (err) {
    const m = String(err.details?.message || err.message);
    return fail(res, 409, 'bad_coupon', m.includes('already_used') ? 'That credit has already been used' : m.includes('expired') ? 'That credit has expired' : 'That credit could not be applied');
  }
  await insert('payments', [{ tenant_id: t.id, booking_id: b.id, provider: 'other', amount_kobo: credit, status: 'success',
    channel: 'coupon', settled_at: new Date().toISOString(), raw: { kind: 'coupon', code } }], 'return=minimal');
  await audit({ tenant_id: t.id, actor_type: 'customer', action: 'coupon.redeemed_online', entity: 'booking', entity_id: b.id, detail: { code, credit_kobo: credit } });

  const balance = due - credit;
  let confirmed = false;
  if (balance <= 0) {
    /* The credit covered everything: there is nothing for Paystack to take, so confirm here —
       the same confirm_booking a paid card uses — and send the ticket. */
    const outcome = await rpc('confirm_booking', { p_booking: b.id });
    confirmed = outcome === 'confirmed' || outcome === 'already' || outcome === 'reseated';
    if (confirmed) { try { await sendTicketEmail(b.reference); } catch (e) { if (e.code !== 'not_configured') console.error('ticket email failed:', e.message); } }
  }
  return res.status(200).json({ credit: credit / 100, balance: Math.max(0, balance) / 100, confirmed });
}

export async function cancelRequest(req, res) {
  const p = await proven(req, res,
    'id,reference,status,total_kobo,contact_phone,contact_email,' +
    'passengers(status,trip:trips(status,depart_date,depart_time)),payments(status,amount_kobo,channel)');
  if (!p) return;
  const { t, b } = p;
  const legs = [...new Map(b.passengers.filter(x => x.trip).map(x => [`${x.trip.depart_date}${x.trip.depart_time}`,
    { date: x.trip.depart_date, time: String(x.trip.depart_time).slice(0, 5), status: x.trip.status }])).values()];
  const q = cancellationQuote({ status: b.status, legs, passengers: b.passengers, payments: b.payments, settings: t.settings });
  if (!q.allowed) return fail(res, 409, 'cannot_cancel', q.reason);
  if (!b.contact_email) return fail(res, 409, 'no_email', 'This booking has no email address. Call the terminal to cancel.');

  const key = process.env.RESEND_API_KEY, from = process.env.TICKET_FROM, secret = process.env.SESSION_SECRET;
  if (!key || !from || !secret) return fail(res, 503, 'not_configured', 'Online cancellation is not switched on. Call the terminal.');

  /* Cancelling cannot be undone, so reference + phone is not enough on its own: the link goes to
     the email on the booking, and only that link cancels. It works once, for 30 minutes. */
  const jti = crypto.randomUUID(), expires = new Date(Date.now() + 30 * 60000);
  await insert('login_tokens', [{ tenant_id: t.id, jti, email: b.contact_email, expires_at: expires.toISOString() }], 'return=minimal');
  const token = sign({ kind: 'cancel', jti, booking: b.id, exp: Math.floor(expires.getTime() / 1000) }, secret);
  const link = `${(process.env.SITE_URL || '').replace(/\/$/, '')}/api/auth/cancel?t=${encodeURIComponent(token)}`;
  const what = q.band === 'unpaid' ? 'Nothing has been paid, so nothing is refunded; the seats are released.'
    : q.refundKobo > 0 ? `You will get ${naira(q.refundKobo)} back${q.band === 'fee' ? `, which is what you paid less the ${q.feePct}% late-cancellation fee` : ', the full amount you paid'}.`
    : 'It is too close to departure for a refund under our policy.';

  const r = await fetch('https://api.resend.com/emails', {
    method: 'POST', headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ from, to: [b.contact_email], subject: `Confirm cancelling booking ${b.reference}`,
      html: `<div style="font-family:system-ui,Arial,sans-serif;max-width:520px;margin:0 auto;padding:24px;color:#15171c">
        <h1 style="font-size:20px">Cancel booking ${esc(b.reference)}?</h1>
        <p>${esc(what)}</p>
        <p style="margin:24px 0"><a href="${esc(link)}" style="background:#15171c;color:#fff;text-decoration:none;padding:13px 22px;border-radius:10px;font-weight:700">Yes, cancel this booking</a></p>
        <p style="font-size:13px;color:#6b7280">The link works once and expires in 30 minutes. If you did not ask for this, ignore this email — your booking stays as it is.</p></div>` })
  });
  if (!r.ok) { console.error('cancel email rejected', r.status); return fail(res, 502, 'send_failed', 'Could not send the confirmation email'); }
  await audit({ tenant_id: t.id, actor_type: 'customer', action: 'booking.cancel_requested', entity: 'booking', entity_id: b.id, detail: { refund_kobo: q.refundKobo, band: q.band } });
  const [u, d] = b.contact_email.split('@');
  return res.status(200).json({ sent: true, email: `${u.slice(0, 1)}${'•'.repeat(Math.max(2, Math.min(6, u.length - 1)))}@${d}`, refund: q.refundKobo / 100, band: q.band });
}
