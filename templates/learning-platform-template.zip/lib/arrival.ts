import { cookies } from "next/headers";

/**
 * "Did they just arrive, or have they been here a while?"
 *
 * The dashboard greets differently depending on how somebody got there, and
 * a server component cannot tell a fresh login from a click on the rail —
 * both are ordinary GETs for /dashboard.
 *
 * So every place that starts a session drops this cookie, and the middleware
 * deletes it on the way out of the first /dashboard render. The page sees it
 * exactly once: present means they came in from outside, absent means they
 * navigated here from somewhere else in the app.
 *
 * Deliberately not sessionStorage. The greeting is server-rendered, and a
 * client-side check would mean shipping one greeting and swapping it after
 * hydration — a visible flicker on the first line of the page.
 */
export const ARRIVAL_COOKIE = "splari-arrival";

/** Call before redirecting to a signed-in surface. */
export async function markArrival() {
  const store = await cookies();
  store.set(ARRIVAL_COOKIE, "1", {
    path: "/",
    httpOnly: true,
    sameSite: "lax",
    // It only has to survive one redirect. A short life means an abandoned
    // tab cannot come back tomorrow and still be greeted as a fresh login.
    maxAge: 120,
  });
}

export async function hasArrived(): Promise<boolean> {
  const store = await cookies();
  return store.get(ARRIVAL_COOKIE)?.value === "1";
}
