"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { logout } from "@/app/actions/auth";
import Avatar from "@/components/Avatar";
import NavIcon from "@/components/NavIcon";

/**
 * Avatar button that opens the account menu.
 *
 * The name, the log-out button and the help link used to sit in the bar as
 * three separate controls of similar visual weight. Log out was the most
 * prominent thing in the top right of every page, which is a strange thing
 * to emphasise. They are one control now, and the destructive one is last.
 */
export default function UserMenu({
  name, avatarPath, email, helpHref = "/help", homeHref = "/dashboard",
  cartHref, cartCount = 0,
}: {
  name?: string | null; avatarPath?: string | null; email?: string | null;
  helpHref?: string; homeHref?: string;
  /** Only the learner surface has a cart; the others pass nothing. */
  cartHref?: string; cartCount?: number;
}) {
  const [open, setOpen] = useState(false);
  const box = useRef<HTMLDivElement>(null);
  const shut = useRef<ReturnType<typeof setTimeout> | null>(null);

  // Hover opens it, but only where hovering is a real thing. A touch device
  // fires mouseenter on tap and then the click handler toggles it straight
  // back shut, so the menu could not be opened at all on a phone. Checked at
  // runtime rather than by width: a laptop with a touchscreen has both.
  const [canHover, setCanHover] = useState(false);
  useEffect(() => {
    setCanHover(window.matchMedia("(hover: hover) and (pointer: fine)").matches);
  }, []);

  function hoverOpen() {
    if (shut.current) { clearTimeout(shut.current); shut.current = null; }
    setOpen(true);
  }
  function hoverClose() {
    if (shut.current) clearTimeout(shut.current);
    shut.current = setTimeout(() => setOpen(false), 220);
  }

  // Close on outside click and on Escape — a menu you can only dismiss by
  // picking something from it is a trap on touch devices.
  useEffect(() => {
    if (!open) return;
    function onDown(e: MouseEvent) {
      if (box.current && !box.current.contains(e.target as Node)) setOpen(false);
    }
    function onKey(e: KeyboardEvent) {
      if (e.key === "Escape") setOpen(false);
    }
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, [open]);

  const hasCart = !!cartHref;
  const inCart = hasCart && cartCount > 0;

  return (
    <div
      className="umenu" ref={box}
      onMouseEnter={canHover ? hoverOpen : undefined}
      onMouseLeave={canHover ? hoverClose : undefined}
    >
      <button
        className="umenu__btn"
        onClick={() => setOpen(!open)}
        aria-expanded={open}
        aria-haspopup="menu"
        aria-label={
          inCart
            ? `Account menu, ${cartCount} item${cartCount === 1 ? "" : "s"} in your cart`
            : "Account menu"
        }
      >
        <Avatar name={name} path={avatarPath} size={34} />
        {/* A dot, not a number: it says there is something to look at without
            claiming to say what. The count is on the item inside. */}
        {inCart && <span className="umenu__dot" aria-hidden="true" />}
      </button>

      {open && (
        <div className="umenu__pop" role="menu">
          <div className="umenu__head">
            <Avatar name={name} path={avatarPath} size={40} />
            <span className="umenu__id">
              <span className="umenu__name">{name ?? "Your account"}</span>
              {email && <span className="umenu__mail">{email}</span>}
            </span>
          </div>

          <Link className="umenu__item" href={homeHref} role="menuitem" onClick={() => setOpen(false)}>
            <NavIcon name="home" size={17} /> Dashboard
          </Link>
          <Link className="umenu__item" href="/dashboard/account" role="menuitem" onClick={() => setOpen(false)}>
            <NavIcon name="user" size={17} /> Edit profile
          </Link>
          <Link className="umenu__item" href="/dashboard/certificates" role="menuitem" onClick={() => setOpen(false)}>
            <NavIcon name="award" size={17} /> Certificates
          </Link>
          {hasCart && (
            <Link className="umenu__item" href={cartHref} role="menuitem" onClick={() => setOpen(false)}>
              <NavIcon name="cart" size={17} /> Cart
              {cartCount > 0 && <span className="umenu__count num">{cartCount}</span>}
            </Link>
          )}
          <Link className="umenu__item" href={helpHref} role="menuitem" onClick={() => setOpen(false)}>
            <NavIcon name="help" size={17} /> Help
          </Link>

          <form action={logout} className="umenu__out">
            <button className="umenu__item umenu__item--danger" role="menuitem">
              <NavIcon name="logout" size={17} /> Log out
            </button>
          </form>
        </div>
      )}
    </div>
  );
}
