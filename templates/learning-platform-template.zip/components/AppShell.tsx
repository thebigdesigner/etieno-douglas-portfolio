import AppSidebar from "@/components/AppSidebar";
import Assistant from "@/components/Assistant";
import type { NavGroup } from "@/lib/app-nav";
import AppTopBar from "@/components/AppTopBar";

/**
 * Sidebar plus content. Every signed-in surface uses this, so the learner
 * dashboard, studio, institution and console are the same shape with
 * different rails.
 */
export default function AppShell({
  brand, groups, name, profile, helpHref = "/contact", children,
  email, homeHref, notifications, unread, settingsHref, cartHref, cartCount,
  searchPlaceholder,
}: {
  brand: string;
  groups: NavGroup[];
  name?: string | null;
  profile?: { name: string; id: string; avatarPath?: string | null };
  email?: string | null;
  homeHref?: string;
  notifications?: { kind: string; title: string; body: string; at: string; href: string }[];
  unread?: number;
  /** Where the topbar help icon points. Instructors have guides; nobody
   *  else does, so everyone else gets contact. */
  helpHref?: string;
  /** Where the rail's Settings item points. Defaults to the learner's. */
  settingsHref?: string;
  cartHref?: string;
  cartCount?: number;
  searchPlaceholder?: string;
  children: React.ReactNode;
}) {
  return (
    <div className="shell">
      <AppSidebar groups={groups} brand={brand} settingsHref={settingsHref} />
      <div className="shell__main">
        <AppTopBar
          name={name} groups={groups} brand={brand} helpHref={helpHref}
          avatarPath={profile?.avatarPath} email={email} homeHref={homeHref}
          notifications={notifications} unread={unread}
          cartHref={cartHref} cartCount={cartCount}
          searchPlaceholder={searchPlaceholder}
        />
        <div className="shell__body">{children}</div>
      </div>

      {/* Signed-in surfaces get the assistant too — same floating button. */}
      <Assistant />
    </div>
  );
}
