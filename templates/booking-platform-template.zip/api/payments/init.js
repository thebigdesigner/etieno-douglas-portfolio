/**
 * POST /api/payments/init — start a Paystack transaction for a pending booking.
 *
 * The amount comes from the database, never from the browser. The response is an
 * authorization_url the page opens; the booking is only confirmed later by the webhook.
 *
 *   PAYSTACK_SECRET_KEY   sk_live_… (Vercel env, server only)
 *   SITE_URL              https://yourbrand.com — where Paystack returns the customer
 */
import { opsAlert } from '../_lib/ops-alert.js';
import { configured, select, insert, rpc, tenant, audit, fail, limited, clientIp } from '../_lib/db.js';

export default async function handler(req, res) {
  if (req.method !== 'POST') return fail(res, 405, 'method', 'POST only');
  const key = process.env.PAYSTACK_SECRET_KEY;
  if (!configured() || !key) return fail(res, 503, 'not_configured', 'Payments not configured');

  const { reference } = req.body || {};
  if (!/^[A-Z]{2,5}-[A-Z0-9]{4,10}(-[A-Z0-9]{2,6})?$/.test(reference || '')) return fail(res, 400, 'bad_reference', 'Unknown booking');

  if (await limited(`pay-init:ip:${clientIp(req)}`, 20, 600)) return fail(res, 429, 'too_many', 'Too many payment attempts. Please wait a few minutes.');

  try {
    const t = await tenant();
    const rows = await select('bookings',
      `tenant_id=eq.${t.id}&reference=eq.${reference}&select=id,status,total_kobo,contact_email,contact_phone,hold_expires_at,payments(status,amount_kobo)`);
    if (!rows.length) return fail(res, 404, 'no_booking', 'Booking not found');
    const b = rows[0];
    if (b.status === 'confirmed') return fail(res, 409, 'already_paid', 'This booking is already paid');
    if (b.status !== 'pending') return fail(res, 409, 'not_payable', 'This booking can no longer be paid for');
    if (b.hold_expires_at && Date.parse(b.hold_expires_at) < Date.now())
      return fail(res, 409, 'hold_expired', 'The seat hold expired. Please choose your trip again.');

    /* Paystack's checkout — especially a bank transfer — can outlast a 15-minute hold.
       Give the seats the length of a realistic checkout from the moment payment starts, so the
       money does not arrive for seats that have already gone back on sale. */
    const payMins = Number((t.settings || {}).payment_hold_minutes ?? 30);
    await rpc('extend_hold', { p_booking: b.id, p_minutes: Math.min(Math.max(payMins, 5), 120) });

    /* Charge what is still owed. A travel credit may already have paid part of it. */
    const paid = (b.payments || []).filter(x => x.status === 'success').reduce((a, x) => a + x.amount_kobo, 0);
    const due = b.total_kobo - paid;
    if (due <= 0) return fail(res, 409, 'already_paid', 'Nothing is left to pay on this booking');

    const payRef = `${reference}-${Date.now().toString(36).toUpperCase()}`;   // unique per attempt
    const r = await fetch('https://api.paystack.co/transaction/initialize', {
      method: 'POST',
      headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
      body: JSON.stringify({
        amount: due,                                           // kobo, from the database: total less anything paid
        email: b.contact_email || `${String(b.contact_phone).replace(/\D/g, '')}@no-email.acetrail`,
        reference: payRef,
        currency: t.currency || 'NGN',
        /* Only the ways of paying the site offers. Left unset, Paystack's checkout also shows
           USSD, which Your Brand does not take. */
        channels: ['card', 'bank', 'bank_transfer'],
        callback_url: `${(process.env.SITE_URL || '').replace(/\/$/, '')}/booking/${reference}?paid=1`,
        metadata: { booking_reference: reference, booking_id: b.id, tenant: t.slug }
      })
    });
    const data = await r.json();
    if (!r.ok || !data.status) throw new Error(data.message || `paystack ${r.status}`);

    await insert('payments', [{
      tenant_id: t.id, booking_id: b.id, provider: 'paystack',
      provider_ref: payRef, amount_kobo: due, status: 'initialised'
    }], 'return=minimal');

    await audit({ tenant_id: t.id, actor_type: 'customer', action: 'payment.initialised', entity: 'booking', entity_id: b.id, detail: { provider_ref: payRef, amount_kobo: due } });

    return res.status(200).json({ authorizationUrl: data.data.authorization_url, reference: payRef });
  } catch (err) {
    console.error('payment init failed:', err.message);
    /* One failure is a customer's bad luck; the alert keeps a count and emails once an hour, so
       a Paystack outage or a wrong key is noticed within minutes instead of days. */
    await opsAlert('paystack:init', { severity: 'urgent', title: 'Card payments cannot start',
      detail: { error: err.message, what_to_do: 'Check the Paystack dashboard and PAYSTACK_SECRET_KEY in Vercel.' } });
    return fail(res, 502, 'provider', 'Could not start the payment');
  }
}
