-- =====================================================================
-- 18+ platform. Segments removed, course metadata added.
-- =====================================================================

-- ---------------------------------------------------------------------
-- Courses are categorised by subject and level. The learner segment is
-- gone: an adult deciding whether a course suits them is better served by
-- a difficulty level and an hours estimate than by being asked to pick a
-- bracket for themselves.
-- ---------------------------------------------------------------------
-- Idempotent: this migration half-applied once (Postgres refuses to
-- `create or replace` a function whose return type changed, which aborted
-- it partway), so re-running it from the top must be safe.
do $$
begin
  create type course_level as enum ('beginner', 'intermediate', 'advanced');
exception when duplicate_object then null;
end $$;

alter table courses
  add column if not exists level        course_level not null default 'beginner',
  add column if not exists hours_low    int,
  add column if not exists hours_high   int;

comment on column courses.hours_low is
  'Shown as a range — "6-10 hours". A single number reads as a promise.';

-- Segment stops being an axis. The column stays for one release so nothing
-- breaks mid-deploy, but nothing reads it.
alter table courses alter column segment drop not null;
alter table profiles alter column segment drop not null;

-- ---------------------------------------------------------------------
-- Every account is an adult account now. Consent records are kept rather
-- than dropped — they are evidence that consent was properly obtained for
-- accounts that existed under the old rules, and deleting that evidence
-- would be the wrong instinct.
-- ---------------------------------------------------------------------
alter table profiles
  add column if not exists adult_confirmed_at timestamptz;

update profiles
   set adult_confirmed_at = created_at
 where account_type = 'adult' and adult_confirmed_at is null;

-- Anyone left mid-consent under the old rules is suspended rather than
-- silently promoted to an adult account.
update profiles
   set status = 'suspended'
 where status = 'pending_consent';

-- ---------------------------------------------------------------------
-- Catalogue counts by subject, for the landing grid.
-- ---------------------------------------------------------------------
create or replace view public.subject_counts as
select c.subject,
       count(*)                                            as courses,
       count(*) filter (where c.is_free)                    as free_courses,
       sum(coalesce(c.hours_high, 0))                       as hours_total
  from courses c
 where c.state = 'published'
 group by c.subject
 order by count(*) desc;

-- ---------------------------------------------------------------------
-- Card data in one place: level, hours, enrolment count, thumbnail.
-- ---------------------------------------------------------------------
create or replace view public.course_cards as
select c.slug,
       c.title,
       c.summary,
       c.subject,
       c.level,
       c.hours_low,
       c.hours_high,
       c.is_free,
       c.thumbnail_path,
       c.thumbnail_alt,
       c.published_at,
       p.display_name                                      as instructor,
       (select count(*) from enrolments e where e.course_id = c.id)      as learners,
       (select count(*) from enrolments e
         where e.course_id = c.id and e.state = 'certified')             as graduates,
       (select count(*) from modules m join topics t on t.module_id = m.id
         where m.course_id = c.id)                                       as topics
  from courses c
  left join profiles p on p.id = c.instructor_id
 where c.state = 'published';

-- ---------------------------------------------------------------------
-- Search drops the segment field. The 0012 signature returned segment, and
-- Postgres will not change a return type in place, so the old one goes
-- first — `create or replace` alone raises 42P13 here.
-- ---------------------------------------------------------------------
drop function if exists public.search_courses(text);

create function public.search_courses(p_query text)
returns table (
  slug text, title text, summary text, subject text,
  level course_level, hours_low int, hours_high int,
  is_free boolean, thumbnail_path text, learners bigint, rank real
)
language sql stable security definer set search_path = public as $$
  select c.slug, c.title, c.summary, c.subject, c.level,
         c.hours_low, c.hours_high, c.is_free, c.thumbnail_path,
         (select count(*) from enrolments e where e.course_id = c.id) as learners,
         ts_rank(
           to_tsvector('english',
             c.title || ' ' || coalesce(c.summary,'') || ' ' || c.subject || ' ' ||
             coalesce((select string_agg(t.title, ' ')
                         from modules m join topics t on t.module_id = m.id
                        where m.course_id = c.id), '')),
           plainto_tsquery('english', p_query)
         ) as rank
    from courses c
   where c.state = 'published'
     and to_tsvector('english',
           c.title || ' ' || coalesce(c.summary,'') || ' ' || c.subject || ' ' ||
           coalesce((select string_agg(t.title, ' ')
                       from modules m join topics t on t.module_id = m.id
                      where m.course_id = c.id), ''))
         @@ plainto_tsquery('english', p_query)
   order by rank desc
   limit 40;
$$;

-- ---------------------------------------------------------------------
-- Certificates always carry the holder's name now — there are no minors.
-- ---------------------------------------------------------------------
update certificates set show_name = true where show_name = false;

-- Publication gate: level and hours are part of a usable card.
create or replace function public.submit_course_for_review(p_course_id uuid, p_instructor_id uuid)
returns table (ok boolean, reason text)
language plpgsql security definer set search_path = public as $$
declare
  v_course courses%rowtype;
  v_topics int; v_criteria int; v_quiz int; v_empty int;
begin
  select * into v_course from courses where id = p_course_id and instructor_id = p_instructor_id;
  if not found then return query select false, 'not_yours'; return; end if;
  if v_course.state not in ('draft','revision_requested') then
    return query select false, 'wrong_state'; return;
  end if;

  if v_course.thumbnail_path is null then
    return query select false, 'no_thumbnail'; return;
  end if;
  if v_course.hours_low is null or v_course.hours_high is null then
    return query select false, 'no_hours'; return;
  end if;

  select count(*) into v_topics
    from topics t join modules m on m.id = t.module_id where m.course_id = p_course_id;
  if v_topics < 3 then return query select false, 'too_few_topics'; return; end if;

  select count(*) into v_empty
    from topics t join modules m on m.id = t.module_id
   where m.course_id = p_course_id
     and coalesce(length(trim(t.body)), 0) < 40
     and not exists (select 1 from topic_materials tm where tm.topic_id = t.id);
  if v_empty > 0 then return query select false, 'empty_topics'; return; end if;

  select count(*) into v_quiz
    from quiz_items q join topics t on t.id = q.topic_id
    join modules m on m.id = t.module_id where m.course_id = p_course_id;
  if v_quiz < 3 then return query select false, 'too_few_questions'; return; end if;

  if coalesce(length(trim(v_course.project_brief)), 0) < 120 then
    return query select false, 'brief_too_short'; return;
  end if;

  select count(*) into v_criteria from rubric_criteria where course_id = p_course_id;
  if v_criteria < 2 then return query select false, 'rubric_too_thin'; return; end if;

  update courses set state = 'in_review' where id = p_course_id;
  return query select true, null::text;
end; $$;
