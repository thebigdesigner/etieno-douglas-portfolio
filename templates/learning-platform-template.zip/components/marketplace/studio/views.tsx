import Link from "next/link";
import { categoryBySlug } from "@/lib/marketplace/categories";
import { price } from "@/lib/marketplace/format";
import { mk } from "@/lib/marketplace/href";
import type { Product } from "@/lib/marketplace/types";
import type { ItemState, Shop, StudioItem } from "@/lib/marketplace/studio";
import MkIcon from "@/components/marketplace/MkIcon";
import ProductPreview from "@/components/marketplace/ProductPreview";
import ShopForm from "./ShopForm";
import AnnounceUpdate from "@/components/marketplace/studio/AnnounceUpdate";
import ItemForm from "./ItemForm";
import Uploader from "./Uploader";
import ItemActions from "./ItemActions";
import StudioTabs from "./StudioTabs";
import { CancelPayout, PayoutAccountForm, RequestPayoutForm } from "./WalletForms";
import type { Balance, Entry, Payout, PayoutAccount } from "@/lib/marketplace/wallet";
import { CCY_LABEL, money, type Ccy } from "@/lib/money";

/**
 * The studio's screens as plain props-in, markup-out views. The pages
 * fetch and pass data in; keeping the markup here means each screen can
 * be rendered and checked without a database.
 */

export const STATE_LABEL: Record<ItemState, string> = {
  draft: "Draft", in_review: "In review", published: "Live", retired: "Off sale",
};

export function StatePill({ state }: { state: ItemState }) {
  return <span className={`st-pill st-pill--${state}`}>{STATE_LABEL[state]}</span>;
}

/** A studio item drawn with the storefront's cover renderer. */
export function asProduct(i: StudioItem, handle: string): Product {
  return {
    id: i.id, slug: i.slug, title: i.title, category: i.category, subcategory: i.subcategory,
    author: handle, priceCents: i.priceCents, commercialCents: i.commercialCents, currency: "USD",
    rating: 0, ratings: 0, downloads: i.downloads, publishedAt: i.updatedAt, updatedAt: i.updatedAt,
    formats: i.formats, tags: i.tags, summary: i.summary, includes: i.includes, fileSize: "",
    coverUrl: i.coverUrl, trending: false, featured: false,
  };
}

export function StudioHead({ title, sub, action }: { title: string; sub?: React.ReactNode; action?: React.ReactNode }) {
  return (
    <header className="st-head">
      <div>
        <h1 className="st-head__h">{title}</h1>
        {sub && <p className="st-head__p">{sub}</p>}
      </div>
      {action}
    </header>
  );
}

export function StudioNotice({ icon, title, children, action }: {
  icon: "store" | "users" | "clock"; title: string; children: React.ReactNode; action?: React.ReactNode;
}) {
  return (
    <section className="mk-panel st-notice">
      <span className="st-notice__ico"><MkIcon name={icon} size={26} /></span>
      <h1 className="st-notice__h">{title}</h1>
      <p className="st-notice__p">{children}</p>
      {action}
    </section>
  );
}

export function OpenShopView({ suggestedName }: { suggestedName: string }) {
  return (
    <div className="st-narrow">
      <StudioHead title="Open your shop" sub="Sell templates, fonts, sounds and graphics to people who will use them. Setting up takes a minute; nothing goes live until you submit an item and we approve it." />
      <section className="mk-panel st-card"><ShopForm suggestedName={suggestedName} /></section>
    </div>
  );
}

export function DashboardView({ shop, items, base }: { shop: Shop; items: StudioItem[]; base: string }) {
  const count = (s: ItemState) => items.filter((i) => i.state === s).length;
  const downloads = items.reduce((n, i) => n + i.downloads, 0);
  return (
    <div className="st-wrap">
      <StudioHead
        title={shop.displayName}
        sub={<>Your shop · <Link href={mk(base, `/author/${shop.handle}`)}>View it as buyers do</Link></>}
        action={<Link href={mk(base, "/studio/items/new")} className="mk-btn mk-btn--fill"><MkIcon name="arrow-up" size={16} />New item</Link>}
      />
      <StudioTabs base={base} on="items" />
      <ul className="st-stats">
        <li><span className="st-stats__n num">{count("published")}</span><span className="st-stats__l">Live</span></li>
        <li><span className="st-stats__n num">{count("in_review")}</span><span className="st-stats__l">In review</span></li>
        <li><span className="st-stats__n num">{count("draft")}</span><span className="st-stats__l">Drafts</span></li>
        <li><span className="st-stats__n num">{downloads.toLocaleString("en-US")}</span><span className="st-stats__l">Downloads</span></li>
      </ul>

      {items.length === 0 ? (
        <StudioNotice icon="store" title="No items yet"
          action={<Link href={mk(base, "/studio/items/new")} className="mk-btn mk-btn--fill">Create your first item</Link>}>
          Start with the details, then add a cover image and the file buyers download.
        </StudioNotice>
      ) : (
        <div className="mk-panel st-list" role="table" aria-label="Your items">
          <div className="st-list__row st-list__row--head" role="row">
            <span role="columnheader">Item</span><span role="columnheader">Status</span>
            <span role="columnheader">Price</span><span role="columnheader">Downloads</span><span role="columnheader"><span className="sr">Edit</span></span>
          </div>
          {items.map((i) => (
            <div className="st-list__row" role="row" key={i.id}>
              <span role="cell" className="st-list__item">
                <span className="st-list__thumb"><ProductPreview product={asProduct(i, shop.handle)} className="st-list__img" label="" /></span>
                <span className="st-list__txt">
                  <Link href={mk(base, `/studio/items/${i.id}`)} className="st-list__title">{i.title}</Link>
                  <span className="st-list__cat">{categoryBySlug(i.category)?.name}</span>
                  {i.reviewNote && i.state === "draft" && <span className="st-list__note">Changes requested</span>}
                </span>
              </span>
              <span role="cell"><StatePill state={i.state} /></span>
              <span role="cell" className="num">{i.priceCents === 0 ? "Free" : price(i.priceCents)}</span>
              <span role="cell" className="num">{i.downloads.toLocaleString("en-US")}</span>
              <span role="cell"><Link href={mk(base, `/studio/items/${i.id}`)} className="st-list__edit">Edit</Link></span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

export function NewItemView({ base, shopName }: { base: string; shopName: string }) {
  return (
    <div className="st-wrap">
      <nav className="mk-crumbs st-crumbs"><Link href={mk(base, "/studio")}>Studio</Link><span aria-hidden="true">/</span><span>New item</span></nav>
      <StudioHead title="New item" sub="Step 1 of 2: the details. Nothing is public until you submit it and it passes review." />
      <section className="mk-panel st-card"><ItemForm shopName={shopName} /></section>
    </div>
  );
}

export function EditItemView({ item, shop, userId, base, created, owners = 0 }: {
  item: StudioItem; shop: Shop; userId: string; base: string; created?: boolean; owners?: number;
}) {
  const product = asProduct(item, shop.handle);
  const ready = [
    { ok: true, label: "Details" },
    { ok: Boolean(item.coverUrl), label: "Cover image" },
    { ok: Boolean(item.file), label: "Download file" },
    { ok: item.formats.length > 0, label: "File formats" },
  ];
  return (
    <div className="st-wrap">
      <nav className="mk-crumbs st-crumbs"><Link href={mk(base, "/studio")}>Studio</Link><span aria-hidden="true">/</span><span>{item.title}</span></nav>
      <StudioHead title={item.title} sub={<><StatePill state={item.state} />
        {item.state === "published" && <> · <Link href={mk(base, `/item/${item.slug}`)}>View live page</Link></>}</>} />

      {created && <p className="st-msg st-msg--ok st-banner" role="status">Draft created. Add the cover and the file below, then submit it for review.</p>}
      {item.reviewNote && item.state === "draft" && (
        <div className="st-banner st-banner--warn" role="status">
          <strong>Changes requested</strong><p>{item.reviewNote}</p>
        </div>
      )}
      {item.state === "in_review" && <p className="st-banner" role="status">Waiting for review. We check new items within two working days; you will see the result here.</p>}

      <div className="st-edit">
        <div className="st-edit__main">
          <section className="mk-panel st-card">
            <h2 className="st-card__h">Files</h2>
            <Uploader itemId={item.id} userId={userId} kind="cover" current={{ url: item.coverUrl }} />
            <Uploader itemId={item.id} userId={userId} kind="file"
              current={item.file ? { name: item.file.name, size: item.file.bytes ? `${(item.file.bytes / 1024 / 1024).toFixed(1)} MB` : null } : null} />
          </section>
          <section className="mk-panel st-card">
            <h2 className="st-card__h">Details</h2>
            <ItemForm item={item} />
          </section>
        </div>
        <aside className="st-edit__side">
          <section className="mk-panel st-card">
            <h2 className="st-card__h">Preview</h2>
            <div className="st-prev"><ProductPreview product={product} className="st-prev__img" label="" /></div>
            <p className="st-prev__t">{item.title}</p>
            <p className="st-prev__p num">{item.priceCents === 0 ? "Free" : price(item.priceCents)}</p>
          </section>
          <section className="mk-panel st-card">
            <h2 className="st-card__h">{shop.house ? "Ready to publish" : "Ready to submit"}</h2>
            <ul className="st-check-list">
              {ready.map((r) => (
                <li key={r.label} className={r.ok ? "is-ok" : undefined}>
                  <MkIcon name={r.ok ? "check" : "clock"} size={15} />{r.label}
                </li>
              ))}
            </ul>
            <ItemActions id={item.id} state={item.state} house={shop.house} missing={ready.filter((r) => !r.ok).map((r) => r.label)} />
          </section>

          {item.state === "published" && owners > 0 && (
            <section className="mk-panel st-card">
              <h2 className="st-card__h">New version</h2>
              <AnnounceUpdate id={item.id} owners={owners} />
            </section>
          )}
        </aside>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------ earnings */


const day = (iso: string | null) =>
  iso ? new Date(iso).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" }) : "—";

const ENTRY_LABEL: Record<Entry["kind"], string> = {
  sale: "Sale", refund: "Refund", withdrawal: "Withdrawal",
  withdrawal_reversed: "Withdrawal returned", adjustment: "Adjustment",
};

const PAYOUT_LABEL: Record<Payout["status"], string> = {
  requested: "Requested", approved: "Approved", paid: "Paid", rejected: "Sent back", cancelled: "Cancelled",
};

export function EarningsView({ shop, base, balances, entries, payouts, accounts, sales, minPayout, holdDays }: {
  shop: Shop; base: string; balances: Balance[]; entries: Entry[]; payouts: Payout[];
  accounts: Record<string, PayoutAccount>;
  sales: { id: string; title: string; paidAt: string | null; licence: string; currency: Ccy; amountCents: number; creatorCents: number; feeCents: number }[];
  minPayout: Record<Ccy, number>; holdDays: number;
}) {
  // A creator selling only in dollars sees exactly what they saw before:
  // one set of figures, no currency furniture anywhere on the page.
  const held: Ccy[] = balances.length ? balances.map((b) => b.currency) : ["USD"];
  const only = held.length === 1 ? held[0] : null;

  return (
    <div className="st-wrap">
      <StudioHead title="Earnings" sub={<>{shop.displayName} · you keep 80% of every sale</>} />
      <StudioTabs base={base} on="earnings" />

      {(balances.length ? balances : [{ currency: "USD" as Ccy, available: 0, pending: 0, lifetime: 0, withdrawn: 0 }])
        .map((b) => (
        <section key={b.currency} className="st-bal">
          {!only && <h2 className="st-bal__h">{CCY_LABEL[b.currency]}</h2>}
          <ul className="st-stats">
            <li><span className="st-stats__n num">{money(b.available, b.currency)}</span><span className="st-stats__l">Available now</span></li>
            <li><span className="st-stats__n num">{money(b.pending, b.currency)}</span><span className="st-stats__l">Clearing ({holdDays} days)</span></li>
            <li><span className="st-stats__n num">{money(b.lifetime, b.currency)}</span><span className="st-stats__l">Earned in total</span></li>
            <li><span className="st-stats__n num">{money(b.withdrawn, b.currency)}</span><span className="st-stats__l">Withdrawn</span></li>
          </ul>
        </section>
      ))}

      <div className="st-edit">
        <div className="st-edit__main">
          <section className="mk-panel st-card">
            <h2 className="st-card__h">Recent sales</h2>
            {sales.length === 0 ? (
              <p className="st-field__hint">No sales yet. They appear here the moment a payment clears.</p>
            ) : (
              <div className="st-list st-list--flat" role="table">
                <div className="st-list__row st-list__row--head st-list__row--sale" role="row">
                  <span role="columnheader">Item</span><span role="columnheader">Sold</span>
                  <span role="columnheader">Price</span><span role="columnheader">Fee</span><span role="columnheader">You earn</span>
                </div>
                {sales.map((s) => (
                  <div className="st-list__row st-list__row--sale" role="row" key={s.id}>
                    <span role="cell" className="st-list__title">{s.title}</span>
                    <span role="cell">{day(s.paidAt)}</span>
                    <span role="cell" className="num">{money(s.amountCents, s.currency)}</span>
                    <span role="cell" className="num st-neg">-{money(s.feeCents, s.currency)}</span>
                    <span role="cell" className="num"><strong>{money(s.creatorCents, s.currency)}</strong></span>
                  </div>
                ))}
              </div>
            )}
          </section>

          <section className="mk-panel st-card">
            <h2 className="st-card__h">Wallet history</h2>
            {entries.length === 0 ? (
              <p className="st-field__hint">Every sale, withdrawal and correction is listed here, newest first.</p>
            ) : (
              <ul className="st-ledger">
                {entries.map((e) => {
                  const heldStill = e.kind === "sale" && new Date(e.availableAt) > new Date();
                  return (
                    <li key={e.id}>
                      <span className="st-ledger__what">
                        {ENTRY_LABEL[e.kind]}{e.productTitle ? ` · ${e.productTitle}` : ""}
                        <span className="st-ledger__when">
                          {day(e.createdAt)}{heldStill ? ` · clears ${day(e.availableAt)}` : ""}
                        </span>
                      </span>
                      <span className={`num${e.amountCents < 0 ? " st-neg" : ""}`}>
                        {e.amountCents > 0 ? "+" : "-"}{money(Math.abs(e.amountCents), e.currency)}
                      </span>
                    </li>
                  );
                })}
              </ul>
            )}
          </section>
        </div>

        <aside className="st-edit__side">
          {held.map((c) => (
            <section key={c} className="mk-panel st-card">
              <h2 className="st-card__h">Withdraw{!only && ` ${CCY_LABEL[c]}`}</h2>
              <RequestPayoutForm
                currency={c}
                availableCents={balances.find((b) => b.currency === c)?.available ?? 0}
                minCents={minPayout[c]}
                hasAccount={Boolean(accounts[c]?.accountNumber)}
              />
            </section>
          ))}

          {held.map((c) => (
            <section key={c} className="mk-panel st-card">
              <h2 className="st-card__h">Payout details{!only && ` · ${CCY_LABEL[c]}`}</h2>
              <PayoutAccountForm currency={c} account={accounts[c] ?? null} />
            </section>
          ))}

          {payouts.length > 0 && (
            <section className="mk-panel st-card">
              <h2 className="st-card__h">Withdrawals</h2>
              <ul className="st-ledger">
                {payouts.map((p) => (
                  <li key={p.id}>
                    <span className="st-ledger__what">
                      {money(p.amountCents, p.currency)}
                      <span className="st-ledger__when">
                        {day(p.requestedAt)}{p.note ? ` · ${p.note}` : ""}
                      </span>
                    </span>
                    <span className="st-payout">
                      <span className={`st-pill st-pill--${p.status === "paid" ? "published" : p.status === "rejected" ? "retired" : "in_review"}`}>
                        {PAYOUT_LABEL[p.status]}
                      </span>
                      {p.status === "requested" && <CancelPayout id={p.id} />}
                    </span>
                  </li>
                ))}
              </ul>
              <p className="st-field__hint">
                Sales clear {holdDays} days after payment, the window for refunds and card disputes.
                Each currency is paid out on its own; nothing is converted.
              </p>
            </section>
          )}
        </aside>
      </div>
    </div>
  );
}
