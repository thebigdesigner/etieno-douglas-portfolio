"use client";

import { useActionState, useState } from "react";
import { useFormStatus } from "react-dom";
import { addMaterial, removeMaterial } from "@/app/actions/studio";
import type { FormState } from "@/lib/forms";
import FileDrop from "@/components/FileDrop";
import Alert from "@/components/Alert";

export type Material = {
  id: string; kind: string; title: string;
  path: string | null; url: string | null; size_bytes: number | null;
};

const initial: FormState = {};

const KINDS = [
  { id: "video", label: "Video", hint: "An ID or URL from your video library", upload: false },
  { id: "pdf", label: "PDF", hint: "Notes, a worksheet, a reference sheet", upload: true },
  { id: "slides", label: "Slides", hint: "PowerPoint or a PDF export", upload: true },
  { id: "download", label: "Download", hint: "A template, spreadsheet or dataset", upload: true },
  { id: "audio", label: "Audio", hint: "An MP3 or M4A", upload: true },
  { id: "link", label: "Link", hint: "Something that already exists elsewhere", upload: false },
];

const ICONS: Record<string, string> = {
  video: "▶", pdf: "◫", slides: "◨", download: "↓", audio: "♪", link: "↗",
};

function Add() {
  const { pending } = useFormStatus();
  return <button className="btn btn--line" disabled={pending}>{pending ? "Adding…" : "Add"}</button>;
}

export default function Materials({
  topicId, slug, materials, readonly,
}: { topicId: string; slug: string; materials: Material[]; readonly: boolean }) {
  const [state, action] = useActionState(addMaterial.bind(null, topicId, slug), initial);
  const [kind, setKind] = useState("pdf");
  const spec = KINDS.find((k) => k.id === kind)!;

  return (
    <div className="mat">
      <p className="studio__hint" style={{ marginTop: 0 }}>
        A topic can be a video and notes and a worksheet. Add as many as it needs.
      </p>

      {materials.length > 0 && (
        <div className="mat__list">
          {materials.map((m) => (
            <div key={m.id} className="mat__row">
              <span className="mat__ic">{ICONS[m.kind] ?? "•"}</span>
              <div className="mat__meta">
                <span className="mat__t">{m.title}</span>
                <span className="mat__k">
                  {m.kind}
                  {m.size_bytes ? ` · ${(m.size_bytes / 1024 / 1024).toFixed(1)}MB` : ""}
                </span>
              </div>
              {!readonly && (
                <form action={removeMaterial.bind(null, m.id, slug)}>
                  <button className="mat__x" aria-label={`Remove ${m.title}`}>Remove</button>
                </form>
              )}
            </div>
          ))}
        </div>
      )}

      {!readonly && (
        <form action={action} className="mat__form">
          <div className="mat__kinds">
            {KINDS.map((k) => (
              <label key={k.id} className={`mat__kind${kind === k.id ? " is-on" : ""}`}>
                <input
                  type="radio" name="kind" value={k.id}
                  checked={kind === k.id} onChange={() => setKind(k.id)}
                />
                <span>{ICONS[k.id]} {k.label}</span>
              </label>
            ))}
          </div>

          <label className="field">
            <span className="field__label">What learners will see it called</span>
            <input name="title" required placeholder="Worksheet: the three statements" />
          </label>

          {spec.upload ? (
            <div className="field">
              <span className="field__label">File</span>
              <FileDrop
                name="file" required
                maxBytes={100 * 1024 * 1024}
                hint={`${spec.hint}. Up to 100MB.`}
              />
            </div>
          ) : (
            <label className="field">
              <span className="field__label">{kind === "video" ? "Video ID or URL" : "URL"}</span>
              <input name="url" required placeholder={kind === "video" ? "abc123…" : "https://"} />
              <span className="field__hint">{spec.hint}.</span>
            </label>
          )}

          {state.error && <Alert kind="error">{state.error}</Alert>}
          {state.ok && <Alert kind="success">{state.message}</Alert>}
          <Add />
        </form>
      )}
    </div>
  );
}
