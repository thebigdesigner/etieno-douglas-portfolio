"use client";

import { useActionState, useState } from "react";
import { useFormStatus } from "react-dom";
import {
  saveCourseDetails, addModule, addTopic, saveTopic,
  addQuizItem, addCriterion, submitForReview, publishOwnCourse, saveListing,
  removeModule, removeTopic, removeCriterion,
  archiveModule, archiveTopic,
} from "@/app/actions/studio";
import type { FormState } from "@/lib/forms";
import SubmitButton from "@/components/SubmitButton";
import Materials, { type Material } from "./Materials";
import Section from "./Section";
import AutosaveForm from "@/components/AutosaveForm";
import ExamSection, { type ExamItem } from "./ExamSection";
import Thumbnail from "./Thumbnail";
import Alert from "@/components/Alert";

type Course = {
  id: string; slug: string; title: string; summary: string | null;
  subject: string; level: string; hours_low: number | null; hours_high: number | null;
  project_brief: string | null; state: string; requires_project: boolean;
  thumbnail_path: string | null; thumbnail_alt: string | null;
  price_cents: number | null; is_free: boolean;
  outcomes: string[] | null; includes: string[] | null;
  owner_kind: "splari" | "instructor" | "institution";
};
type Module = { id: string; title: string; position: number };
type Topic = {
  id: string; module_id: string; title: string; body: string | null;
  video_uid: string | null; transcript: string | null; position: number; is_free: boolean;
};
type Criterion = { id: string; title: string; descriptor: string; position: number };

const initial: FormState = {};

function PlainButton({ label }: { label: string }) {
  const { pending } = useFormStatus();
  return <button className="btn btn--line" disabled={pending}>{pending ? "…" : label}</button>;
}

export default function CourseEditor({
  course, modules, topics, quizCounts, criteria, materials, examItems,
  canPublishDirectly = false,
}: {
  course: Course; modules: Module[]; topics: Topic[];
  quizCounts: Record<string, number>; criteria: Criterion[]; examItems: ExamItem[];
  materials: Record<string, Material[]>;
  /** Decided on the server: this reader is the course's own assessor and
   *  an operator, so review would be self-approval. */
  canPublishDirectly?: boolean;
}) {
  const [open, setOpen] = useState<string | null>(null);
  const [gate, setGate] = useState<FormState>({});

  const totalTopics = topics.length;
  const totalQuestions = Object.values(quizCounts).reduce((a, b) => a + b, 0);
  const readonly = course.state === "in_review" || course.state === "published";
  /* Anything that is not an institution course is sold or free — 0063 made
   * Your Brand-authored courses payable like any other, and 0064 refuses to
   * publish one with neither a price nor the free flag. Leaving Your Brand out
   * here would hide the only field that satisfies that gate. */
  const sellable = course.owner_kind !== "institution";
  /* Whether this person still has a reviewer other than themselves.
   * An operator publishing their own instructor course does not, so the
   * hop would be self-approval; publishOwnCourse enforces the same rule
   * server-side, this only decides which button to draw. */
  const selfReviewed = sellable && canPublishDirectly;
  const goesToReview = sellable && !selfReviewed;
  const hasHours = course.hours_low != null && course.hours_high != null;

  /* Every item here mirrors a check inside submit_course_for_review. The
   * list used to omit hours and payability, so the button lit green and
   * the server said "set an hours range" — for which no field existed
   * anywhere in the product. */
  const checks = [
    { label: "A thumbnail", done: !!course.thumbnail_path, detail: "", at: "s-thumbnail" },
    { label: "An hours range", done: hasHours, detail: "", at: "s-listing" },
    ...(sellable
      ? [{
          label: "A price of $30 or more, or the free flag",
          done: course.is_free
            || (course.price_cents != null && course.price_cents >= 3000),
          detail:
            !course.is_free && course.price_cents != null && course.price_cents < 3000
              ? "Below the $30 minimum"
              : "",
          at: "s-listing",
        }]
      : []),
    { label: "At least three topics", done: totalTopics >= 3, detail: `${totalTopics} so far`, at: "s-curriculum" },
    { label: "At least three quiz questions", done: totalQuestions >= 3, detail: `${totalQuestions} so far`, at: "s-curriculum" },
    { label: "A real project brief", done: (course.project_brief ?? "").length >= 120, detail: "", at: "s-basics" },
    { label: "At least two rubric criteria", done: criteria.length >= 2, detail: `${criteria.length} so far`, at: "s-rubric" },
    { label: "A final exam of at least five questions", done: examItems.length >= 5,
      detail: `${examItems.length} so far`, at: "s-exam" },
  ];
  const ready = checks.every((c) => c.done);
  const remaining = checks.filter((c) => !c.done);

  return (
    <>
      <div className="studio__head">
        <div>
          <h1 className="rvw__h">{course.title}</h1>
          <p className="rvw__meta">{course.subject} · {course.level}</p>
        </div>
        <span className={`pill${course.state === "published" ? " pill--free" : ""}`}>
          {course.state.replace("_", " ")}
        </span>
      </div>

      {/* What is left, at the top, where the work happens.
          The same list used to live only at the bottom of the page inside a
          section that stayed collapsed until everything was already done —
          so for the whole time an author needed it, it was hidden. Each
          remaining item links to the section that fixes it. */}
      {!readonly && (
        <div className={`cprog${ready ? " is-ready" : ""}`}>
          <div className="cprog__bar" aria-hidden="true">
            <span style={{ width: `${(checks.length - remaining.length) / checks.length * 100}%` }} />
          </div>
          <div className="cprog__row">
            <span className="cprog__n num">
              {checks.length - remaining.length} of {checks.length} done
            </span>
            {ready ? (
              <span className="cprog__ok">
                Everything checks out — {goesToReview ? "ready to send for review" : "ready to publish"}
              </span>
            ) : (
              <span className="cprog__left">
                {remaining.map((c) => (
                  <a key={c.label} className="cprog__chip" href={`#${c.at}`}>
                    {c.label}
                  </a>
                ))}
              </span>
            )}
          </div>
        </div>
      )}

      {course.state === "revision_requested" && (
        <div className="notice" style={{ marginTop: 22 }}>
          <div>
            <p className="notice__h">We asked for changes</p>
            <p className="notice__p">
              Check your email for what we flagged, make the changes, and submit again.
            </p>
          </div>
        </div>
      )}

      {/* ---------- details ---------- */}
      <Section
        title="The basics"
        anchor="s-basics"
        summary={
          (course.project_brief ?? "").length >= 120
            ? "Title, summary and project brief written"
            : "Title, summary, and the brief your reviewers assess against"
        }
        done={(course.project_brief ?? "").length >= 120}
        defaultOpen={!course.project_brief}
      >
        <AutosaveForm
          action={saveCourseDetails.bind(null, course.id, course.slug)}
          className="auth__form"
        >
          <label className="field">
            <span className="field__label">Title</span>
            <input name="title" defaultValue={course.title} required disabled={readonly} />
          </label>
          <label className="field">
            <span className="field__label">Summary</span>
            <textarea name="summary" rows={3} defaultValue={course.summary ?? ""} disabled={readonly} />
          </label>
          <label className="field">
            <span className="field__label">Final project brief</span>
            <textarea name="project_brief" rows={6} defaultValue={course.project_brief ?? ""} disabled={readonly}
              placeholder="What should they produce? Be concrete — a reviewer has to be able to assess it." />
            <span className="field__hint">
              This is what a practitioner assesses. Vague briefs produce vague verdicts.
            </span>
          </label>
        </AutosaveForm>
      </Section>

      {/* ---------- thumbnail ---------- */}
      <Section
        title="Thumbnail"
        anchor="s-thumbnail"
        summary={course.thumbnail_path ? "Set" : "Needed before you can publish"}
        done={!!course.thumbnail_path}
        defaultOpen={!course.thumbnail_path}
      >
        <Thumbnail
          courseId={course.id}
          slug={course.slug}
          path={course.thumbnail_path}
          alt={course.thumbnail_alt}
          subject={course.subject}
          title={course.title}
          readonly={readonly}
        />
      </Section>

      {/* ---------- listing ---------- */}
      <Section
        title="The listing"
        anchor="s-listing"
        summary={
          hasHours
            ? `${course.hours_low}–${course.hours_high} hours${
                sellable
                  ? course.is_free
                    ? " · free"
                    : course.price_cents != null
                      ? ` · $${(course.price_cents / 100).toFixed(2)}`
                      : " · price still needed"
                  : ""
              }`
            : "Hours, outcomes" + (sellable ? ", and the price" : "")
        }
        done={hasHours && (!sellable || course.is_free
        || (course.price_cents != null && course.price_cents >= 3000))}
        defaultOpen={!hasHours}
      >
        <AutosaveForm
          action={saveListing.bind(null, course.id, course.slug)}
          className="auth__form"
        >
          <div className="ncf__row ncf__row--two">
            <label className="field">
              <span className="field__label">Hours, from</span>
              <input
                name="hours_low" type="number" min={1} inputMode="numeric"
                defaultValue={course.hours_low ?? ""} disabled={readonly}
              />
            </label>
            <label className="field">
              <span className="field__label">to</span>
              <input
                name="hours_high" type="number" min={1} inputMode="numeric"
                defaultValue={course.hours_high ?? ""} disabled={readonly}
              />
            </label>
          </div>

          {sellable && (
            <>
              <label className="field" style={{ maxWidth: 260 }}>
                <span className="field__label">Price (USD)</span>
                <input
                  name="price" inputMode="decimal" placeholder="30.00"
                  defaultValue={course.price_cents != null ? (course.price_cents / 100).toFixed(2) : ""}
                  disabled={readonly}
                  /* Not disabled when free is ticked: a disabled input is
                     left out of FormData, so ticking free and unticking it
                     would post an empty price and wipe one already set.
                     The server clears price_cents when free anyway. */
                  aria-disabled={course.is_free}
                  style={course.is_free ? { opacity: 0.5 } : undefined}
                />
                <span className="field__hint">
                  $30 minimum — a sale has to cover the assessment inside it.
                </span>
              </label>
              <label className="field field--row">
                <input
                  type="checkbox" name="is_free"
                  defaultChecked={course.is_free} disabled={readonly}
                />
                <span className="field__label" style={{ margin: 0 }}>
                  Free — no price, and it earns you royalties from the pool instead
                </span>
              </label>
            </>
          )}

          <label className="field">
            <span className="field__label">What they will be able to do</span>
            {[0, 1, 2].map((i) => (
              <input
                key={i} name="outcome" disabled={readonly}
                defaultValue={(course.outcomes ?? [])[i] ?? ""}
                placeholder={i === 0 ? "e.g. Scope and price a freelance project" : ""}
                style={{ marginTop: i === 0 ? 0 : 8 }}
              />
            ))}
          </label>

          <label className="field">
            <span className="field__label">What is included</span>
            {[0, 1, 2].map((i) => (
              <input
                key={i} name="include" disabled={readonly}
                defaultValue={(course.includes ?? [])[i] ?? ""}
                placeholder={i === 0 ? "e.g. Templates you can reuse" : ""}
                style={{ marginTop: i === 0 ? 0 : 8 }}
              />
            ))}
          </label>
        </AutosaveForm>
      </Section>

      {/* ---------- curriculum ---------- */}
      <Section
        title="Curriculum"
        anchor="s-curriculum"
        summary={
          totalTopics === 0
            ? "No topics yet — three is the minimum"
            : `${modules.length} module${modules.length === 1 ? "" : "s"}, ${totalTopics} topic${totalTopics === 1 ? "" : "s"}, ${totalQuestions} question${totalQuestions === 1 ? "" : "s"}`
        }
        done={totalTopics >= 3 && totalQuestions >= 3}
        defaultOpen={totalTopics > 0 && totalTopics < 3}
      >
        <div className="sec__head" style={{ marginTop: 0 }}>
          <span className="studio__hint">Modules hold topics. Topics hold the teaching.</span>
          {!readonly && (
            <form action={addModule.bind(null, course.id, course.slug)}>
              <PlainButton label="Add a module" />
            </form>
          )}
        </div>

        {modules.length === 0 ? (
          <p className="studio__hint">No modules yet. Add one to start.</p>
        ) : (
          /* Two columns: the shape of the course on the left, the thing you
             are editing on the right. It was an accordion inside an
             accordion — opening a topic pushed every module below it down
             the page, and there was no way to see the structure and the
             detail at the same time. */
          <div className="curr">
            <div className="curr__list">
              {modules.map((m) => {
                const mine = topics.filter((t) => t.module_id === m.id);
                return (
                  <div key={m.id} className="curr__mod">
                    <div className="curr__modh">
                      <span className="curr__modt">{m.title}</span>
                      <span className="curr__modn num">
                        {mine.length} topic{mine.length === 1 ? "" : "s"}
                      </span>
                      {/* Removing a module takes its topics with it, so the
                          label says so rather than leaving it to be found out. */}
                      {/* A draft can be deleted outright. A live course can
                          only withdraw — somebody is part-way through it. */}
                      <form
                        action={(readonly ? archiveModule : removeModule)
                          .bind(null, m.id, course.slug)}
                      >
                        <button
                          className="curr__x"
                          title={readonly ? "Withdraw from the course" : "Delete"}
                          aria-label={
                            readonly
                              ? `Withdraw ${m.title} from the live course`
                              : `Delete ${m.title} and its ${mine.length} topic${mine.length === 1 ? "" : "s"}`
                          }
                        >✕</button>
                      </form>
                    </div>

                    {mine.length === 0 ? (
                      <p className="curr__empty">Nothing in this module yet.</p>
                    ) : mine.map((t) => {
                      const ready = (t.body ?? "").length >= 40;
                      return (
                        <div key={t.id} className="curr__row">
                        <button
                          type="button"
                          className={`curr__t${open === t.id ? " is-on" : ""}`}
                          aria-current={open === t.id ? "true" : undefined}
                          onClick={() => setOpen(t.id)}
                        >
                          {/* A dot rather than a tick: this says whether the
                              topic has teaching in it, which is the thing
                              that blocks publishing. */}
                          <span className={`curr__dot${ready ? " is-ready" : ""}`} aria-hidden="true" />
                          <span className="curr__tb">
                            <span className="curr__tt">{t.title}</span>
                            <span className="curr__tm">
                              {t.is_free ? "Free · " : ""}
                              {quizCounts[t.id] ?? 0} question{(quizCounts[t.id] ?? 0) === 1 ? "" : "s"}
                              {(materials[t.id]?.length ?? 0) > 0
                                ? ` · ${materials[t.id].length} file${materials[t.id].length === 1 ? "" : "s"}`
                                : ""}
                            </span>
                          </span>
                        </button>
                        {/* Outside the selecting button: a delete nested in a
                            button is not a button, and clicking it would also
                            select the thing being removed. */}
                        <form
                          action={(readonly ? archiveTopic : removeTopic)
                            .bind(null, t.id, course.slug)}
                        >
                          <button
                            className="curr__x"
                            title={readonly ? "Withdraw from the course" : "Delete"}
                            aria-label={
                              readonly ? `Withdraw ${t.title}` : `Delete ${t.title}`
                            }
                          >✕</button>
                        </form>
                        </div>
                      );
                    })}

                    {!readonly && (
                      <form action={addTopic.bind(null, m.id, course.slug)}>
                        <button className="curr__add">+ topic</button>
                      </form>
                    )}
                  </div>
                );
              })}
            </div>

            <div className="curr__pane">
              {(() => {
                const t = topics.find((x) => x.id === open);
                if (!t) {
                  return (
                    <div className="curr__none">
                      <p className="curr__noneh">Pick a topic</p>
                      <p className="curr__nonep">
                        Its teaching, video, files and questions open here. The list
                        stays put, so you can move through the course without losing
                        your place in it.
                      </p>
                    </div>
                  );
                }
                return (
                  <>
                    {/* Which topic this is. Obvious with the list beside it;
                        not obvious at all once the list moves above on a
                        narrow screen. */}
                    <div className="curr__paneh">
                      <span className="curr__panek">Editing</span>
                      <h3 className="curr__panet">{t.title}</h3>
                    </div>
                    <TopicPanel
                      topic={t} slug={course.slug} readonly={readonly}
                      materials={materials[t.id] ?? []}
                    />
                  </>
                );
              })()}
            </div>
          </div>
        )}
      </Section>

      {/* ---------- rubric ---------- */}
      <Section
        title="Rubric"
        anchor="s-rubric"
        summary={
          criteria.length === 0
            ? "Nothing yet — two criteria minimum"
            : `${criteria.length} criteri${criteria.length === 1 ? "on" : "a"}, scored out of five`
        }
        done={criteria.length >= 2}
      >
        <p className="studio__hint" style={{ marginTop: 0 }}>
          Published to learners before they start. Specific enough that two reviewers
          would reach the same verdict from it.
        </p>

        {criteria.length > 0 && (
          <div className="cmt" style={{ marginTop: 16 }}>
            {criteria.map((c, i) => (
              <div key={c.id} className="cmt__i">
                <span className="cmt__k">{i + 1}</span>
                <div>
                  <div className="cmt__t">{c.title}</div>
                  <div className="cmt__d">{c.descriptor}</div>
                </div>
                {!readonly && (
                  <form action={removeCriterion.bind(null, c.id, course.slug)}>
                    <button className="curr__x" aria-label={`Remove ${c.title}`}>✕</button>
                  </form>
                )}
              </div>
            ))}
          </div>
        )}

        {!readonly && <CriterionForm courseId={course.id} slug={course.slug} />}
      </Section>

      {/* ---------- final exam ---------- */}
      <div id="s-exam" style={{ scrollMarginTop: 90 }} />
      <ExamSection
        courseId={course.id}
        slug={course.slug}
        items={examItems}
        requiresProject={course.requires_project}
        readonly={readonly}
      />

      {/* ---------- gate ---------- */}
      {!readonly && (
        <Section
          title={goesToReview ? "Ready to submit?" : "Ready to publish?"}
          summary={ready ? "Everything checks out" : `${checks.filter((c) => !c.done).length} still to do`}
          done={ready}
          defaultOpen={ready}
        >
          <div className="gatelist">
            {checks.map((c) => (
              <div key={c.label} className={`gateitem${c.done ? " is-done" : ""}`}>
                <span className="gateitem__mark">{c.done ? "✓" : ""}</span>
                <span>{c.label}</span>
                {c.detail && <span className="gateitem__d num">{c.detail}</span>}
              </div>
            ))}
          </div>

          {gate.error && <Alert kind="error">{gate.error}</Alert>}
          {gate.ok && <Alert kind="success">{gate.message}</Alert>}

          {/* An instructor's course is reviewed by Your Brand before it ships
              under Your Brand's roof. A Your Brand course reviewed from the console
              would be the author approving themself, and an institution
              course is private material Your Brand has no business reviewing —
              both publish directly, through the identical server-side gate. */}
          <button
            className="btn btn--fill btn--lg"
            style={{ marginTop: 20 }}
            disabled={!ready}
            onClick={async () =>
              setGate(
                goesToReview
                  ? await submitForReview(course.id, course.slug)
                  : await publishOwnCourse(course.id, course.slug)
              )
            }
          >
            {goesToReview ? "Send for review" : "Publish course"}
          </button>
          {!ready && (
            <p className="studio__hint" style={{ marginTop: 10 }}>
              Everything above needs a tick first.
            </p>
          )}
        </Section>
      )}
    </>
  );
}

function TopicPanel({
  topic, slug, readonly, materials,
}: { topic: Topic; slug: string; readonly: boolean; materials: Material[] }) {
  const hasBody = (topic.body ?? "").length >= 40;
  const videoCount = materials.filter((m) => m.kind === "video").length;

  return (
    <div className="studio__panel">
      <Section
        title="Teaching"
        summary={hasBody ? "Written" : "Nothing written yet"}
        done={hasBody || materials.length > 0}
        defaultOpen={!hasBody && materials.length === 0}
      >
      <AutosaveForm
        action={saveTopic.bind(null, topic.id, slug)}
        className="auth__form"
      >
        <label className="field">
          <span className="field__label">Topic title</span>
          <input name="title" defaultValue={topic.title} required disabled={readonly} />
        </label>
        <label className="field">
          <span className="field__label">Body</span>
          <textarea name="body" rows={10} defaultValue={topic.body ?? ""} disabled={readonly} />
          <span className="field__hint">Blank line between paragraphs. **bold** works.</span>
        </label>
        {materials.some((m) => m.kind === "video") && (
          <label className="field">
            <span className="field__label">Transcript</span>
            <textarea name="transcript" rows={6} defaultValue={topic.transcript ?? ""} disabled={readonly} />
            <span className="field__hint">
              Required where there is video. It is what makes the topic usable on a weak
              connection, and what institutional buyers ask about.
            </span>
          </label>
        )}
      </AutosaveForm>
      </Section>

      <Section
        title="Materials"
        summary={
          materials.length === 0
            ? "Video, PDF, slides, downloads — add what it needs"
            : `${materials.length} attached${videoCount ? ` · ${videoCount} video` : ""}`
        }
        done={materials.length > 0}
      >
        <Materials topicId={topic.id} slug={slug} materials={materials} readonly={readonly} />
      </Section>

      {!readonly && (
        <Section
          title="Quiz"
          summary="80% to move on. Three across the course is the minimum."
        >
          <QuizForm topicId={topic.id} slug={slug} />
        </Section>
      )}
    </div>
  );
}

function QuizForm({ topicId, slug }: { topicId: string; slug: string }) {
  const [state, action] = useActionState(addQuizItem.bind(null, topicId, slug), initial);

  return (
    <form action={action} className="auth__form studio__quiz">
      <label className="field">
        <span className="field__label">Question</span>
        <textarea name="prompt" rows={2} required minLength={10} />
      </label>
      <div className="studio__opts">
        {["a", "b", "c", "d"].map((id) => (
          <label key={id} className="field">
            <span className="field__label">Option {id.toUpperCase()}</span>
            <input name={`opt_${id}`} />
          </label>
        ))}
      </div>
      <label className="field">
        <span className="field__label">Which is correct?</span>
        <select name="correct" required defaultValue="">
          <option value="" disabled>Choose</option>
          {["a", "b", "c", "d"].map((id) => (
            <option key={id} value={id}>{id.toUpperCase()}</option>
          ))}
        </select>
      </label>
      <label className="field">
        <span className="field__label">Why (shown after they answer)</span>
        <textarea name="explanation" rows={2} />
      </label>
      {state.error && <Alert kind="error">{state.error}</Alert>}
      {state.ok && <Alert kind="success">{state.message}</Alert>}
      <SubmitButton>Add question</SubmitButton>
    </form>
  );
}

function CriterionForm({ courseId, slug }: { courseId: string; slug: string }) {
  const [state, action] = useActionState(addCriterion.bind(null, courseId, slug), initial);

  return (
    <form action={action} className="auth__form" style={{ marginTop: 22, maxWidth: 620 }}>
      <label className="field">
        <span className="field__label">Criterion</span>
        <input name="title" required minLength={4} placeholder="Reads the statements correctly" />
      </label>
      <label className="field">
        <span className="field__label">What earns a good score</span>
        <textarea name="descriptor" rows={3} required minLength={40} />
        <span className="field__hint">
          Specific enough that two reviewers would reach the same verdict from it.
        </span>
      </label>
      {state.error && <Alert kind="error">{state.error}</Alert>}
      {state.ok && <Alert kind="success">{state.message}</Alert>}
      <SubmitButton>Add criterion</SubmitButton>
    </form>
  );
}
