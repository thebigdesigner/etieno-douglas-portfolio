import { createAdminClient } from "@/lib/supabase/admin";
import AssignForm from "./AssignForm";

export const metadata = { title: "Appeals" };
export const dynamic = "force-dynamic";

export default async function AppealsPage() {
  const admin = createAdminClient();

  const { data: appeals } = await admin
    .from("appeals")
    .select("id, submission_id, grounds, second_reviewer_id, outcome, resolved_at, created_at")
    .order("created_at", { ascending: true });

  const rows = appeals ?? [];
  const open = rows.filter((a) => !a.resolved_at);

  const subIds = open.map((a) => a.submission_id);
  const { data: subs } = subIds.length
    ? await admin.from("submissions")
        .select("id, enrolment_id, enrolments(course_id, user_id)").in("id", subIds)
    : { data: [] };

  const courseIds = [...new Set((subs ?? []).map((s) =>
    (s.enrolments as unknown as { course_id: string })?.course_id).filter(Boolean))];
  const { data: courses } = courseIds.length
    ? await admin.from("courses").select("id, title").in("id", courseIds)
    : { data: [] };

  /* Who can read an appeal second.
   *
   * This asked the instructors table, which was right while only
   * practitioners could assess. Since a Your Brand course may name a member
   * of staff and an institution course a member of the organisation,
   * an appeal against one of their verdicts had no eligible second at
   * all — the assign control rendered with an empty list and the appeal
   * could not move. The same list that decides who may assess decides
   * who may re-read: eligible_assessors, minus whoever gave the first
   * verdict. */
  const { data: reviewers } = await admin.rpc("eligible_assessors");

  const { data: firstVerdicts } = subIds.length
    ? await admin.from("reviews").select("submission_id, reviewer_id").in("submission_id", subIds)
    : { data: [] };

  return (
    <>
        <h1 className="sec__h" style={{ fontSize: 30, marginTop: 34 }}>
          {open.length} appeal{open.length === 1 ? "" : "s"} open
        </h1>
        <p className="sec__meta">
          One per submission, on grounds of rubric misapplication. The second reviewer
          never sees the first verdict, and can never be the person who gave it.
        </p>

        {open.length === 0 ? (
          <div className="empty" style={{ marginTop: 28 }}>
            <p className="empty__h">Nothing outstanding</p>
            <p className="empty__p">Appeals appear here when a learner opens one.</p>
          </div>
        ) : (
          <div className="apps">
            {open.map((a) => {
              const sub = (subs ?? []).find((s) => s.id === a.submission_id);
              const enrolment = sub?.enrolments as unknown as { course_id: string } | undefined;
              const course = (courses ?? []).find((c) => c.id === enrolment?.course_id);
              const firstReviewer = (firstVerdicts ?? [])
                .find((r) => r.submission_id === a.submission_id)?.reviewer_id;

              const eligible = ((reviewers ?? []) as { id: string; name: string }[])
                .filter((r) => r.id !== firstReviewer)
                .map((r) => ({ id: r.id, name: r.name ?? "Reviewer" }));

              return (
                <article key={a.id} className="app">
                  <div className="app__head">
                    <div>
                      <div className="app__name">{course?.title ?? "Course"}</div>
                      <div className="app__hl num">
                        Opened {new Date(a.created_at).toLocaleDateString()}
                      </div>
                    </div>
                    {a.second_reviewer_id && <span className="pill">Assigned</span>}
                  </div>

                  <div className="app__field">
                    <div className="eyebrow">Their grounds</div>
                    <p>{a.grounds}</p>
                  </div>

                  {!a.second_reviewer_id && <AssignForm appealId={a.id} reviewers={eligible} />}
                </article>
              );
            })}
          </div>
        )}
      </>
  );
}
