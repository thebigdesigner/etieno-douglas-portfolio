-- =====================================================================
-- 0031 — buying courses
--
-- Instructor courses are bought; Your Brand and institution courses come with
-- the subscription. This adds the cart, the purchase record, and the one
-- function everything else asks: can this person open this course.
--
-- A purchase includes the assessment of that course's project. That is
-- why create_submission changes here too — a buyer with no subscription
-- could previously finish every topic, pass the exam, and never be
-- assessed, on a product whose whole promise is the assessment.
-- =====================================================================

-- ---------------------------------------------------------------------
-- The cart. Server-side rather than in the browser: it has to survive a
-- redirect to a payment provider and come back, and it is what the
-- checkout amount is computed from.
-- ---------------------------------------------------------------------
create table if not exists cart_items (
  user_id    uuid not null references profiles(id) on delete cascade,
  course_id  uuid not null references courses(id) on delete cascade,
  added_at   timestamptz not null default now(),
  primary key (user_id, course_id)
);

create index if not exists cart_items_user on cart_items (user_id, added_at desc);

alter table cart_items enable row level security;
drop policy if exists own_cart on cart_items;
create policy own_cart on cart_items for all to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

-- ---------------------------------------------------------------------
-- What was bought, for how much, and whether the assessment inside it
-- has been used. price_cents is copied, not joined — an instructor
-- raising their price later must not change what somebody already paid,
-- and the revenue split has to be reconstructable from the row.
-- ---------------------------------------------------------------------
create table if not exists course_purchases (
  id             uuid primary key default gen_random_uuid(),
  user_id        uuid not null references profiles(id) on delete cascade,
  course_id      uuid not null references courses(id) on delete restrict,
  price_cents    int  not null,
  currency       text not null,
  tx_ref         text,
  instructor_cents int not null default 0,
  platform_cents   int not null default 0,
  assessment_cents int not null default 0,
  -- The assessment the price paid for. Spent on first submission, so a
  -- resubmission after "changes needed" does not need a second purchase.
  assessment_used boolean not null default false,
  purchased_at   timestamptz not null default now(),
  refunded_at    timestamptz,
  unique (user_id, course_id)
);

create index if not exists course_purchases_course on course_purchases (course_id, purchased_at desc);

alter table course_purchases enable row level security;
drop policy if exists own_purchases on course_purchases;
create policy own_purchases on course_purchases for select to authenticated
  using (user_id = auth.uid());

-- ---------------------------------------------------------------------
-- The intent table carries course purchases as well as plans now. One
-- table and one fulfilment path: two would drift, and the one that
-- drifted would be the one taking money.
-- ---------------------------------------------------------------------
alter table checkout_intents
  add column if not exists kind text not null default 'plan',
  add column if not exists course_ids uuid[] not null default '{}';

-- plan was not-null because a plan was the only thing anyone could buy.
alter table checkout_intents alter column plan drop not null;

do $$ begin
  if not exists (select 1 from pg_constraint where conname = 'checkout_intents_kind_shape') then
    alter table checkout_intents add constraint checkout_intents_kind_shape
      check (
        (kind = 'plan'    and plan is not null and cardinality(course_ids) = 0) or
        (kind = 'courses' and plan is null     and cardinality(course_ids) > 0)
      );
  end if;
end $$;

-- ---------------------------------------------------------------------
-- Can this person open this course?
--
-- The single answer, so the catalogue, the lesson page and the exam
-- cannot disagree about it. Free courses are open; instructor courses
-- need a purchase; everything else needs a live subscription.
-- ---------------------------------------------------------------------
create or replace function public.course_entitlement(p_user_id uuid, p_course_id uuid)
returns table (
  allowed     boolean,
  reason      text,      -- free | purchased | subscription | cohort | needs_purchase | needs_plan
  needs_price int
)
language plpgsql
stable
security definer set search_path = public
as $$
declare
  v_course courses%rowtype;
  v_owned  boolean;
  v_cohort boolean;
begin
  select * into v_course from courses where id = p_course_id;
  if not found then
    return query select false, 'no_course'::text, null::int; return;
  end if;

  if v_course.is_free then
    return query select true, 'free'::text, null::int; return;
  end if;

  -- A cohort learner's institution has paid for them, whichever kind of
  -- course it is. Charging a learner their school already paid for would
  -- be the worst version of this change.
  select exists (
    select 1 from enrolments e
     where e.user_id = p_user_id and e.course_id = p_course_id and e.source = 'cohort'
  ) into v_cohort;
  if v_cohort then
    return query select true, 'cohort'::text, null::int; return;
  end if;

  if v_course.owner_kind = 'instructor' and v_course.price_cents is not null then
    select exists (
      select 1 from course_purchases cp
       where cp.user_id = p_user_id and cp.course_id = p_course_id and cp.refunded_at is null
    ) into v_owned;

    if v_owned then
      return query select true, 'purchased'::text, null::int; return;
    end if;
    return query select false, 'needs_purchase'::text, v_course.price_cents; return;
  end if;

  -- Your Brand and institution courses, and any instructor course with no
  -- price set: the subscription covers it.
  if has_live_subscription(p_user_id) then
    return query select true, 'subscription'::text, null::int; return;
  end if;

  return query select false, 'needs_plan'::text, null::int;
end;
$$;

-- hasAccess lives in TypeScript; this is the same question in SQL so the
-- entitlement function above has one place to ask it.
create or replace function public.has_live_subscription(p_user_id uuid)
returns boolean
language sql
stable
security definer set search_path = public
as $$
  select exists (
    select 1 from subscriptions s
     where s.user_id = p_user_id
       and s.status in ('active','past_due','cancelled')
       and s.current_period_end > now()
  );
$$;

-- ---------------------------------------------------------------------
-- Turn a paid intent into purchases. Idempotent on tx_ref, because a
-- provider that sends a webhook twice must not charge twice or issue two
-- rows — the unique (user_id, course_id) is the backstop.
--
-- The split is computed and stored per purchase: the assessment is
-- reserved first because the price promised it, then 70/30 of what is
-- left in the instructor's favour.
-- ---------------------------------------------------------------------
create or replace function public.record_course_purchases(p_tx_ref text)
returns int
language plpgsql
security definer set search_path = public
as $$
declare
  v_intent   checkout_intents%rowtype;
  v_course   courses%rowtype;
  v_assess   int := 1885;      -- what an assessment costs to pay for
  v_rest     int;
  v_made     int := 0;
begin
  select * into v_intent from checkout_intents where tx_ref = p_tx_ref;
  if not found or v_intent.kind <> 'courses' then return 0; end if;

  foreach v_course.id in array v_intent.course_ids loop
    select * into v_course from courses where id = v_course.id;
    continue when not found or v_course.price_cents is null;

    v_rest := greatest(v_course.price_cents - v_assess, 0);

    insert into course_purchases (
      user_id, course_id, price_cents, currency, tx_ref,
      assessment_cents, instructor_cents, platform_cents
    )
    values (
      v_intent.user_id, v_course.id, v_course.price_cents, v_intent.currency, p_tx_ref,
      least(v_assess, v_course.price_cents),
      floor(v_rest * 0.70)::int,
      v_rest - floor(v_rest * 0.70)::int
    )
    on conflict (user_id, course_id) do nothing;

    if found then v_made := v_made + 1; end if;
  end loop;

  delete from cart_items
   where user_id = v_intent.user_id and course_id = any(v_intent.course_ids);

  update checkout_intents set completed_at = now() where tx_ref = p_tx_ref;
  return v_made;
end;
$$;

-- ---------------------------------------------------------------------
-- Submitting a project on a bought course spends the assessment that the
-- purchase already paid for, not a plan allowance.
--
-- Restated in full again — create or replace cannot patch a body.
-- ---------------------------------------------------------------------
create or replace function public.create_submission(
  p_user_id uuid,
  p_course_id uuid,
  p_body text,
  p_files text[]
)
returns table (submission_id uuid, deadline timestamptz, error text)
language plpgsql
security definer set search_path = public
as $$
declare
  v_enrolment    enrolments%rowtype;
  v_prev         submissions%rowtype;
  v_attempt      int := 1;
  v_consumes     boolean := true;
  v_allowance    cert_allowances%rowtype;
  v_purchase     course_purchases%rowtype;
  v_reviewer     uuid;
  v_deadline     timestamptz;
  v_id           uuid;
  v_topics_left  int;
  v_has_exam     int;
  v_exam_passed  boolean;
begin
  select * into v_enrolment
    from enrolments where user_id = p_user_id and course_id = p_course_id;

  if not found then
    return query select null::uuid, null::timestamptz, 'not_enrolled'::text; return;
  end if;

  select count(*) into v_topics_left
    from topics t join modules m on m.id = t.module_id
   where m.course_id = p_course_id
     and t.id not in (
       select tc.topic_id from topic_completions tc where tc.enrolment_id = v_enrolment.id
     );

  if v_topics_left > 0 then
    return query select null::uuid, null::timestamptz, 'topics_incomplete'::text; return;
  end if;

  select count(*) into v_has_exam from exam_items where course_id = p_course_id;
  if v_has_exam > 0 then
    select coalesce(bool_or(passed), false) into v_exam_passed
      from exam_attempts where enrolment_id = v_enrolment.id;
    if not v_exam_passed then
      return query select null::uuid, null::timestamptz, 'exam_not_passed'::text; return;
    end if;
  end if;

  select * into v_prev
    from submissions where enrolment_id = v_enrolment.id
    order by attempt_no desc limit 1;

  if found then
    if v_prev.state in ('submitted','assigned','in_review') then
      return query select null::uuid, null::timestamptz, 'already_under_review'::text; return;
    end if;
    if v_prev.state = 'passed' then
      return query select null::uuid, null::timestamptz, 'already_passed'::text; return;
    end if;
    v_attempt := v_prev.attempt_no + 1;
    if v_prev.state = 'revision_requested' and v_attempt = 2 then
      v_consumes := false;
    end if;
  end if;

  if v_consumes then
    if v_enrolment.source = 'cohort' then
      v_consumes := false;                       -- the institution's plan
    else
      -- A purchase of this course already paid for one assessment. Checked
      -- before the plan allowance, so somebody with both does not spend a
      -- yearly certification on a course they bought outright.
      select * into v_purchase
        from course_purchases
       where user_id = p_user_id and course_id = p_course_id and refunded_at is null
       limit 1;

      if found and not v_purchase.assessment_used then
        update course_purchases set assessment_used = true where id = v_purchase.id;
        v_consumes := false;
      elsif found and v_purchase.assessment_used then
        return query select null::uuid, null::timestamptz, 'assessment_used'::text; return;
      else
        select * into v_allowance
          from cert_allowances
         where user_id = p_user_id and now() between period_start and period_end
         order by period_end desc limit 1;

        if not found then
          return query select null::uuid, null::timestamptz, 'no_plan'::text; return;
        end if;
        if v_allowance.used >= (v_allowance.included + v_allowance.purchased) then
          return query select null::uuid, null::timestamptz, 'allowance_spent'::text; return;
        end if;

        update cert_allowances set used = used + 1 where id = v_allowance.id;
      end if;
    end if;
  end if;

  select c.instructor_id into v_reviewer from courses c where c.id = p_course_id;
  v_deadline := add_working_days(now(), 4);

  insert into submissions (enrolment_id, attempt_no, body, file_paths, state,
                           assigned_reviewer_id, deadline_at, consumed_allowance)
  values (v_enrolment.id, v_attempt, p_body, p_files, 'submitted',
          v_reviewer, v_deadline, v_consumes)
  returning id into v_id;

  update enrolments set state = 'submitted' where id = v_enrolment.id;

  return query select v_id, v_deadline, null::text;
end;
$$;
