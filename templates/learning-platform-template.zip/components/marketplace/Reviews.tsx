import MkIcon from "@/components/marketplace/MkIcon";
import ReviewForm from "@/components/marketplace/ReviewForm";
import { shortDate } from "@/lib/marketplace/format";
import type { Review, ReviewSummary } from "@/lib/marketplace/reviews";

/**
 * The reviews section of an item page.
 *
 * Three states, and the quiet one matters most: a new listing has no
 * reviews and must not look abandoned, so it says plainly that it is new
 * rather than showing an empty five-star scaffold.
 */
export default function Reviews({
  productId, reviews, summary, owns, mine, signedIn,
}: {
  productId: string;
  reviews: Review[];
  summary: ReviewSummary;
  owns: boolean;
  mine: { rating: number; body: string | null } | null;
  signedIn: boolean;
}) {
  const others = reviews.filter((r) => !r.mine);

  return (
    <section className="mk-panel mk-rev" id="reviews">
      <div className="mk-rev__head">
        <h2 className="mk-rev__h">Reviews</h2>
        {summary.count > 0 && (
          <p className="mk-rev__avg">
            <span className="num">{summary.average.toFixed(1)}</span>
            <span className="mk-rev__stars" aria-hidden="true">
              {[1, 2, 3, 4, 5].map((n) => (
                <MkIcon key={n} name="star" size={14}
                  className={n <= Math.round(summary.average) ? "is-on" : undefined} />
              ))}
            </span>
            <span className="mk-rev__n">
              {summary.count} {summary.count === 1 ? "review" : "reviews"}
            </span>
          </p>
        )}
      </div>

      {summary.count > 0 && (
        <ul className="mk-rev__bars" aria-hidden="true">
          {[5, 4, 3, 2, 1].map((star) => {
            const n = summary.spread[star - 1];
            const pct = summary.count ? Math.round((n / summary.count) * 100) : 0;
            return (
              <li key={star}>
                <span className="mk-rev__bl num">{star}</span>
                <span className="mk-rev__bt"><span className="mk-rev__bf" style={{ width: `${pct}%` }} /></span>
                <span className="mk-rev__bn num">{n}</span>
              </li>
            );
          })}
        </ul>
      )}

      {owns && <ReviewForm productId={productId} mine={mine} />}

      {summary.count === 0 ? (
        <p className="mk-rev__none">
          {owns
            ? "Nobody has reviewed this yet. Yours would be the first."
            : "No reviews yet — this item is new. Reviews can only be left by people who own it."}
        </p>
      ) : (
        <ul className="mk-rev__list">
          {others.map((r) => (
            <li key={r.id} className="mk-rev__item">
              <div className="mk-rev__who">
                <span className="mk-rev__ini" aria-hidden="true">{r.who === "A buyer" ? "·" : r.who}</span>
                <span>
                  <span className="mk-rev__name">{r.who}</span>
                  <span className="mk-rev__when">{shortDate(r.at)}</span>
                </span>
                <span className="mk-rev__rate" role="img" aria-label={`${r.rating} out of 5`}>
                  {[1, 2, 3, 4, 5].map((n) => (
                    <MkIcon key={n} name="star" size={12} className={n <= r.rating ? "is-on" : undefined} />
                  ))}
                </span>
              </div>
              {r.body && <p className="mk-rev__body">{r.body}</p>}
            </li>
          ))}
        </ul>
      )}

      {!signedIn && summary.count === 0 && null}
    </section>
  );
}
