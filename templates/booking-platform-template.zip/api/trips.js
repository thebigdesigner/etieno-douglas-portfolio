/**
 * GET /api/trips?from=uyo&to=phc&date=2026-09-12
 * Real availability: seats are counted from trip_seats, not guessed.
 */
import { configured, select, tenant, fail, departsAt } from './_lib/db.js';

export default async function handler(req, res) {
  if (req.method !== 'GET') return fail(res, 405, 'method', 'GET only');
  if (!configured()) return fail(res, 503, 'not_configured', 'Database not configured');

  /* GET /api/trips?routes=1 — the live route table: fares, journey times, departure times and
     operating days. The public pages used to carry their own copy of these numbers, which meant
     a manager changing a fare in the dashboard changed nothing a customer could see. */
  if (req.query && req.query.routes === '1') {
    try {
      const t = await tenant();
      const terminals = await select('terminals', `tenant_id=eq.${t.id}&select=id,code,city,name,address,phone,whatsapp,opens_at,active`);
      const code = id => terminals.find(x => x.id === id)?.code || null;
      const rows = await select('routes', `tenant_id=eq.${t.id}&active=is.true&select=from_terminal,to_terminal,fare_kobo,duration_min,departures,operating_days`);
      res.setHeader('Cache-Control', 'public, max-age=120, stale-while-revalidate=600');
      return res.status(200).json({
        routes: rows.map(r => ({
          from: code(r.from_terminal), to: code(r.to_terminal),
          fare: r.fare_kobo / 100, durationMin: r.duration_min,
          departures: (r.departures || []).map(x => String(x).slice(0, 5)).sort(),
          days: r.operating_days || []
        })).filter(r => r.from && r.to),

        /* Addresses, phone numbers and the head-office line come from the database now, so a
           manager edits them once in Terminals and every page changes. They used to be copied
           into index.html and assets/pages.js, which is why all three still read "full address
           to be confirmed" months after the terminals opened. */
        terminals: terminals.filter(x => x.active !== false).map(x => ({
          id: x.code, code: x.code, city: x.city, name: x.name,
          address: x.address || null, phone: x.phone || null, whatsapp: x.whatsapp || null,
          opensAt: x.opens_at ? String(x.opens_at).slice(0, 5) : null
        })),
        company: {
          tollFree: (t.settings || {}).toll_free || null,
          email: (t.settings || {}).contact_email || null,
          bank: (t.settings || {}).bank_account_number ? {
            name: (t.settings || {}).bank_name || null,
            accountName: (t.settings || {}).bank_account_name || null,
            accountNumber: (t.settings || {}).bank_account_number
          } : null
        },
        policy: {
          holdMinutes: Number((t.settings || {}).hold_minutes ?? 15),
          childFareRatio: Number((t.settings || {}).child_fare_ratio ?? 0.75),
          arriveBeforeMin: Number((t.settings || {}).arrive_before_min ?? 30),
          checkInCloseMin: Number((t.settings || {}).check_in_close_min ?? 15),
          cancelFreeHours: Number((t.settings || {}).cancel_free_hours ?? 24),
          cancelFeePct: Number((t.settings || {}).cancel_fee_pct ?? 25),
          noRefundHours: Number((t.settings || {}).no_refund_hours ?? 2)
        }
      });
    } catch (err) {
      console.error('route list failed:', err.message);
      return fail(res, 500, 'server', 'Could not load routes');
    }
  }

  const { from, to, date } = req.query || {};
  if (!/^[a-z]{2,8}$/.test(from || '') || !/^[a-z]{2,8}$/.test(to || '')) return fail(res, 400, 'bad_terminal', 'Unknown terminal');
  if (!/^\d{4}-\d{2}-\d{2}$/.test(date || '')) return fail(res, 400, 'bad_date', 'Date must be YYYY-MM-DD');

  try {
    const t = await tenant();
    const terminals = await select('terminals', `tenant_id=eq.${t.id}&select=id,code,city`);
    const a = terminals.find(x => x.code === from), b = terminals.find(x => x.code === to);
    if (!a || !b) return fail(res, 404, 'unknown_route', 'We do not serve that pair yet');

    const routes = await select('routes', `tenant_id=eq.${t.id}&from_terminal=eq.${a.id}&to_terminal=eq.${b.id}&active=is.true&select=*`);
    if (!routes.length) return res.status(200).json({ trips: [], route: null });

    const trips = await select('trips',
      `tenant_id=eq.${t.id}&route_id=eq.${routes[0].id}&depart_date=eq.${date}&status=eq.scheduled` +
      `&select=id,depart_time,capacity,fare_kobo,vehicle:vehicles(label),trip_seats(seat_no,state,held_until)&order=depart_time.asc`);

    /* A departure whose check-in has closed must not be on sale. The list was filtered by date
       only, so at 15:00 the site still offered this morning's 07:00 — a customer could pick it,
       pay, and own a seat on a vehicle that left eight hours ago.

       The cut-off is check-in closing, not departure: selling a seat to somebody who cannot
       reach the desk in time is the same failure a few minutes later. Both numbers are the
       manager's, from Terminals. */
    const closeMin = Number((t.settings || {}).check_in_close_min ?? 15);
    const cutoff = new Date(Date.now() + closeMin * 60000);
    const stillSellable = tr => {
      /* Lagos time. Parsed bare, 07:00 was read as 07:00 UTC — 08:00 in Lagos — so every
         departure stayed on sale an hour after its real cut-off. */
      return departsAt(date, tr.depart_time) > cutoff;
    };

    const now = Date.now();
    const out = trips.filter(stillSellable).map(tr => {
      const seats = tr.trip_seats || [];
      const free = seats.filter(s => s.state === 'free' || (s.state === 'held' && s.held_until && Date.parse(s.held_until) < now));
      return {
        id: tr.id,
        time: String(tr.depart_time).slice(0, 5),
        vehicle: tr.vehicle?.label || 'Vehicle',
        capacity: tr.capacity,
        fare: tr.fare_kobo / 100,
        seatsLeft: free.length,
        seats: seats.map(s => ({ no: s.seat_no, free: s.state === 'free' || (s.state === 'held' && s.held_until && Date.parse(s.held_until) < now) }))
             .sort((x, y) => x.no - y.no)
      };
    });
    res.setHeader('Cache-Control', 'no-store');
    return res.status(200).json({ route: { fare: routes[0].fare_kobo / 100, durationMin: routes[0].duration_min }, trips: out });
  } catch (err) {
    console.error('trips failed:', err.message);
    return fail(res, 500, 'server', 'Could not load trips');
  }
}
