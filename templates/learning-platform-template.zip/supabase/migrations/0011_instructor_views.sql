-- =====================================================================
-- Instructor dashboard — what needs doing, and how things are going
-- =====================================================================

-- ---------------------------------------------------------------------
-- One row per instructor with everything the studio home needs. Kept as a
-- view so the numbers an instructor sees and the numbers we see in the
-- console come from the same place.
-- ---------------------------------------------------------------------
create or replace view public.instructor_overview as
select i.id,
       i.state,
       i.available,
       i.reliability,
       i.creator_course_done_at,

       (select count(*) from courses c
         where c.instructor_id = i.id and c.state = 'published')          as courses_live,
       (select count(*) from courses c
         where c.instructor_id = i.id and c.state = 'draft')              as courses_draft,
       (select count(*) from courses c
         where c.instructor_id = i.id and c.state = 'in_review')          as courses_in_review,
       (select count(*) from courses c
         where c.instructor_id = i.id and c.state = 'revision_requested') as courses_returned,

       (select count(*) from review_queue_status q
         where q.assigned_reviewer_id = i.id)                            as queue_total,
       (select count(*) from review_queue_status q
         where q.assigned_reviewer_id = i.id and q.breached)             as queue_late,
       (select count(*) from review_queue_status q
         where q.assigned_reviewer_id = i.id and q.due_soon and not q.breached)
                                                                          as queue_soon,
       (select count(*) from appeals a
         where a.second_reviewer_id = i.id and a.resolved_at is null)    as appeals_open,

       (select count(distinct e.id) from enrolments e
          join courses c on c.id = e.course_id
         where c.instructor_id = i.id)                                    as learners_total,
       (select count(distinct e.id) from enrolments e
          join courses c on c.id = e.course_id
         where c.instructor_id = i.id and e.state = 'certified')          as learners_certified,
       (select count(*) from reviews r where r.reviewer_id = i.id)        as reviews_done,

       coalesce((select sum(ee.amount_cents) from earnings_entries ee
                  where ee.instructor_id = i.id), 0)                      as accrued_cents,
       coalesce((select sum(pr.amount_cents) from payout_runs pr
                  where pr.instructor_id = i.id and pr.state = 'paid'), 0) as paid_cents,
       coalesce((select sum(ee.amount_cents) from earnings_entries ee
                  where ee.instructor_id = i.id
                    and ee.created_at >= date_trunc('month', now())), 0)  as month_cents
  from instructors i;

-- ---------------------------------------------------------------------
-- Per-course numbers for the instructor's own courses. Completion is the
-- number worth watching: a course nobody finishes is a content problem.
-- ---------------------------------------------------------------------
create or replace view public.instructor_course_stats as
select c.id,
       c.instructor_id,
       c.slug,
       c.title,
       c.subject,
       c.state,
       c.is_free,
       c.published_at,
       (select count(*) from modules m join topics t on t.module_id = m.id
         where m.course_id = c.id)                                        as topics,
       count(distinct e.id)                                               as enrolments,
       count(distinct e.id) filter (where e.state = 'certified')          as certified,
       count(distinct s.id) filter (where s.state in ('submitted','assigned','in_review'))
                                                                          as awaiting,
       round(100.0 * count(distinct e.id) filter (where e.state = 'certified')
             / nullif(count(distinct e.id), 0), 0)                        as completion_pct,
       (select count(*) from topic_completions tc
          join enrolments e2 on e2.id = tc.enrolment_id
         where e2.course_id = c.id
           and tc.completed_at >= now() - interval '30 days')             as activity_30d
  from courses c
  left join enrolments e on e.course_id = c.id
  left join submissions s on s.enrolment_id = e.id
 group by c.id, c.instructor_id, c.slug, c.title, c.subject, c.state, c.is_free, c.published_at;

-- ---------------------------------------------------------------------
-- Feedback an instructor has written, so they can look back at what they
-- said before assessing the same learner's resubmission.
-- ---------------------------------------------------------------------
create or replace view public.instructor_recent_reviews as
select r.id,
       r.reviewer_id,
       r.outcome,
       r.within_sla,
       r.completed_at,
       c.title                              as course_title,
       c.slug                               as course_slug,
       p.display_name                       as learner_name,
       s.attempt_no
  from reviews r
  join submissions s on s.id = r.submission_id
  join enrolments  e on e.id = s.enrolment_id
  join courses     c on c.id = e.course_id
  join profiles    p on p.id = e.user_id
 order by r.completed_at desc;
