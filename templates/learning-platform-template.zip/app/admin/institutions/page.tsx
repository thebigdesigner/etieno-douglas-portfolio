import { createAdminClient } from "@/lib/supabase/admin";
import InvoiceForm from "./InvoiceForm";

export const metadata = { title: "Institutions" };
export const dynamic = "force-dynamic";

export default async function AdminInstitutionsPage() {
  const admin = createAdminClient();

  const { data: institutions } = await admin
    .from("institutions").select("id, name, contact_email, plan, dpa_signed_at")
    .order("created_at", { ascending: false });

  return (
    <>
        <h1 className="sec__h" style={{ fontSize: 30, marginTop: 34 }}>Institutions</h1>
        <p className="sec__meta">
          Accounts are created by hand after a call — there is no self-serve signup at
          this tier, and there should not be.
        </p>

        {(!institutions || institutions.length === 0) ? (
          <div className="empty" style={{ marginTop: 28 }}>
            <p className="empty__h">No institutions yet</p>
            <p className="empty__p">
              Create one with <code>create_institution</code> once a call is done.
            </p>
          </div>
        ) : (
          <div className="apps">
            {institutions.map((i) => (
              <article key={i.id} className="app">
                <div className="app__head">
                  <div>
                    <div className="app__name">{i.name}</div>
                    <div className="app__hl">{i.contact_email} · {i.plan}</div>
                  </div>
                  {!i.dpa_signed_at && <span className="pill pill--lock">No DPA</span>}
                </div>
                <InvoiceForm institutionId={i.id} />
              </article>
            ))}
          </div>
        )}
      </>
  );
}
