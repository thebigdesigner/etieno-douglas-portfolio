"use client";
import { useActionState } from "react";
import { requestReset } from "@/app/actions/auth";
import type { FormState } from "@/lib/forms";
import SubmitButton from "@/components/SubmitButton";
import Alert from "@/components/Alert";

const initial: FormState = {};

export default function ForgotForm() {
  const [state, action] = useActionState(requestReset, initial);

  if (state.ok) {
    return (
      <div className="auth__done" role="status">
        <p>{state.message}</p>
        <p style={{ marginTop: 10, fontSize: 14, fontWeight: 400 }}>
          It usually arrives within a minute. Check your spam folder if not.
        </p>
      </div>
    );
  }

  return (
    <form action={action} className="auth__form">
      <label className="field">
        <span className="field__label">Email</span>
        <input name="email" type="email" autoComplete="email" required autoFocus />
      </label>

      {state.error && <Alert kind="error">{state.error}</Alert>}

      <SubmitButton>Send the reset link</SubmitButton>
    </form>
  );
}
