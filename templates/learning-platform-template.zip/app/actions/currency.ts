"use server";

import { cookies } from "next/headers";
import { revalidatePath } from "next/cache";
import { CCY_COOKIE, isCcy } from "@/lib/currency";
import { cookieOptions } from "@/lib/supabase/cookie-domain";

/**
 * Remember a visitor's currency. Set on the shared domain so a choice made
 * on the marketplace holds on the Academy too, and for a year: this is a
 * preference, not a session.
 */
export async function setCurrency(value: string, path = "/") {
  if (!isCcy(value)) return;
  const jar = await cookies();
  jar.set(CCY_COOKIE, value, {
    ...cookieOptions(),
    httpOnly: false,       // the switcher reads it back without a round trip
    sameSite: "lax",
    maxAge: 60 * 60 * 24 * 365,
    path: "/",
  });
  revalidatePath(path);
}
