import Link from "next/link";
import CourseThumb from "@/components/CourseThumb";
import { siteUrl } from "@/lib/site";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import CertActions from "./CertActions";

export const metadata = { title: "Your certificates" };
export const dynamic = "force-dynamic";

export default async function CertificatesPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const admin = createAdminClient();

  const { data: profile } = await admin
    .from("profiles").select("display_name").eq("id", user!.id).maybeSingle();

  const { data: enrolments } = await admin
    .from("enrolments").select("id, course_id, courses(title, subject, thumbnail_path)").eq("user_id", user!.id);

  const rows = enrolments ?? [];
  const ids = rows.map((e) => e.id);

  const { data: certs } = ids.length
    ? await admin.from("certificates")
        .select("id, code, reviewer_name, kind, issued_at, revoked_at, enrolment_id")
        .in("enrolment_id", ids)
        .order("issued_at", { ascending: false })
    : { data: [] };

  const base = siteUrl();

  if (!certs || certs.length === 0) {
    return (
      <div className="empty" style={{ marginTop: 30 }}>
        <p className="empty__h">No certificates yet</p>
        <p className="empty__p">
          Finish a course and your certificate appears here with a code anyone can
          check — carrying the name of the practitioner who assessed your project,
          or recording the exam you passed where a course has no project.
        </p>
        <Link className="btn btn--fill btn--lg" href="/courses" style={{ marginTop: 20 }}>
          Find a course
        </Link>
      </div>
    );
  }

  return (
    <>
      <div className="certs" style={{ marginTop: 30 }}>
        {certs.map((c) => {
          const e = rows.find((r) => r.id === c.enrolment_id);
          const course = e?.courses as unknown as
            { title: string; subject: string; thumbnail_path: string | null } | null;
          const url = `${base}/verify/${c.code}`;

          return (
            <article key={c.id} className={`cert${c.revoked_at ? " is-revoked" : ""}`}>
              {/* The course's own thumbnail, so a shelf of certificates is
                  scannable by sight rather than by reading every title. The
                  band across it carries the kind, which is the thing that
                  actually differs between two certificates. */}
              <Link className="cert__thumb" href={`/certificate/${c.code}`}>
                <CourseThumb
                  path={course?.thumbnail_path ?? null}
                  title={course?.title ?? ""}
                  subject={course?.subject ?? ""}
                />
                <span className={`cert__kind${c.kind === "examined" ? " is-exam" : ""}`}>
                  {c.kind === "examined" ? "Examined" : "Assessed"}
                </span>
              </Link>

              <div className="cert__top">
                <span className="cert__seal">{c.revoked_at ? "—" : "✓"}</span>
                <span className="cert__state">
                  {c.revoked_at ? "Withdrawn" : "Verified"}
                </span>
              </div>

              <h2 className="cert__course">{course?.title}</h2>
              <p className="cert__who">
                {c.kind === "examined"
                  ? <>Passed the <strong>final examination</strong></>
                  : <>Assessed by <strong>{c.reviewer_name}</strong></>}
              </p>

              <dl className="cert__dl">
                <div>
                  <dt>Issued</dt>
                  <dd>
                    {new Date(c.issued_at).toLocaleDateString(undefined, {
                      day: "numeric", month: "long", year: "numeric",
                    })}
                  </dd>
                </div>
                <div><dt>Code</dt><dd className="num">{c.code}</dd></div>
              </dl>

              {!c.revoked_at && <CertActions code={c.code} url={url} />}
            </article>
          );
        })}
      </div>
    </>
  );
}
