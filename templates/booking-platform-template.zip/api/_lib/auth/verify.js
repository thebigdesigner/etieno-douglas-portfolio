/**
 * GET  /api/auth/verify?t=TOKEN — shows a one-button page (see confirm-page.js for why).
 * POST /api/auth/verify  t=TOKEN — completes an email sign-in and redirects home.
 * The token must be signed, unexpired, and unused; the row is marked used before the
 * session is issued, so a forwarded link cannot be replayed.
 */
import { configured, select, update, fail } from '../db.js';
import { sign, verify } from './session.js';
import { confirmPage, tokenOf } from './confirm-page.js';

const home = (res, hash) => { res.writeHead(302, { Location: `/#${hash}` }); res.end(); };

export default async function handler(req, res) {
  const secret = process.env.SESSION_SECRET;
  if (!secret || !configured()) return fail(res, 503, 'not_configured', 'Email sign-in is not switched on');

  const token = tokenOf(req);
  const claims = verify(token, secret);
  if (!claims || claims.kind !== 'magic' || !claims.jti) return home(res, 'signin-expired');
  if (req.method !== 'POST') return confirmPage(res, { action: '/api/auth/verify', token, title: 'Sign in to Your Brand', button: 'Sign in' });

  try {
    const rows = await select('login_tokens', `jti=eq.${claims.jti}&select=id,email,expires_at,used_at`);
    const row = rows[0];
    if (!row || row.used_at || Date.parse(row.expires_at) < Date.now()) return home(res, 'signin-expired');

    /* Spend it, and only go on if this request is the one that spent it: two taps racing each
       other must not both get a session. */
    const spent = await update('login_tokens', `id=eq.${row.id}&used_at=is.null`, { used_at: new Date().toISOString() });
    if (!spent?.length) return home(res, 'signin-expired');

    const user = {
      kind: 'customer',
      sub: `email:${row.email}`,
      name: row.email.split('@')[0].replace(/[._-]+/g, ' ').replace(/\b\w/g, c => c.toUpperCase()),
      email: row.email,
      picture: '',
      exp: Math.floor(Date.now() / 1000) + 60 * 60 * 24 * 30
    };
    res.setHeader('Set-Cookie', [
      `atx_session=${sign(user, secret)}`, 'Path=/', 'HttpOnly', 'Secure', 'SameSite=Lax', `Max-Age=${60 * 60 * 24 * 30}`
    ].join('; '));
    return home(res, 'signed-in');
  } catch (err) {
    console.error('verify failed:', err.message);
    return home(res, 'signin-expired');
  }
}
