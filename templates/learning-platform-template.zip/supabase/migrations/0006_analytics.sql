-- =====================================================================
-- Instrumentation — the phase gates, made measurable
-- =====================================================================

create index if not exists events_name_created on events (name, created_at desc);
create index if not exists events_user on events (user_id, created_at desc);

-- Everything the launch gates are stated in terms of, in one place.
create or replace view public.launch_metrics as
select
  (select count(*) from profiles where status = 'active')                       as learners,
  (select count(*) from profiles
     where status = 'active' and created_at > now() - interval '30 days')       as learners_30d,
  (select count(*) from enrolments)                                            as enrolments,
  (select count(*) from topic_completions)                                     as topics_completed,
  (select count(*) from submissions where state = 'passed')                    as projects_passed,
  (select count(*) from reviews)                                               as reviews_done,
  (select count(*) from reviews where within_sla)                              as reviews_in_sla,
  (select round(100.0 * count(*) filter (where within_sla) / nullif(count(*), 0), 1)
     from reviews)                                                             as sla_pct,
  (select count(*) from certificates where revoked_at is null)                 as certificates,
  (select count(*) from institutions)                                          as institutions,
  (select count(distinct institution_id) from invoices
     where period_month > (current_date - interval '3 months'))                as institutions_billed,
  (select count(*) from instructors where state = 'active')                    as instructors,
  (select count(*) from courses where state = 'published')                     as courses_live;

-- Funnel, by day. Counts distinct people, not events, so a reload does not
-- inflate the numerator.
create or replace view public.funnel_daily as
select date_trunc('day', created_at)::date as day,
       count(distinct user_id) filter (where name = 'signup_started')   as signup_started,
       count(distinct user_id) filter (where name = 'account_created')  as account_created,
       count(distinct user_id) filter (where name = 'course_started')   as course_started,
       count(distinct user_id) filter (where name = 'paywall_shown')    as paywall_shown,
       count(distinct user_id) filter (where name = 'project_submitted') as project_submitted,
       count(distinct user_id) filter (where name = 'certificate_issued') as certified,
       count(*) filter (where name = 'age_gate_blocked')                as under_13_blocked,
       count(*) filter (where name = 'sla_breached')                    as sla_breaches
  from events
 group by 1
 order by 1 desc;

-- Where learners stop. The first quiz with a high failure rate is usually a
-- badly written question rather than a difficult topic.
create or replace view public.topic_dropoff as
select c.title                                as course,
       m.position                             as module_pos,
       t.position                             as topic_pos,
       t.title                                as topic,
       count(distinct tc.enrolment_id)        as completions,
       count(distinct qa.enrolment_id) filter (where not qa.passed) as failed_at_least_once,
       round(avg(qa.score_pct), 1)            as avg_score
  from topics t
  join modules m on m.id = t.module_id
  join courses c on c.id = m.course_id
  left join topic_completions tc on tc.topic_id = t.id
  left join quiz_attempts qa on qa.topic_id = t.id
 group by c.title, m.position, t.position, t.title
 order by c.title, m.position, t.position;
