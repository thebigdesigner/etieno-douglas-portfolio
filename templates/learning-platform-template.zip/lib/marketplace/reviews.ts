/**
 * Reviews of a marketplace item.
 *
 * Read through the admin client on purpose: the reviewer's name lives in
 * profiles, which buyers cannot read, and a review signed by nobody is
 * worth less than no review at all. Only the fields below leave this
 * file — never an email address, and never a full name unless the person
 * asked for their initials to be public.
 */

import { createAdminClient } from "@/lib/supabase/admin";

export type Review = {
  id: string;
  rating: number;
  body: string | null;
  at: string;
  who: string;      // initials, or "A buyer"
  mine: boolean;
};

export type ReviewSummary = {
  count: number;
  average: number;
  /** How many gave 1, 2, 3, 4, 5. Index 0 is one star. */
  spread: [number, number, number, number, number];
};

type Row = {
  id: string; rating: number; body: string | null; created_at: string; user_id: string;
  profiles: { display_name: string | null; show_purchases: boolean | null }
          | { display_name: string | null; show_purchases: boolean | null }[] | null;
};

/** First letters of the first two words. "Etieno Douglas" becomes ED. */
function initials(name: string | null | undefined): string {
  const parts = (name ?? "").trim().split(/\s+/).filter(Boolean).slice(0, 2);
  const s = parts.map((p) => p[0]?.toUpperCase() ?? "").join("");
  return s || "A buyer";
}

export async function reviewsFor(productId: string, viewerId?: string | null): Promise<Review[]> {
  const { data, error } = await createAdminClient()
    .from("mk_reviews")
    .select("id, rating, body, created_at, user_id, profiles(display_name, show_purchases)")
    .eq("product_id", productId)
    .order("created_at", { ascending: false })
    .limit(50);
  if (error) { console.error("reviews: list", error.message); return []; }

  return ((data ?? []) as unknown as Row[]).map((r) => {
    const p = Array.isArray(r.profiles) ? r.profiles[0] : r.profiles;
    return {
      id: r.id,
      rating: r.rating,
      body: r.body,
      at: r.created_at,
      // The same opt-out that governs buyer initials on the item page.
      who: p?.show_purchases === false ? "A buyer" : initials(p?.display_name),
      mine: !!viewerId && r.user_id === viewerId,
    };
  });
}

/** The bar chart beside the average. Derived here so the page stays a read. */
export function summarise(reviews: Review[]): ReviewSummary {
  const spread: [number, number, number, number, number] = [0, 0, 0, 0, 0];
  for (const r of reviews) spread[r.rating - 1] += 1;
  const count = reviews.length;
  const average = count ? reviews.reduce((n, r) => n + r.rating, 0) / count : 0;
  return { count, average, spread };
}

/**
 * Whether this person may review this item, and what they said last time.
 *
 * Ownership is the same rule the database enforces — a paid order or a
 * free claim. Checked here too so the form can be hidden rather than
 * shown and then refused, which reads as a bug.
 */
export async function reviewStanding(productId: string, userId: string | null | undefined) {
  if (!userId) return { owns: false, mine: null as Review | null };
  const admin = createAdminClient();
  const [{ data: order }, { data: claim }, { data: mine }] = await Promise.all([
    admin.from("mk_orders").select("id")
      .eq("user_id", userId).eq("product_id", productId).eq("status", "paid").limit(1).maybeSingle(),
    admin.from("mk_downloads").select("id")
      .eq("user_id", userId).eq("product_id", productId).limit(1).maybeSingle(),
    admin.from("mk_reviews").select("id, rating, body, created_at")
      .eq("user_id", userId).eq("product_id", productId).maybeSingle(),
  ]);
  return {
    owns: Boolean(order || claim),
    mine: mine
      ? { id: mine.id as string, rating: mine.rating as number, body: (mine.body as string) ?? null,
          at: mine.created_at as string, who: "You", mine: true }
      : null,
  };
}
