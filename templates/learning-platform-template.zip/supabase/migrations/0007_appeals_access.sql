-- =====================================================================
-- Appeals routing, transcripts, instructor departure
-- =====================================================================

-- ---------------------------------------------------------------------
-- Transcripts. Moved from "should" to "must": institutional buyers ask
-- about accessibility, and a transcript is also what makes a topic
-- readable on a connection too weak for video.
-- ---------------------------------------------------------------------
alter table topics add column transcript text;

-- ---------------------------------------------------------------------
-- Appeals. The second reviewer must not see the first verdict, and must
-- never be the person who gave it.
-- ---------------------------------------------------------------------
alter table appeals
  add column feedback text,
  add column decided_by uuid references instructors(id);

create or replace function public.assign_appeal(p_appeal_id uuid, p_reviewer_id uuid)
returns table (ok boolean, reason text)
language plpgsql security definer set search_path = public as $$
declare
  v_appeal appeals%rowtype;
  v_first  uuid;
begin
  select * into v_appeal from appeals where id = p_appeal_id for update;
  if not found then return query select false, 'not_found'; return; end if;
  if v_appeal.resolved_at is not null then return query select false, 'already_resolved'; return; end if;

  select r.reviewer_id into v_first
    from reviews r where r.submission_id = v_appeal.submission_id
   order by r.completed_at desc limit 1;

  if v_first = p_reviewer_id then
    return query select false, 'same_reviewer'; return;
  end if;

  update appeals set second_reviewer_id = p_reviewer_id where id = p_appeal_id;
  return query select true, null::text;
end; $$;

create or replace function public.resolve_appeal(
  p_appeal_id uuid, p_reviewer_id uuid, p_outcome review_outcome, p_feedback text
)
returns table (ok boolean, certificate_code text, reason text)
language plpgsql security definer set search_path = public as $$
declare
  v_appeal    appeals%rowtype;
  v_sub       submissions%rowtype;
  v_enrolment enrolments%rowtype;
  v_profile   profiles%rowtype;
  v_reviewer  text;
  v_code      text;
begin
  select * into v_appeal from appeals where id = p_appeal_id for update;
  if not found then return query select false, null::text, 'not_found'; return; end if;
  if v_appeal.resolved_at is not null then
    return query select false, null::text, 'already_resolved'; return;
  end if;
  if v_appeal.second_reviewer_id is distinct from p_reviewer_id then
    return query select false, null::text, 'not_assigned'; return;
  end if;

  update appeals
     set outcome = p_outcome, feedback = p_feedback,
         decided_by = p_reviewer_id, resolved_at = now()
   where id = p_appeal_id;

  -- The appeal reviewer is paid the same as any other assessment.
  insert into earnings_entries (instructor_id, type, amount_cents, ref_id, note)
  values (p_reviewer_id, 'review', 1885, v_appeal.submission_id, 'Appeal assessment');

  if p_outcome = 'revise' then
    return query select true, null::text, null::text; return;
  end if;

  -- Overturned. Issue the certificate the first verdict withheld.
  select * into v_sub from submissions where id = v_appeal.submission_id;
  select * into v_enrolment from enrolments where id = v_sub.enrolment_id;
  select * into v_profile from profiles where id = v_enrolment.user_id;
  select coalesce(pr.display_name, 'Your Brand reviewer') into v_reviewer
    from profiles pr where pr.id = p_reviewer_id;

  update submissions set state = 'passed' where id = v_appeal.submission_id;
  update enrolments  set state = 'certified' where id = v_enrolment.id;

  v_code := 'SPL-' || upper(substr(encode(gen_random_bytes(6), 'hex'), 1, 4))
            || '-' || upper(substr(encode(gen_random_bytes(6), 'hex'), 1, 4));

  insert into certificates (enrolment_id, code, reviewer_name, show_name)
  values (v_enrolment.id, v_code, v_reviewer,
          not coalesce(v_profile.minor_protections, false));

  return query select true, v_code, null::text;
end; $$;

-- ---------------------------------------------------------------------
-- Instructor departure. The terms promise 30 days' notice and continued
-- access for existing learners; this is what enforces it.
-- ---------------------------------------------------------------------
alter table instructors
  add column notice_given_at timestamptz,
  add column access_until    date;

create or replace function public.instructor_departs(p_instructor_id uuid, p_for_cause boolean)
returns int
language plpgsql security definer set search_path = public as $$
declare
  v_open int;
  v_until date;
begin
  -- Notice period plus 90 days of access for learners already enrolled.
  v_until := case when p_for_cause then current_date else current_date + 30 end + 90;

  update instructors
     set state = case when p_for_cause then 'suspended'::instructor_state else 'paused'::instructor_state end,
         available = false,
         notice_given_at = now(),
         access_until = v_until
   where id = p_instructor_id;

  -- Closed to new enrolments; existing learners keep going.
  update courses set state = 'unpublished'
   where instructor_id = p_instructor_id and state = 'published';

  -- Open reviews move to the queue for reassignment. The departing
  -- instructor is paid for work completed, not work held.
  update submissions
     set assigned_reviewer_id = null, state = 'submitted'
   where assigned_reviewer_id = p_instructor_id
     and state in ('assigned','in_review');

  get diagnostics v_open = row_count;
  return v_open;
end; $$;

revoke all on function public.assign_appeal(uuid, uuid) from public, anon, authenticated;
revoke all on function public.resolve_appeal(uuid, uuid, review_outcome, text) from public, anon, authenticated;
revoke all on function public.instructor_departs(uuid, boolean) from public, anon, authenticated;

-- Appeal reviewers read the submission they are assigned, and nothing else.
create policy appeal_reviewer_reads on appeals for select using (
  second_reviewer_id = auth.uid()
  or exists (
    select 1 from submissions s join enrolments e on e.id = s.enrolment_id
     where s.id = appeals.submission_id and e.user_id = auth.uid()
  )
);
