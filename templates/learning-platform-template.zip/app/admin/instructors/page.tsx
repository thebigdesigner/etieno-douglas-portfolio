import { createAdminClient } from "@/lib/supabase/admin";
import DepartForm from "./DepartForm";

export const metadata = { title: "Instructors" };
export const dynamic = "force-dynamic";

export default async function InstructorsPage() {
  const admin = createAdminClient();

  const { data: instructors } = await admin
    .from("instructors")
    .select("id, state, headline, available, reliability, access_until, profiles(display_name, email)")
    .in("state", ["active", "paused", "suspended"])
    .order("approved_at", { ascending: false });

  const rows = instructors ?? [];

  return (
    <>
        <h1 className="sec__h" style={{ fontSize: 30, marginTop: 34 }}>Instructors</h1>
        <p className="sec__meta">
          Departure closes courses to new enrolments and releases open reviews back to the
          queue. Existing learners keep access for the notice period plus 90 days, as the
          terms promise.
        </p>

        {rows.length === 0 ? (
          <div className="empty" style={{ marginTop: 28 }}>
            <p className="empty__h">No approved instructors yet</p>
            <p className="empty__p">Approve one from the applications queue.</p>
          </div>
        ) : (
          <div className="apps">
            {rows.map((i) => {
              const p = i.profiles as unknown as { display_name: string; email: string } | null;
              return (
                <article key={i.id} className="app">
                  <div className="app__head">
                    <div>
                      <div className="app__name">{p?.display_name ?? "Instructor"}</div>
                      <div className="app__hl">{i.headline}</div>
                    </div>
                    <div style={{ display: "grid", gap: 6, justifyItems: "end" }}>
                      <span className={`pill${i.state === "active" ? " pill--free" : " pill--lock"}`}>
                        {i.state}
                      </span>
                      {i.reliability !== null && (
                        <span className="rq__sub num">{i.reliability}% within SLA</span>
                      )}
                    </div>
                  </div>

                  {i.access_until && (
                    <p className="studio__hint" style={{ marginTop: 14 }}>
                      Learner access continues until{" "}
                      {new Date(i.access_until).toLocaleDateString()}.
                    </p>
                  )}

                  {i.state === "active" && <DepartForm instructorId={i.id} />}
                </article>
              );
            })}
          </div>
        )}
      </>
  );
}
