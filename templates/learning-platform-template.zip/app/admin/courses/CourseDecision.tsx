"use client";
import { useActionState } from "react";
import { decideCourse } from "@/app/actions/studio";
import type { FormState } from "@/lib/forms";
import { useFormStatus } from "react-dom";
import Alert from "@/components/Alert";

const initial: FormState = {};

function Btn({ label, variant }: { label: string; variant: string }) {
  const { pending } = useFormStatus();
  return <button className={`btn ${variant}`} disabled={pending}>{pending ? "…" : label}</button>;
}

export default function CourseDecision({ courseId }: { courseId: string }) {
  const [pubState, publish] = useActionState(decideCourse.bind(null, courseId, true), initial);
  const [revState, revise] = useActionState(decideCourse.bind(null, courseId, false), initial);

  if (pubState.ok || revState.ok) {
    return <Alert kind="success">{pubState.message ?? revState.message}</Alert>;
  }

  return (
    <div className="app__decide">
      <form action={publish}><Btn label="Publish" variant="btn--fill" /></form>
      <form action={revise} className="app__reject">
        <input name="note" placeholder="What needs changing" />
        <Btn label="Send back" variant="btn--line" />
      </form>
      {(pubState.error || revState.error) && (
        <Alert kind="error">{pubState.error ?? revState.error}</Alert>
      )}
    </div>
  );
}
