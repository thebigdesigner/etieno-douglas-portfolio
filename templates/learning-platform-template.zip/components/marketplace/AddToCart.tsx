"use client";

import Link from "next/link";
import { useState } from "react";
import type { Product } from "@/lib/marketplace/types";
import MkIcon from "@/components/marketplace/MkIcon";
import { addToCart, useCart, type Licence } from "@/lib/marketplace/cart";

/**
 * Sits inside the licence form so it can read whichever licence is
 * ticked, without the form needing to become a client component.
 */
export default function AddToCart({ product, cartHref }: { product: Product; cartHref: string }) {
  const inCart = useCart().some((l) => l.slug === product.slug);
  const [just, setJust] = useState(false);

  const add = (e: React.MouseEvent<HTMLButtonElement>) => {
    const form = e.currentTarget.form;
    const picked = form?.querySelector<HTMLInputElement>('input[name="licence"]:checked')?.value;
    addToCart(product, (picked === "commercial" ? "commercial" : "personal") as Licence);
    setJust(true);
  };

  return (
    <div className="mk-addcart">
      <button type="button" className="mk-btn mk-btn--line mk-btn--wide" onClick={add}>
        <MkIcon name={inCart ? "check" : "cart"} size={18} />
        {inCart ? (just ? "Added to cart" : "In your cart — update licence") : "Add to cart"}
      </button>
      {inCart && <Link href={cartHref} className="mk-addcart__go">View cart<MkIcon name="arrow-right" size={14} /></Link>}
    </div>
  );
}
