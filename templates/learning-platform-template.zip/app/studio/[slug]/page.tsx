import CourseScreen from "./CourseScreen";

export const dynamic = "force-dynamic";

type Params = Promise<{ slug: string }>;

/** The instructor's route into the editor. The screen itself is shared with
 *  the console, which renders it inside its own shell. */
export default async function StudioCoursePage({ params }: { params: Params }) {
  const { slug } = await params;
  return <CourseScreen slug={slug} backHref="/studio" backLabel="My courses" />;
}
