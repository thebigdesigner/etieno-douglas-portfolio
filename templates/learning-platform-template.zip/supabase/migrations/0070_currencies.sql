-- =====================================================================
-- Prices per currency, and wallets that can hold more than one.
--
-- A naira price is not a dollar price through an exchange rate. It is a
-- number somebody chose because it reads right in that market — ₦25,000,
-- not ₦28,417 — and it does not move when the rate does. So each product
-- carries a small price list, one row per currency, set deliberately.
--
-- The dollar price on mk_products stays the canonical one: it is what
-- listings fall back to, what the "free or paid" filters read, and what
-- exists for every product. The rows here are additions to it.
--
-- Because a sale can now be taken in any of these, a creator's earnings
-- are held per currency. No rate is invented to merge them: ₦20,000 from
-- a naira sale is paid out as naira, and pounds as pounds. Inventing a
-- conversion would mean the platform quietly taking the FX risk, and
-- getting it wrong in one direction or the other every single day.
-- =====================================================================

create table if not exists mk_product_prices (
  product_id       uuid not null references mk_products(id) on delete cascade,
  currency         text not null check (currency in ('USD','GBP','NGN')),
  price_cents      integer not null check (price_cents >= 0),
  commercial_cents integer check (commercial_cents is null or commercial_cents >= 0),
  updated_at       timestamptz not null default now(),
  primary key (product_id, currency),
  -- Same shape as the base price: free means free in both licences, and a
  -- commercial licence is never cheaper than a personal one.
  constraint mk_product_prices_shape check (
    (price_cents = 0 and commercial_cents is null) or
    (price_cents > 0 and (commercial_cents is null or commercial_cents >= price_cents))
  )
);
alter table mk_product_prices enable row level security;

-- Anyone may read the price of a published item; only the owner writes it.
drop policy if exists mk_product_prices_read on mk_product_prices;
create policy mk_product_prices_read on mk_product_prices for select using (
  exists (select 1 from mk_products p where p.id = product_id and p.state = 'published')
);

-- Seed the dollar row from what each product already charges, so every
-- published item has a complete price list from the first deploy.
insert into mk_product_prices (product_id, currency, price_cents, commercial_cents)
select id, 'USD', price_cents, commercial_price_cents from mk_products
on conflict (product_id, currency) do nothing;

-- ------------------------------------------------------- wallet per currency
alter table mk_wallet_entries add column if not exists currency text not null default 'USD'
  check (currency in ('USD','GBP','NGN'));
alter table mk_payouts add column if not exists currency text not null default 'USD'
  check (currency in ('USD','GBP','NGN'));
create index if not exists mk_wallet_ccy_idx on mk_wallet_entries (creator_id, currency);

-- A creator may be paid in more than one currency, so the single account
-- from 0068 becomes one per currency.
alter table mk_payout_accounts drop constraint if exists mk_payout_accounts_pkey;
alter table mk_payout_accounts add column if not exists id uuid not null default gen_random_uuid();
alter table mk_payout_accounts add primary key (creator_id, currency);

-- Balances, one row per currency held.
drop function if exists mk_wallet_balance(uuid);
create or replace function mk_wallet_balance(p_creator uuid)
returns table (currency text, available_cents bigint, pending_cents bigint, lifetime_cents bigint, withdrawn_cents bigint)
language sql stable as $$
  select
    e.currency,
    coalesce(sum(e.amount_cents) filter (where e.available_at <= now()), 0)::bigint,
    coalesce(sum(e.amount_cents) filter (where e.available_at > now()), 0)::bigint,
    coalesce(sum(e.amount_cents) filter (where e.kind = 'sale'), 0)::bigint,
    coalesce(-sum(e.amount_cents) filter (where e.kind = 'withdrawal'), 0)::bigint
  from mk_wallet_entries e where e.creator_id = p_creator group by e.currency;
$$;

-- A sale credits the currency it was taken in. The 20% is taken from the
-- amount actually charged, so no rate enters the calculation.
create or replace function mk_record_sale(p_order_id uuid, p_hold_days integer default 7)
returns void language plpgsql security definer set search_path = public as $$
declare
  v_order   mk_orders%rowtype;
  v_creator uuid;
  v_fee     integer;
begin
  select * into v_order from mk_orders where id = p_order_id for update;
  if not found or v_order.status <> 'paid' then return; end if;

  select creator_id into v_creator from mk_products where id = v_order.product_id;
  if v_creator is null then return; end if;

  v_fee := round(v_order.amount_cents * mk_commission_bp() / 10000.0);

  update mk_orders
     set creator_id = v_creator,
         commission_cents = v_fee,
         creator_cents = v_order.amount_cents - v_fee
   where id = p_order_id;

  insert into mk_wallet_entries (creator_id, kind, amount_cents, currency, available_at, order_id, note)
  values (v_creator, 'sale', v_order.amount_cents - v_fee, v_order.currency,
          coalesce(v_order.paid_at, now()) + make_interval(days => p_hold_days),
          p_order_id, 'Sale, less 20% platform fee')
  on conflict (order_id, kind) do nothing;
end;
$$;

-- Withdrawals name their currency, and are checked against that balance
-- and that payout account.
drop function if exists mk_request_payout(uuid, integer);
create or replace function mk_request_payout(p_creator uuid, p_amount_cents integer, p_currency text default 'USD')
returns uuid language plpgsql security definer set search_path = public as $$
declare
  v_available bigint;
  v_account   mk_payout_accounts%rowtype;
  v_payout    uuid;
begin
  if p_amount_cents is null or p_amount_cents <= 0 then
    raise exception 'amount must be positive' using errcode = '22023';
  end if;

  select * into v_account from mk_payout_accounts
   where creator_id = p_creator and currency = p_currency;
  if not found or v_account.account_number is null then
    raise exception 'no payout account' using errcode = 'P0002';
  end if;

  perform 1 from mk_wallet_entries where creator_id = p_creator and currency = p_currency for update;
  select available_cents into v_available from mk_wallet_balance(p_creator) b where b.currency = p_currency;
  if coalesce(v_available, 0) < p_amount_cents then
    raise exception 'insufficient available balance' using errcode = 'P0001';
  end if;

  insert into mk_payouts (creator_id, amount_cents, currency, account)
  values (p_creator, p_amount_cents, p_currency, to_jsonb(v_account) - 'creator_id')
  returning id into v_payout;

  insert into mk_wallet_entries (creator_id, kind, amount_cents, currency, payout_id, note)
  values (p_creator, 'withdrawal', -p_amount_cents, p_currency, v_payout, 'Withdrawal requested');

  return v_payout;
end;
$$;

create or replace function mk_reverse_payout(p_payout uuid, p_status text, p_note text default null)
returns void language plpgsql security definer set search_path = public as $$
declare v_p mk_payouts%rowtype;
begin
  select * into v_p from mk_payouts where id = p_payout for update;
  if not found or v_p.status in ('paid','rejected','cancelled') then return; end if;

  update mk_payouts set status = p_status, note = p_note, decided_at = now() where id = p_payout;

  insert into mk_wallet_entries (creator_id, kind, amount_cents, currency, payout_id, note)
  values (v_p.creator_id, 'withdrawal_reversed', v_p.amount_cents, v_p.currency, p_payout,
          coalesce(p_note, 'Withdrawal ' || p_status));
end;
$$;
