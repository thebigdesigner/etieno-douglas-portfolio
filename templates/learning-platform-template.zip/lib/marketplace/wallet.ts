// Server only: uses the service-role client.
import { createAdminClient } from "@/lib/supabase/admin";
import { isCcy, type Ccy } from "@/lib/currency";

/**
 * Creator earnings. The ledger (mk_wallet_entries) is the truth; nothing
 * here keeps a running total. Every read goes through the service role
 * because wallet rows have no read policy: a creator sees their own money
 * through these functions, which always scope by their creator id.
 */

export type Balance = { currency: Ccy; available: number; pending: number; lifetime: number; withdrawn: number };
export type Entry = {
  id: string; kind: "sale" | "refund" | "withdrawal" | "withdrawal_reversed" | "adjustment";
  amountCents: number; currency: Ccy; availableAt: string; createdAt: string; note: string | null; productTitle: string | null;
};
export type Payout = {
  id: string; amountCents: number; currency: Ccy; status: "requested" | "approved" | "paid" | "rejected" | "cancelled";
  requestedAt: string; paidAt: string | null; note: string | null; reference: string | null;
};
export type PayoutAccount = {
  country: string; currency: string; bankName: string | null;
  accountNumber: string | null; accountName: string | null;
};

/**
 * The smallest withdrawal, per currency, set so a transfer fee never eats
 * a meaningful share of the payout. These are judgements about each
 * market, not one figure converted three ways.
 */
export const MIN_PAYOUT: Record<Ccy, number> = { USD: 1000, GBP: 1000, NGN: 500000 };  // $10, £10, ₦5,000
export const MIN_PAYOUT_CENTS = MIN_PAYOUT.USD;
export const HOLD_DAYS = 7;

/**
 * One balance per currency held. A creator selling in naira and pounds has
 * two, paid out separately: merging them would mean inventing an exchange
 * rate and carrying the risk of it.
 */
export async function balances(creatorId: string): Promise<Balance[]> {
  const { data, error } = await createAdminClient().rpc("mk_wallet_balance", { p_creator: creatorId });
  if (error) { console.error("wallet: balances", error.message); return []; }
  type Row = { currency: string; available_cents: number; pending_cents: number; lifetime_cents: number; withdrawn_cents: number };
  const rows = ((Array.isArray(data) ? data : []) as Row[])
    .filter((r) => isCcy(r.currency))
    .map((r) => ({
      currency: r.currency as Ccy,
      available: Number(r.available_cents ?? 0),
      pending: Number(r.pending_cents ?? 0),
      lifetime: Number(r.lifetime_cents ?? 0),
      withdrawn: Number(r.withdrawn_cents ?? 0),
    }));
  // Dollars first, then whatever else they hold, so the page is stable.
  return rows.sort((a, b) => (a.currency === "USD" ? -1 : b.currency === "USD" ? 1 : a.currency.localeCompare(b.currency)));
}

export async function entries(creatorId: string, limit = 25): Promise<Entry[]> {
  const { data } = await createAdminClient().from("mk_wallet_entries")
    .select("id, kind, amount_cents, currency, available_at, created_at, note, mk_orders(mk_products(title))")
    .eq("creator_id", creatorId).order("created_at", { ascending: false }).limit(limit);
  type Row = {
    id: string; kind: Entry["kind"]; amount_cents: number; currency: Ccy; available_at: string; created_at: string; note: string | null;
    mk_orders: { mk_products: { title: string } | { title: string }[] | null } | null;
  };
  return ((data ?? []) as unknown as Row[]).map((r) => {
    const p = r.mk_orders?.mk_products;
    return {
      id: r.id, kind: r.kind, amountCents: r.amount_cents, currency: r.currency, availableAt: r.available_at,
      createdAt: r.created_at, note: r.note,
      productTitle: (Array.isArray(p) ? p[0]?.title : p?.title) ?? null,
    };
  });
}

export async function payouts(creatorId: string, limit = 20): Promise<Payout[]> {
  const { data } = await createAdminClient().from("mk_payouts")
    .select("id, amount_cents, currency, status, requested_at, paid_at, note, reference")
    .eq("creator_id", creatorId).order("requested_at", { ascending: false }).limit(limit);
  type Row = { id: string; amount_cents: number; currency: Ccy; status: Payout["status"]; requested_at: string; paid_at: string | null; note: string | null; reference: string | null };
  return ((data ?? []) as Row[]).map((r) => ({
    id: r.id, amountCents: r.amount_cents, currency: r.currency, status: r.status,
    requestedAt: r.requested_at, paidAt: r.paid_at, note: r.note, reference: r.reference,
  }));
}

/** One account per currency a creator is paid in. */
export async function payoutAccounts(creatorId: string): Promise<Record<string, PayoutAccount>> {
  const { data } = await createAdminClient().from("mk_payout_accounts")
    .select("country, currency, bank_name, account_number, account_name")
    .eq("creator_id", creatorId);
  return Object.fromEntries(((data ?? []) as {
    country: string; currency: string; bank_name: string | null;
    account_number: string | null; account_name: string | null;
  }[]).map((d) => [d.currency, {
    country: d.country, currency: d.currency, bankName: d.bank_name,
    accountNumber: d.account_number, accountName: d.account_name,
  }]));
}

/** Sales, newest first, for the earnings page's list. */
export async function recentSales(creatorId: string, limit = 10) {
  const { data } = await createAdminClient().from("mk_orders")
    .select("id, amount_cents, currency, creator_cents, commission_cents, paid_at, licence, mk_products(title)")
    .eq("creator_id", creatorId).eq("status", "paid")
    .order("paid_at", { ascending: false }).limit(limit);
  type Row = {
    id: string; amount_cents: number; currency: Ccy; creator_cents: number | null;
    commission_cents: number | null; paid_at: string | null; licence: string;
    mk_products: { title: string } | { title: string }[] | null;
  };
  return ((data ?? []) as unknown as Row[]).map((r) => ({
    id: r.id, paidAt: r.paid_at, licence: r.licence, currency: r.currency, amountCents: r.amount_cents,
    creatorCents: r.creator_cents ?? 0, feeCents: r.commission_cents ?? 0,
    title: (Array.isArray(r.mk_products) ? r.mk_products[0]?.title : r.mk_products?.title) ?? "Item",
  }));
}

/** The operator queue: everything waiting to be approved or paid. */
export async function openPayouts() {
  const { data } = await createAdminClient().from("mk_payouts")
    .select("id, amount_cents, currency, status, requested_at, account, note, mk_creators(handle, display_name)")
    .in("status", ["requested", "approved"]).order("requested_at", { ascending: true });
  type Row = {
    id: string; amount_cents: number; currency: Ccy; status: string; requested_at: string; note: string | null;
    account: Record<string, string | null>;
    mk_creators: { handle: string; display_name: string } | { handle: string; display_name: string }[] | null;
  };
  return ((data ?? []) as unknown as Row[]).map((r) => ({
    id: r.id, amountCents: r.amount_cents, currency: r.currency, status: r.status, requestedAt: r.requested_at, note: r.note,
    account: r.account ?? {},
    creator: Array.isArray(r.mk_creators) ? r.mk_creators[0] : r.mk_creators,
  }));
}
