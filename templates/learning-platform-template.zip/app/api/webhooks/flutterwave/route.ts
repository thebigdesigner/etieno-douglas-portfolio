import { NextResponse } from "next/server";
import { timingSafeEqual } from "crypto";
import { createAdminClient } from "@/lib/supabase/admin";
import { fulfilPayment } from "@/lib/fulfil";

export const dynamic = "force-dynamic";

/**
 * Flutterwave webhook.
 *
 * Three defences, in order, because this endpoint grants paid access to
 * anyone who can convince it:
 *
 *   1. The `verif-hash` header must match FLW_WEBHOOK_HASH. Flutterwave
 *      uses a shared secret rather than an HMAC of the body, so this only
 *      proves the sender knows the secret — which is why it is not the
 *      last check.
 *   2. The transaction is re-verified against Flutterwave's own API. The
 *      request body is attacker-supplied; that response is not.
 *   3. The amount is checked against the plan's real price, so a genuine
 *      1-unit payment cannot be replayed as a Complete subscription.
 *
 * Idempotency is handled by a unique key on the event log plus an
 * activate_subscription() that no-ops on a provider_ref it already has.
 * Flutterwave retries for up to 72 hours, so duplicates are certain.
 */
export async function POST(request: Request) {
  const expected = process.env.FLW_WEBHOOK_HASH;
  if (!expected) {
    console.error("FLW_WEBHOOK_HASH unset — refusing webhook");
    return NextResponse.json({ error: "not configured" }, { status: 503 });
  }

  const given = request.headers.get("verif-hash") ?? "";
  const a = Buffer.from(given);
  const b = Buffer.from(expected);
  if (a.length !== b.length || !timingSafeEqual(a, b)) {
    return NextResponse.json({ error: "bad signature" }, { status: 401 });
  }

  let body: { event?: string; data?: Record<string, unknown> };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "bad body" }, { status: 400 });
  }

  const event = String(body.event ?? "");
  const data = body.data ?? {};
  const txRef = data.tx_ref ? String(data.tx_ref) : null;
  const providerRef = data.id ? String(data.id) : txRef;

  if (!providerRef) return NextResponse.json({ ok: true });

  const admin = createAdminClient();

  // Record first. The unique constraint is what makes a retry harmless.
  const { error: logErr } = await admin.from("payment_events").insert({
    provider: "flutterwave",
    event_type: event,
    provider_ref: providerRef,
    tx_ref: txRef,
    payload: body as unknown as Record<string, unknown>,
  });

  // Already seen this exact event — acknowledge and stop.
  if (logErr && logErr.code === "23505") {
    return NextResponse.json({ ok: true, duplicate: true });
  }

  if (event === "subscription.cancelled") {
    const email = (data.customer as { email?: string } | undefined)?.email;
    if (email) {
      const { data: profile } = await admin
        .from("profiles").select("id").eq("email", email).maybeSingle();
      if (profile) await admin.rpc("cancel_subscription", { p_user_id: profile.id });
    }
    return NextResponse.json({ ok: true });
  }

  if (event !== "charge.completed") return NextResponse.json({ ok: true });

  if (!txRef) return NextResponse.json({ ok: true });

  const result = await fulfilPayment(txRef);
  if (!result.ok) {
    console.error("webhook fulfil declined", txRef, result.reason);
    return NextResponse.json({ ok: true, ignored: result.reason });
  }

  await admin.from("payment_events")
    .update({ handled_at: new Date().toISOString() })
    .eq("provider_ref", providerRef).eq("event_type", event);

  return NextResponse.json({ ok: true });
}
