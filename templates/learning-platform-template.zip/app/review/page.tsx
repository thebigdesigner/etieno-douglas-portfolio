import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { isOwnerEmail } from "@/lib/owner";
import { slaLabel } from "@/lib/sla";

export const metadata = { title: "Review queue" };
export const dynamic = "force-dynamic";

type Row = {
  submission_id: string;
  state: string;
  submitted_at: string;
  deadline_at: string;
  assigned_reviewer_id: string | null;
  course_title: string;
  learner_name: string | null;
  breached: boolean;
  due_soon: boolean;
};

export default async function ReviewQueuePage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  const admin = createAdminClient();
  const { data: profile } = await admin
    .from("profiles").select("role").eq("id", user!.id).maybeSingle();

  let query = admin
    .from("review_queue_status")
    .select("*")
    .order("deadline_at", { ascending: true });

  /* Everyone sees their own queue; only Your Brand sees all of them.
   *
   * This was written as "if instructor, scope it" — an allowlist that
   * happened to hold while instructor and operator were the only roles
   * that could reach the page. Widening the door to institution
   * assessors would have turned it into a leak: an organisation's admin
   * reading every other organisation's and every practitioner's pending
   * submissions. Scoping is now the default and seeing everything is
   * the exception, which is the way round that survives the next role. */
  const operator = profile?.role === "operator" || isOwnerEmail(user!.email);
  if (!operator) {
    query = query.eq("assigned_reviewer_id", user!.id);
  }

  const { data } = await query;
  const rows = (data ?? []) as Row[];

  const { data: appeals } = await admin
    .from("appeals")
    .select("id, submission_id, grounds")
    .eq("second_reviewer_id", user!.id)
    .is("resolved_at", null);
  const breached = rows.filter((r) => r.breached).length;

  return (
    <>
        <div className="sec__head" style={{ marginTop: 34 }}>
          <div>
            <h1 className="sec__h" style={{ fontSize: 30 }}>
              {rows.length} waiting
            </h1>
            <div className="sec__meta">
              Oldest deadline first. Four working days from submission.
              {breached > 0 && (
                <> · <strong style={{ color: "#9B2C22" }}>{breached} past the promise</strong></>
              )}
            </div>
          </div>
        </div>

        {appeals && appeals.length > 0 && (
          <div className="awaiting" style={{ marginTop: 24 }}>
            <div className="eyebrow">Second readings assigned to you</div>
            {appeals.map((a) => (
              <div key={a.id} className="awaiting__row">
                <span className="awaiting__t">An appeal is waiting on your reading</span>
                <Link className="sec__link" href={`/review/appeal/${a.id}`}>Open</Link>
              </div>
            ))}
          </div>
        )}

        {rows.length === 0 ? (
          <div className="empty" style={{ marginTop: 30 }}>
            <p className="empty__h">Nothing waiting</p>
            <p className="empty__p">
              Projects appear here as learners submit them. You will get an email too.
            </p>
          </div>
        ) : (
          <div className="rq">
            {rows.map((r) => {
              const sla = slaLabel(r.deadline_at);
              return (
                <Link key={r.submission_id} className={`rq__row${r.breached ? " is-late" : r.due_soon ? " is-soon" : ""}`}
                  href={`/review/${r.submission_id}`}>
                  <div>
                    <div className="rq__course">{r.course_title}</div>
                    <div className="rq__learner">{r.learner_name ?? "Learner"}</div>
                  </div>
                  <div className="rq__meta">
                    <span className="rq__sub num">
                      submitted {new Date(r.submitted_at).toLocaleDateString()}
                    </span>
                    <span className={`rq__clock${r.breached ? " is-late" : r.due_soon ? " is-soon" : ""}`}>
                      {sla}
                    </span>
                  </div>
                  <span className="rq__go">Assess &rarr;</span>
                </Link>
              );
            })}
          </div>
        )}
      </>
  );
}
