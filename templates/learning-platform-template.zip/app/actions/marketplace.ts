"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { createAdminClient } from "@/lib/supabase/admin";
import { requireProfile } from "@/lib/guard";
import { categoryBySlug } from "@/lib/marketplace/categories";
import { studioViewer, myItem } from "@/lib/marketplace/studio";
import { MIN_PAYOUT } from "@/lib/marketplace/wallet";
import { CCY_LABEL, isCcy, money, type Ccy } from "@/lib/currency";
import type { FormState } from "@/lib/forms";
import { sendEmail } from "@/lib/email";
import { itemApproved, itemNeedsChanges, itemUpdated } from "@/lib/notifications";
import { siteUrl } from "@/lib/site";

/**
 * Creator studio writes. Every action starts from the signed-in user's own
 * shop and checks the item belongs to it; ids from the form are never
 * trusted on their own. Writes use the service role because mk_products
 * has no write policy for anyone (see 0065), which keeps the rules here,
 * in one place, rather than split between SQL and code.
 */

const HANDLE = /^[a-z0-9][a-z0-9-]{2,39}$/;
const MAX_PRICE_CENTS = 100_000; // $1,000 — well past anything sensible, catches a typo'd extra zero

function text(fd: FormData, k: string): string { return String(fd.get(k) ?? "").trim(); }
function lines(v: string): string[] { return v.split("\n").map((s) => s.trim()).filter(Boolean).slice(0, 20); }
/** "25000" → 2500000 minor units. Same shape in every currency. */
function unitsToCents(v: string): number | null {
  if (v === "") return null;
  const n = Number(v.replace(/[$,\s]/g, ""));
  return Number.isFinite(n) && n >= 0 ? Math.round(n * 100) : NaN;
}
function slugify(s: string): string {
  return s.toLowerCase().normalize("NFKD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 70) || "item";
}

async function uniqueSlug(base: string, exceptId?: string): Promise<string> {
  const admin = createAdminClient();
  const root = base.length >= 3 ? base : `${base}-item`;
  for (let n = 1; n < 50; n++) {
    const slug = n === 1 ? root : `${root}-${n}`;
    const { data } = await admin.from("mk_products").select("id").eq("slug", slug).maybeSingle();
    if (!data || data.id === exceptId) return slug;
  }
  return `${root}-${Date.now().toString(36)}`;
}

async function needShop() {
  const v = await studioViewer();
  if (!v) return { error: "Sign in to use the studio." } as const;
  if (!v.shop) return { error: "Set up your shop first." } as const;
  return { v, shop: v.shop } as const;
}

// ---------------------------------------------------------------- shop

export async function createShop(_prev: FormState, fd: FormData): Promise<FormState> {
  const v = await studioViewer();
  if (!v) return { error: "Sign in to open a shop." };
  if (v.shop) redirect("/marketplace/studio");

  const displayName = text(fd, "display_name");
  const handle = text(fd, "handle").toLowerCase();
  const location = text(fd, "location") || null;
  const bio = text(fd, "bio") || null;

  if (displayName.length < 2 || displayName.length > 60) return { error: "Shop name must be 2 to 60 characters." };
  if (!HANDLE.test(handle)) return { error: "Shop address: 3 to 40 lowercase letters, numbers or hyphens, starting with a letter or number." };
  if (bio && bio.length > 600) return { error: "Keep the bio under 600 characters." };

  const admin = createAdminClient();
  const { data: taken } = await admin.from("mk_creators").select("id").eq("handle", handle).maybeSingle();
  if (taken) return { error: `marketplace.yourbrand.com/author/${handle} is taken. Try another address.` };

  const { error } = await admin.from("mk_creators").insert({
    user_id: v.userId, handle, display_name: displayName, location, bio,
    hue: v.userId.charCodeAt(0) % 6,
  });
  if (error) {
    console.error("studio: createShop", error.message);
    return { error: "Could not open the shop. Try again in a moment." };
  }
  revalidatePath("/marketplace/studio");
  redirect("/marketplace/studio");
}

// ---------------------------------------------------------------- items

/**
 * Saves the details. Creates the draft on first save and returns to its
 * editor, so uploads (which need an item id for their folder) come after.
 */
export async function saveItem(_prev: FormState, fd: FormData): Promise<FormState> {
  const got = await needShop();
  if ("error" in got) return { error: got.error };
  const { shop } = got;

  const id = text(fd, "id") || null;
  const existing = id ? await myItem(shop.id, id) : null;
  if (id && !existing) return { error: "That item is not in your shop." };

  const title = text(fd, "title");
  const category = text(fd, "category");
  const subcategory = text(fd, "subcategory");
  const summary = text(fd, "summary");
  const includes = lines(text(fd, "includes"));
  const tags = text(fd, "tags").split(",").map((t) => t.trim().toLowerCase()).filter(Boolean).slice(0, 12);
  const formats = fd.getAll("formats").map(String);
  const price = unitsToCents(text(fd, "price"));
  const commercial = unitsToCents(text(fd, "commercial_price"));

  const cat = categoryBySlug(category);
  if (title.length < 3 || title.length > 90) return { error: "Title must be 3 to 90 characters." };
  if (!cat) return { error: "Choose a category." };
  if (!cat.subcategories.some((s) => s.slug === subcategory)) return { error: "Choose a type within the category." };
  if (summary.length < 20 || summary.length > 600) return { error: "Description must be 20 to 600 characters." };
  if (formats.some((f) => !cat.formats.includes(f))) return { error: "One of the formats does not belong to this category." };
  if (price === null || Number.isNaN(price)) return { error: "Enter a price, or 0 for free." };
  if (price > MAX_PRICE_CENTS) return { error: "The price is over $1,000. Check for an extra zero." };
  if (Number.isNaN(commercial as number)) return { error: "The commercial price is not a number." };
  if (price === 0 && commercial) return { error: "A free item cannot have a commercial price: free covers commercial use." };
  if (commercial !== null && commercial < price) return { error: "The commercial licence cannot cost less than the personal one." };
  if (commercial !== null && commercial > MAX_PRICE_CENTS) return { error: "The commercial price is over $1,000. Check for an extra zero." };

  /**
   * Pounds and naira are set by hand, not converted. A blank currency
   * means buyers there are charged in dollars, so an empty field removes
   * the row rather than storing a zero, which would read as "free".
   */
  const local: { currency: Ccy; price_cents: number; commercial_cents: number | null }[] = [];
  const dropped: Ccy[] = [];
  for (const c of ["GBP", "NGN"] as const) {
    const raw = text(fd, `price_${c}`);
    const p = raw === "" ? null : unitsToCents(raw);
    const com = unitsToCents(text(fd, `commercial_${c}`));
    if (p === null || price === 0) { dropped.push(c); continue; }
    if (Number.isNaN(p) || p < 0) return { error: `The ${CCY_LABEL[c]} price is not a number.` };
    if (Number.isNaN(com as number)) return { error: `The ${CCY_LABEL[c]} commercial price is not a number.` };
    if (p === 0) return { error: `An item cannot be free in ${CCY_LABEL[c]} only. Leave it blank to charge in dollars.` };
    if (com !== null && com < p) return { error: `The ${CCY_LABEL[c]} commercial licence cannot cost less than the personal one.` };
    local.push({ currency: c, price_cents: p, commercial_cents: com });
  }

  const row = {
    title, category, subcategory, summary, includes, tags, formats,
    price_cents: price, commercial_price_cents: price === 0 ? null : commercial,
  };
  const admin = createAdminClient();

  /** The dollar row mirrors mk_products, so every item has a full list. */
  const writePrices = async (productId: string) => {
    await admin.from("mk_product_prices").upsert([
      { product_id: productId, currency: "USD", price_cents: price,
        commercial_cents: price === 0 ? null : commercial, updated_at: new Date().toISOString() },
      ...local.map((l) => ({ product_id: productId, ...l, updated_at: new Date().toISOString() })),
    ]);
    if (dropped.length) {
      await admin.from("mk_product_prices").delete().eq("product_id", productId).in("currency", dropped);
    }
  };

  if (existing) {
    const { error } = await admin.from("mk_products").update(row).eq("id", existing.id).eq("creator_id", shop.id);
    if (error) { console.error("studio: saveItem update", error.message); return { error: "Could not save. Try again." }; }
    await writePrices(existing.id);
    revalidatePath(`/marketplace/studio/items/${existing.id}`);
    revalidatePath("/marketplace/studio");
    if (existing.state === "published") revalidatePath(`/marketplace/item/${existing.slug}`);
    return { ok: true, message: "Saved." };
  }

  const slug = await uniqueSlug(slugify(title));
  const { data, error } = await admin.from("mk_products")
    .insert({ ...row, creator_id: shop.id, slug, state: "draft" }).select("id").single();
  if (error || !data) { console.error("studio: saveItem insert", error?.message); return { error: "Could not create the item. Try again." }; }
  await writePrices(data.id);
  revalidatePath("/marketplace/studio");
  redirect(`/marketplace/studio/items/${data.id}?created=1`);
}

/** The browser has uploaded into the user's folder; attach it to the item. */
export async function attachUpload(input: {
  id: string; kind: "cover" | "file"; path: string; name?: string; bytes?: number;
}): Promise<FormState> {
  const got = await needShop();
  if ("error" in got) return { error: got.error };
  const { v, shop } = got;
  const item = await myItem(shop.id, input.id);
  if (!item) return { error: "That item is not in your shop." };

  // The path must be inside this user's folder and this item's subfolder:
  // storage policy stops writes elsewhere, this stops attaching someone
  // else's upload by guessing its path.
  const prefix = `${v.userId}/${item.id}/`;
  if (!input.path.startsWith(prefix) || input.path.includes("..")) return { error: "That upload is not yours." };

  const admin = createAdminClient();
  const bucket = input.kind === "cover" ? "mk-covers" : "mk-files";
  const folder = input.path.slice(0, input.path.lastIndexOf("/"));
  const fname = input.path.slice(input.path.lastIndexOf("/") + 1);
  const { data: listed } = await admin.storage.from(bucket).list(folder, { search: fname });
  if (!listed?.some((o) => o.name === fname)) return { error: "The upload did not arrive. Try again." };

  if (input.kind === "cover") {
    const url = admin.storage.from("mk-covers").getPublicUrl(input.path).data.publicUrl;
    const old = item.coverUrl;
    const { error } = await admin.from("mk_products").update({ cover_url: url }).eq("id", item.id);
    if (error) return { error: "Could not save the cover." };
    const oldPath = old?.split("/mk-covers/")[1];
    if (oldPath && oldPath !== input.path) await admin.storage.from("mk-covers").remove([oldPath]);
  } else {
    const { data: prev } = await admin.from("mk_product_files").select("path").eq("product_id", item.id).maybeSingle();
    const bytes = typeof input.bytes === "number" && input.bytes >= 0 ? Math.round(input.bytes) : null;
    const { error } = await admin.from("mk_product_files").upsert({
      product_id: item.id, path: input.path, bytes, name: (input.name ?? fname).slice(0, 200),
      updated_at: new Date().toISOString(),
    });
    if (error) return { error: "Could not save the file." };
    await admin.from("mk_products").update({ file_size: bytes ? humanSize(bytes) : null }).eq("id", item.id);
    if (prev?.path && prev.path !== input.path) await admin.storage.from("mk-files").remove([prev.path]);
  }
  revalidatePath(`/marketplace/studio/items/${item.id}`);
  if (item.state === "published") revalidatePath(`/marketplace/item/${item.slug}`);
  return { ok: true };
}

function humanSize(b: number): string {
  if (b < 1024 * 1024) return `${Math.max(1, Math.round(b / 1024))} KB`;
  if (b < 1024 ** 3) return `${(b / 1024 ** 2).toFixed(b < 10 * 1024 ** 2 ? 1 : 0)} MB`;
  return `${(b / 1024 ** 3).toFixed(1)} GB`;
}

/** Draft or sent-back item -> review queue. Needs everything a buyer sees. */
export async function submitItem(id: string): Promise<FormState> {
  const got = await needShop();
  if ("error" in got) return { error: got.error };
  const item = await myItem(got.shop.id, id);
  if (!item) return { error: "That item is not in your shop." };
  if (item.state === "in_review") return { ok: true };
  if (item.state === "published") return { error: "This item is already live." };
  const missing = [
    !item.coverUrl && "a cover image",
    !item.file && "the file buyers download",
    item.formats.length === 0 && "at least one file format",
  ].filter(Boolean);
  if (missing.length) return { error: `Add ${missing.join(" and ")} before submitting.` };

  /**
   * Your Brand's own shop publishes straight away. Queueing it would mean
   * the same desk writing the item, reading it and approving it — a
   * review in name only, and two days of nobody being able to buy.
   */
  const now = new Date().toISOString();
  const patch = got.shop.house
    ? { state: "published" as const, published_at: now, submitted_at: now, review_note: null }
    : { state: "in_review" as const, submitted_at: now, review_note: null };

  const { error } = await createAdminClient().from("mk_products")
    .update(patch).eq("id", item.id).eq("creator_id", got.shop.id);
  if (error) return { error: "Could not submit. Try again." };
  revalidatePath("/marketplace/studio");
  revalidatePath(`/marketplace/studio/items/${item.id}`);
  if (got.shop.house) {
    revalidatePath("/marketplace");
    revalidatePath(`/marketplace/item/${item.slug}`);
    return { ok: true, message: "Published." };
  }
  return { ok: true, message: "Submitted. We review new items within two working days." };
}

/** Take an item off sale. Past buyers keep their downloads. */
export async function retireItem(id: string): Promise<FormState> {
  const got = await needShop();
  if ("error" in got) return { error: got.error };
  const item = await myItem(got.shop.id, id);
  if (!item) return { error: "That item is not in your shop." };
  const next = item.state === "in_review" ? "draft" : "retired";
  const { error } = await createAdminClient().from("mk_products").update({ state: next }).eq("id", item.id);
  if (error) return { error: "Could not update the item." };
  revalidatePath("/marketplace/studio");
  revalidatePath(`/marketplace/studio/items/${item.id}`);
  revalidatePath(`/marketplace/item/${item.slug}`);
  return { ok: true, message: next === "draft" ? "Withdrawn from review." : "Taken off sale." };
}

/** Only drafts that were never sold can be deleted; anything else is retired. */
export async function deleteDraft(id: string): Promise<FormState> {
  const got = await needShop();
  if ("error" in got) return { error: got.error };
  const { v, shop } = got;
  const item = await myItem(shop.id, id);
  if (!item) return { error: "That item is not in your shop." };
  if (item.state !== "draft") return { error: "Only drafts can be deleted. Take it off sale instead." };
  const admin = createAdminClient();
  const { count } = await admin.from("mk_orders").select("id", { head: true, count: "exact" }).eq("product_id", item.id);
  if (count) return { error: "This item has orders, so it can only be taken off sale." };

  for (const bucket of ["mk-covers", "mk-files"]) {
    const { data } = await admin.storage.from(bucket).list(`${v.userId}/${item.id}`);
    if (data?.length) await admin.storage.from(bucket).remove(data.map((o) => `${v.userId}/${item.id}/${o.name}`));
  }
  await admin.from("mk_products").delete().eq("id", item.id).eq("creator_id", shop.id);
  revalidatePath("/marketplace/studio");
  redirect("/marketplace/studio");
}

// ---------------------------------------------------------------- review

/** Operators only. Approve publishes; reject sends it back with a note. */
export async function reviewItem(_prev: FormState, fd: FormData): Promise<FormState> {
  await requireProfile(["operator"], { next: "/admin/marketplace" });
  const id = text(fd, "id");
  const decision = text(fd, "decision");
  const note = text(fd, "note");
  const admin = createAdminClient();
  const { data: item } = await admin.from("mk_products")
    .select("id, slug, title, state, mk_creators(display_name, user_id)").eq("id", id).maybeSingle();
  if (!item || item.state !== "in_review") return { error: "That item is no longer waiting for review." };

  if (decision === "approve") {
    const { error } = await admin.from("mk_products")
      .update({ state: "published", published_at: new Date().toISOString(), review_note: null }).eq("id", id);
    if (error) return { error: "Could not publish." };
    revalidatePath("/marketplace");
    revalidatePath(`/marketplace/item/${item.slug}`);
    await tellCreator(item, "approve");
  } else if (decision === "reject") {
    if (note.length < 10) return { error: "Tell the creator what to change (at least a sentence)." };
    const { error } = await admin.from("mk_products").update({ state: "draft", review_note: note.slice(0, 1000) }).eq("id", id);
    if (error) return { error: "Could not send it back." };
    await tellCreator(item, "reject", note.slice(0, 1000));
  } else {
    return { error: "Choose approve or send back." };
  }
  revalidatePath("/admin/marketplace");
  return { ok: true };
}

// ---------------------------------------------------------------- wallet

/** Where a creator's withdrawals are sent. Replaces whatever was there. */
export async function savePayoutAccount(_prev: FormState, fd: FormData): Promise<FormState> {
  const got = await needShop();
  if ("error" in got) return { error: got.error };

  const country = text(fd, "country").toUpperCase() || "NG";
  // Which wallet this account is for. Fixed by the form it came from, so a
  // naira balance can never be sent to a dollar account by accident.
  const currency = text(fd, "currency").toUpperCase();
  if (!isCcy(currency)) return { error: "Choose a currency." };
  const bankName = text(fd, "bank_name");
  const accountNumber = text(fd, "account_number").replace(/\s+/g, "");
  const accountName = text(fd, "account_name");

  if (bankName.length < 2) return { error: "Enter your bank's name." };
  if (!/^[0-9]{6,20}$/.test(accountNumber)) return { error: "Enter the account number, digits only." };
  if (accountName.length < 2) return { error: "Enter the name on the account." };
  if (!/^[A-Z]{2}$/.test(country)) return { error: "Choose a country." };

  const { error } = await createAdminClient().from("mk_payout_accounts").upsert({
    creator_id: got.shop.id, country, currency, bank_name: bankName,
    account_number: accountNumber, account_name: accountName,
    updated_at: new Date().toISOString(),
  });
  if (error) { console.error("studio: savePayoutAccount", error.message); return { error: "Could not save those details." }; }
  revalidatePath("/marketplace/studio/earnings");
  return { ok: true, message: "Payout details saved." };
}

/**
 * Asks for money out. The balance check and the debit happen inside
 * mk_request_payout, in one transaction, so two quick clicks cannot
 * withdraw the same money twice.
 */
export async function requestPayout(_prev: FormState, fd: FormData): Promise<FormState> {
  const got = await needShop();
  if ("error" in got) return { error: got.error };

  const cents = Math.round(Number(text(fd, "amount").replace(/[$,\s]/g, "")) * 100);
  if (!Number.isFinite(cents) || cents <= 0) return { error: "Enter how much you want to withdraw." };
  const currency = text(fd, "currency").toUpperCase();
  if (!isCcy(currency)) return { error: "Choose a currency." };
  if (cents < MIN_PAYOUT[currency]) {
    return { error: `The smallest withdrawal is ${money(MIN_PAYOUT[currency], currency)}.` };
  }

  const { error } = await createAdminClient().rpc("mk_request_payout", {
    p_creator: got.shop.id, p_amount_cents: cents, p_currency: currency,
  });
  if (error) {
    if (error.message.includes("no payout account")) return { error: "Add your bank details first." };
    if (error.message.includes("insufficient")) return { error: "That is more than your available balance." };
    console.error("studio: requestPayout", error.message);
    return { error: "Could not request that withdrawal." };
  }
  revalidatePath("/marketplace/studio/earnings");
  return { ok: true, message: "Withdrawal requested. We pay out within three working days." };
}

/** A creator changing their mind before it is paid. Puts the money back. */
export async function cancelPayout(id: string): Promise<FormState> {
  const got = await needShop();
  if ("error" in got) return { error: got.error };
  const admin = createAdminClient();
  const { data: p } = await admin.from("mk_payouts").select("id, creator_id, status").eq("id", id).maybeSingle();
  if (!p || p.creator_id !== got.shop.id) return { error: "That withdrawal is not yours." };
  if (p.status !== "requested") return { error: "That withdrawal is already being processed." };

  const { error } = await admin.rpc("mk_reverse_payout", { p_payout: id, p_status: "cancelled", p_note: "Cancelled by the creator" });
  if (error) return { error: "Could not cancel it." };
  revalidatePath("/marketplace/studio/earnings");
  return { ok: true, message: "Withdrawal cancelled; the money is back in your balance." };
}

/** Operators: approve, mark paid, or send back a withdrawal. */
export async function decidePayout(_prev: FormState, fd: FormData): Promise<FormState> {
  await requireProfile(["operator"], { next: "/admin/marketplace/payouts" });
  const id = text(fd, "id");
  const decision = text(fd, "decision");
  const note = text(fd, "note");
  const reference = text(fd, "reference");
  const admin = createAdminClient();

  if (decision === "reject") {
    if (note.length < 5) return { error: "Say why, so the creator knows what to fix." };
    const { error } = await admin.rpc("mk_reverse_payout", { p_payout: id, p_status: "rejected", p_note: note.slice(0, 500) });
    if (error) return { error: "Could not reject it." };
  } else if (decision === "approve") {
    const { error } = await admin.from("mk_payouts")
      .update({ status: "approved", decided_at: new Date().toISOString() })
      .eq("id", id).eq("status", "requested");
    if (error) return { error: "Could not approve it." };
  } else if (decision === "paid") {
    // Marked by hand after the transfer is sent from the bank or Paystack.
    // The wallet was debited when it was requested, so nothing moves here.
    const { error } = await admin.from("mk_payouts")
      .update({ status: "paid", paid_at: new Date().toISOString(), reference: reference || null })
      .eq("id", id).in("status", ["requested", "approved"]);
    if (error) return { error: "Could not mark it paid." };
  } else {
    return { error: "Choose approve, paid, or reject." };
  }
  revalidatePath("/admin/marketplace/payouts");
  return { ok: true };
}


/**
 * Tells the creator what the review decided.
 *
 * Without this the studio is the only place a decision exists, so a
 * creator who submitted on Friday has no way of knowing on Monday
 * whether anyone looked. Failure is swallowed: the decision itself is
 * already saved, and an email provider having a bad minute must not
 * make an operator think their approval did not land.
 */
async function tellCreator(
  item: { id: string; slug: string; title: string; mk_creators: unknown },
  decision: "approve" | "reject",
  note?: string,
) {
  try {
    const shop = (Array.isArray(item.mk_creators) ? item.mk_creators[0] : item.mk_creators) as
      { display_name: string; user_id: string } | null;
    if (!shop) return;
    const admin = createAdminClient();
    const { data: person } = await admin.from("profiles")
      .select("email").eq("id", shop.user_id).maybeSingle();
    if (!person?.email) return;
    const site = siteUrl();
    await sendEmail({
      to: person.email,
      ...(decision === "approve"
        ? itemApproved({ name: shop.display_name, item: item.title,
                         url: `${site}/marketplace/item/${item.slug}` })
        : itemNeedsChanges({ name: shop.display_name, item: item.title, note: note ?? "",
                             url: `${site}/marketplace/studio/items/${item.id}` })),
    });
  } catch (err) {
    console.error("review decision email failed for", item.id, err);
  }
}


/**
 * Tell everyone who owns an item that there is a new version.
 *
 * Deliberately a button the creator presses, not something that fires
 * when a file changes. Most re-uploads are a typo in a layer name, and a
 * marketplace that emails every buyer about those trains them to ignore
 * the one email that matters.
 *
 * Once per day at most, so a creator working through a batch of fixes
 * cannot send five.
 */
export async function announceUpdate(_prev: FormState, fd: FormData): Promise<FormState> {
  const got = await needShop();
  if ("error" in got) return { error: got.error };
  const { shop } = got;

  const id = text(fd, "id");
  const note = text(fd, "note").slice(0, 600);
  const item = await myItem(shop.id, id);
  if (!item) return { error: "That item is not in your shop." };
  if (item.state !== "published") return { error: "Only a live item can have an update announced." };
  if (note.length < 10) return { error: "Say what changed, in a sentence at least." };

  const admin = createAdminClient();
  const { data: row } = await admin.from("mk_products")
    .select("title, slug, update_sent_at").eq("id", id).maybeSingle();
  const last = row?.update_sent_at ? new Date(row.update_sent_at as string).getTime() : 0;
  if (Date.now() - last < 24 * 60 * 60 * 1000) {
    return { error: "You have already told buyers about an update today. Try again tomorrow." };
  }

  // Everyone who paid, plus everyone who claimed it free.
  const [{ data: orders }, { data: claims }] = await Promise.all([
    admin.from("mk_orders").select("user_id").eq("product_id", id).eq("status", "paid"),
    admin.from("mk_downloads").select("user_id").eq("product_id", id),
  ]);
  const owners = new Set<string>([
    ...((orders ?? []) as { user_id: string }[]).map((o) => o.user_id),
    ...((claims ?? []) as { user_id: string }[]).map((o) => o.user_id),
  ]);
  if (owners.size === 0) {
    return { error: "Nobody owns this yet, so there is nobody to tell." };
  }

  await admin.from("mk_products")
    .update({ update_note: note, update_sent_at: new Date().toISOString() }).eq("id", id);

  const site = siteUrl();
  const { data: people } = await admin.from("profiles")
    .select("id, email, display_name").in("id", [...owners]);

  let sent = 0;
  for (const person of (people ?? []) as { email: string | null; display_name: string | null }[]) {
    if (!person.email) continue;
    try {
      await sendEmail({
        to: person.email,
        ...itemUpdated({
          name: person.display_name ?? "there",
          item: (row?.title as string) ?? item.title,
          note,
          url: `${site}/marketplace/library`,
        }),
      });
      sent += 1;
    } catch (err) {
      console.error("update email failed", err);
    }
  }

  revalidatePath(`/marketplace/studio/items/${id}`);
  return { ok: true, message: `Told ${sent} ${sent === 1 ? "buyer" : "buyers"} about the new version.` };
}
