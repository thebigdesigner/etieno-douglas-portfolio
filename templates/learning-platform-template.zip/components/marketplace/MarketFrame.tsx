"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useRef, useState } from "react";
import { mk } from "@/lib/marketplace/href";
import { initials } from "@/lib/marketplace/format";
import type { MkIconName } from "@/lib/marketplace/types";
import MkIcon from "@/components/marketplace/MkIcon";
import CartButton from "@/components/marketplace/CartButton";
import { CATEGORIES } from "@/lib/marketplace/categories";
import CurrencySwitch from "@/components/CurrencySwitch";
import type { Ccy } from "@/lib/currency";
import { mkLogout } from "@/app/actions/marketplace-auth";

/**
 * The marketplace window.
 *
 * Laid out after the store reference: a frosted window on a misty canvas,
 * the store's name in the top left, six destinations, a hairline, then the
 * two utility links. The top bar carries back, search, two labelled
 * actions and the account.
 *
 * The rail was six destinations, on the reasoning that it is for where
 * people go most rather than a directory. That held while the categories
 * were twelve asset types. Now that the catalogue has its own — AI and
 * automation, business, career, creator — hiding them behind "All items"
 * hides the shop's actual shape, so the rail lists every category under a
 * heading, with Home and All items pinned above it.
 */

type User = { name: string; hue: number } | null;

const RAIL: { path: string; icon: MkIconName; label: string }[] = [
  { path: "/", icon: "home", label: "Home" },
  { path: "/all", icon: "apps", label: "All items" },
];

export default function MarketFrame({
  base, user, links, children, ccy }: {
  base: string;
  counts?: Record<string, number>;
  user: User;
  /** Absolute URLs on the main site. The marketplace may be on another host. */
  links: { signIn: string; signUp: string; account: string; help: string; academy: string; sell: string };
  /** The currency prices are shown in, for the switcher in the top bar. */
  ccy: Ccy;
  children: React.ReactNode;
}) {
  const pathname = usePathname();
  const [open, setOpen] = useState(false);
  const moreRef = useRef<HTMLDetailsElement>(null);

  useEffect(() => {
    setOpen(false);
    moreRef.current?.removeAttribute("open");
  }, [pathname]);

  useEffect(() => {
    const esc = (e: KeyboardEvent) => {
      if (e.key !== "Escape") return;
      setOpen(false);
      moreRef.current?.removeAttribute("open");
    };
    // A click anywhere outside the More menu closes it, as a menu should.
    const away = (e: MouseEvent) => {
      if (moreRef.current && !moreRef.current.contains(e.target as Node)) moreRef.current.removeAttribute("open");
    };
    document.addEventListener("keydown", esc);
    document.addEventListener("click", away);
    return () => { document.removeEventListener("keydown", esc); document.removeEventListener("click", away); };
  }, []);

  const home = mk(base, "/");
  const isOn = (href: string) =>
    href === home ? pathname === home || pathname === `${home}/` : pathname === href || pathname.startsWith(`${href}/`);

  // Back within the shop when there is somewhere to go back to; home when
  // the visitor landed here directly and history would leave the site.
  // Account screens are focused: no rail, no top bar, nothing to click
  // away to while someone is typing a password.
  const focused = ["/login", "/signup", "/forgot", "/reset"].some((p) => pathname === mk(base, p));
  if (focused) return <div className="mk mk--focused">{children}</div>;

  return (
    <div className={`mk${open ? " is-open" : ""}`}>
      <div className="mk-window">
        <aside className="mk-rail" aria-label="Marketplace">
          <div className="mk-rail__head">
            <Link href={home} className="mk-rail__brand">
              <span className="mk-rail__kicker">Your Brand</span>
              <span className="mk-rail__title">Marketplace</span>
            </Link>
            <button type="button" className="mk-rail__close" onClick={() => setOpen(false)}>
              <MkIcon name="close" size={18} /><span className="sr">Close menu</span>
            </button>
          </div>

          <nav className="mk-nav">
            {RAIL.map((r) => {
              const href = mk(base, r.path);
              const on = isOn(href);
              return (
                <Link key={r.path} href={href} className={`mk-nav__item${on ? " is-on" : ""}`} aria-current={on ? "page" : undefined}>
                  <MkIcon name={r.icon} size={19} className="mk-nav__ico" />
                  <span>{r.label}</span>
                </Link>
              );
            })}
            <p className="mk-nav__h" id="mk-nav-cats">Categories</p>
            {CATEGORIES.map((c) => {
              const href = mk(base, `/${c.slug}`);
              const on = isOn(href);
              return (
                <Link key={c.slug} href={href} className={`mk-nav__item${on ? " is-on" : ""}`}
                  aria-current={on ? "page" : undefined}>
                  <MkIcon name={c.icon} size={19} className="mk-nav__ico" />
                  <span>{c.name}</span>
                </Link>
              );
            })}
          </nav>

          <div className="mk-nav mk-nav--foot">
            <Link href={mk(base, "/library")} className={`mk-nav__item${isOn(mk(base, "/library")) ? " is-on" : ""}`}>
              <MkIcon name="download" size={19} className="mk-nav__ico" /><span>Your library</span>
            </Link>
            <a href={links.sell} className="mk-nav__item">
              <MkIcon name="store" size={19} className="mk-nav__ico" /><span>Sell your work</span>
            </a>
            <a href={links.help} className="mk-nav__item">
              <MkIcon name="help" size={19} className="mk-nav__ico" /><span>Help & support</span>
            </a>
          </div>
        </aside>

        <div className="mk-scrim" aria-hidden="true" onClick={() => setOpen(false)} />

        <div className="mk-main">
          <header className="mk-top">
            <button type="button" className="mk-top__menu" onClick={() => setOpen(true)} aria-expanded={open}>
              <MkIcon name="menu" size={20} /><span className="sr">Open menu</span>
            </button>
            <form className="mk-search" action={mk(base, "/search")} role="search">
              <MkIcon name="search" size={17} />
              <label className="sr" htmlFor="mk-q">Search the marketplace</label>
              <input id="mk-q" name="q" type="search" placeholder="Search" autoComplete="off" />
            </form>

            <div className="mk-top__actions">
              <a href={links.sell} className="mk-top__act mk-top__sell">
                <MkIcon name="store" size={21} /><span className="mk-top__lab">Sell</span>
              </a>

              <CartButton href={mk(base, "/cart")} />

              <details className="mk-more" ref={moreRef}>
                <summary className="mk-top__act">
                  <MkIcon name="more-circle" size={21} /><span className="mk-top__lab">More</span>
                </summary>
                <div className="mk-more__menu" role="menu">
                  <a role="menuitem" href={links.help}><MkIcon name="help" size={17} />Help & support</a>
                  <a role="menuitem" href={links.academy}><MkIcon name="academy" size={17} />Your Brand Academy</a>
                  <div className="mk-more__ccy" role="group" aria-label="Currency">
                    <span>Currency</span>
                    <CurrencySwitch value={ccy} />
                  </div>
                  <a role="menuitem" href={mk(base, "/library")}><MkIcon name="download" size={17} />Your library</a>
                  <a role="menuitem" href={links.sell}><MkIcon name="store" size={17} />Sell your work</a>
                  <hr />
                  {user ? (
                    <>
                      <span className="mk-more__who">Signed in as <strong>{user.name}</strong></span>
                      <a role="menuitem" href={links.account}><MkIcon name="users" size={17} />Your Your Brand account</a>
                      <form action={mkLogout}>
                        <button type="submit" role="menuitem" className="mk-more__btn"><MkIcon name="arrow-right" size={17} />Sign out</button>
                      </form>
                    </>
                  ) : (
                    <>
                      <a role="menuitem" href={links.signIn}><MkIcon name="users" size={17} />Sign in</a>
                      <a role="menuitem" href={links.signUp}><MkIcon name="users" size={17} />Create account</a>
                    </>
                  )}
                </div>
              </details>

              {user ? (
                <a href={links.account} className="mk-me" title={user.name}>
                  <span className="mk-av" data-hue={user.hue % 6} aria-hidden="true">{initials(user.name)}</span>
                  <span className="sr">Your account</span>
                </a>
              ) : (
                <a href={links.signIn} className="mk-me" title="Sign in">
                  <span className="mk-av mk-av--empty" aria-hidden="true"><MkIcon name="users" size={16} /></span>
                  <span className="sr">Sign in</span>
                </a>
              )}
            </div>
          </header>
          <main className="mk-body">{children}</main>
        </div>
      </div>
    </div>
  );
}
