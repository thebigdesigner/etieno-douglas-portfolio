import type { Metadata } from "next";
import MarketFrame from "@/components/marketplace/MarketFrame";
import { readCurrency } from "@/lib/currency";
import { marketBase, mk } from "@/lib/marketplace/url";
import { siteUrlFor } from "@/lib/site";
import { createClient } from "@/lib/supabase/server";
import "./marketplace.css";

export const metadata: Metadata = {
  title: { default: "Your Brand Marketplace — templates, fonts, music and more", template: "%s · Your Brand Marketplace" },
  description:
    "Placeholder description by Aphinity Digital. Describe your platform in one sentence.",
};

/**
 * Who is looking, if anyone. A failure here costs the visitor their name in
 * the rail and nothing else, so it is swallowed rather than allowed to take
 * the shop down — the same trade the middleware makes.
 */
async function viewer(): Promise<{ name: string; hue: number } | null> {
  if (!process.env.NEXT_PUBLIC_SUPABASE_URL) return null;
  try {
    const supabase = await createClient();
    const { data: { user } } = await supabase.auth.getUser();
    if (!user) return null;
    const { data: profile } = await supabase.from("profiles").select("display_name").eq("id", user.id).maybeSingle();
    const name = profile?.display_name || user.email?.split("@")[0] || "You";
    return { name, hue: user.id.charCodeAt(0) % 6 };
  } catch {
    return null;
  }
}

export default async function MarketplaceLayout({ children }: { children: React.ReactNode }) {
  const [base, user, ccy] = await Promise.all([marketBase(), viewer(), readCurrency()]);
  return (
    <MarketFrame
      base={base}
      user={user}
      ccy={ccy}
      links={{
        signIn: mk(base, "/login"),
        signUp: mk(base, "/signup"),
        account: siteUrlFor("/dashboard"),
        help: siteUrlFor("/contact"),
        academy: siteUrlFor("/"),
        sell: mk(base, "/studio"),
      }}
    >
      {children}
    </MarketFrame>
  );
}
