-- =====================================================================
-- 0035 — a certificate tells the learner it exists
--
-- Passing a project sends an email, because the review path sends it. A
-- certificate issued any other way sends nothing: the exam path on an
-- exam-only course, an appeal upheld, or an owner issuing one by hand.
-- The learner sees it in the bell and on their certificates page, and
-- otherwise finds out by looking.
--
-- The email cannot be sent from the database, so this records whether it
-- has gone out and lets the app sweep for the ones that have not. That
-- covers every route by which a certificate can appear, including a
-- direct insert, rather than one more call site that the next route
-- forgets.
-- =====================================================================

alter table certificates
  add column if not exists notified_at timestamptz;

comment on column certificates.notified_at is
  'When the learner was emailed about it. Null means the sweep still owes them one.';

-- Everything already issued predates the email; nobody should now receive
-- a "your certificate is ready" for something they collected weeks ago.
update certificates set notified_at = issued_at where notified_at is null;

create index if not exists certificates_unnotified
  on certificates (issued_at) where notified_at is null and revoked_at is null;

-- ---------------------------------------------------------------------
-- What the sweep needs, in one call: the certificate, who it belongs to,
-- and what it is for.
-- ---------------------------------------------------------------------
create or replace function public.certificates_awaiting_email(p_limit int default 50)
returns table (
  code          text,
  kind          certificate_kind,
  reviewer_name text,
  issued_at     timestamptz,
  learner_name  text,
  learner_email text,
  course_title  text
)
language sql
stable
security definer set search_path = public
as $$
  select c.code, c.kind, c.reviewer_name, c.issued_at,
         p.display_name, p.email, co.title
    from certificates c
    join enrolments e on e.id = c.enrolment_id
    join profiles   p on p.id = e.user_id
    join courses   co on co.id = e.course_id
   where c.notified_at is null
     and c.revoked_at is null
     and p.email is not null
     -- Cohort learners have placeholder addresses that go nowhere.
     and p.email not like '%@cohort.splari.internal'
   order by c.issued_at
   limit p_limit;
$$;

create or replace function public.mark_certificate_notified(p_code text)
returns void
language sql
security definer set search_path = public
as $$
  update certificates set notified_at = now() where code = p_code;
$$;
