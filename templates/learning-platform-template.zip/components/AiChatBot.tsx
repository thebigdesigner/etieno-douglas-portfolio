"use client";

import { useEffect, useRef } from "react";
import BotFace from "@/components/BotFace";

const EMOJIS = ["\u2764\uFE0F", "\u2728", "\uD83D\uDC4B", "\uD83D\uDCAC"];

/**
 * The chat launcher.
 *
 * Replaces the "Ask Sara" pill rather than sitting beside it — two launchers
 * in the same corner is the one thing the widget's own notes warn about, and
 * the assistant only needs one way in.
 *
 * The emoji burst is imperative DOM rather than React state on purpose: the
 * particles are short-lived, spawn on a timer, and remove themselves on
 * animationend. Rendering them from state would re-render the whole launcher
 * twice a second for something purely decorative.
 */
export default function AiChatBot({ onOpen }: { onOpen: () => void }) {
  const bot = useRef<HTMLDivElement>(null);
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);
  const bursts = useRef<ReturnType<typeof setTimeout>[]>([]);

  useEffect(() => {
    const el = bot.current;
    if (!el) return;
    const fx = el.querySelector(".ai-bot__fx");
    if (!fx) return;

    const reduced = window.matchMedia("(prefers-reduced-motion: reduce)");

    function spawn() {
      if (reduced.matches) return;
      const s = document.createElement("span");
      s.className = "ai-bot__emoji";
      s.textContent = EMOJIS[Math.floor(Math.random() * EMOJIS.length)];
      s.style.left = `${22 + Math.random() * 50}%`;
      s.style.setProperty("--dx", `${Math.random() * 44 - 22}px`);
      fx!.appendChild(s);
      s.addEventListener("animationend", () => s.remove());
    }

    // Two per 1.3s beat, in step with the blink and the bubble.
    const enter = () => { spawn(); timer.current = setInterval(spawn, 650); };
    const leave = () => { if (timer.current) clearInterval(timer.current); };
    // Touch has no hover, so a tap gets the greeting it would otherwise miss.
    const burst = () => {
      for (let i = 0; i < 6; i++) bursts.current.push(setTimeout(spawn, i * 90));
    };

    el.addEventListener("mouseenter", enter);
    el.addEventListener("mouseleave", leave);
    el.addEventListener("splari:bot-burst", burst);

    return () => {
      el.removeEventListener("mouseenter", enter);
      el.removeEventListener("mouseleave", leave);
      el.removeEventListener("splari:bot-burst", burst);
      if (timer.current) clearInterval(timer.current);
      // Pending bursts would fire into a detached node after unmount.
      bursts.current.forEach(clearTimeout);
      bursts.current = [];
    };
  }, []);

  function open() {
    bot.current?.dispatchEvent(new Event("splari:bot-burst"));
    onOpen();
  }

  return (
    <div
      className="ai-bot"
      ref={bot}
      role="button"
      tabIndex={0}
      aria-label="Ask Sara, the Your Brand assistant"
      onClick={open}
      onKeyDown={(e) => {
        if (e.key === "Enter" || e.key === " ") { e.preventDefault(); open(); }
      }}
    >
      <BotFace />

      <div className="ai-bot__fx" aria-hidden="true" />
    </div>
  );
}
