-- =====================================================================
-- 0037 — a sold course does not also draw from the pool
--
-- calculate_pool takes 35% of subscription revenue (30% institutional) and
-- divides it by every completed topic that month. That was right when
-- everything was covered by a subscription. It is wrong now that
-- instructor courses are bought:
--
--   · the instructor is paid twice for the same work — once by the buyer,
--     once from a pool funded by subscribers;
--   · those completions inflate the divisor, so every other instructor's
--     rate per completion falls to pay for it;
--   · and the subscribers funding it cannot open the course at all.
--
-- A priced instructor course is therefore excluded from both halves — the
-- divisor and the payout. A free instructor course stays in: nobody paid
-- for it directly, and it is giving subscribers something to read.
--
-- The test is the price, not the owner. price_cents is null on every
-- course that is covered by a plan, so one condition covers Your Brand
-- courses, institution courses, and practitioners who publish for free.
-- =====================================================================

create or replace function public.calculate_pool(p_month date, p_source revenue_source, p_revenue_cents bigint)
returns uuid
language plpgsql security definer set search_path = public as $$
declare
  v_start date := date_trunc('month', p_month)::date;
  v_end   date := (date_trunc('month', p_month) + interval '1 month')::date;
  v_rate  numeric(5,4) := case p_source when 'individual' then 0.35 else 0.30 end;
  v_pool  bigint := floor(p_revenue_cents * v_rate);
  v_completions int;
  v_per    numeric(12,4);
  v_id     uuid;
begin
  -- The divisor counts only what the pool is meant to pay for.
  select count(*) into v_completions
    from topic_completions tc
    join enrolments e on e.id = tc.enrolment_id
    join courses    c on c.id = e.course_id
   where tc.revenue_source = p_source
     and tc.completed_at >= v_start and tc.completed_at < v_end
     and c.price_cents is null;

  if v_completions = 0 then return null; end if;
  v_per := v_pool::numeric / v_completions;

  insert into pool_periods (period_month, source, revenue_cents, pool_rate,
                            pool_cents, completions, rate_per_completion_cents)
  values (v_start, p_source, p_revenue_cents, v_rate, v_pool, v_completions, v_per)
  on conflict (period_month, source) do update
     set revenue_cents = excluded.revenue_cents, pool_cents = excluded.pool_cents,
         completions = excluded.completions,
         rate_per_completion_cents = excluded.rate_per_completion_cents,
         calculated_at = now()
  returning id into v_id;

  -- And the payout counts the same set, so the two halves cannot disagree.
  insert into earnings_entries (instructor_id, type, amount_cents, ref_id, note)
  select c.instructor_id,
         -- Cast, because earning_type is an enum and the case yields text.
         -- Without it the insert is rejected — which it always was: this is
         -- the 0005 expression unchanged, so calculate_pool has never once
         -- run to completion. Same class of fault as create_submission had.
         (case p_source when 'individual' then 'pool_individual'
                        else 'pool_institution' end)::earning_type,
         floor(count(*) * v_per)::int,
         v_id,
         to_char(v_start, 'Mon YYYY') || ' pool, ' || count(*) || ' completions'
    from topic_completions tc
    join enrolments e on e.id = tc.enrolment_id
    join courses    c on c.id = e.course_id
   where tc.revenue_source = p_source
     and tc.completed_at >= v_start and tc.completed_at < v_end
     and c.instructor_id is not null
     and c.price_cents is null
   group by c.instructor_id
  having floor(count(*) * v_per) > 0;

  return v_id;
end; $$;

comment on function public.calculate_pool is
  'Subscription royalties. Excludes courses with a price: those are paid for directly, and counting them would pay their author twice while diluting everyone else.';
