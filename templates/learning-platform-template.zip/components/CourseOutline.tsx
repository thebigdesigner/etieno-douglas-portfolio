"use client";

import Link from "next/link";
import { useState } from "react";
import NavIcon from "@/components/NavIcon";

export type OutlineRow = {
  topic_id: string;
  module_title: string;
  topic_title: string;
  pos: number;
  is_free: boolean;
  has_quiz: boolean;
  completed: boolean;
  unlocked: boolean;
};

/**
 * Modules collapse. A course with twelve modules was previously a single
 * long list, which makes it hard to see the shape of the thing before
 * committing to it — and the shape is most of what somebody is deciding on.
 *
 * The first module opens by default because its first topic is the free one,
 * so it is the part a visitor is most likely to want.
 */
export default function CourseOutline({
  rows, slug,
}: { rows: OutlineRow[]; slug: string }) {
  const modules = rows.reduce<Record<string, OutlineRow[]>>((acc, r) => {
    (acc[r.module_title] ||= []).push(r);
    return acc;
  }, {});
  const names = Object.keys(modules);

  const [open, setOpen] = useState<Record<string, boolean>>(
    () => Object.fromEntries(names.map((n, i) => [n, i === 0]))
  );
  const allOpen = names.every((n) => open[n]);

  return (
    <div className="cout">
      <div className="cout__head">
        <h2 className="cout__h">Course content</h2>
        <button
          className="cout__all"
          onClick={() =>
            setOpen(Object.fromEntries(names.map((n) => [n, !allOpen])))
          }
        >
          {allOpen ? "Collapse all" : "Expand all sections"}
        </button>
      </div>

      <div className="cout__facts">
        <span><NavIcon name="list" size={15} /> {names.length} modules</span>
        <span><NavIcon name="book" size={15} /> {rows.length} topics</span>
        <span><NavIcon name="inbox" size={15} /> {rows.filter((r) => r.has_quiz).length} quizzes</span>
      </div>

      {names.map((name) => {
        const items = modules[name];
        const done = items.filter((t) => t.completed).length;
        const pct = items.length ? Math.round((done / items.length) * 100) : 0;
        const isOpen = !!open[name];

        return (
          <div className={`cmod${isOpen ? " is-open" : ""}`} key={name}>
            <button
              className="cmod__bar"
              aria-expanded={isOpen}
              onClick={() => setOpen({ ...open, [name]: !isOpen })}
            >
              <span className="cmod__chev" aria-hidden="true">
                <NavIcon name="chevron" size={16} />
              </span>
              <span className="cmod__t">{name}</span>
              <span className="cmod__n num">{items.length} topics</span>
              {done > 0 && (
                <span
                  className="cmod__ring"
                  style={{ "--pct": pct } as React.CSSProperties}
                  aria-label={`${pct} percent complete`}
                >
                  <span className="cmod__pct num">{pct}%</span>
                </span>
              )}
            </button>

            {isOpen && (
              <div className="cmod__list">
                {items.map((t) => {
                  const openable = t.unlocked || t.is_free;
                  return (
                    <div className="crow" key={t.topic_id}>
                      <span
                        className={`crow__ico${t.completed ? " is-done" : ""}${openable ? "" : " is-locked"}`}
                        aria-hidden="true"
                      >
                        <NavIcon
                          name={t.completed ? "award" : openable ? "play" : "lock"}
                          size={15}
                        />
                      </span>
                      <span className="crow__t">
                        {openable ? (
                          <Link href={`/learn/${slug}/${t.topic_id}`}>{t.topic_title}</Link>
                        ) : (
                          t.topic_title
                        )}
                      </span>
                      <span className="crow__meta">
                        {t.is_free && <span className="pill pill--free">Free</span>}
                        {t.has_quiz && <span className="pill">Quiz</span>}
                      </span>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
