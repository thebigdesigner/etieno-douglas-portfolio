-- =====================================================================
-- Topic-level progress on the dashboard ring.
--
-- `completion_pct` answers "of the courses you began, how many did you
-- finish" — a genuinely useful number, and the honest version of a
-- completion rate. But it sits at 0 until a whole course is done, which
-- makes it the wrong thing to put inside a progress ring: a ring reads as
-- "how far along am I", and somebody two topics into four was being shown
-- zero.
--
-- So this adds a second measure rather than redefining the first. Columns
-- are appended, which is all `create or replace view` permits.
-- =====================================================================

create or replace view public.learner_stats as
select p.id,
       p.display_name,

       (select count(*) from enrolments e where e.user_id = p.id)              as courses_started,
       (select count(*) from enrolments e
         where e.user_id = p.id and e.state = 'certified')                     as courses_completed,

       round(100.0 * (select count(*) from enrolments e
                       where e.user_id = p.id and e.state = 'certified')
             / nullif((select count(*) from enrolments e where e.user_id = p.id), 0), 0)
                                                                                as completion_pct,

       -- Best attempt per topic, averaged. Retakes are unlimited, so counting
       -- every attempt would punish somebody for practising.
       (select round(avg(best), 0) from (
          select max(qa.score_pct) as best
            from quiz_attempts qa
            join enrolments e on e.id = qa.enrolment_id
           where e.user_id = p.id
           group by qa.topic_id
        ) t)                                                                    as average_score,

       (select count(*) from certificates c
          join enrolments e on e.id = c.enrolment_id
         where e.user_id = p.id and c.revoked_at is null)                      as certificates,

       (select count(*) from saved_courses s where s.user_id = p.id)           as saved,

       (select count(*) from submissions s
          join enrolments e on e.id = s.enrolment_id
         where e.user_id = p.id
           and s.state in ('submitted','assigned','in_review'))                as awaiting_review,

       (select max(tc.completed_at) from topic_completions tc
          join enrolments e on e.id = tc.enrolment_id
         where e.user_id = p.id)                                                as last_active,

       (select count(*) from topic_completions tc
          join enrolments e on e.id = tc.enrolment_id
         where e.user_id = p.id
           and tc.completed_at >= now() - interval '7 days')                    as topics_this_week,

       -- Appended: topics finished as a share of every topic in every course
       -- the learner has enrolled in. Moves on the first topic completed.
       (select count(*) from topic_completions tc
          join enrolments e on e.id = tc.enrolment_id
         where e.user_id = p.id)                                                as topics_done,

       (select count(*)
          from enrolments e
          join modules m on m.course_id = e.course_id
          join topics  t on t.module_id = m.id
         where e.user_id = p.id)                                                as topics_total,

       round(100.0 * (select count(*) from topic_completions tc
                        join enrolments e on e.id = tc.enrolment_id
                       where e.user_id = p.id)
             / nullif((select count(*)
                         from enrolments e
                         join modules m on m.course_id = e.course_id
                         join topics  t on t.module_id = m.id
                        where e.user_id = p.id), 0), 0)                         as topics_pct

  from profiles p;
