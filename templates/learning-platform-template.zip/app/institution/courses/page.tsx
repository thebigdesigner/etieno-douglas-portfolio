import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import FilterBar from "@/components/FilterBar";

export const metadata = { title: "Your courses" };
export const dynamic = "force-dynamic";

type SearchParams = Promise<{ q?: string; state?: string }>;

const STATE: Record<string, string> = {
  draft: "Draft", in_review: "In review", published: "Live",
  revision_requested: "Changes asked for", unpublished: "Retired",
};

/**
 * Courses an organisation writes for its own cohorts.
 *
 * Private by design: they are kept out of the public catalogue, and only
 * this institution's people can open them. A school's induction course is
 * not something other organisations' learners should be reading.
 */
export default async function InstitutionCoursesPage(
  { searchParams }: { searchParams: SearchParams }
) {
  const { q, state } = await searchParams;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login?next=/institution/courses");

  const admin = createAdminClient();
  const { data: member } = await admin
    .from("institution_members").select("institution_id")
    .eq("user_id", user.id).maybeSingle();
  if (!member) redirect("/institution");

  let query = admin.from("courses")
    .select("id, slug, title, subject, state")
    .eq("institution_id", member.institution_id);

  if (q) query = query.ilike("title", `%${q.replace(/[\\%_]/g, (c) => `\\${c}`)}%`);
  if (state) query = query.eq("state", state);

  const [{ data: courses }, { count: total }] = await Promise.all([
    query.order("created_at", { ascending: false }).limit(100),
    admin.from("courses").select("id", { count: "exact", head: true })
      .eq("institution_id", member.institution_id),
  ]);

  const rows = courses ?? [];

  return (
    <>
      <div className="dash__bar">
        <div>
          <div className="eyebrow">Teaching</div>
          <h1 className="dash__title">Your courses</h1>
        </div>
        <Link className="btn btn--fill" href="/institution/courses/new">Write a course</Link>
      </div>

      <div className="card">
        <p className="card__meta" style={{ maxWidth: "62ch" }}>
          Courses you write are open to your cohorts and nobody else — they stay out
          of the public catalogue. Everything else works the same: modules, an exam,
          and a project assessed by somebody you name.
        </p>
      </div>

      {(total ?? 0) > 4 && (
        <div style={{ marginTop: 18 }}>
          <FilterBar
            search={{ name: "q", placeholder: "Course title", value: q }}
            selects={[{
              name: "state", label: "Any state", value: state,
              options: Object.entries(STATE).map(([value, label]) => ({ value, label })),
            }]}
            total={total ?? rows.length}
            showing={rows.length}
            clearHref="/institution/courses"
          />
        </div>
      )}

      {rows.length === 0 ? (
        <div className="card" style={{ marginTop: 18 }}>
          <div className="empty2" style={{ padding: "36px 0" }}>
            <p className="card__h" style={{ marginBottom: 8 }}>Nothing written yet</p>
            <p className="card__meta" style={{ maxWidth: "44ch", margin: "0 auto" }}>
              An induction, a policy walkthrough, something only your cohorts need.
            </p>
            <Link className="btn btn--fill" href="/institution/courses/new" style={{ marginTop: 18 }}>
              Write your first
            </Link>
          </div>
        </div>
      ) : (
        <div className="icourses" style={{ marginTop: 18 }}>
          {rows.map((c) => (
            <article key={c.id} className={`icourse${c.state === "published" ? " is-live" : ""}`}>
              <div className="icourse__top">
                <span className="tag">{c.subject}</span>
                <span className="icourse__state">{STATE[c.state as string] ?? c.state}</span>
              </div>
              <h2 className="icourse__h">{c.title}</h2>
              <Link className="btn btn--line" href={`/institution/courses/${c.slug}`}>
                {c.state === "published" ? "Open" : "Keep building"}
              </Link>
            </article>
          ))}
        </div>
      )}
    </>
  );
}
