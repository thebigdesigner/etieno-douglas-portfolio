import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import VerifyForms from "./VerifyForms";

export const metadata = { title: "Verify your organisation" };
export const dynamic = "force-dynamic";

export default async function VerifyPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login?next=/institution/verify");

  const admin = createAdminClient();
  const { data: member } = await admin
    .from("institution_members").select("institution_id").eq("user_id", user.id).maybeSingle();
  if (!member) redirect("/institution");

  const { data: institution } = await admin
    .from("institutions")
    .select("name, verification, submitted_at, review_note, country, website")
    .eq("id", member.institution_id).maybeSingle();

  const { data: docs } = await admin
    .from("institution_documents")
    .select("id, kind, filename, uploaded_at")
    .eq("institution_id", member.institution_id)
    .order("uploaded_at", { ascending: false });

  const state = institution?.verification ?? "unverified";

  return (
    <>
        <nav className="crumb" style={{ paddingTop: 28 }}>
          <Link href="/institution">Dashboard</Link> / Verification
        </nav>

        <h1 className="sec__h" style={{ fontSize: 30, marginTop: 16 }}>
          Verify {institution?.name}
        </h1>

        {state === "verified" ? (
          <div className="underreview" style={{ marginTop: 26 }}>
            <p className="underreview__h">Verified</p>
            <p className="underreview__p">
              You can create cohorts and enrol learners.
            </p>
            <p style={{ marginTop: 16 }}>
              <Link className="btn btn--fill" href="/institution">Back to your dashboard</Link>
            </p>
          </div>
        ) : state === "pending" ? (
          <div className="underreview" style={{ marginTop: 26 }}>
            <p className="underreview__h">With us now</p>
            <p className="underreview__p">
              Submitted{" "}
              {institution?.submitted_at &&
                new Date(institution.submitted_at).toLocaleDateString()}
              . We usually come back within two working days, and we will email you
              either way.
            </p>
          </div>
        ) : (
          <>
            <p className="sec__meta" style={{ marginTop: 10 }}>
              Your account works already — look around, read the courses, see how cohorts
              work. Enrolling learners needs this step first, because you will be handling
              other people&rsquo;s data, some of it belonging to children.
            </p>

            {state === "rejected" && institution?.review_note && (
              <div className="notice" style={{ marginTop: 24, background: "#FDEDEC", borderColor: "#F5C6C2" }}>
                <div>
                  <p className="notice__h">We could not verify you with what you sent</p>
                  <p className="notice__p">{institution.review_note}</p>
                </div>
              </div>
            )}

            <div className="sub__brief" style={{ marginTop: 24 }}>
              <div className="eyebrow">What works for us</div>
              <ul className="acct__list" style={{ marginTop: 12 }}>
                <li>A registration or incorporation document for the organisation</li>
                <li>A letter on your headed paper naming you and your role</li>
                <li>Photo ID for whoever is signing up, if the above is thin</li>
              </ul>
              <p className="studio__hint" style={{ marginTop: 12 }}>
                One is usually enough. PDF, PNG or JPEG, up to 10MB each. These are stored
                privately and only an operator reviewing your account can see them.
              </p>
            </div>

            <VerifyForms docs={docs ?? []} canSubmit={(docs ?? []).length > 0} />
          </>
        )}
      </>
  );
}
