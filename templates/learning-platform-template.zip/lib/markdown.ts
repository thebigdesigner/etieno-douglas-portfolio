/**
 * Deliberately tiny renderer for topic bodies: paragraphs and **bold** only.
 * Topic content is authored by us, but it is still escaped before any
 * formatting is applied so an instructor cannot inject markup later.
 */
export function renderBody(body: string): string {
  const escaped = body
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;");

  return escaped
    .split(/\n\s*\n/)
    .map((para) => {
      const withBold = para.replace(/\*\*(.+?)\*\*/g, "<strong>$1</strong>");
      return `<p>${withBold.replace(/\n/g, "<br />")}</p>`;
    })
    .join("");
}
