import Link from "next/link";
import FlatIcon, { type FlatName } from "@/components/FlatIcon";

export type Stat = {
  label: string;
  value: number;
  icon: FlatName;
  href: string;
  tone: "peach" | "blue" | "green" | "purple";
};

/**
 * The four counts, as the tinted tiles they have always been.
 *
 * The only change from the original markup is that each tile is a link rather
 * than a div — a number you cannot click is a dead end, and somebody reading
 * "2 certificates" wants the certificates. Layout, colour and sizing are
 * untouched, including the pancol container queries that drop the row to two
 * tiles and then one as the column narrows.
 */
export default function StatList({ stats }: { stats: Stat[] }) {
  return (
    <div className="stats3 stats3--four">
      {stats.map((s) => (
        <Link key={s.label} className={`stat3 stat3--${s.tone}`} href={s.href}>
          {/* Filled rather than stroked: on a 44px tinted chip a hairline
              outline reads as faint, not quiet. */}
          <span className="stat3__ico" aria-hidden="true">
            <FlatIcon name={s.icon} size={21} />
          </span>
          <span>
            <span className="stat3__v num">{s.value}</span>
            <span className="stat3__n">{s.label}</span>
          </span>
        </Link>
      ))}
    </div>
  );
}
