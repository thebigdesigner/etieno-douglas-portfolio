// Server only: imports the service-role client.
import { cache } from "react";
import type { Ccy } from "@/lib/money";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";

/**
 * Studio reads. The storefront's RLS only shows published items, and a
 * creator has to see their own drafts, so these go through the service
 * role — always scoped to the signed-in user's creator row first. Nothing
 * here takes an id from the caller without checking who owns it.
 */

export type ItemState = "draft" | "in_review" | "published" | "retired";

export type Shop = {
  id: string; handle: string; displayName: string; personName: string | null;
  location: string | null; bio: string | null; hue: number;
  /** Your Brand's own shop: no commission, and no queue to wait in. */
  house: boolean;
};

export type StudioItem = {
  id: string; slug: string; title: string; category: string; subcategory: string;
  summary: string; includes: string[]; tags: string[]; formats: string[];
  priceCents: number; commercialCents: number | null; coverUrl: string | null;
  /** Prices the creator set in other currencies, if any. */
  prices: Partial<Record<Ccy, { priceCents: number; commercialCents: number | null }>>;
  state: ItemState; reviewNote: string | null; downloads: number; updatedAt: string;
  file: { name: string | null; bytes: number | null } | null;
};

export type Viewer = { userId: string; email: string | null; shop: Shop | null };

/** null: signed out. Otherwise the user, and their shop if they have one. */
export const studioViewer = cache(async (): Promise<Viewer | null> => {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return null;
  const { data } = await createAdminClient().from("mk_creators")
    .select("id, handle, display_name, person_name, location, bio, hue, house")
    .eq("user_id", user.id).maybeSingle();
  return {
    userId: user.id, email: user.email ?? null,
    shop: data ? {
      id: data.id, handle: data.handle, displayName: data.display_name, personName: data.person_name,
      location: data.location, bio: data.bio, hue: data.hue, house: Boolean(data.house),
    } : null,
  };
});

type Row = {
  id: string; slug: string; title: string; category: string; subcategory: string; summary: string;
  includes: string[] | null; tags: string[] | null; formats: string[] | null;
  price_cents: number; commercial_price_cents: number | null; cover_url: string | null;
  state: ItemState; review_note: string | null; downloads: number; updated_at: string;
  mk_product_files: { name: string | null; bytes: number | null } | { name: string | null; bytes: number | null }[] | null;
  mk_product_prices?: { currency: string; price_cents: number; commercial_cents: number | null }[] | null;
};

const COLS = "id, slug, title, category, subcategory, summary, includes, tags, formats, price_cents, " +
  "commercial_price_cents, cover_url, state, review_note, downloads, updated_at, mk_product_files(name, bytes), " +
  "mk_product_prices(currency, price_cents, commercial_cents)";

export function itemFromRow(r: Row): StudioItem {
  const f = Array.isArray(r.mk_product_files) ? r.mk_product_files[0] : r.mk_product_files;
  return {
    id: r.id, slug: r.slug, title: r.title, category: r.category, subcategory: r.subcategory,
    summary: r.summary, includes: r.includes ?? [], tags: r.tags ?? [], formats: r.formats ?? [],
    priceCents: r.price_cents, commercialCents: r.commercial_price_cents, coverUrl: r.cover_url,
    prices: Object.fromEntries((r.mk_product_prices ?? [])
      .filter((x) => x.currency !== "USD")
      .map((x) => [x.currency, { priceCents: x.price_cents, commercialCents: x.commercial_cents }])),
    state: r.state, reviewNote: r.review_note, downloads: r.downloads, updatedAt: r.updated_at,
    file: f ?? null,
  };
}

export async function myItems(shopId: string): Promise<StudioItem[]> {
  const { data, error } = await createAdminClient().from("mk_products").select(COLS)
    .eq("creator_id", shopId).order("updated_at", { ascending: false });
  if (error) { console.error("studio: myItems", error.message); return []; }
  return ((data ?? []) as unknown as Row[]).map(itemFromRow);
}

export async function myItem(shopId: string, id: string): Promise<StudioItem | null> {
  if (!/^[0-9a-f-]{36}$/i.test(id)) return null;
  const { data } = await createAdminClient().from("mk_products").select(COLS)
    .eq("creator_id", shopId).eq("id", id).maybeSingle();
  return data ? itemFromRow(data as unknown as Row) : null;
}

/** For the operator queue: everything waiting, oldest first. */
export async function reviewQueue() {
  const { data } = await createAdminClient().from("mk_products")
    .select(COLS + ", submitted_at, mk_creators(handle, display_name)")
    .eq("state", "in_review").order("submitted_at", { ascending: true });
  type QRow = Row & { submitted_at: string | null; mk_creators: { handle: string; display_name: string } | { handle: string; display_name: string }[] | null };
  return ((data ?? []) as unknown as QRow[]).map((r) => {
    const c = Array.isArray(r.mk_creators) ? r.mk_creators[0] : r.mk_creators;
    return { ...itemFromRow(r), submittedAt: r.submitted_at, creator: c };
  });
}

/** True when the studio's tables exist; false while migrations are pending. */
export const studioReady = cache(async (): Promise<boolean> => {
  if (!process.env.SUPABASE_SERVICE_ROLE_KEY || !process.env.NEXT_PUBLIC_SUPABASE_URL) return false;
  try {
    const { error } = await createAdminClient().from("mk_products").select("review_note", { head: true }).limit(1);
    return !error;
  } catch { return false; }
});


/**
 * How many people own an item. Paid orders and free claims, counted
 * once each — the studio uses it to decide whether "tell buyers about
 * the update" is a button worth showing.
 */
export async function ownerCount(productId: string): Promise<number> {
  const admin = createAdminClient();
  const [{ data: orders }, { data: claims }] = await Promise.all([
    admin.from("mk_orders").select("user_id").eq("product_id", productId).eq("status", "paid"),
    admin.from("mk_downloads").select("user_id").eq("product_id", productId),
  ]);
  const ids = new Set<string>([
    ...((orders ?? []) as { user_id: string }[]).map((o) => o.user_id),
    ...((claims ?? []) as { user_id: string }[]).map((o) => o.user_id),
  ]);
  return ids.size;
}
