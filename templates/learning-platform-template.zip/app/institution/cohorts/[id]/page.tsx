import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import CohortTools from "./CohortTools";
import SeatTable from "./SeatTable";

export const dynamic = "force-dynamic";

type Params = Promise<{ id: string }>;

export default async function CohortPage({ params }: { params: Params }) {
  const { id } = await params;

  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect(`/login?next=/institution/cohorts/${id}`);

  const admin = createAdminClient();

  const { data: cohort } = await admin
    .from("cohorts")
    .select("id, name, class_code, seat_ceiling, starts_on, ends_on, state, institution_id")
    .eq("id", id).maybeSingle();
  if (!cohort) notFound();

  // Role alone isn't enough here: this is one institution's roster, and the
  // id in the URL is just a client-supplied identifier. An institution_admin
  // may only see their own institution's cohorts; operators see any.
  const { data: profile } = await admin
    .from("profiles").select("role").eq("id", user.id).maybeSingle();

  if (profile?.role !== "operator") {
    const { data: member } = await admin
      .from("institution_members").select("institution_id").eq("user_id", user.id).maybeSingle();
    if (!member || member.institution_id !== cohort.institution_id) notFound();
  }

  const { data: seats } = await admin
    .from("cohort_progress").select("*").eq("cohort_id", id).order("username");

  const rows = seats ?? [];
  const joined = rows.filter((r) => r.user_id).length;
  const active = rows.filter((r) => Number(r.topics_done) > 0).length;
  const passed = rows.reduce((sum, r) => sum + Number(r.projects_passed ?? 0), 0);
  const stale = rows.filter(
    (r) => r.user_id && r.last_active &&
      Date.now() - new Date(r.last_active).getTime() > 14 * 86400_000
  ).length;

  return (
    <>
        <nav className="crumb" style={{ paddingTop: 28 }}>
          <Link href="/institution">Cohorts</Link> / {cohort.name}
        </nav>

        <div className="studio__head">
          <div>
            <h1 className="rvw__h">{cohort.name}</h1>
            <p className="rvw__meta">
              {new Date(cohort.starts_on).toLocaleDateString()} –{" "}
              {new Date(cohort.ends_on).toLocaleDateString()}
            </p>
          </div>
          <span className={`pill${cohort.state === "active" ? " pill--free" : ""}`}>{cohort.state}</span>
        </div>

        <div className="dash__grid" style={{ marginTop: 26 }}>
          <div className="dash__card">
            <div className="eyebrow">Joined</div>
            <div className="dash__val num">{joined} / {cohort.seat_ceiling}</div>
            <p className="dash__note">Seats claimed against the ceiling.</p>
          </div>
          <div className="dash__card">
            <div className="eyebrow">Active</div>
            <div className="dash__val num">{active}</div>
            <p className="dash__note">Completed at least one topic. This is what you are billed for.</p>
          </div>
          <div className="dash__card">
            <div className="eyebrow">Projects passed</div>
            <div className="dash__val num">{passed}</div>
            <p className="dash__note">Assessed by a practitioner.</p>
          </div>
        </div>

        {stale > 0 && (
          <div className="notice" style={{ marginTop: 22 }}>
            <div>
              <p className="notice__h">
                {stale} learner{stale === 1 ? " has" : "s have"} not been back in two weeks
              </p>
              <p className="notice__p">
                Worth a nudge now rather than at the end of the month.
              </p>
            </div>
          </div>
        )}

        <CohortTools
          cohortId={cohort.id}
          classCode={cohort.class_code}
          ceiling={cohort.seat_ceiling}
          state={cohort.state}
        />

        <section style={{ marginTop: 44, marginBottom: 40 }}>
          <div className="sec__head">
            <h2 className="sub__h2">Usernames</h2>
            <span className="sec__meta">
              Hand these out with the class code. Learners choose their own PIN.
            </span>
          </div>
          <SeatTable cohortId={cohort.id} rows={rows} />
        </section>
      </>
  );
}
