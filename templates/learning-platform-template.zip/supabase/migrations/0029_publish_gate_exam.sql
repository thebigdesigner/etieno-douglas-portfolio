-- =====================================================================
-- 0029 — a course cannot be published without its exam
--
-- Every course now ends in one, so publishing without exam items would
-- put a learner through the topics and then dead-end them: the last topic
-- points at /learn/[slug]/exam, which redirects straight back out when
-- there is nothing to sit.
--
-- The project brief and rubric checks become conditional at the same
-- time. They are the right bar for a course that ends in a practitioner
-- assessment, and meaningless for one that does not — an exam-only course
-- has no project to brief and no rubric to mark against, so demanding
-- them would make requires_project = false unpublishable.
--
-- Restated in full: create or replace cannot patch a body.
-- =====================================================================
create or replace function public.submit_course_for_review(p_course_id uuid, p_instructor_id uuid)
returns table (ok boolean, reason text)
language plpgsql security definer set search_path = public as $$
declare
  v_course courses%rowtype;
  v_topics int; v_criteria int; v_quiz int; v_empty int; v_exam int;
begin
  select * into v_course from courses where id = p_course_id and instructor_id = p_instructor_id;
  if not found then
    return query select false, 'not_yours'; return;
  end if;

  if v_course.state not in ('draft','revision_requested') then
    return query select false, 'wrong_state'; return;
  end if;

  if v_course.thumbnail_path is null then
    return query select false, 'no_thumbnail'; return;
  end if;
  if v_course.hours_low is null or v_course.hours_high is null then
    return query select false, 'no_hours'; return;
  end if;

  select count(*) into v_topics
    from topics t join modules m on m.id = t.module_id where m.course_id = p_course_id;
  if v_topics < 3 then return query select false, 'too_few_topics'; return; end if;

  select count(*) into v_empty
    from topics t join modules m on m.id = t.module_id
   where m.course_id = p_course_id
     and coalesce(length(trim(t.body)), 0) < 40
     and not exists (select 1 from topic_materials tm where tm.topic_id = t.id);
  if v_empty > 0 then return query select false, 'empty_topics'; return; end if;

  select count(*) into v_quiz
    from quiz_items q join topics t on t.id = q.topic_id
    join modules m on m.id = t.module_id where m.course_id = p_course_id;
  if v_quiz < 3 then return query select false, 'too_few_questions'; return; end if;

  -- Five is a low bar deliberately. It is enough that 80% means something
  -- (four right out of five) without asking for an exam paper before a
  -- first course can go out.
  select count(*) into v_exam from exam_items where course_id = p_course_id;
  if v_exam < 5 then return query select false, 'too_few_exam_questions'; return; end if;

  -- Only where there is a project to assess.
  if v_course.requires_project then
    if coalesce(length(trim(v_course.project_brief)), 0) < 120 then
      return query select false, 'brief_too_short'; return;
    end if;

    select count(*) into v_criteria from rubric_criteria where course_id = p_course_id;
    if v_criteria < 2 then return query select false, 'rubric_too_thin'; return; end if;
  end if;

  update courses set state = 'in_review' where id = p_course_id;
  return query select true, null::text;
end; $$;
