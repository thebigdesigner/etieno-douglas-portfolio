"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import type { Product } from "@/lib/marketplace/types";
import ProductPreview from "@/components/marketplace/ProductPreview";

/**
 * The small feature card beside the hero, after the reference's "Djay Pro"
 * panel: one item at a time, full-bleed, with dots to move between them.
 *
 * It advances on its own every seven seconds, stops while it is hovered or
 * focused so nobody loses the card they were reading, and never moves for
 * anyone who has asked for reduced motion.
 */
export default function HeroCarousel({ slides }: {
  /** Each slide shows a photo when it has one, otherwise the item's cover. */
  slides: { href: string; title: string; line: string; product?: Product; image?: string; focus?: string }[];
}) {
  const [i, setI] = useState(0);
  const [held, setHeld] = useState(false);

  useEffect(() => {
    if (held || slides.length < 2) return;
    if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) return;
    const t = window.setInterval(() => setI((n) => (n + 1) % slides.length), 7000);
    return () => window.clearInterval(t);
  }, [held, slides.length]);

  if (!slides.length) return null;
  const s = slides[i];

  return (
    <div
      className="mk-feature"
      onMouseEnter={() => setHeld(true)} onMouseLeave={() => setHeld(false)}
      onFocus={() => setHeld(true)} onBlur={() => setHeld(false)}
      aria-roledescription="carousel" aria-label="Featured items"
    >
      <Link href={s.href} className="mk-feature__link" aria-live="polite">
        {s.image
          ? <img src={s.image} alt="" className="mk-feature__img" style={s.focus ? { objectPosition: s.focus } : undefined} />
          : s.product && <ProductPreview product={s.product} className="mk-feature__img" label="" />}
        <span className="mk-feature__txt">
          <span className="mk-feature__h">{s.title}</span>
          <span className="mk-feature__p">{s.line}</span>
        </span>
      </Link>
      {slides.length > 1 && (
        <div className="mk-feature__dots">
          {slides.map((x, n) => (
            <button key={x.href} type="button" className={n === i ? "is-on" : undefined}
              onClick={() => setI(n)} aria-label={`Show ${x.title}`} aria-current={n === i} />
          ))}
        </div>
      )}
    </div>
  );
}
