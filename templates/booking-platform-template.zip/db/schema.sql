-- ============================================================================
-- HISPREN TRANSPORT OS -- core schema (Postgres / Supabase)
-- Run once in the Supabase SQL editor. Safe to re-run: every object uses IF NOT EXISTS
-- or CREATE OR REPLACE.
--
-- Design notes
--   * Every business table carries tenant_id. Your Brand is simply the first row in
--     tenants; a second operator is a second row, never a second deployment.
--   * Seats are rows, not a count. A seat can only be sold once because claiming it is a
--     single UPDATE guarded by its state -- see claim_seats() at the bottom.
--   * Money is stored in kobo (integer). Never floats.
--   * Nothing is hard deleted; rows carry status and timestamps so the audit trail holds.
-- ============================================================================

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------- tenants
create table if not exists tenants (
  id              uuid primary key default gen_random_uuid(),
  slug            text not null unique,
  name            text not null,
  prefix          text not null,                       -- booking reference prefix, e.g. ATX
  currency        text not null default 'NGN',
  settings        jsonb not null default '{}'::jsonb,  -- hold minutes, child ratio, check-in rules
  created_at      timestamptz not null default now()
);

-- ---------------------------------------------------------------- people
create table if not exists customers (
  id              uuid primary key default gen_random_uuid(),
  tenant_id       uuid not null references tenants(id) on delete cascade,
  google_sub      text,                                 -- set when they sign in with Google
  name            text,
  email           text,
  phone           text not null,
  created_at      timestamptz not null default now(),
  unique (tenant_id, phone)
);
create index if not exists customers_tenant_email_idx on customers (tenant_id, lower(email));
create unique index if not exists customers_google_idx on customers (tenant_id, google_sub) where google_sub is not null;

create table if not exists staff (
  id              uuid primary key default gen_random_uuid(),
  tenant_id       uuid not null references tenants(id) on delete cascade,
  auth_user_id    uuid unique,                          -- Supabase auth.users.id
  name            text not null,
  email           text not null,
  role            text not null check (role in ('manager','terminal','accountant','driver')),
  terminal_id     uuid,                                 -- terminal staff are scoped to one desk
  active          boolean not null default true,
  created_at      timestamptz not null default now(),
  unique (tenant_id, email)
);

-- ---------------------------------------------------------------- network
create table if not exists terminals (
  id              uuid primary key default gen_random_uuid(),
  tenant_id       uuid not null references tenants(id) on delete cascade,
  code            text not null,                        -- uyo, phc, cal
  city            text not null,
  name            text not null,
  address         text,
  phone           text,
  whatsapp        text,
  opens_at        time,
  active          boolean not null default true,
  unique (tenant_id, code)
);

create table if not exists vehicles (
  id              uuid primary key default gen_random_uuid(),
  tenant_id       uuid not null references tenants(id) on delete cascade,
  label           text not null,                        -- Toyota Sequoia
  plate           text,
  capacity        smallint not null check (capacity between 1 and 80),
  seat_map        jsonb not null,                       -- [["D",1],[2,3],[4,5]] plus seat labels
  status          text not null default 'active' check (status in ('active','maintenance','retired')),
  unique (tenant_id, plate)
);

create table if not exists drivers (
  id              uuid primary key default gen_random_uuid(),
  tenant_id       uuid not null references tenants(id) on delete cascade,
  staff_id        uuid references staff(id),
  name            text not null,
  phone           text not null,
  licence_no      text,
  active          boolean not null default true,
  unique (tenant_id, phone)
);

create table if not exists routes (
  id              uuid primary key default gen_random_uuid(),
  tenant_id       uuid not null references tenants(id) on delete cascade,
  from_terminal   uuid not null references terminals(id),
  to_terminal     uuid not null references terminals(id),
  fare_kobo       integer not null check (fare_kobo > 0),
  duration_min    integer not null check (duration_min > 0),
  operating_days  smallint[] not null,                  -- 0=Sunday ... 6=Saturday
  departures      time[] not null,
  active          boolean not null default true,
  check (from_terminal <> to_terminal),
  unique (tenant_id, from_terminal, to_terminal)
);

-- ---------------------------------------------------------------- operations
create table if not exists trips (
  id              uuid primary key default gen_random_uuid(),
  tenant_id       uuid not null references tenants(id) on delete cascade,
  route_id        uuid not null references routes(id),
  vehicle_id      uuid references vehicles(id),
  driver_id       uuid references drivers(id),
  depart_date     date not null,
  depart_time     time not null,
  capacity        smallint not null,                    -- copied from the vehicle, overridable
  fare_kobo       integer not null,                     -- copied from the route at creation
  status          text not null default 'scheduled'
                  check (status in ('scheduled','boarding','departed','arrived','completed','cancelled')),
  departed_at     timestamptz,
  arrived_at      timestamptz,
  created_at      timestamptz not null default now(),
  unique (tenant_id, route_id, depart_date, depart_time)
);
create index if not exists trips_lookup_idx on trips (tenant_id, depart_date, route_id) where status <> 'cancelled';

create table if not exists bookings (
  id              uuid primary key default gen_random_uuid(),
  tenant_id       uuid not null references tenants(id) on delete cascade,
  reference       text not null,
  customer_id     uuid references customers(id),
  channel         text not null default 'web' check (channel in ('web','terminal','phone','whatsapp','api')),
  created_by      uuid references staff(id),            -- terminal staff, when not self-service
  status          text not null default 'pending'
                  check (status in ('pending','confirmed','cancelled','expired','refunded','no_show','completed')),
  contact_name    text,
  contact_phone   text not null,
  contact_email   text,
  kin_name        text,
  kin_phone       text,
  total_kobo      integer not null default 0,
  hold_expires_at timestamptz,                          -- while unpaid; null once settled
  confirmed_at    timestamptz,
  cancelled_at    timestamptz,
  created_at      timestamptz not null default now(),
  unique (tenant_id, reference)
);
create index if not exists bookings_phone_idx on bookings (tenant_id, contact_phone);
create index if not exists bookings_expiry_idx on bookings (hold_expires_at) where status = 'pending';

-- One row per physical seat on a trip. This table is why a seat cannot be sold twice.
create table if not exists trip_seats (
  trip_id         uuid not null references trips(id) on delete cascade,
  seat_no         smallint not null,
  state           text not null default 'free' check (state in ('free','held','sold','blocked')),
  booking_id      uuid references bookings(id) on delete set null,
  held_until      timestamptz,
  updated_at      timestamptz not null default now(),
  primary key (trip_id, seat_no)
);
create index if not exists trip_seats_state_idx on trip_seats (trip_id, state);
create index if not exists trip_seats_expiry_idx on trip_seats (held_until) where state = 'held';

create table if not exists passengers (
  id              uuid primary key default gen_random_uuid(),
  booking_id      uuid not null references bookings(id) on delete cascade,
  trip_id         uuid not null references trips(id),
  seat_no         smallint not null,
  full_name       text not null,
  pax_type        text not null default 'adult' check (pax_type in ('adult','child','infant')),
  fare_kobo       integer not null,
  status          text not null default 'reserved'
                  check (status in ('reserved','confirmed','checked_in','boarded','no_show','cancelled')),
  checked_in_at   timestamptz,
  boarded_at      timestamptz,
  unique (trip_id, seat_no)
);
-- A plain unique (trip_id, seat_no) is wrong, and wrong in a way that only shows up later:
-- nothing ever deletes a passenger row. Cancelling, refunding or expiring a hold frees the
-- seat in trip_seats and marks the passenger 'cancelled', but the row stays for the record --
-- so the seat comes back on sale and then cannot be sold, because the old row still owns the
-- pair. One cancelled booking poisons that seat on that departure permanently.
--
-- Replaced by a partial index: one LIVE passenger per seat, any number of dead ones.
--
-- The predicate names the statuses that actually hold a seat, rather than excluding the ones
-- that do not. 'cancelled' alone was not enough: a passenger marked 'no_show' at the gate on a
-- booking that was later refunded is just as finished, and kept blocking the seat. Listing the
-- live statuses means any status added later has to be opted in deliberately, instead of
-- silently making seats unsellable again.
alter table passengers drop constraint if exists passengers_trip_id_seat_no_key;
drop index if exists passengers_trip_id_seat_no_key;
drop index if exists passengers_seat_live_idx;
create unique index passengers_seat_live_idx
  on passengers (trip_id, seat_no)
  where status in ('reserved', 'confirmed', 'checked_in', 'boarded');

-- ---------------------------------------------------------------- money
create table if not exists payments (
  id              uuid primary key default gen_random_uuid(),
  tenant_id       uuid not null references tenants(id) on delete cascade,
  booking_id      uuid not null references bookings(id),
  provider        text not null default 'paystack' check (provider in ('paystack','cash','pos','transfer','other')),
  provider_ref    text,                                 -- Paystack reference; unique per tenant
  amount_kobo     integer not null,
  status          text not null default 'initialised'
                  check (status in ('initialised','pending','success','failed','abandoned','reversed')),
  channel         text,                                 -- card, bank, bank_transfer, cash, pos ...
  recorded_by     uuid references staff(id),            -- who took the cash, when offline
  raw             jsonb,                                -- verified provider payload
  created_at      timestamptz not null default now(),
  settled_at      timestamptz
);
create unique index if not exists payments_provider_ref_idx on payments (tenant_id, provider_ref) where provider_ref is not null;
create index if not exists payments_booking_idx on payments (booking_id);

-- Webhook deliveries, so a replayed Paystack event can never be applied twice.
create table if not exists webhook_events (
  id              uuid primary key default gen_random_uuid(),
  provider        text not null,
  event_id        text not null,
  received_at     timestamptz not null default now(),
  payload         jsonb,
  unique (provider, event_id)
);

create table if not exists refunds (
  id              uuid primary key default gen_random_uuid(),
  tenant_id       uuid not null references tenants(id) on delete cascade,
  booking_id      uuid not null references bookings(id),
  amount_kobo     integer not null,
  reason          text,
  approved_by     uuid references staff(id),
  status          text not null default 'pending' check (status in ('pending','processed','rejected')),
  created_at      timestamptz not null default now()
);

create table if not exists expenses (
  id              uuid primary key default gen_random_uuid(),
  tenant_id       uuid not null references tenants(id) on delete cascade,
  trip_id         uuid references trips(id),
  vehicle_id      uuid references vehicles(id),
  category        text not null,
  amount_kobo     integer not null,
  note            text,
  recorded_by     uuid references staff(id),
  incurred_on     date not null default current_date,
  created_at      timestamptz not null default now()
);

-- ------------------------------------------------- staff, roles and archiving
-- Re-runnable role list. 'terminal_manager' supervises a desk: everything a clerk can do,
-- plus authorising refunds and seeing the day's picture for their terminal.
alter table staff drop constraint if exists staff_role_check;
alter table staff add constraint staff_role_check
  check (role in ('manager','terminal_manager','terminal','accountant','driver'));

-- Removing someone must not delete their history: every booking, check-in and payment is
-- attributed to a staff row, so the row stays and is marked archived instead.
alter table staff add column if not exists archived_at timestamptz;
alter table staff add column if not exists archived_by uuid references staff(id);
alter table staff add column if not exists phone text;
create index if not exists staff_active_idx on staff (tenant_id, active);

-- ------------------------------------------------------------------ expenses
-- Money going out, recorded by the accountant: who was paid and what for.
alter table expenses add column if not exists payee text;
alter table expenses add column if not exists driver_id uuid references drivers(id);
alter table expenses add column if not exists method text;
alter table expenses add column if not exists approved_by uuid references staff(id);
create index if not exists expenses_date_idx on expenses (tenant_id, incurred_on desc);

-- Password state. A manager can only ever see a temporary password they just issued; once the
-- person sets their own, it exists solely as a hash inside Supabase Auth and nobody can read it.
alter table staff add column if not exists must_change_password boolean not null default false;
alter table staff add column if not exists password_set_at timestamptz;
alter table staff add column if not exists email_verified_at timestamptz;

-- Where each terminal actually is. Needed so a driver's map can show the destination, and so
-- the office can see how far off a vehicle is. Nullable: a terminal without coordinates simply
-- has no pin, rather than a pin in the Gulf of Guinea at 0,0.
alter table terminals add column if not exists lat double precision check (lat between -90 and 90);
alter table terminals add column if not exists lng double precision check (lng between -180 and 180);

-- A vehicle's usual driver. Trips still carry their own driver_id — the person who actually
-- drove that departure, which is what the manifest and the audit trail need — but assigning a
-- regular driver to a vehicle means the office knows who to call about a particular car, and a
-- new departure can be pre-filled instead of chosen from scratch every time.
alter table vehicles add column if not exists driver_id uuid references drivers(id) on delete set null;
create index if not exists vehicles_driver_idx on vehicles (tenant_id, driver_id);

-- ------------------------------------------------------- transfer receipts
-- A passenger who pays by bank transfer has nothing to show for it until somebody looks at their
-- bank. So they photograph the receipt, and the desk approves it.
--
-- The image is NOT in this table. It lives in Supabase Storage under a private bucket and only
-- the path is kept here — a photograph of a bank receipt carries an account number and a name,
-- and it should not be sitting in a row that half the office can select.
--
-- Approval is what confirms the booking. Nothing here touches the seat directly: the existing
-- confirm_booking() does that, so a transfer and a card payment end in exactly the same state.
create table if not exists payment_proofs (
  id            uuid primary key default gen_random_uuid(),
  tenant_id     uuid not null references tenants(id) on delete cascade,
  booking_id    uuid not null references bookings(id) on delete cascade,
  storage_path  text not null,
  mime          text,
  bytes         integer,
  sender_name   text,
  bank          text,
  amount_kobo   integer,
  status        text not null default 'pending' check (status in ('pending','approved','rejected')),
  note          text,
  reviewed_by   uuid references staff(id),
  reviewed_at   timestamptz,
  created_at    timestamptz not null default now()
);
create index if not exists proofs_queue_idx on payment_proofs (tenant_id, status, created_at desc);
create index if not exists proofs_booking_idx on payment_proofs (booking_id, created_at desc);

-- Only one receipt awaiting a decision per booking: a customer sending three photographs of the
-- same transfer should not give the desk three things to approve, and approving twice would take
-- the fare twice.
create unique index if not exists proofs_one_pending_idx
  on payment_proofs (booking_id) where status = 'pending';

-- Holding the seat while a transfer clears. Separate from claim_seats' fifteen minutes because
-- the reason is different: not "they are still typing" but "the money is on its way". The window
-- is settings.transfer_hold_minutes, a manager's to change.
create or replace function hold_for_transfer(p_booking uuid, p_minutes integer default 60)
returns timestamptz language plpgsql as $$
declare v_until timestamptz;
begin
  v_until := now() + make_interval(mins => greatest(5, least(p_minutes, 720)));
  update bookings set hold_expires_at = v_until
   where id = p_booking and status = 'pending';
  update trip_seats set held_until = v_until, updated_at = now()
   where booking_id = p_booking and state = 'held';
  return v_until;
end $$;

-- ---------------------------------------------------------------- sign-in attempts
-- Staff sign-in was the only door in the building with no lock on the number of tries. Every
-- other endpoint counts attempts in memory, which is fine for a courtesy limit and useless
-- here: a serverless instance forgets everything when it goes cold, and there are many of them,
-- so an attacker gets a fresh allowance every few seconds. This lives in the database.
--
-- Two counters, because they stop different things. By email: somebody working through a
-- password list against one manager. By address: somebody trying one common password against
-- every account they can name.
create table if not exists auth_attempts (
  id         bigserial primary key,
  tenant_id  uuid references tenants(id) on delete cascade,
  email      text,
  ip         text,
  ok         boolean not null,
  at         timestamptz not null default now()
);
create index if not exists auth_attempts_email_idx on auth_attempts (lower(email), at desc);
create index if not exists auth_attempts_ip_idx on auth_attempts (ip, at desc);
create index if not exists auth_attempts_purge_idx on auth_attempts (at);

-- Is this sign-in allowed to be attempted at all?
--
-- Deliberately says the same thing whether or not the email exists — a lockout message that
-- only appears for real accounts is an account-enumeration oracle. And it counts failures
-- *since the last success*, so somebody who mistypes twice and then gets in starts clean.
create or replace function login_gate(p_email text, p_ip text)
returns jsonb language plpgsql stable as $$
declare
  v_since timestamptz := now() - interval '15 minutes';
  v_last_ok timestamptz;
  v_email_fails integer;
  v_ip_fails integer;
  v_next timestamptz;
begin
  select max(at) into v_last_ok from auth_attempts
   where lower(email) = lower(p_email) and ok and at > v_since;

  select count(*), max(at) into v_email_fails, v_next from auth_attempts
   where lower(email) = lower(p_email) and not ok and at > greatest(v_since, coalesce(v_last_ok, v_since));

  select count(*) into v_ip_fails from auth_attempts
   where ip = p_ip and p_ip is not null and not ok and at > v_since;

  -- Five wrong passwords for one account, or twenty from one address, and the door closes for
  -- the rest of the quarter hour.
  if v_email_fails >= 5 or v_ip_fails >= 20 then
    return jsonb_build_object('locked', true,
      'retryAfter', greatest(1, ceil(extract(epoch from (coalesce(v_next, now()) + interval '15 minutes' - now()))))::int);
  end if;
  return jsonb_build_object('locked', false, 'fails', v_email_fails);
end $$;

create or replace function note_login(p_tenant uuid, p_email text, p_ip text, p_ok boolean)
returns void language sql as $$
  insert into auth_attempts (tenant_id, email, ip, ok) values (p_tenant, lower(p_email), p_ip, p_ok);
$$;

-- Called nightly. Attempts are for rate limiting, not a permanent record of who typed what.
create or replace function purge_auth_attempts(p_days integer default 30)
returns integer language plpgsql as $$
declare v_n integer;
begin
  delete from auth_attempts where at < now() - make_interval(days => p_days);
  get diagnostics v_n = row_count;
  return v_n;
end $$;

-- ---------------------------------------------------------------- tracking
-- Where a vehicle is, from the driver's phone. No hardware.
--
-- Three things this design refuses to do:
--   * present an old position as a current one. Every row is stamped, and every reader is given
--     the age, so a screen can say "last seen 40 minutes ago" instead of drawing a van on a road
--     it left an hour back. That is the failure that makes tracking worse than none at all.
--   * keep a history of where a driver has been. Positions are for the trip in progress; the
--     nightly job deletes anything older than the retention window. A transport operator does
--     not need a permanent record of an employee's movements, and holding one is a liability
--     under NDPR.
--   * share a driver's position with customers. Manager and terminal manager only; the driver
--     sees their own.
create table if not exists trip_locations (
  id           bigserial primary key,
  tenant_id    uuid not null references tenants(id) on delete cascade,
  trip_id      uuid not null references trips(id) on delete cascade,
  driver_id    uuid references drivers(id),
  lat          double precision not null check (lat between -90 and 90),
  lng          double precision not null check (lng between -180 and 180),
  accuracy_m   integer,
  speed_kph    integer,
  heading      integer,
  recorded_at  timestamptz not null default now()
);
create index if not exists trip_loc_latest_idx on trip_locations (trip_id, recorded_at desc);
create index if not exists trip_loc_purge_idx on trip_locations (recorded_at);

-- Which trips are moving, and how fresh each position is. The age is computed here so that no
-- caller has to remember to work it out -- forgetting is how a stale dot ends up looking live.
create or replace function tracking_now(p_tenant uuid)
returns jsonb language sql stable as $$
  select coalesce(jsonb_agg(x order by x->>'departs'), '[]'::jsonb) from (
    select jsonb_build_object(
      'tripId', t.id,
      'departs', t.depart_date::text || ' ' || to_char(t.depart_time, 'HH24:MI'),
      'status', t.status,
      'from', cf.city,
      'to', ct.city,
      'fromLat', cf.lat, 'fromLng', cf.lng,
      'toLat', ct.lat, 'toLng', ct.lng,
      'vehicle', coalesce(v.label, ''),
      'plate', coalesce(v.plate, ''),
      'driver', coalesce(d.name, ''),
      'driverPhone', coalesce(d.phone, ''),
      'passengers', (select count(*) from passengers p
                      where p.trip_id = t.id and p.status in ('confirmed','checked_in','boarded')),
      'lat', l.lat, 'lng', l.lng,
      'accuracyM', l.accuracy_m, 'speedKph', l.speed_kph,
      'recordedAt', l.recorded_at,
      'ageSeconds', case when l.recorded_at is null then null
                         else floor(extract(epoch from (now() - l.recorded_at)))::int end
    ) as x
      from trips t
      join routes r     on r.id = t.route_id
      join terminals cf on cf.id = r.from_terminal
      join terminals ct on ct.id = r.to_terminal
      left join vehicles v on v.id = t.vehicle_id
      left join drivers d  on d.id = t.driver_id
      left join lateral (
        select lat, lng, accuracy_m, speed_kph, recorded_at
          from trip_locations tl where tl.trip_id = t.id
         order by recorded_at desc limit 1
      ) l on true
     where t.tenant_id = p_tenant
       and t.status in ('boarding','departed')
       and t.depart_date between current_date - 1 and current_date + 1
  ) s;
$$;

-- Called nightly. The window is deliberately short: this is operational data for a journey in
-- progress, not a movement history.
create or replace function purge_locations(p_days integer default 7)
returns integer language plpgsql as $$
declare v_n integer;
begin
  delete from trip_locations where recorded_at < now() - make_interval(days => p_days);
  get diagnostics v_n = row_count;
  return v_n;
end $$;

-- ---------------------------------------------------------------- notifications
-- Two kinds of thing reach a person, and they behave differently.
--
-- DERIVED alerts are worked out from current state every time someone looks: unpaid holds
-- about to lapse, a departure in two hours with no driver, messages nobody has answered. They
-- are not stored, because storing them means storing something that can go stale -- the hold
-- gets paid and the row still says otherwise. They disappear when the situation resolves, which
-- is the correct behaviour, and they work retroactively on data that already exists.
--
-- STORED notifications are announcements: a manager telling the desks that Saturday's 14:00 is
-- cancelled, or that a vehicle changed. There is no state to derive those from -- they happened,
-- somebody said them -- so they are rows, and they carry real read state per person.
create table if not exists notifications (
  id            uuid primary key default gen_random_uuid(),
  tenant_id     uuid not null references tenants(id) on delete cascade,
  -- Exactly one audience is set. A role reaches everyone holding it; a staff id reaches one
  -- person; an email reaches one customer; 'customers' reaches every signed-in customer.
  audience_role text check (audience_role in ('manager','terminal_manager','terminal','accountant','driver','all','customers')),
  audience_staff uuid references staff(id) on delete cascade,
  audience_email text,
  kind          text not null default 'notice' check (kind in ('notice','warning','urgent')),
  title         text not null,
  body          text,
  entity        text,
  entity_id     uuid,
  created_by    uuid references staff(id),
  created_at    timestamptz not null default now(),
  expires_at    timestamptz,
  check (num_nonnulls(audience_role, audience_staff, audience_email) = 1)
);
create index if not exists notif_role_idx on notifications (tenant_id, audience_role, created_at desc);
create index if not exists notif_staff_idx on notifications (tenant_id, audience_staff, created_at desc);
create index if not exists notif_email_idx on notifications (tenant_id, lower(audience_email), created_at desc);

-- Read state is per reader, not per row: a broadcast to every clerk is one notification and
-- one read row for each clerk who has seen it.
create table if not exists notification_reads (
  notification_id uuid not null references notifications(id) on delete cascade,
  reader          text not null,          -- a staff uuid, or a customer's lowercased email
  read_at         timestamptz not null default now(),
  primary key (notification_id, reader)
);

-- ---------------------------------------------------------------- audit
create table if not exists audit_log (
  id              bigserial primary key,
  tenant_id       uuid references tenants(id) on delete cascade,
  actor_type      text not null check (actor_type in ('customer','staff','system','provider')),
  actor_id        uuid,
  action          text not null,                        -- booking.created, payment.confirmed ...
  entity          text not null,
  entity_id       uuid,
  detail          jsonb,
  created_at      timestamptz not null default now()
);
create index if not exists audit_tenant_time_idx on audit_log (tenant_id, created_at desc);

-- What one staff member has actually done, for the manager's view of a person.
create or replace function staff_activity(p_staff uuid, p_from date, p_to date)
returns jsonb
language sql
stable
as $$
  select jsonb_build_object(
    'bookings',   (select count(*) from bookings
                    where created_by = p_staff
                      and created_at >= p_from::timestamptz and created_at < (p_to + 1)::timestamptz),
    'sales_kobo', (select coalesce(sum(amount_kobo), 0) from payments
                    where recorded_by = p_staff and status = 'success' and amount_kobo > 0
                      and created_at >= p_from::timestamptz and created_at < (p_to + 1)::timestamptz),
    'refunds_kobo', (select coalesce(abs(sum(amount_kobo)), 0) from payments
                    where recorded_by = p_staff and status = 'success' and amount_kobo < 0
                      and created_at >= p_from::timestamptz and created_at < (p_to + 1)::timestamptz),
    'check_ins',  (select count(*) from audit_log
                    where actor_id = p_staff and action like 'passenger.%'
                      and created_at >= p_from::timestamptz and created_at < (p_to + 1)::timestamptz),
    'actions',    (select count(*) from audit_log
                    where actor_id = p_staff
                      and created_at >= p_from::timestamptz and created_at < (p_to + 1)::timestamptz)
  );
$$;

-- ---------------------------------------------------------------- loyalty
-- Trail points.
--
-- Points are a ledger, not a counter: every award and every spend is its own row, so a balance
-- can always be explained and a refund can take back exactly what a booking earned. A counter
-- column would drift the first time anything went wrong.
--
-- A customer is identified by the email on the booking, matching how booking history works.
-- Someone who books under two addresses collects two balances; that is a known limit, not a bug
-- to be surprised by later.
create table if not exists loyalty_ledger (
  id              bigserial primary key,
  tenant_id       uuid not null references tenants(id) on delete cascade,
  customer_email  text not null,
  booking_id      uuid references bookings(id) on delete set null,
  passenger_id    uuid references passengers(id) on delete set null,
  points          integer not null,                     -- negative when spent or reversed
  reason          text not null,                        -- trip | coupon | reversal | adjustment
  note            text,
  created_at      timestamptz not null default now()
);
create index if not exists loyalty_customer_idx on loyalty_ledger (tenant_id, lower(customer_email));
-- One award per passenger per trip, however many times boarding is tapped.
create unique index if not exists loyalty_trip_once_idx
  on loyalty_ledger (passenger_id) where reason = 'trip';

create table if not exists coupons (
  id              uuid primary key default gen_random_uuid(),
  tenant_id       uuid not null references tenants(id) on delete cascade,
  code            text not null,
  customer_email  text not null,
  value_kobo      integer not null check (value_kobo > 0),
  points_spent    integer not null,
  issued_at       timestamptz not null default now(),
  expires_at      timestamptz,
  redeemed_at     timestamptz,
  booking_id      uuid references bookings(id),         -- the booking it paid towards
  unique (tenant_id, code)
);
create index if not exists coupons_customer_idx on coupons (tenant_id, lower(customer_email)) where redeemed_at is null;

-- Award points for a boarded passenger and issue a coupon if the balance has earned one.
-- Returns what happened so the caller can tell the passenger.
create or replace function award_trip_points(p_passenger uuid)
returns jsonb
language plpgsql
as $$
declare
  v_tenant   uuid;
  v_email    text;
  v_booking  uuid;
  v_cfg      jsonb;
  v_per_trip integer;
  v_needed   integer;
  v_value    integer;
  v_expiry   integer;
  v_balance  integer;
  v_code     text;
  v_issued   boolean := false;
begin
  select b.tenant_id, lower(b.contact_email), b.id
    into v_tenant, v_email, v_booking
    from passengers p join bookings b on b.id = p.booking_id
   where p.id = p_passenger;

  -- No email means no way to identify the customer or send them anything.
  if v_email is null or v_email = '' then
    return jsonb_build_object('awarded', 0, 'reason', 'no_email');
  end if;

  select coalesce(settings -> 'loyalty', '{}'::jsonb) into v_cfg from tenants where id = v_tenant;
  if coalesce((v_cfg ->> 'enabled')::boolean, true) is not true then
    return jsonb_build_object('awarded', 0, 'reason', 'disabled');
  end if;

  v_per_trip := coalesce((v_cfg ->> 'points_per_trip')::integer, 10);
  v_needed   := coalesce((v_cfg ->> 'points_per_coupon')::integer, 100);
  v_value    := coalesce((v_cfg ->> 'coupon_value_kobo')::integer, 500000);
  v_expiry   := coalesce((v_cfg ->> 'coupon_expiry_days')::integer, 180);

  -- The partial unique index makes a second tap a no-op rather than a second award.
  insert into loyalty_ledger (tenant_id, customer_email, booking_id, passenger_id, points, reason)
  values (v_tenant, v_email, v_booking, p_passenger, v_per_trip, 'trip')
  on conflict do nothing;

  if not found then
    return jsonb_build_object('awarded', 0, 'reason', 'already_awarded');
  end if;

  select coalesce(sum(points), 0) into v_balance
    from loyalty_ledger where tenant_id = v_tenant and lower(customer_email) = v_email;

  if v_needed > 0 and v_balance >= v_needed then
    v_code := 'ATXC-' || upper(substr(md5(gen_random_uuid()::text), 1, 6));
    insert into coupons (tenant_id, code, customer_email, value_kobo, points_spent, expires_at)
    values (v_tenant, v_code, v_email, v_value, v_needed,
            case when v_expiry > 0 then now() + (v_expiry || ' days')::interval else null end);

    insert into loyalty_ledger (tenant_id, customer_email, points, reason, note)
    values (v_tenant, v_email, -v_needed, 'coupon', v_code);

    v_balance := v_balance - v_needed;
    v_issued := true;
  end if;

  return jsonb_build_object('awarded', v_per_trip, 'balance', v_balance,
                            'coupon', case when v_issued then v_code else null end,
                            'coupon_value_kobo', case when v_issued then v_value else null end,
                            'email', v_email);
end;
$$;

-- Take back what a booking earned when it is refunded or cancelled, so a booked-and-refunded
-- trip cannot be farmed for points. Never drives a balance below zero.
create or replace function reverse_trip_points(p_booking uuid)
returns integer
language plpgsql
as $$
declare v_earned integer; v_tenant uuid; v_email text; v_balance integer;
begin
  -- Postgres has no max() for uuid, so the original form of this raised every time it ran --
  -- and the caller logs the failure and carries on, which meant points were never actually
  -- taken back on a refund. Book, board, collect points, ask for a refund, keep the points:
  -- exactly what earning at boarding was meant to prevent.
  select coalesce(sum(points), 0) into v_earned
    from loyalty_ledger where booking_id = p_booking and reason = 'trip';

  select tenant_id, lower(customer_email) into v_tenant, v_email
    from loyalty_ledger where booking_id = p_booking and reason = 'trip' limit 1;

  if v_earned is null or v_earned = 0 then return 0; end if;

  select coalesce(sum(points), 0) into v_balance
    from loyalty_ledger where tenant_id = v_tenant and lower(customer_email) = v_email;

  v_earned := least(v_earned, greatest(v_balance, 0));
  if v_earned <= 0 then return 0; end if;

  insert into loyalty_ledger (tenant_id, customer_email, booking_id, points, reason, note)
  values (v_tenant, v_email, p_booking, -v_earned, 'reversal', 'booking cancelled or refunded');
  return v_earned;
end;
$$;

-- Spend a credit against a booking.
--
-- Single-use is enforced by the update itself: the row is only claimed when redeemed_at is
-- still null, so two clerks typing the same code at the same moment cannot both succeed --
-- one gets the credit, the other gets nothing back and is told it is already used.
--
-- Returns the value applied in kobo, or raises so the caller can say exactly what was wrong.
create or replace function redeem_coupon(
  p_tenant  uuid,
  p_code    text,
  p_booking uuid,
  p_max_kobo integer
)
returns integer
language plpgsql
as $$
declare v_id uuid; v_value integer; v_expires timestamptz; v_used timestamptz; v_applied integer;
begin
  select id, value_kobo, expires_at, redeemed_at
    into v_id, v_value, v_expires, v_used
    from coupons
   where tenant_id = p_tenant and upper(code) = upper(trim(p_code));

  if v_id is null then raise exception 'no_coupon' using errcode = 'P0002'; end if;
  if v_used is not null then raise exception 'already_used' using errcode = 'P0001'; end if;
  if v_expires is not null and v_expires < now() then raise exception 'expired' using errcode = 'P0001'; end if;

  -- A credit never pays out more than the booking is worth, and never turns into change.
  v_applied := least(v_value, greatest(p_max_kobo, 0));
  if v_applied <= 0 then raise exception 'nothing_to_pay' using errcode = 'P0001'; end if;

  update coupons
     set redeemed_at = now(), booking_id = p_booking
   where id = v_id and redeemed_at is null;

  if not found then raise exception 'already_used' using errcode = 'P0001'; end if;
  return v_applied;
end;
$$;

-- Read a credit without spending it, so the desk can tell a passenger what it is worth
-- before anything is committed.
create or replace function check_coupon(p_tenant uuid, p_code text)
returns jsonb
language sql
stable
as $$
  select coalesce(
    (select jsonb_build_object(
       'code', code,
       'value', value_kobo,
       'used', redeemed_at is not null,
       'expired', expires_at is not null and expires_at < now(),
       'email', customer_email)
       from coupons
      where tenant_id = p_tenant and upper(code) = upper(trim(p_code))),
    '{"code":null}'::jsonb);
$$;

-- ---------------------------------------------------------------- feedback
-- Messages sent from the contact page. Stored as well as emailed: DMARC for the sending
-- domain is not finished, so an email that silently fails to deliver would otherwise mean a
-- complaint nobody ever sees.
create table if not exists feedback (
  id          uuid primary key default gen_random_uuid(),
  tenant_id   uuid not null references tenants(id) on delete cascade,
  name        text not null,
  email       text,
  phone       text,
  reference   text,                       -- a booking reference, when the message is about one
  topic       text not null,
  message     text not null,
  handled_at  timestamptz,
  handled_by  uuid references staff(id),
  created_at  timestamptz not null default now()
);
create index if not exists feedback_new_idx on feedback (tenant_id, created_at desc) where handled_at is null;
-- The inbox lists handled messages too, so it needs an index that is not partial.
create index if not exists feedback_all_idx on feedback (tenant_id, created_at desc);
-- What was actually done about the message. Added after the table so an existing deployment
-- picks it up on a re-run rather than needing a migration of its own.
alter table feedback add column if not exists handled_note text;

-- ============================================================================
-- SEAT CLAIM
-- The only supported way to take seats. Runs in one transaction: it locks just the seats
-- asked for, releases any hold that has expired, and fails loudly if another booking got
-- there first. Two people tapping the last seat at the same moment: one succeeds, one gets
-- 'seat_taken'.
-- ============================================================================
create or replace function claim_seats(
  p_trip_id   uuid,
  p_seats     smallint[],
  p_booking   uuid,
  p_hold_mins integer
) returns void
language plpgsql
as $$
declare
  v_locked  integer;
  v_claimed integer;
begin
  -- Lock the requested seats in a deterministic order so concurrent callers cannot deadlock.
  select count(*) into v_locked
  from (
    select seat_no from trip_seats
    where trip_id = p_trip_id and seat_no = any(p_seats)
    order by seat_no
    for update
  ) locked;

  if v_locked <> array_length(p_seats, 1) then
    raise exception 'seat_missing' using hint = 'A requested seat does not exist on this trip.';
  end if;

  -- A hold that has run out is free again.
  update trip_seats
     set state = 'free', booking_id = null, held_until = null, updated_at = now()
   where trip_id = p_trip_id
     and seat_no = any(p_seats)
     and state = 'held'
     and held_until < now();

  update trip_seats
     set state      = 'held',
         booking_id = p_booking,
         held_until = now() + make_interval(mins => p_hold_mins),
         updated_at = now()
   where trip_id = p_trip_id
     and seat_no = any(p_seats)
     and state = 'free';

  get diagnostics v_claimed = row_count;

  if v_claimed <> array_length(p_seats, 1) then
    raise exception 'seat_taken' using hint = 'Someone else took one of those seats.';
  end if;
end;
$$;

-- Settle a booking once payment is verified: seats become sold, passengers confirmed.
-- Returns what actually happened, because the caller has usually just taken money:
--   'confirmed'  seats were still held for this booking; now sold
--   'already'    it was confirmed before (a retry, or the desk got there first)
--   'reseated'   the hold had lapsed but the same seats were still free, so they were taken back
--   'lost'       the hold lapsed and a seat went to someone else, or the booking was cancelled.
--                Nothing is changed. The money is real and somebody must refund or re-seat.
--   'missing'    no such booking
-- The old version returned void and did nothing on a lapsed hold, so a customer whose card
-- payment finished after the 15-minute hold was charged, got no ticket, and nobody was told.
drop function if exists confirm_booking(uuid);
create function confirm_booking(p_booking uuid)
returns text
language plpgsql
as $$
declare
  v_status text;
  v_needed integer;
  v_held   integer;
  v_taken  integer;
begin
  select status into v_status from bookings where id = p_booking for update;
  if v_status is null then return 'missing'; end if;

  if v_status = 'confirmed' then
    update trip_seats set state = 'sold', held_until = null, updated_at = now()
     where booking_id = p_booking and state = 'held';
    return 'already';
  end if;

  if v_status = 'pending' then
    select count(*) into v_needed from passengers
     where booking_id = p_booking and status in ('reserved', 'confirmed');
    select count(*) into v_held from trip_seats
     where booking_id = p_booking and state in ('held', 'sold');

    if v_needed > 0 and v_held = v_needed then
      update trip_seats
         set state = 'sold', held_until = null, updated_at = now()
       where booking_id = p_booking and state in ('held', 'sold');
      update passengers set status = 'confirmed'
       where booking_id = p_booking and status = 'reserved';
      update bookings
         set status = 'confirmed', confirmed_at = coalesce(confirmed_at, now()), hold_expires_at = null
       where id = p_booking;
      return 'confirmed';
    end if;
  end if;

  if v_status not in ('pending', 'expired') then
    return 'lost';                       -- cancelled or refunded by a person: never undo that
  end if;

  -- The hold lapsed. Take the same seats back if, and only if, every one is still free.
  -- Any conflict rolls this block back as a unit, so a partial re-seat cannot happen.
  begin
    select count(*) into v_needed from passengers where booking_id = p_booking;
    if v_needed = 0 then return 'lost'; end if;

    update trip_seats ts
       set state = 'sold', booking_id = p_booking, held_until = null, updated_at = now()
      from passengers p
     where p.booking_id = p_booking
       and ts.trip_id = p.trip_id and ts.seat_no = p.seat_no
       and (ts.state = 'free' or ts.booking_id = p_booking);
    get diagnostics v_taken = row_count;

    if v_taken <> v_needed then
      raise exception 'reseat_incomplete';
    end if;

    update passengers set status = 'confirmed'
     where booking_id = p_booking and status in ('reserved', 'cancelled');
    update bookings
       set status = 'confirmed', confirmed_at = now(), cancelled_at = null, hold_expires_at = null
     where id = p_booking;
    return 'reseated';
  exception
    when unique_violation or raise_exception then
      return 'lost';
  end;
end;
$$;

-- Push a pending booking's hold out while the customer is paying. Card and bank transfer
-- checkouts at Paystack can outlast a 15-minute hold; the seats must still be there when the
-- money lands. Only ever lengthens, only for a booking that is still pending.
-- p_cap_minutes bounds the hold measured from when the booking was made, so repeating the call
-- cannot keep seats off sale indefinitely.
drop function if exists extend_hold(uuid, integer);
create or replace function extend_hold(p_booking uuid, p_minutes integer, p_cap_minutes integer default 90)
returns timestamptz
language plpgsql
as $$
declare v_until timestamptz;
begin
  select least(now() + make_interval(mins => greatest(1, least(p_minutes, 720))),
               created_at + make_interval(mins => greatest(1, least(p_cap_minutes, 1440))))
    into v_until
    from bookings where id = p_booking and status = 'pending';
  if v_until is null or v_until <= now() then return null; end if;

  update bookings set hold_expires_at = greatest(coalesce(hold_expires_at, v_until), v_until)
   where id = p_booking and status = 'pending';
  update trip_seats set held_until = greatest(coalesce(held_until, v_until), v_until), updated_at = now()
   where booking_id = p_booking and state = 'held';
  return v_until;
end;
$$;

-- Release everything a booking is holding (expiry, cancellation).
create or replace function release_booking(p_booking uuid, p_status text)
returns void
language plpgsql
as $$
begin
  update trip_seats
     set state = 'free', booking_id = null, held_until = null, updated_at = now()
   where booking_id = p_booking and state = 'held';

  update passengers set status = 'cancelled'
   where booking_id = p_booking and status in ('reserved', 'confirmed');

  update bookings
     set status = p_status, cancelled_at = now(), hold_expires_at = null
   where id = p_booking;
end;
$$;

-- ---------------------------------------------------------------- customers
-- Until now `customers` existed and nothing wrote to it: bookings carried a name and a phone
-- number as loose text, so the same person booking twice was two strangers. The phone number is
-- the identity -- it is the one thing every booking has, online or at a desk, and it is what a
-- clerk asks for.
--
-- A trigger rather than application code: bookings are created from the website, the desk and
-- (later) other channels, and every one of them must link. One rule in one place cannot be
-- forgotten by the twenty-first caller.
create or replace function link_booking_customer() returns trigger
language plpgsql as $$
declare v_phone text; v_id uuid;
begin
  v_phone := regexp_replace(coalesce(new.contact_phone, ''), '\D', '', 'g');
  -- Nigerian numbers are written 0803..., +234803... and 234803...; the last 10 digits are the same
  -- in all three, so that is what identifies a person.
  if length(v_phone) >= 10 then
    v_phone := right(v_phone, 10);
  else
    return new;                       -- nothing usable to identify them by
  end if;

  select id into v_id from customers
   where tenant_id = new.tenant_id and right(regexp_replace(phone, '\D', '', 'g'), 10) = v_phone
   limit 1;

  if v_id is null then
    insert into customers (tenant_id, name, phone, email)
    values (new.tenant_id, new.contact_name, new.contact_phone, new.contact_email)
    returning id into v_id;
  else
    -- Keep the freshest name and email we have been given, without wiping what we had.
    update customers
       set name  = coalesce(nullif(trim(new.contact_name), ''), name),
           email = coalesce(nullif(trim(new.contact_email), ''), email)
     where id = v_id;
  end if;

  new.customer_id := v_id;
  return new;
end $$;

drop trigger if exists bookings_link_customer on bookings;
create trigger bookings_link_customer
  before insert or update of contact_phone on bookings
  for each row execute function link_booking_customer();

-- Backfill: safe to re-run, and only touches bookings that are not linked yet.
update bookings set contact_phone = contact_phone where customer_id is null and contact_phone is not null;

-- One customer's history. Counted from passengers and payments rather than stored on the
-- customer row, so it cannot drift out of step with the bookings it describes.
create or replace function customer_stats(p_tenant uuid, p_customer uuid)
returns jsonb language sql stable as $$
  select jsonb_build_object(
    'bookings',   (select count(*) from bookings b where b.tenant_id = p_tenant and b.customer_id = p_customer),
    'trips',      (select count(*) from passengers p join bookings b on b.id = p.booking_id
                    where b.tenant_id = p_tenant and b.customer_id = p_customer and p.status = 'boarded'),
    'spend_kobo', (select coalesce(sum(pay.amount_kobo), 0) from payments pay join bookings b on b.id = pay.booking_id
                    where b.tenant_id = p_tenant and b.customer_id = p_customer and pay.status = 'success'),
    'cancelled',  (select count(*) from bookings b where b.tenant_id = p_tenant and b.customer_id = p_customer
                    and b.status in ('cancelled','refunded')),
    'no_shows',   (select count(*) from passengers p join bookings b on b.id = p.booking_id
                    where b.tenant_id = p_tenant and b.customer_id = p_customer and p.status = 'no_show'),
    'first_seen', (select min(b.created_at) from bookings b where b.tenant_id = p_tenant and b.customer_id = p_customer),
    'last_seen',  (select max(b.created_at) from bookings b where b.tenant_id = p_tenant and b.customer_id = p_customer),
    'top_route',  (select cf.city || ' to ' || ct.city
                     from passengers p
                     join bookings b on b.id = p.booking_id
                     join trips tr on tr.id = p.trip_id
                     join routes r on r.id = tr.route_id
                     join terminals cf on cf.id = r.from_terminal
                     join terminals ct on ct.id = r.to_terminal
                    where b.tenant_id = p_tenant and b.customer_id = p_customer
                    group by cf.city, ct.city order by count(*) desc limit 1)
  );
$$;

-- Move one passenger to another seat, or to another departure, without cancelling.
--
-- Until now the only way to move somebody was to cancel and re-sell: the reference changed, the
-- money ledger gained a refund and a fresh sale for what was really one journey, and between the
-- two the seat could be taken by somebody else. This does it in one transaction instead.
--
-- What it will not do:
--   * put two live passengers in one seat -- the target is locked and checked, exactly as
--     claim_seats does, so two clerks moving people into the same seat cannot both win;
--   * move somebody onto a departure that has already left, or been cancelled;
--   * move somebody who has already boarded -- they are on the vehicle;
--   * move between tenants, or onto a seat the vehicle does not have.
--
-- The fare difference is returned rather than charged here. Money is the API's business: it
-- appends a payment row so the ledger still sums to what the passenger owes, and the desk can
-- see what to collect or hand back.
create or replace function move_passenger(
  p_passenger uuid,
  p_trip      uuid,
  p_seat      smallint,
  p_staff     uuid
) returns jsonb
language plpgsql
as $$
declare
  v_old_trip uuid; v_old_seat smallint; v_booking uuid; v_status text;
  v_tenant uuid; v_old_fare integer; v_new_fare integer; v_state text; v_cap integer;
  v_route_old uuid; v_route_new uuid;
begin
  select p.trip_id, p.seat_no, p.booking_id, p.status, b.tenant_id, p.fare_kobo
    into v_old_trip, v_old_seat, v_booking, v_status, v_tenant, v_old_fare
    from passengers p join bookings b on b.id = p.booking_id
   where p.id = p_passenger
   for update of p;

  if v_booking is null then
    raise exception 'no_passenger' using hint = 'That passenger is not on any booking.';
  end if;
  if v_status in ('cancelled', 'no_show') then
    raise exception 'not_live' using hint = 'That passenger is no longer travelling.';
  end if;
  if v_status = 'boarded' then
    raise exception 'already_boarded' using hint = 'They are already on the vehicle.';
  end if;

  select t.capacity, t.fare_kobo, t.route_id into v_cap, v_new_fare, v_route_new
    from trips t
   where t.id = p_trip and t.tenant_id = v_tenant and t.status = 'scheduled'
     and (t.depart_date + t.depart_time) > now();
  if v_cap is null then
    raise exception 'no_trip' using hint = 'That departure is not available.';
  end if;
  if p_seat < 1 or p_seat > v_cap then
    raise exception 'seat_missing' using hint = 'That seat does not exist on this vehicle.';
  end if;

  select route_id into v_route_old from trips where id = v_old_trip;
  if v_route_old is distinct from v_route_new then
    raise exception 'different_route' using hint = 'Moving between routes means a new booking.';
  end if;

  if p_trip = v_old_trip and p_seat = v_old_seat then
    return jsonb_build_object('moved', false, 'reason', 'same_seat');
  end if;

  -- Take the new seat first, in the same locking style as claim_seats. If this fails nothing
  -- has been given up yet.
  select state into v_state from trip_seats
   where trip_id = p_trip and seat_no = p_seat for update;
  if v_state is null then
    raise exception 'seat_missing' using hint = 'That seat does not exist on this departure.';
  end if;

  update trip_seats set state = 'free', booking_id = null, held_until = null, updated_at = now()
   where trip_id = p_trip and seat_no = p_seat and state = 'held' and held_until < now();

  update trip_seats
     set state = 'sold', booking_id = v_booking, held_until = null, updated_at = now()
   where trip_id = p_trip and seat_no = p_seat and state = 'free';
  if not found then
    raise exception 'seat_taken' using hint = 'Somebody else has that seat.';
  end if;

  -- Only now let the old one go.
  update trip_seats set state = 'free', booking_id = null, held_until = null, updated_at = now()
   where trip_id = v_old_trip and seat_no = v_old_seat and booking_id = v_booking;

  update passengers
     set trip_id = p_trip, seat_no = p_seat, fare_kobo = v_new_fare,
         status = case when status = 'checked_in' then 'confirmed' else status end,
         checked_in_at = null
   where id = p_passenger;

  insert into audit_log (tenant_id, actor_type, actor_id, action, entity, entity_id, detail)
  select v_tenant, case when p_staff is null then 'system' else 'staff' end, p_staff,
         'passenger.moved', 'passenger', p_passenger,
         jsonb_build_object('booking', b.reference, 'from_seat', v_old_seat, 'to_seat', p_seat,
                            'same_trip', p_trip = v_old_trip,
                            'fare_change_kobo', v_new_fare - v_old_fare)
    from bookings b where b.id = v_booking;

  return jsonb_build_object(
    'moved', true,
    'booking', v_booking,
    'from_seat', v_old_seat, 'to_seat', p_seat,
    'same_trip', p_trip = v_old_trip,
    'fare_change_kobo', v_new_fare - v_old_fare);
end;
$$;

-- Cancel or refund a booking.
--
-- release_booking() only frees seats still in 'held' state, which is right for an expiring
-- hold but wrong here: a confirmed booking's seats are 'sold', and cancelling one has to put
-- them back on sale. This frees both states.
--
-- The money is never edited in place. A refund is appended as its own negative payment row,
-- so every report that sums payments nets out automatically and the original sale stays on
-- the record. p_refund_kobo = 0 cancels without paying anything back (an unpaid hold, or a
-- no-show under a no-refund fare).
--
-- Returns the refunded amount in kobo, or raises if the booking is already closed.
create or replace function cancel_booking(
  p_booking     uuid,
  p_status      text,          -- 'cancelled' or 'refunded'
  p_staff       uuid,
  p_refund_kobo integer default 0,
  p_reason      text default null
)
returns integer
language plpgsql
as $$
declare
  v_booking  bookings%rowtype;
  v_paid     integer;
  v_provider text;
  v_channel  text;
begin
  select * into v_booking from bookings where id = p_booking for update;
  if not found then
    raise exception 'no_booking' using errcode = 'P0002';
  end if;
  if v_booking.status in ('cancelled', 'refunded', 'expired') then
    raise exception 'already_closed' using errcode = 'P0001';
  end if;
  if p_status not in ('cancelled', 'refunded') then
    raise exception 'bad_status' using errcode = 'P0001';
  end if;

  -- Never refund more than was actually taken.
  select coalesce(sum(amount_kobo), 0) into v_paid
    from payments where booking_id = p_booking and status = 'success';
  if p_refund_kobo < 0 or p_refund_kobo > v_paid then
    raise exception 'bad_amount' using errcode = 'P0001';
  end if;

  update trip_seats
     set state = 'free', booking_id = null, held_until = null, updated_at = now()
   where booking_id = p_booking and state in ('held', 'sold');

  update passengers set status = 'cancelled'
   where booking_id = p_booking and status <> 'cancelled';

  update bookings
     set status = p_status, cancelled_at = now(), hold_expires_at = null
   where id = p_booking;

  if p_refund_kobo > 0 then
    -- Pay it back the way it came in, so the desk's cash reconciles.
    select provider, channel into v_provider, v_channel
      from payments
     where booking_id = p_booking and status = 'success' and amount_kobo > 0
     order by created_at desc limit 1;

    insert into payments (tenant_id, booking_id, provider, amount_kobo, status, channel, recorded_by, settled_at, raw)
    values (v_booking.tenant_id, p_booking, coalesce(v_provider, 'other'), -p_refund_kobo, 'success',
            coalesce(v_channel, 'refund'), p_staff, now(),
            jsonb_build_object('kind', 'refund', 'reason', p_reason));
  end if;

  return p_refund_kobo;
end;
$$;

-- One terminal's day, for the close-out sheet the desk prints and hands over with the cash.
-- p_terminal null = every terminal. p_staff null = the whole desk rather than one person.
create or replace function closeout_summary(
  p_tenant   uuid,
  p_date     date,
  p_terminal uuid default null,
  p_staff    uuid default null
)
returns jsonb
language sql
stable
as $$
  with pay as (
    select p.amount_kobo, p.channel, p.provider, p.recorded_by, b.channel as booking_channel
      from payments p
      join bookings b on b.id = p.booking_id
     where p.tenant_id = p_tenant
       and p.status = 'success'
       and p.created_at >= p_date::timestamptz
       and p.created_at <  (p_date + 1)::timestamptz
       and (p_staff is null or p.recorded_by = p_staff)
       and (p_terminal is null or exists (
             select 1 from passengers pa join trips tr on tr.id = pa.trip_id
                      join routes r on r.id = tr.route_id
              where pa.booking_id = b.id and r.from_terminal = p_terminal))
  )
  select jsonb_build_object(
    'date', p_date,
    'gross_kobo',   (select coalesce(sum(amount_kobo), 0) from pay where amount_kobo > 0),
    'refunds_kobo', (select coalesce(abs(sum(amount_kobo)), 0) from pay where amount_kobo < 0),
    'net_kobo',     (select coalesce(sum(amount_kobo), 0) from pay),
    'sales',        (select count(*) from pay where amount_kobo > 0),
    'refund_count', (select count(*) from pay where amount_kobo < 0),
    'by_method',    (select coalesce(jsonb_object_agg(k, v), '{}'::jsonb)
                       from (select coalesce(channel, provider) as k, sum(amount_kobo) as v
                               from pay group by 1) m),
    'by_source',    (select coalesce(jsonb_object_agg(k, v), '{}'::jsonb)
                       from (select booking_channel as k, sum(amount_kobo) as v
                               from pay group by 1) c),
    'seats_sold',   (select count(*) from passengers pa
                       join trips tr on tr.id = pa.trip_id
                      where tr.tenant_id = p_tenant and tr.depart_date = p_date
                        and pa.status <> 'cancelled'),
    'cancelled',    (select count(*) from bookings
                      where tenant_id = p_tenant and status in ('cancelled','refunded')
                        and cancelled_at >= p_date::timestamptz
                        and cancelled_at <  (p_date + 1)::timestamptz)
  );
$$;

-- Materialise trip rows from each route's operating days and departure times.
--
-- This lives in the schema, not the seed, because it has to run every day: the seed's one-shot
-- call only covered 30 days, after which the site quietly runs out of bookable dates. Safe to
-- call repeatedly -- existing departures are left alone (on conflict do nothing), so it only
-- ever extends the far edge of the window.
--
-- Each route takes the vehicle already assigned to its most recent trip, so a manager's vehicle
-- choice carries forward; otherwise the first active vehicle. Returns the number created.
create or replace function generate_trips(p_tenant_slug text, p_days integer default 30)
returns integer
language plpgsql
as $$
declare
  v_tenant uuid;
  v_route  record;
  v_day    date;
  v_time   time;
  v_trip   uuid;
  v_veh    record;
  v_made   integer := 0;
begin
  select id into v_tenant from tenants where slug = p_tenant_slug;
  if v_tenant is null then raise exception 'unknown tenant %', p_tenant_slug; end if;

  for v_route in select * from routes where tenant_id = v_tenant and active loop
    select v.* into v_veh
      from vehicles v
     where v.tenant_id = v_tenant and v.status = 'active'
     order by (v.id = (select t.vehicle_id from trips t
                        where t.route_id = v_route.id and t.vehicle_id is not null
                        order by t.depart_date desc limit 1)) desc,
              v.capacity desc
     limit 1;
    continue when v_veh is null;

    v_day := current_date;
    while v_day < current_date + p_days loop
      if extract(dow from v_day)::smallint = any(v_route.operating_days) then
        foreach v_time in array v_route.departures loop
          insert into trips (tenant_id, route_id, vehicle_id, depart_date, depart_time, capacity, fare_kobo)
          values (v_tenant, v_route.id, v_veh.id, v_day, v_time, v_veh.capacity, v_route.fare_kobo)
          on conflict (tenant_id, route_id, depart_date, depart_time) do nothing
          returning id into v_trip;

          if v_trip is not null then
            insert into trip_seats (trip_id, seat_no)
            select v_trip, generate_series(1, v_veh.capacity)::smallint;
            v_made := v_made + 1;
          end if;
          v_trip := null;
        end loop;
      end if;
      v_day := v_day + 1;
    end loop;
  end loop;
  return v_made;
end;
$$;

-- Cancelling a departure. Refuses while anyone holds a paid seat: those passengers have to be
-- refunded (and told) first, which is a decision for a person, not a cascade.
create or replace function cancel_trip(p_trip uuid, p_staff uuid, p_reason text default null)
returns integer
language plpgsql
as $$
declare v_sold integer;
begin
  select count(*) into v_sold from trip_seats where trip_id = p_trip and state = 'sold';
  if v_sold > 0 then
    raise exception 'has_passengers' using errcode = 'P0001';
  end if;

  update trip_seats set state = 'blocked', booking_id = null, held_until = null, updated_at = now()
   where trip_id = p_trip and state in ('free', 'held');
  update trips set status = 'cancelled' where id = p_trip;
  return v_sold;
end;
$$;

-- Sweep expired holds. Call from a scheduled job (pg_cron or a Vercel cron hitting an endpoint).
create or replace function expire_holds()
returns integer
language plpgsql
as $$
declare v_count integer;
begin
  with dead as (
    select id from bookings
     where status = 'pending' and hold_expires_at is not null and hold_expires_at < now()
     for update skip locked
  )
  select count(*) into v_count from dead;

  update trip_seats ts
     set state = 'free', booking_id = null, held_until = null, updated_at = now()
    from bookings b
   where ts.booking_id = b.id and ts.state = 'held'
     and b.status = 'pending' and b.hold_expires_at < now();

  -- The passenger rows have to be retired too. Without this the seat is free in trip_seats
  -- but still spoken for in passengers, and the next customer to pick it gets a duplicate key.
  update passengers p
     set status = 'cancelled'
    from bookings b
   where p.booking_id = b.id and p.status in ('reserved', 'confirmed')
     and b.status = 'pending' and b.hold_expires_at is not null and b.hold_expires_at < now();

  -- A travel credit applied to a booking that was never finished goes back to its owner. Without
  -- this, a customer who started paying with a credit and walked away lost the credit for good.
  update payments pay
     set status = 'reversed'
    from bookings b
   where pay.booking_id = b.id and pay.channel = 'coupon' and pay.status = 'success'
     and b.status = 'pending' and b.hold_expires_at is not null and b.hold_expires_at < now();
  update coupons c
     set redeemed_at = null, booking_id = null
    from bookings b
   where c.booking_id = b.id
     and b.status = 'pending' and b.hold_expires_at is not null and b.hold_expires_at < now();

  update bookings
     set status = 'expired', hold_expires_at = null
   where status = 'pending' and hold_expires_at is not null and hold_expires_at < now();

  return coalesce(v_count, 0);
end;
$$;

-- ============================================================================
-- ROW LEVEL SECURITY
-- The API uses the service role and scopes every query by tenant itself. RLS is the second
-- line: even a leaked anon key cannot read another operator's data, or any customer data.
-- ============================================================================
alter table tenants      enable row level security;
alter table customers    enable row level security;
alter table staff        enable row level security;
alter table terminals    enable row level security;
alter table vehicles     enable row level security;
alter table drivers      enable row level security;
alter table routes       enable row level security;
alter table trips        enable row level security;
alter table bookings     enable row level security;
alter table trip_seats   enable row level security;
alter table passengers   enable row level security;
alter table payments     enable row level security;
alter table refunds      enable row level security;
alter table expenses     enable row level security;
alter table audit_log    enable row level security;
alter table webhook_events enable row level security;

-- Staff may read their own tenant's operational data.
-- Dropped first so this file can be re-run safely (create policy has no IF NOT EXISTS).
drop policy if exists staff_reads_own_tenant on trips;
create policy staff_reads_own_tenant on trips for select
  using (tenant_id in (select tenant_id from staff where auth_user_id = auth.uid() and active));

drop policy if exists staff_reads_bookings on bookings;
create policy staff_reads_bookings on bookings for select
  using (tenant_id in (select tenant_id from staff where auth_user_id = auth.uid() and active));

-- Money is for managers and accountants only.
drop policy if exists finance_reads_payments on payments;
create policy finance_reads_payments on payments for select
  using (tenant_id in (
    select tenant_id from staff
     where auth_user_id = auth.uid() and active and role in ('manager','accountant')
  ));

-- No anon policies anywhere: the public site reaches data only through the API.

-- ============================================================================
-- SCHEDULED HOLD EXPIRY (runs inside Postgres, no external cron needed)
-- Supabase: Database -> Extensions -> enable "pg_cron", then run this block once.
-- Vercel's Hobby plan only allows daily crons, so the sweep lives here instead.
-- ============================================================================
-- create extension if not exists pg_cron;
-- select cron.schedule('expire-holds', '*/2 * * * *', $$select expire_holds();$$);
--
-- Keep the departure calendar rolling (run once a day at 02:00):
-- select cron.schedule('generate-trips', '0 2 * * *', $$select generate_trips('ace-trail', 30);$$);
--
-- To inspect or remove:
-- select * from cron.job;
-- select cron.unschedule('expire-holds');

-- ============================================================================
-- EMAIL SIGN-IN LINKS (magic links)
-- One row per link issued. `used_at` makes a link single-use: a forwarded or replayed
-- link cannot sign anyone in twice.
-- ============================================================================
create table if not exists login_tokens (
  id          uuid primary key default gen_random_uuid(),
  tenant_id   uuid references tenants(id) on delete cascade,
  jti         text not null unique,
  email       text not null,
  expires_at  timestamptz not null,
  used_at     timestamptz,
  requested_ip text,
  created_at  timestamptz not null default now()
);
create index if not exists login_tokens_email_idx on login_tokens (lower(email), created_at desc);
alter table login_tokens enable row level security;

-- Housekeeping: drop links older than a day (schedule with pg_cron if you like).
-- select cron.schedule('purge-login-tokens', '0 3 * * *',
--   $$delete from login_tokens where created_at < now() - interval '1 day';$$);

-- ============================================================================
-- STAFF ACCOUNTS
-- People sign in with Supabase Auth (email + password). The `staff` row links that
-- auth user to a tenant, a role and -- for desk staff -- a terminal.
--
-- To add someone:
--   1. Supabase dashboard -> Authentication -> Users -> Add user (email + password,
--      tick "Auto Confirm User").
--   2. Copy their User UID, then:
--        insert into staff (tenant_id, auth_user_id, name, email, role, terminal_id)
--        select t.id, '<UID>', 'Aniekan Udo', 'aniekan@yourbrand.com', 'terminal', term.id
--          from tenants t, terminals term
--         where t.slug = 'ace-trail' and term.code = 'uyo';
--      Roles: manager, terminal, accountant, driver. terminal_id may be null for
--      managers and accountants.
-- ============================================================================

-- Link desk staff to their terminal properly (the column existed without the constraint).
do $$
begin
  if not exists (select 1 from pg_constraint where conname = 'staff_terminal_fk') then
    alter table staff add constraint staff_terminal_fk
      foreign key (terminal_id) references terminals(id) on delete set null;
  end if;
end $$;

create index if not exists staff_auth_idx on staff (auth_user_id) where active;

-- Check-in and boarding, recorded against the person who did it.
create or replace function mark_passenger(p_passenger uuid, p_status text, p_staff uuid)
returns void
language plpgsql
as $$
begin
  if p_status not in ('checked_in','boarded','no_show','confirmed') then
    raise exception 'bad_status';
  end if;
  update passengers
     set status = p_status,
         checked_in_at = case when p_status = 'checked_in' then now() else checked_in_at end,
         boarded_at    = case when p_status = 'boarded'    then now() else boarded_at end
   where id = p_passenger;

  insert into audit_log (tenant_id, actor_type, actor_id, action, entity, entity_id, detail)
  -- The seat and the passenger's name go in the entry, not just the reference: "passenger
  -- boarded ATX-UP1409-1BRX" three times in a row tells the manager nothing about which
  -- three people boarded.
  select b.tenant_id, 'staff', p_staff, 'passenger.' || p_status, 'passenger', p_passenger,
         jsonb_build_object('booking', b.reference, 'seat', p.seat_no, 'passenger', p.full_name)
    from passengers p join bookings b on b.id = p.booking_id
   where p.id = p_passenger;
end;
$$;

-- Trip lifecycle, driven by the driver's screen.
create or replace function set_trip_status(p_trip uuid, p_status text, p_staff uuid)
returns void
language plpgsql
as $$
begin
  if p_status not in ('scheduled','boarding','departed','arrived','completed','cancelled') then
    raise exception 'bad_status';
  end if;
  update trips
     set status = p_status,
         departed_at = case when p_status = 'departed' then coalesce(departed_at, now()) else departed_at end,
         arrived_at  = case when p_status in ('arrived','completed') then coalesce(arrived_at, now()) else arrived_at end
   where id = p_trip;

  insert into audit_log (tenant_id, actor_type, actor_id, action, entity, entity_id, detail)
  select tenant_id, 'staff', p_staff, 'trip.' || p_status, 'trip', id, jsonb_build_object('status', p_status)
    from trips where id = p_trip;
end;
$$;

-- One call for the manager's control tower: today's operations at a glance.
create or replace function ops_summary(p_tenant uuid, p_date date)
returns jsonb
language plpgsql
as $$
declare v jsonb;
begin
  select jsonb_build_object(
    'date', p_date,
    'trips', (select count(*) from trips where tenant_id = p_tenant and depart_date = p_date and status <> 'cancelled'),
    'seats_total', (select coalesce(sum(capacity),0) from trips where tenant_id = p_tenant and depart_date = p_date and status <> 'cancelled'),
    'seats_sold', (select count(*) from trip_seats ts join trips t on t.id = ts.trip_id
                    where t.tenant_id = p_tenant and t.depart_date = p_date and ts.state = 'sold'),
    'seats_held', (select count(*) from trip_seats ts join trips t on t.id = ts.trip_id
                    where t.tenant_id = p_tenant and t.depart_date = p_date and ts.state = 'held'),
    'revenue_kobo', (select coalesce(sum(p.amount_kobo),0) from payments p
                      join bookings b on b.id = p.booking_id
                      join passengers pa on pa.booking_id = b.id
                      join trips t on t.id = pa.trip_id
                     where p.tenant_id = p_tenant and p.status = 'success' and t.depart_date = p_date
                       and pa.seat_no = (select min(seat_no) from passengers where booking_id = b.id)),
    'pending', (select count(*) from bookings where tenant_id = p_tenant and status = 'pending'),
    'checked_in', (select count(*) from passengers pa join trips t on t.id = pa.trip_id
                    where t.tenant_id = p_tenant and t.depart_date = p_date and pa.status in ('checked_in','boarded')),
    'no_shows', (select count(*) from passengers pa join trips t on t.id = pa.trip_id
                  where t.tenant_id = p_tenant and t.depart_date = p_date and pa.status = 'no_show')
  ) into v;
  return v;
end;
$$;

-- ============================================================================
-- HARDENING (September 2026 audit)
-- Everything below is additive and safe to re-run. It must stay LAST in this file: it refers
-- to tables and functions defined above, and the lock-down at the end has to see all of them.
-- ============================================================================

-- ---------------------------------------------------------------- webhook processing state
-- An event row used to mean "seen", and a retry of a delivery that crashed half-way was
-- answered "duplicate" and dropped — a paid booking left unconfirmed forever. Now the row means
-- "received" and processed_at means "done"; only a done event is skipped.
alter table webhook_events add column if not exists processed_at timestamptz;

-- ---------------------------------------------------------------- money that needs a person
-- Set when money arrived for a booking that could not be honoured (the hold lapsed and a seat
-- was resold, or the booking had been cancelled). The staff dashboard raises it until handled.
alter table payments add column if not exists needs_attention text;
alter table payments add column if not exists attention_handled_at timestamptz;
create index if not exists payments_attention_idx on payments (tenant_id)
  where needs_attention is not null and attention_handled_at is null;

-- ---------------------------------------------------------------- customer emails, lowercased
-- "My bookings" now matches the signed-in address exactly (it was ilike, where '_' is a
-- wildcard and one customer could see another's bookings). New bookings store it lowercased;
-- this brings older rows in line. Touches nothing that is already lowercase, so re-runs are free.
update bookings set contact_email = lower(contact_email)
 where contact_email is not null and contact_email <> lower(contact_email);

-- ---------------------------------------------------------------- rate limits
-- One row per request against a limited key. rate_hit() takes an advisory lock on the key, so
-- two instances counting the same caller at the same instant cannot both slip under the limit.
create table if not exists rate_hits (
  key  text not null,
  at   timestamptz not null default now()
);
create index if not exists rate_hits_key_at_idx on rate_hits (key, at desc);

create or replace function rate_hit(p_key text, p_max integer, p_window_secs integer)
returns boolean
language plpgsql
as $$
declare v_count integer;
begin
  perform pg_advisory_xact_lock(hashtext(p_key));
  delete from rate_hits where key = p_key and at < now() - make_interval(secs => p_window_secs);
  select count(*) into v_count from rate_hits where key = p_key;
  if v_count >= p_max then
    return true;                          -- over the limit; this attempt is not counted
  end if;
  insert into rate_hits (key) values (p_key);
  -- Keys that stop being used are never revisited by the delete above; sweep them now and then.
  if random() < 0.01 then
    delete from rate_hits where at < now() - interval '2 days';
  end if;
  return false;
end;
$$;

-- For guessing attacks only the misses matter: a passenger whose tracking page re-checks their
-- own booking every 30 seconds must never be locked out. rate_blocked() only looks; rate_note()
-- records a miss.
create or replace function rate_blocked(p_key text, p_max integer, p_window_secs integer)
returns boolean
language sql stable
as $$
  select count(*) >= p_max from rate_hits
   where key = p_key and at > now() - make_interval(secs => p_window_secs);
$$;

create or replace function rate_note(p_key text)
returns void
language sql
as $$
  insert into rate_hits (key) values (p_key);
$$;

-- ---------------------------------------------------------------- customers cancelling online
-- The customer confirms from a link emailed to the booking's address. Seats go back on sale at
-- once; any refund due under the published policy becomes a pending refunds row that a manager
-- or the accountant pays out and then marks as paid. Nothing here moves money.
create or replace function customer_cancel(p_booking uuid, p_refund_kobo integer, p_reason text)
returns text
language plpgsql
as $$
declare
  v      bookings%rowtype;
  v_cash integer;
begin
  select * into v from bookings where id = p_booking for update;
  if not found then return 'missing'; end if;
  if v.status in ('cancelled', 'refunded', 'expired') then return 'already'; end if;
  if exists (select 1 from passengers where booking_id = p_booking and status in ('checked_in', 'boarded', 'no_show')) then
    return 'checked_in';
  end if;

  -- Credits are not cash: only what was actually paid can come back.
  select coalesce(sum(amount_kobo), 0) into v_cash
    from payments where booking_id = p_booking and status = 'success' and coalesce(channel, '') <> 'coupon';
  if p_refund_kobo < 0 or p_refund_kobo > v_cash then raise exception 'bad_amount'; end if;

  update trip_seats set state = 'free', booking_id = null, held_until = null, updated_at = now()
   where booking_id = p_booking and state in ('held', 'sold');
  update passengers set status = 'cancelled' where booking_id = p_booking and status <> 'cancelled';

  -- An unfinished booking gives its credit back; a paid trip has spent it.
  if v.status = 'pending' then
    update payments set status = 'reversed' where booking_id = p_booking and channel = 'coupon' and status = 'success';
    update coupons set redeemed_at = null, booking_id = null where booking_id = p_booking;
  end if;

  update bookings set status = 'cancelled', cancelled_at = now(), hold_expires_at = null where id = p_booking;

  if p_refund_kobo > 0 then
    insert into refunds (tenant_id, booking_id, amount_kobo, reason, status)
    values (v.tenant_id, p_booking, p_refund_kobo, p_reason, 'pending');
  end if;
  return 'cancelled';
end;
$$;

-- Closing a pending refund. 'paid' records the money going back as a negative payment on the
-- same provider and channel it came in on (so the desk's cash reconciles, exactly as the staff
-- refund action does) and marks the booking refunded. 'rejected' closes it with no money moved.
alter table refunds add column if not exists decided_at timestamptz;
alter table refunds add column if not exists note text;
create index if not exists refunds_pending_idx on refunds (tenant_id) where status = 'pending';

create or replace function process_refund(p_refund uuid, p_staff uuid, p_paid boolean, p_note text)
returns text
language plpgsql
as $$
declare
  r          refunds%rowtype;
  v_provider text;
  v_channel  text;
begin
  select * into r from refunds where id = p_refund for update;
  if not found then return 'missing'; end if;
  if r.status <> 'pending' then return 'already'; end if;

  if p_paid then
    select provider, channel into v_provider, v_channel
      from payments
     where booking_id = r.booking_id and status = 'success' and amount_kobo > 0 and coalesce(channel, '') <> 'coupon'
     order by created_at desc limit 1;
    insert into payments (tenant_id, booking_id, provider, amount_kobo, status, channel, recorded_by, settled_at, raw)
    values (r.tenant_id, r.booking_id, coalesce(v_provider, 'other'), -r.amount_kobo, 'success',
            coalesce(v_channel, 'refund'), p_staff, now(),
            jsonb_build_object('kind', 'refund', 'reason', r.reason, 'note', p_note, 'refund_id', r.id));
    update bookings set status = 'refunded' where id = r.booking_id and status = 'cancelled';
  end if;

  update refunds
     set status = case when p_paid then 'processed' else 'rejected' end,
         approved_by = p_staff, decided_at = now(), note = p_note
   where id = p_refund;
  return case when p_paid then 'processed' else 'rejected' end;
end;
$$;

-- ---------------------------------------------------------------- operational alerts
-- Things going wrong that someone should hear about without reading logs: a payment taken
-- with no seat, the webhook failing, card payments not confirming, holds not expiring, the
-- assistant down. One open row per problem (key); repeats bump the count. The function says
-- whether to email now, so a problem that recurs every minute sends one email an hour.
create table if not exists ops_alerts (
  id          uuid primary key default gen_random_uuid(),
  tenant_id   uuid not null references tenants(id) on delete cascade,
  key         text not null,
  severity    text not null default 'warning' check (severity in ('info','warning','urgent')),
  title       text not null,
  detail      jsonb,
  count       integer not null default 1,
  first_at    timestamptz not null default now(),
  last_at     timestamptz not null default now(),
  emailed_at  timestamptz,
  resolved_at timestamptz,
  resolved_by text
);
create unique index if not exists ops_alerts_open_idx on ops_alerts (tenant_id, key) where resolved_at is null;
alter table ops_alerts enable row level security;

create or replace function raise_ops_alert(p_tenant uuid, p_key text, p_severity text, p_title text,
                                           p_detail jsonb, p_email_every_min integer default 60)
returns boolean
language plpgsql
as $$
declare r ops_alerts%rowtype;
begin
  select * into r from ops_alerts where tenant_id = p_tenant and key = p_key and resolved_at is null for update;
  if not found then
    insert into ops_alerts (tenant_id, key, severity, title, detail, emailed_at)
    values (p_tenant, p_key, p_severity, p_title, p_detail, now());
    return true;
  end if;
  update ops_alerts set count = count + 1, last_at = now(), title = p_title, detail = p_detail,
         severity = case when p_severity = 'urgent' then 'urgent' else severity end,
         emailed_at = case when emailed_at is null or emailed_at < now() - make_interval(mins => p_email_every_min) then now() else emailed_at end
   where id = r.id;
  return r.emailed_at is null or r.emailed_at < now() - make_interval(mins => p_email_every_min);
end;
$$;

-- A health check that passes closes its alert, so the dashboard shows what is wrong now.
create or replace function resolve_ops_alert(p_tenant uuid, p_key text, p_by text default 'health check')
returns integer
language sql
as $$
  with u as (update ops_alerts set resolved_at = now(), resolved_by = p_by
              where tenant_id = p_tenant and key = p_key and resolved_at is null returning 1)
  select count(*)::int from u;
$$;

-- ---------------------------------------------------------------- bookings claimed into an account
-- The account shows bookings made with its email. A booking made at a terminal, or with a
-- different address, can be added by proving the reference and phone number.
create table if not exists booking_claims (
  id          uuid primary key default gen_random_uuid(),
  tenant_id   uuid not null references tenants(id) on delete cascade,
  email       text not null,
  booking_id  uuid not null references bookings(id) on delete cascade,
  created_at  timestamptz not null default now(),
  unique (tenant_id, email, booking_id)
);
alter table booking_claims enable row level security;

revoke execute on function raise_ops_alert(uuid, text, text, text, jsonb, integer) from public, anon, authenticated;
revoke execute on function resolve_ops_alert(uuid, text, text) from public, anon, authenticated;
revoke execute on function customer_cancel(uuid, integer, text) from public, anon, authenticated;
revoke execute on function process_refund(uuid, uuid, boolean, text) from public, anon, authenticated;

-- ---------------------------------------------------------------- row level security, the rest
-- Eight tables were created after the RLS block above and never had it switched on. With RLS
-- off, the anon key reads and writes them freely — including trip_locations (where vehicles are)
-- and auth_attempts (who tried to sign in, from where). No policies: only the API reaches them.
alter table auth_attempts      enable row level security;
alter table coupons            enable row level security;
alter table feedback           enable row level security;
alter table loyalty_ledger     enable row level security;
alter table notification_reads enable row level security;
alter table notifications      enable row level security;
alter table payment_proofs     enable row level security;
alter table trip_locations     enable row level security;
alter table rate_hits          enable row level security;

-- ---------------------------------------------------------------- functions: API only
-- PostgREST exposes every function in the public schema as /rest/v1/rpc/<name>, and Postgres
-- grants EXECUTE to PUBLIC by default. With the anon key, anyone could call confirm_booking on
-- their own unpaid booking. Only the service role (the API) may call them now.
-- Wrapped in a check so this file still applies to a plain Postgres with no Supabase roles.
do $$
declare r text;
begin
  execute 'revoke execute on all functions in schema public from public';
  foreach r in array array['anon', 'authenticated'] loop
    if exists (select 1 from pg_roles where rolname = r) then
      execute format('revoke execute on all functions in schema public from %I', r);
      execute format('alter default privileges in schema public revoke execute on functions from %I', r);
    end if;
  end loop;
  execute 'alter default privileges in schema public revoke execute on functions from public';
  if exists (select 1 from pg_roles where rolname = 'service_role') then
    execute 'grant execute on all functions in schema public to service_role';
    execute 'alter default privileges in schema public grant execute on functions to service_role';
  end if;
end $$;
