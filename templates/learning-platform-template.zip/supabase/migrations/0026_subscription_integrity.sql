-- =====================================================================
-- Subscription integrity.
--
-- WHY: fulfilment runs from two places on purpose — the webhook and the
-- payment return page — so that a misconfigured webhook cannot mean
-- money-taken-nothing-unlocked. Those two fire within a second or two of
-- each other on a normal successful payment, because Flutterwave posts
-- the webhook at the same moment it redirects the browser back.
--
-- activate_subscription() claimed to be idempotent, but its idempotency
-- was a read-then-write with nothing serialising it:
--
--     select id from subscriptions where provider_ref = ...  -- neither sees the other
--     if found then return; end if;
--     update subscriptions set status = 'cancelled' ...      -- both cancel
--     insert into subscriptions (... 'active' ...)           -- BOTH insert
--
-- Under concurrency both callers miss the guard and both insert, so the
-- learner ends up with TWO active rows for one payment. hasAccess() then
-- reads that with .maybeSingle(), which errors on more than one row and
-- returns null — so the paying customer is told they have no plan.
--
-- Paid, charged, no access. That is the reported bug.
--
-- Three layers of fix, because one is not enough:
--   1. A transaction-level advisory lock per user, so two activations for
--      the same learner serialise instead of interleaving.
--   2. Unique indexes, so the guarantee is enforced by the database and
--      not by the correctness of one function.
--   3. on conflict handling, so the indexes never surface to a customer
--      as a 500 on the payment return page.
--
-- Existing bad rows are cleaned up first — the indexes cannot be created
-- while duplicates are sitting in the table.
-- =====================================================================

-- ---------------------------------------------------------------------
-- 1. Remove true duplicates: more than one row for the same payment.
--    Keep the active one, else the longest-running, else the lowest id.
-- ---------------------------------------------------------------------
with ranked as (
  select id,
         row_number() over (
           partition by provider, provider_ref
           order by (status = 'active') desc, current_period_end desc, id
         ) as rn
    from subscriptions
)
delete from subscriptions s
 using ranked r
 where s.id = r.id
   and r.rn > 1;

-- ---------------------------------------------------------------------
-- 2. Collapse any remaining multiple-active rows per learner. These are
--    not duplicate payments, so they are cancelled rather than deleted —
--    the payment history stays intact.
-- ---------------------------------------------------------------------
with ranked as (
  select id,
         row_number() over (
           partition by user_id
           order by current_period_end desc, current_period_start desc, id
         ) as rn
    from subscriptions
   where status = 'active'
)
update subscriptions s
   set status = 'cancelled',
       cancelled_at = coalesce(s.cancelled_at, now())
  from ranked r
 where s.id = r.id
   and r.rn > 1;

-- ---------------------------------------------------------------------
-- 3. Untouched duplicate allowances from the same race. Only rows with
--    nothing spent against them are removed, so no learner loses a
--    certification they already used or paid extra for.
-- ---------------------------------------------------------------------
with ranked as (
  select id,
         row_number() over (
           partition by user_id, date_trunc('minute', period_start)
           order by used desc, purchased desc, id
         ) as rn
    from cert_allowances
)
delete from cert_allowances c
 using ranked r
 where c.id = r.id
   and r.rn > 1
   and c.used = 0
   and c.purchased = 0;

-- ---------------------------------------------------------------------
-- 4. Make the guarantees real.
-- ---------------------------------------------------------------------

-- One subscription row per provider payment. This is what actually makes
-- webhook retries safe; the function's select was only ever advisory.
create unique index if not exists subscriptions_provider_ref_key
  on subscriptions (provider, provider_ref);

-- One active subscription per learner, which is what the rest of the app
-- already assumes when it reads with .maybeSingle().
create unique index if not exists subscriptions_one_active_per_user
  on subscriptions (user_id)
  where status = 'active';

-- ---------------------------------------------------------------------
-- 5. Activation, serialised.
--
-- Signature is unchanged, so create or replace is safe here (no 42P13).
-- ---------------------------------------------------------------------
create or replace function activate_subscription(
  p_user_id      uuid,
  p_plan         plan_tier,
  p_provider     text,
  p_provider_ref text,
  p_cycle        text default 'monthly'
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_id       uuid;
  v_start    timestamptz := now();
  v_end      timestamptz;
  v_included int := plan_allowance(p_plan);
begin
  -- Everything below is per-learner. Held until the transaction ends, so
  -- the webhook and the return page take turns instead of racing. Other
  -- learners are unaffected — the lock key is the user id.
  perform pg_advisory_xact_lock(hashtextextended(p_user_id::text, 0));

  -- Already recorded this exact payment: do nothing and return it.
  select id into v_id from subscriptions
   where provider = p_provider and provider_ref = p_provider_ref;
  if found then return v_id; end if;

  v_end := case when p_cycle = 'annual'
                then v_start + interval '1 year'
                else v_start + interval '1 month' end;

  -- One active subscription per learner. A renewal or plan change
  -- supersedes rather than stacks. Runs before the insert so the partial
  -- unique index above is satisfied within this transaction.
  update subscriptions
     set status = 'cancelled', cancelled_at = now()
   where user_id = p_user_id and status = 'active';

  insert into subscriptions (
    user_id, plan, provider, provider_ref, status,
    current_period_start, current_period_end
  )
  values (p_user_id, p_plan, p_provider, p_provider_ref, 'active', v_start, v_end)
  on conflict (provider, provider_ref) do nothing
  returning id into v_id;

  -- Lost the insert to a caller outside this lock (should not happen now,
  -- but the index is the authority, not the lock). Return what is there
  -- and grant no second allowance.
  if v_id is null then
    select id into v_id from subscriptions
     where provider = p_provider and provider_ref = p_provider_ref;
    return v_id;
  end if;

  -- The allowance runs with the billing period. Certifications do not
  -- roll over, which is why a fresh row is created rather than topped up.
  -- Reached only when a subscription row was genuinely inserted, so one
  -- payment can never provision two allowances.
  insert into cert_allowances (user_id, period_start, period_end, included)
  values (p_user_id, v_start, v_end, v_included);

  return v_id;
end;
$$;

revoke all on function activate_subscription(uuid, plan_tier, text, text, text)
  from public, anon, authenticated;
grant execute on function activate_subscription(uuid, plan_tier, text, text, text)
  to service_role;

comment on function activate_subscription(uuid, plan_tier, text, text, text) is
  'Idempotent on (provider, provider_ref). Safe to call concurrently from '
  'the webhook and the payment return page for the same transaction.';
