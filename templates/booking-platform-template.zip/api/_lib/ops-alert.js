/**
 * Telling a person when something is going wrong.
 *
 *   opsAlert('payment:stranded:ATX-…', { severity: 'urgent', title, detail, everyMin })
 *
 * Writes (or bumps) one open row in ops_alerts — shown on the staff dashboard — and emails the
 * managers when the database says it is time: at once for a new problem, then at most once per
 * `everyMin` while it keeps happening. Recipients: ALERT_EMAIL (comma-separated) if set,
 * otherwise every active manager.
 *
 * It never throws. An alert that fails must not turn a payment webhook or a booking into an
 * error of its own; the failure is logged and the caller carries on.
 */
import { select, rpc, tenant } from './db.js';

const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export async function opsAlert(key, { severity = 'warning', title, detail = {}, everyMin = 60 } = {}) {
  try {
    const t = await tenant();
    const sendNow = await rpc('raise_ops_alert', { p_tenant: t.id, p_key: String(key).slice(0, 200),
      p_severity: severity, p_title: String(title || key).slice(0, 300), p_detail: detail, p_email_every_min: everyMin });
    if (sendNow) await emailManagers(t, { severity, title, detail, key });
    return true;
  } catch (err) {
    console.error('ops alert could not be raised:', key, err.message);
    return false;
  }
}

export async function resolveAlert(key) {
  try { const t = await tenant(); return await rpc('resolve_ops_alert', { p_tenant: t.id, p_key: key, p_by: 'health check' }); }
  catch (err) { console.error('could not resolve alert', key, err.message); return 0; }
}

async function emailManagers(t, { severity, title, detail, key }) {
  const apiKey = process.env.RESEND_API_KEY, from = process.env.TICKET_FROM;
  if (!apiKey || !from) { console.error('alert not emailed (email not configured):', title); return; }
  let to = String(process.env.ALERT_EMAIL || '').split(',').map(x => x.trim()).filter(Boolean);
  if (!to.length) {
    const managers = await select('staff', `tenant_id=eq.${t.id}&role=eq.manager&active=is.true&archived_at=is.null&select=email`).catch(() =>
      select('staff', `tenant_id=eq.${t.id}&role=eq.manager&active=is.true&select=email`));
    to = managers.map(m => m.email).filter(Boolean);
  }
  if (!to.length) { console.error('alert not emailed (no manager email):', title); return; }
  const site = (process.env.SITE_URL || '').replace(/\/$/, '');
  const rows = Object.entries(detail || {}).filter(([, v]) => v !== null && v !== undefined && v !== '')
    .map(([k, v]) => `<tr><td style="padding:4px 12px 4px 0;color:#6b7280;vertical-align:top">${esc(k.replace(/_/g, ' '))}</td><td style="padding:4px 0">${esc(typeof v === 'object' ? JSON.stringify(v) : v)}</td></tr>`).join('');
  const colour = severity === 'urgent' ? '#B3261E' : severity === 'warning' ? '#B45F06' : '#0E4D33';
  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST', headers: { Authorization: `Bearer ${apiKey}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ from, to, subject: `${severity === 'urgent' ? '[URGENT] ' : ''}Your Brand: ${title}`,
      html: `<div style="font-family:system-ui,Arial,sans-serif;max-width:560px;margin:0 auto;padding:24px;color:#15171c">
        <p style="margin:0 0 6px;font-weight:700;color:${colour}">${severity === 'urgent' ? 'Needs action now' : severity === 'warning' ? 'Needs a look' : 'For information'}</p>
        <h1 style="font-size:20px;margin:0 0 14px">${esc(title)}</h1>
        ${rows ? `<table style="font-size:14px;border-collapse:collapse;margin:0 0 18px">${rows}</table>` : ''}
        ${site ? `<p><a href="${esc(site)}/staff" style="background:#15171c;color:#fff;text-decoration:none;padding:12px 20px;border-radius:10px;font-weight:700;display:inline-block">Open the dashboard</a></p>` : ''}
        <p style="font-size:12px;color:#6b7280;margin-top:20px">If this keeps happening you will get at most one email an hour about it. It stays on the dashboard until it is fixed or marked as dealt with. (${esc(key)})</p></div>` })
  });
  if (!res.ok) console.error('alert email rejected', res.status);
}
