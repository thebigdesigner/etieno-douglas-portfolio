"use client";

import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import SearchSuggest from "@/components/SearchSuggest";

type Option = { value: string; count?: string };

const LEVELS: Option[] = [
  { value: "Any level" },
  { value: "Beginner" },
  { value: "Intermediate" },
  { value: "Advanced" },
];

const SUBJECTS: Option[] = [
  { value: "Any subject" },
  { value: "Artificial Intelligence" },
  { value: "Entrepreneurship" },
  { value: "Technology" },
  { value: "Business Skills" },
  { value: "Creative" },
  { value: "Career" },
];

function Chevron() {
  return (
    <svg className="sel__chev" viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <path d="M5.5 8L10 12.5L14.5 8" stroke="currentColor" strokeWidth="1.8"
        strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function Tick() {
  return (
    <svg className="sel__tick" viewBox="0 0 20 20" fill="none" aria-hidden="true">
      <path d="M4.5 10.5L8 14L15.5 6" stroke="currentColor" strokeWidth="2.2"
        strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function Select({
  id, label, options, value, onChange, align = "left",
}: {
  id: string;
  label: string;
  options: Option[];
  value: string;
  onChange: (v: string) => void;
  align?: "left" | "right";
}) {
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(0);
  const root = useRef<HTMLDivElement>(null);
  const btn = useRef<HTMLButtonElement>(null);

  useEffect(() => {
    if (!open) return;
    const close = (e: MouseEvent) => {
      if (root.current && !root.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("click", close);
    return () => document.removeEventListener("click", close);
  }, [open]);

  useEffect(() => {
    if (open) setActive(Math.max(0, options.findIndex((o) => o.value === value)));
  }, [open, options, value]);

  const pick = (i: number) => {
    onChange(options[i].value);
    setOpen(false);
    btn.current?.focus();
  };

  const onKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === "Escape") {
      if (open) { e.preventDefault(); setOpen(false); btn.current?.focus(); }
      return;
    }
    if (!open) {
      if (e.key === "ArrowDown" || e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        setOpen(true);
      }
      return;
    }
    if (e.key === "ArrowDown") { e.preventDefault(); setActive((a) => (a + 1) % options.length); }
    else if (e.key === "ArrowUp") { e.preventDefault(); setActive((a) => (a - 1 + options.length) % options.length); }
    else if (e.key === "Home") { e.preventDefault(); setActive(0); }
    else if (e.key === "End") { e.preventDefault(); setActive(options.length - 1); }
    else if (e.key === "Enter" || e.key === " ") { e.preventDefault(); pick(active); }
  };

  return (
    <div className="sel" data-open={open} data-select={id} ref={root} onKeyDown={onKeyDown}>
      <span className="search__label" id={`${id}-lab`}>{label}</span>
      <button
        type="button" className="sel__btn" id={id} ref={btn}
        aria-haspopup="listbox" aria-expanded={open}
        aria-labelledby={`${id}-lab ${id}-val`}
        onClick={(e) => { e.stopPropagation(); setOpen((o) => !o); }}
      >
        <span className="sel__val" id={`${id}-val`}>{value}</span>
        <Chevron />
      </button>

      <div
        className="sel__panel" role="listbox" aria-labelledby={`${id}-lab`} tabIndex={-1}
        style={align === "right" ? { left: "auto", right: -6, transformOrigin: "top right" } : undefined}
      >
        {options.map((o, i) => (
          <div key={o.value}>
            <button
              type="button" className="sel__opt" role="option"
              aria-selected={o.value === value}
              data-active={i === active ? "true" : undefined}
              onClick={(e) => { e.stopPropagation(); pick(i); }}
              onMouseEnter={() => setActive(i)}
            >
              <span className="sel__label">{o.value}</span>
              {o.count && <span className="sel__count num">{o.count}</span>}
              <Tick />
            </button>
            {i === 0 && <div className="sel__sep" />}
          </div>
        ))}
      </div>
    </div>
  );
}

export default function SubjectSearch() {
  const router = useRouter();
  const [subject, setSubject] = useState(SUBJECTS[0].value);
  const [level, setLevel] = useState(LEVELS[0].value);

  const search = () => {
    const params = new URLSearchParams();
    if (subject !== SUBJECTS[0].value) params.set("subject", subject);
    if (level !== LEVELS[0].value) params.set("level", level.toLowerCase());
    const qs = params.toString();
    router.push(qs ? `/courses?${qs}` : "/courses");
  };

  // The two dropdowns narrow; they do not let anybody say what they want.
  // Somebody arriving with "financial modelling" in mind had nowhere to type
  // it on the home page at all.
  const extra = () => {
    const params = new URLSearchParams();
    if (subject !== SUBJECTS[0].value) params.set("subject", subject);
    if (level !== LEVELS[0].value) params.set("level", level.toLowerCase());
    return params;
  };

  return (
    <div className="search search--q" role="search">
      <SearchSuggest
        className="search__q"
        placeholder="What do you want to learn?"
        onSubmitExtra={extra}
      />
      <Select id="subject" label="Subject" options={SUBJECTS} value={subject} onChange={setSubject} />
      <Select id="level" label="Level" options={LEVELS} value={level} onChange={setLevel} align="right" />
      <div className="search__go">
        <button className="btn btn--fill btn--lg" onClick={search}>Search</button>
      </div>
    </div>
  );
}
