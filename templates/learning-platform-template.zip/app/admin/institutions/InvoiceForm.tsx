"use client";
import { useActionState } from "react";
import { issueInvoice } from "@/app/actions/institution";
import type { FormState } from "@/lib/forms";
import SubmitButton from "@/components/SubmitButton";
import Alert from "@/components/Alert";

const initial: FormState = {};

export default function InvoiceForm({ institutionId }: { institutionId: string }) {
  const [state, action] = useActionState(issueInvoice.bind(null, institutionId), initial);
  const lastMonth = new Date();
  lastMonth.setMonth(lastMonth.getMonth() - 1);

  return (
    <form action={action} className="ctools__inline" style={{ marginTop: 16 }}>
      <label className="field">
        <span className="field__label">Invoice month</span>
        <input name="month" type="month" defaultValue={lastMonth.toISOString().slice(0, 7)} required />
      </label>
      <SubmitButton>Generate</SubmitButton>
      {state.error && <Alert kind="error">{state.error}</Alert>}
      {state.ok && <Alert kind="success">{state.message}</Alert>}
    </form>
  );
}
