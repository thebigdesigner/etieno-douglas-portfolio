/**
 * Shared form-action result shape.
 *
 * Lives outside the "use server" modules because those may only export
 * async functions.
 */
export type FormState = { error?: string; ok?: boolean; message?: string };
