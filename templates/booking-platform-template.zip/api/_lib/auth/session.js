/** Signed session cookies. Shared by customer sign-in and the terminal desk. */
import crypto from 'crypto';

const b64u = buf => Buffer.from(buf).toString('base64url');

export function sign(payload, secret) {
  const body = b64u(JSON.stringify(payload));
  const mac = crypto.createHmac('sha256', secret).update(body).digest('base64url');
  return `${body}.${mac}`;
}

export function verify(token, secret) {
  if (typeof token !== 'string' || !token.includes('.')) return null;
  const [body, mac] = token.split('.');
  const expect = crypto.createHmac('sha256', secret).update(body).digest('base64url');
  const a = Buffer.from(mac || ''), b = Buffer.from(expect);
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) return null;
  try {
    const data = JSON.parse(Buffer.from(body, 'base64url').toString());
    if (!data.exp || data.exp < Math.floor(Date.now() / 1000)) return null;
    return data;
  } catch { return null; }
}

/**
 * The signed-in customer, or null.
 *
 * One secret signs several kinds of token — customer sessions, staff sessions, one-time
 * sign-in links, staff email confirmations — so a valid signature alone says nothing about
 * what the token is for. A magic-link token pasted into the session cookie used to be
 * accepted, which let a forwarded link be replayed after it had been "used". Customer
 * sessions now carry kind 'customer'; sessions issued before that carry no kind and are still
 * honoured until they expire. Every other kind is refused.
 */
export function customerFrom(req, secret) {
  if (!secret) return null;
  const raw = (req.headers.cookie || '').split(';').map(c => c.trim()).find(c => c.startsWith('atx_session='));
  const claims = raw ? verify(raw.slice('atx_session='.length), secret) : null;
  if (!claims || !claims.email) return null;
  if (claims.kind !== undefined && claims.kind !== 'customer') return null;
  return claims;
}
