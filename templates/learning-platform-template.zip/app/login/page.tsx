import Link from "next/link";
import AuthShell from "@/components/AuthShell";
import OAuthButtons from "@/components/OAuthButtons";
import LoginForm from "./LoginForm";
import { safeNext } from "@/lib/safe-next";
import Alert from "@/components/Alert";

export const metadata = { title: "Log in" };

type SearchParams = Promise<{ error?: string; next?: string }>;

const ERRORS: Record<string, string> = {
  oauth: "We could not complete that sign-in. Try again, or use your email and password.",
  verification: "That link has expired or has already been used. Try logging in below.",
  suspended: "This account is suspended. Contact support if you think that is wrong.",
  deleted:
    "That account was deleted at its owner's request, so it cannot be reopened. If this is you and you want to come back, create a new account — it will start fresh.",
  deleted_ok: "Your account is closed. Thank you for the time you spent with us.",
};

export default async function LoginPage({ searchParams }: { searchParams: SearchParams }) {
  const { error, next } = await searchParams;
  const message = ERRORS[error ?? ""];

  return (
    <AuthShell
      title="Welcome back"
      footer={
        <>
          <Link href="/forgot">Forgotten your password?</Link>
          <br />
          New here? <Link href="/signup">Create an account</Link>
          <br />
          Joining with a class code? <Link href="/join">Use your username</Link>
        </>
      }
    >
      {message && <Alert kind="error">{message}</Alert>}
      <LoginForm next={safeNext(next) ?? undefined} />
      <OAuthButtons />
    </AuthShell>
  );
}
