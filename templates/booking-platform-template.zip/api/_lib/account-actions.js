/**
 * Things a signed-in customer does to their account, as opposed to a single booking:
 *
 *   claim         add a booking made at a terminal or with another email — proved by reference
 *                 and phone, exactly as Find my booking is, sharing its wrong-guess limit
 *   export        everything held about this email, as a JSON file (Nigeria Data Protection
 *                 Act: the right of access and to data portability)
 *   data-request  ask for the account to be deleted or corrected. Goes to the office as a
 *                 message; bookings and payments are kept for as long as accounting law needs
 */
import { select, insert, tenant, audit, fail, lookupBlocked, lookupMissed } from './db.js';
import { customerFrom } from './auth/session.js';

const REF = /^[A-Z]{2,5}-[A-Z0-9]{4,10}(-[A-Z0-9]{2,6})?$/;
const last7 = s => String(s || '').replace(/\D/g, '').slice(-7);

function signedIn(req, res) {
  const secret = process.env.SESSION_SECRET;
  const user = secret ? customerFrom(req, secret) : null;
  if (!user || !user.email) { fail(res, 401, 'signed_out', 'Sign in to do that'); return null; }
  return { email: String(user.email).trim().toLowerCase(), name: user.name || '' };
}

export async function claimBooking(req, res) {
  const user = signedIn(req, res); if (!user) return;
  const ref = String(req.body?.reference || '').toUpperCase().replace(/\s+/g, ''), phone = String(req.body?.phone || '');
  if (!REF.test(ref)) return fail(res, 400, 'bad_reference', 'Check the reference — it looks like ATX-UP2209-1JC62');
  if (last7(phone).length < 7) return fail(res, 400, 'bad_phone', 'Enter the phone number the booking was made with');
  if (await lookupBlocked(req, phone)) return fail(res, 429, 'too_many', 'Too many attempts. Please wait a few minutes.');
  const t = await tenant();
  const rows = await select('bookings', `tenant_id=eq.${t.id}&reference=eq.${ref}&select=id,reference,contact_phone,contact_email`);
  if (!rows.length || last7(rows[0].contact_phone) !== last7(phone)) {
    await lookupMissed(req, phone);
    return fail(res, 404, 'not_found', 'No booking found for that reference and phone number');
  }
  const b = rows[0];
  if (String(b.contact_email || '').toLowerCase() === user.email) return res.status(200).json({ ok: true, already: true, reference: b.reference });
  try { await insert('booking_claims', [{ tenant_id: t.id, email: user.email, booking_id: b.id }], 'return=minimal'); }
  catch (err) { if (!/duplicate|23505/.test(String(err.message) + JSON.stringify(err.details || ''))) throw err; }
  await audit({ tenant_id: t.id, actor_type: 'customer', action: 'booking.claimed', entity: 'booking', entity_id: b.id, detail: { email: user.email } });
  return res.status(200).json({ ok: true, reference: b.reference });
}

export async function exportMyData(req, res) {
  const user = signedIn(req, res); if (!user) return;
  const t = await tenant();
  const e = encodeURIComponent(user.email);
  const like = encodeURIComponent(user.email.replace(/[\\%_]/g, m => '\\' + m));
  const claims = await select('booking_claims', `tenant_id=eq.${t.id}&email=eq.${e}&select=booking_id,created_at`).catch(() => []);
  const F = '&select=reference,status,channel,created_at,cancelled_at,contact_name,contact_phone,contact_email,kin_name,kin_phone,total_kobo,' +
    'passengers(full_name,pax_type,seat_no,status,fare_kobo,trip:trips(depart_date,depart_time)),payments(status,amount_kobo,channel,created_at,settled_at),refunds(status,amount_kobo,created_at,decided_at)';
  const own = await select('bookings', `tenant_id=eq.${t.id}&contact_email=eq.${e}${F}&order=created_at.desc&limit=1000`);
  const extra = claims.length ? await select('bookings', `tenant_id=eq.${t.id}&id=in.(${claims.map(c => c.booking_id).join(',')})${F}`) : [];
  const [ledger, coupons, messages] = await Promise.all([
    select('loyalty_ledger', `tenant_id=eq.${t.id}&customer_email=ilike.${like}&select=points,reason,note,created_at&order=created_at.desc`),
    select('coupons', `tenant_id=eq.${t.id}&customer_email=ilike.${like}&select=code,value_kobo,issued_at,expires_at,redeemed_at`),
    select('feedback', `tenant_id=eq.${t.id}&email=ilike.${like}&select=topic,message,reference,created_at,handled_at`).catch(() => [])
  ]);
  const kobo = o => JSON.parse(JSON.stringify(o, (k, v) => (/_kobo$/.test(k) && typeof v === 'number') ? undefined : v));
  const naira = rows => rows.map(r => {
    const out = kobo(r);
    for (const [k, v] of Object.entries(r)) if (/_kobo$/.test(k)) out[k.replace(/_kobo$/, '_naira')] = v / 100;
    return out;
  });
  const walk = b => ({ ...naira([b])[0], passengers: naira(b.passengers || []), payments: naira(b.payments || []), refunds: naira(b.refunds || []) });
  const data = {
    exported_at: new Date().toISOString(), company: t.name || 'Your Brand', account_email: user.email, account_name: user.name,
    note: 'Everything Your Brand holds that is linked to this email address. Bookings made with a different email or at a terminal appear only if you added them to your account.',
    bookings: [...own, ...extra].map(walk),
    bookings_added_to_account: claims,
    trail_points: naira(ledger), travel_credits: naira(coupons), messages_you_sent: messages
  };
  await audit({ tenant_id: t.id, actor_type: 'customer', action: 'account.exported', entity: 'account', entity_id: null, detail: { email: user.email } });
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="ace-trail-my-data-${new Date().toISOString().slice(0, 10)}.json"`);
  res.setHeader('Cache-Control', 'no-store');
  return res.status(200).end(JSON.stringify(data, null, 2));
}

export async function dataRequest(req, res) {
  const user = signedIn(req, res); if (!user) return;
  const kind = req.body?.kind === 'correct' ? 'correct' : req.body?.kind === 'delete' ? 'delete' : null;
  if (!kind) return fail(res, 400, 'bad_request', 'Delete or correct?');
  const details = String(req.body?.details || '').trim().slice(0, 1000);
  const t = await tenant();
  await insert('feedback', [{ tenant_id: t.id, name: user.name || user.email, email: user.email, topic: 'something else',
    message: kind === 'delete'
      ? `DATA REQUEST — DELETE ACCOUNT. ${user.email} asked for their account and personal data to be deleted. Remove their Trail points and unused credits and anonymise their details; keep booking and payment records only as long as the law requires for accounting.${details ? `\n\nTheir note: ${details}` : ''}`
      : `DATA REQUEST — CORRECTION. ${user.email} asked for their details to be corrected:\n\n${details || '(no details given)'}` }], 'return=minimal');
  await audit({ tenant_id: t.id, actor_type: 'customer', action: `account.${kind}_requested`, entity: 'account', entity_id: null, detail: { email: user.email } });
  return res.status(200).json({ ok: true });
}
