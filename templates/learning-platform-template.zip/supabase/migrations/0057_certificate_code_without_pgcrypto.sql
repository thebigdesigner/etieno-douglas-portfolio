-- =====================================================================
-- 0057 — certificate codes do not depend on pgcrypto
--
-- Every path that issues a certificate built its code like this:
--
--   'SPL-' || upper(substr(encode(gen_random_bytes(6), 'hex'), 1, 4)) ...
--
-- gen_random_bytes belongs to pgcrypto. All three functions are
-- `security definer set search_path = public`, and on Supabase pgcrypto
-- is pre-installed in the `extensions` schema — so 0001's
-- `create extension if not exists pgcrypto` was a no-op, the extension
-- was never in public, and the function could not see the call.
--
-- The result, in production: any attempt to pass a project threw
-- 42883 undefined_function, the action reported "Could not save your
-- review", and NO CERTIFICATE HAS EVER BEEN ISSUABLE. Three paths, all
-- broken the same way, all silent:
--
--   record_review           an assessed certificate on a pass
--   resolve_appeal          an assessed certificate on an upheld appeal
--   issue_exam_certificate  an examined certificate
--
-- It never showed in development because a local `create extension`
-- installs pgcrypto into public, where search_path finds it. The
-- environments disagreed and only production was wrong — and only on
-- the branch that mints a code, which is the one branch nobody had
-- reached yet.
--
-- The fix removes the dependency rather than widening the search_path.
-- gen_random_uuid() is in pg_catalog and needs no extension, so it is
-- visible whatever the search_path is set to. Codes keep exactly the
-- same shape: SPL-XXXX-XXXX, drawn from hex.
-- =====================================================================

create or replace function public.new_certificate_code()
returns text
language sql
volatile
set search_path = public
as $$
  select 'SPL-'
      || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 4))
      || '-'
      || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 4));
$$;

comment on function public.new_certificate_code() is
  'Certificate code. Uses gen_random_uuid() from pg_catalog rather than pgcrypto''s gen_random_bytes, which is not on the search_path of a security-definer function on Supabase — see 0057.';

grant execute on function public.new_certificate_code() to service_role;

create or replace function public.record_review(p_submission_id uuid, p_reviewer_id uuid, p_outcome review_outcome, p_feedback text, p_scores jsonb)
returns TABLE(certificate_code text, error text)
language plpgsql security definer set search_path = public as $BODY$
declare
  v_sub       submissions%rowtype;
  v_enrolment enrolments%rowtype;
  v_profile   profiles%rowtype;
  v_reviewer  text;
  v_code      text;
  v_in_sla    boolean;
begin
  select * into v_sub from submissions where id = p_submission_id for update;
  if not found then
    return query select null::text, 'not_found'::text; return;
  end if;
  if v_sub.state in ('passed','abandoned') then
    return query select null::text, 'already_decided'::text; return;
  end if;

  v_in_sla := now() <= v_sub.deadline_at;

  insert into reviews (submission_id, reviewer_id, outcome, feedback, scores, within_sla)
  values (p_submission_id, p_reviewer_id, p_outcome, p_feedback, p_scores, v_in_sla);

  select * into v_enrolment from enrolments where id = v_sub.enrolment_id;
  select * into v_profile   from profiles   where id = v_enrolment.user_id;

  select coalesce(pr.display_name, 'Your Brand reviewer') into v_reviewer
    from profiles pr where pr.id = p_reviewer_id;

  -- $18.85 per assessed project, credited on completion rather than enrolment.
  insert into earnings_entries (instructor_id, type, amount_cents, ref_id, note)
  values (p_reviewer_id, 'review', 1885, p_submission_id, 'Project assessment');

  if p_outcome = 'pass' then
    update submissions set state = 'passed' where id = p_submission_id;
    update enrolments  set state = 'certified' where id = v_enrolment.id;

    v_code := new_certificate_code();

    insert into certificates (enrolment_id, code, reviewer_name, show_name)
    values (
      v_enrolment.id, v_code, v_reviewer,
      not coalesce(v_profile.minor_protections, false)
    );

    return query select v_code, null::text;
  else
    update submissions set state = 'revision_requested' where id = p_submission_id;
    update enrolments  set state = 'topics_complete' where id = v_enrolment.id;
    return query select null::text, null::text;
  end if;
end;

$BODY$;

create or replace function public.resolve_appeal(p_appeal_id uuid, p_reviewer_id uuid, p_outcome review_outcome, p_feedback text)
returns TABLE(ok boolean, certificate_code text, reason text)
language plpgsql security definer set search_path = public as $BODY$
declare
  v_appeal    appeals%rowtype;
  v_sub       submissions%rowtype;
  v_enrolment enrolments%rowtype;
  v_profile   profiles%rowtype;
  v_reviewer  text;
  v_code      text;
begin
  select * into v_appeal from appeals where id = p_appeal_id for update;
  if not found then return query select false, null::text, 'not_found'; return; end if;
  if v_appeal.resolved_at is not null then
    return query select false, null::text, 'already_resolved'; return;
  end if;
  if v_appeal.second_reviewer_id is distinct from p_reviewer_id then
    return query select false, null::text, 'not_assigned'; return;
  end if;

  update appeals
     set outcome = p_outcome, feedback = p_feedback,
         decided_by = p_reviewer_id, resolved_at = now()
   where id = p_appeal_id;

  -- The appeal reviewer is paid the same as any other assessment.
  insert into earnings_entries (instructor_id, type, amount_cents, ref_id, note)
  values (p_reviewer_id, 'review', 1885, v_appeal.submission_id, 'Appeal assessment');

  if p_outcome = 'revise' then
    return query select true, null::text, null::text; return;
  end if;

  -- Overturned. Issue the certificate the first verdict withheld.
  select * into v_sub from submissions where id = v_appeal.submission_id;
  select * into v_enrolment from enrolments where id = v_sub.enrolment_id;
  select * into v_profile from profiles where id = v_enrolment.user_id;
  select coalesce(pr.display_name, 'Your Brand reviewer') into v_reviewer
    from profiles pr where pr.id = p_reviewer_id;

  update submissions set state = 'passed' where id = v_appeal.submission_id;
  update enrolments  set state = 'certified' where id = v_enrolment.id;

  v_code := new_certificate_code();

  insert into certificates (enrolment_id, code, reviewer_name, show_name)
  values (v_enrolment.id, v_code, v_reviewer,
          not coalesce(v_profile.minor_protections, false));

  return query select true, v_code, null::text;
end; 
$BODY$;

create or replace function public.issue_exam_certificate(p_user_id uuid, p_course_id uuid)
returns TABLE(code text, error text)
language plpgsql security definer set search_path = public as $BODY$
declare
  v_enrolment  enrolments%rowtype;
  v_profile    profiles%rowtype;
  v_course     courses%rowtype;
  v_allowance  cert_allowances%rowtype;
  v_topics_left int;
  v_passed     boolean;
  v_code       text;
begin
  select * into v_course from courses where id = p_course_id;
  if not found then
    return query select null::text, 'no_course'::text; return;
  end if;

  if v_course.requires_project then
    return query select null::text, 'project_required'::text; return;
  end if;

  select * into v_enrolment
    from enrolments where user_id = p_user_id and course_id = p_course_id;
  if not found then
    return query select null::text, 'not_enrolled'::text; return;
  end if;

  -- Already issued. Hand back the existing code rather than minting a
  -- second one — a double submit must not cost a second allowance.
  select c.code into v_code
    from certificates c
   where c.enrolment_id = v_enrolment.id and c.revoked_at is null
   limit 1;
  if v_code is not null then
    return query select v_code, null::text; return;
  end if;

  select count(*) into v_topics_left
    from topics t join modules m on m.id = t.module_id
   where m.course_id = p_course_id
     and t.id not in (
       select tc.topic_id from topic_completions tc where tc.enrolment_id = v_enrolment.id);

  if v_topics_left > 0 then
    return query select null::text, 'topics_incomplete'::text; return;
  end if;

  select coalesce(bool_or(passed), false) into v_passed
    from exam_attempts where enrolment_id = v_enrolment.id;

  if not v_passed then
    return query select null::text, 'exam_not_passed'::text; return;
  end if;

  -- Cohort learners are covered by their institution, exactly as on the
  -- project path.
  if v_enrolment.source <> 'cohort' then
    select * into v_allowance
      from cert_allowances
     where user_id = p_user_id
       and now() between period_start and period_end
     order by period_end desc
     limit 1;

    if not found then
      return query select null::text, 'no_plan'::text; return;
    end if;
    if v_allowance.used >= (v_allowance.included + v_allowance.purchased) then
      return query select null::text, 'allowance_spent'::text; return;
    end if;

    update cert_allowances set used = used + 1 where id = v_allowance.id;
  end if;

  select * into v_profile from profiles where id = p_user_id;

  v_code := new_certificate_code();

  insert into certificates (enrolment_id, code, reviewer_name, show_name, kind)
  values (
    v_enrolment.id, v_code, '',
    not coalesce(v_profile.minor_protections, false),
    'examined'
  );

  update enrolments set state = 'certified' where id = v_enrolment.id;

  return query select v_code, null::text;
end;

$BODY$;

