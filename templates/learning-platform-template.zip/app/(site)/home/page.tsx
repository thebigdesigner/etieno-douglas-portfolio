import MarketingHome from "@/components/MarketingHome";

export const dynamic = "force-dynamic";
export const metadata = { title: "Your Brand" };

/** The marketing page, reachable whether or not you are signed in. */
export default function MarketingPage() {
  return <MarketingHome />;
}
