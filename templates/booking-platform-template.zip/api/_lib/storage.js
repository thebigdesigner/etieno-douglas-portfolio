/**
 * Supabase Storage, for receipt photographs.
 *
 * Three decisions worth knowing:
 *
 *   1. The image never passes through our functions. The browser is given a one-time signed URL
 *      and uploads straight to Supabase. A serverless function has a request body limit and a
 *      time limit, and a photograph taken on a modern phone will meet both; more to the point,
 *      an endpoint that accepts arbitrary bytes is an endpoint somebody will try to abuse.
 *
 *   2. The bucket is private. Reading an image needs a short-lived signed URL minted for a
 *      member of staff who has already been through the role gate. A bank receipt carries an
 *      account number and a name; it is not something to leave on a public URL because the path
 *      is hard to guess.
 *
 *   3. Paths are opaque and namespaced by tenant: <tenant>/<booking>/<uuid>.<ext>. No reference
 *      numbers, no phone numbers, nothing that reads as a customer identifier in a URL.
 */
const BUCKET = 'receipts';

const base = () => (process.env.SUPABASE_URL || '').replace(/\/$/, '');
const key = () => process.env.SUPABASE_SERVICE_ROLE_KEY || '';

export function storageConfigured() {
  return Boolean(base() && key());
}

async function call(path, options = {}) {
  const res = await fetch(`${base()}/storage/v1${path}`, {
    ...options,
    headers: {
      Authorization: `Bearer ${key()}`,
      apikey: key(),
      'Content-Type': 'application/json',
      ...(options.headers || {})
    }
  });
  const text = await res.text();
  if (!res.ok) {
    const err = new Error(`storage ${res.status}: ${text.slice(0, 200)}`);
    err.status = res.status;
    throw err;
  }
  return text ? JSON.parse(text) : null;
}

/**
 * Create the bucket if it is not there. Called lazily on first upload so a fresh deployment
 * works without anybody remembering a console step — the same reasoning as the schema being
 * re-runnable.
 */
export async function ensureBucket() {
  try {
    await call(`/bucket/${BUCKET}`, { method: 'GET' });
    return true;
  } catch (err) {
    if (err.status !== 404) throw err;
  }
  await call('/bucket', {
    method: 'POST',
    body: JSON.stringify({
      id: BUCKET, name: BUCKET, public: false,
      file_size_limit: 8 * 1024 * 1024,
      allowed_mime_types: ['image/jpeg', 'image/png', 'image/webp', 'image/heic', 'application/pdf']
    })
  });
  return true;
}

/** A one-time URL the browser can PUT a single file to. */
export async function signedUpload(path) {
  await ensureBucket();
  const out = await call(`/object/upload/sign/${BUCKET}/${path}`, {
    method: 'POST',
    body: JSON.stringify({ expiresIn: 600 })
  });
  /* Supabase returns a path with the token on it; give the browser the whole URL so it has one
     thing to use and no way to assemble it wrongly. */
  return { url: `${base()}/storage/v1${out.url.startsWith('/') ? '' : '/'}${out.url}`, path };
}

/** A short-lived URL for a member of staff to look at one receipt. */
export async function signedView(path, seconds = 300) {
  const out = await call(`/object/sign/${BUCKET}/${path}`, {
    method: 'POST',
    body: JSON.stringify({ expiresIn: seconds })
  });
  return `${base()}/storage/v1${out.signedURL.startsWith('/') ? '' : '/'}${out.signedURL}`;
}

export async function removeObject(path) {
  try { await call(`/object/${BUCKET}/${path}`, { method: 'DELETE' }); }
  catch (err) { console.error('receipt delete failed:', err.message); }
}
