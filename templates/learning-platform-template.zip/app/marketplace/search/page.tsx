import type { Metadata } from "next";
import Browse, { type RawParams } from "@/components/marketplace/Browse";
import { marketBase } from "@/lib/marketplace/url";

type Props = { searchParams: Promise<RawParams> };

export async function generateMetadata({ searchParams }: Props): Promise<Metadata> {
  const q = (await searchParams).q;
  const term = Array.isArray(q) ? q[0] : q;
  return { title: term ? `“${term}”` : "Search", robots: { index: false } };
}

export default async function SearchPage({ searchParams }: Props) {
  const [sp, base] = await Promise.all([searchParams, marketBase()]);
  const q = (Array.isArray(sp.q) ? sp.q[0] : sp.q)?.trim();
  return <Browse base={base} params={sp} title={q ? `Results for “${q}”` : "Search the marketplace"} />;
}
