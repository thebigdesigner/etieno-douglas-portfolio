import { siteUrl } from "@/lib/site";
import { marketBase, mk } from "@/lib/marketplace/url";

/**
 * The absolute address of a marketplace page, for links that leave the
 * site and come back: email confirmation, password reset, Google sign-in.
 *
 * They must return to the host the sign-in started on. Supabase keeps a
 * one-time verifier cookie there, and the callback cannot finish without
 * it. On the subdomain that is marketplace.yourbrand.com; when the shop is
 * served at yourbrand.com/marketplace (local dev, previews) it is the site.
 */
export async function marketOrigin(): Promise<string> {
  const base = await marketBase();
  return base === "" ? (process.env.MARKETPLACE_URL ?? "https://marketplace.yourbrand.com").replace(/\/$/, "") : siteUrl();
}

/** Callback URL that lands on a marketplace page once the session exists. */
export async function marketCallback(path: string): Promise<string> {
  // The callback redirects to siteUrl() + next, and the middleware then
  // sends /marketplace/... on the main domain to the subdomain — so next
  // is always the long form, whichever host we are on.
  const next = `/marketplace${path === "/" ? "" : path}`;
  return `${await marketOrigin()}/auth/callback?next=${encodeURIComponent(next)}`;
}

export { mk };
