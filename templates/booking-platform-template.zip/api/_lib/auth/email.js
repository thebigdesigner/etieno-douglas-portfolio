/**
 * POST /api/auth/email  { email }
 * Sends a one-time sign-in link. No passwords anywhere: nothing to store, nothing to reset.
 *
 * The link carries a token signed with SESSION_SECRET and recorded in login_tokens, so it
 * expires after 15 minutes and can be used once. The response is deliberately the same whether
 * or not the address exists — this endpoint must not reveal who has an account.
 *
 * Needs: SESSION_SECRET, SITE_URL, RESEND_API_KEY, TICKET_FROM, and the database.
 */
import crypto from 'crypto';
import { configured, insert, select, tenant, fail, limited, clientIp } from '../db.js';
import { sign } from './session.js';

const LINK_MINUTES = 15;
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function emailHtml(link, minutes) {
  return `<!doctype html><html><body style="margin:0;background:#f4f5f7;padding:28px 12px">
  <table role="presentation" width="100%"><tr><td align="center">
    <table role="presentation" width="480" style="max-width:480px;background:#fff;border-radius:14px;padding:32px">
      <tr><td style="font:700 20px/1.3 Arial,sans-serif;color:#15171c;padding-bottom:12px">Sign in to Your Brand</td></tr>
      <tr><td style="font:400 15px/1.6 Arial,sans-serif;color:#444;padding-bottom:24px">
        Tap the button below to sign in. The link works once and expires in ${minutes} minutes.
      </td></tr>
      <tr><td align="center" style="padding-bottom:24px">
        <a href="${esc(link)}" style="display:inline-block;background:#59ED05;color:#15171c;font:700 15px Arial,sans-serif;text-decoration:none;padding:14px 28px;border-radius:10px">Sign in</a>
      </td></tr>
      <tr><td style="font:400 13px/1.6 Arial,sans-serif;color:#6b7280;border-top:1px solid #e7e9ee;padding-top:16px">
        If you did not ask to sign in, ignore this email — nobody can use the link without it.
      </td></tr>
    </table>
    <div style="font:400 12px Arial,sans-serif;color:#6b7280;padding:16px">Your Brand — first for service</div>
  </td></tr></table></body></html>`;
}

const recent = new Map();                       // per-instance throttle
function tooMany(key, max, windowMs) {
  const now = Date.now();
  const list = (recent.get(key) || []).filter(t => now - t < windowMs);
  list.push(now); recent.set(key, list);
  if (recent.size > 5000) recent.clear();
  return list.length > max;
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return fail(res, 405, 'method', 'POST only');
  const secret = process.env.SESSION_SECRET, key = process.env.RESEND_API_KEY, from = process.env.TICKET_FROM;
  if (!secret || !key || !from || !configured()) return fail(res, 503, 'not_configured', 'Email sign-in is not switched on');

  const email = String(req.body?.email || '').trim().toLowerCase();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 160) return fail(res, 400, 'bad_email', 'Enter a valid email address');

  const ip = clientIp(req);
  /* Counted in the database so the limit survives cold starts: each request sends an email
     from our domain, and an inbox flooded with sign-in links is somebody's harassment. */
  if (tooMany(`ip:${ip}`, 10, 600000) || tooMany(`em:${email}`, 4, 600000) ||
      await limited(`magic:ip:${ip}`, 10, 600) || await limited(`magic:em:${email}`, 4, 600))
    return fail(res, 429, 'too_many', 'Too many sign-in emails. Please wait a few minutes.');

  try {
    const t = await tenant();

    // Don't send repeatedly if a live link already exists.
    const live = await select('login_tokens',
      `tenant_id=eq.${t.id}&email=eq.${encodeURIComponent(email)}&used_at=is.null` +
      `&expires_at=gt.${new Date().toISOString()}&select=id&limit=1`);

    if (!live.length) {
      const jti = crypto.randomUUID();
      const expires = new Date(Date.now() + LINK_MINUTES * 60000);
      await insert('login_tokens', [{ tenant_id: t.id, jti, email, expires_at: expires.toISOString(), requested_ip: ip }], 'return=minimal');

      const token = sign({ jti, email, exp: Math.floor(expires.getTime() / 1000), kind: 'magic' }, secret);
      const link = `${(process.env.SITE_URL || '').replace(/\/$/, '')}/api/auth/verify?t=${encodeURIComponent(token)}`;

      const r = await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ from, to: [email], subject: 'Your Your Brand sign-in link', html: emailHtml(link, LINK_MINUTES) })
      });
      if (!r.ok) throw new Error(`resend ${r.status}`);
    }
    // Same answer either way: never reveal whether an address is known.
    return res.status(200).json({ sent: true });
  } catch (err) {
    console.error('magic link failed:', err.message);
    return fail(res, 502, 'send_failed', 'Could not send the sign-in email');
  }
}
