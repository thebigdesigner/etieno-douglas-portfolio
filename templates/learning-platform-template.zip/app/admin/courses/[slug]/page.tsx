import CourseScreen from "@/app/studio/[slug]/CourseScreen";

export const dynamic = "force-dynamic";
export const metadata = { robots: { index: false, follow: false } };

type Params = Promise<{ slug: string }>;

/**
 * Reading a course that is waiting for a decision, inside the admin shell.
 *
 * The queue used to link straight to /studio/[slug] — the instructor's
 * route, with the Instructor brand, the instructor rail and a "My courses"
 * breadcrumb — to read a course belonging to somebody else. The console
 * had the same problem and it was fixed there by giving the console its
 * own route around the shared screen; this is that fix, for admin.
 *
 * No guard of its own: the admin layout already requires an operator, and
 * CourseScreen re-checks access for the specific course. The state gate
 * still applies, so an in_review course opens read-only — which is what
 * reading before a verdict should be.
 */
export default async function AdminCoursePage({ params }: { params: Params }) {
  const { slug } = await params;
  return <CourseScreen slug={slug} backHref="/admin/courses" backLabel="Courses" />;
}
