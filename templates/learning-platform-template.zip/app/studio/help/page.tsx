import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import NudgeToggle from "./NudgeToggle";

export const metadata = { title: "Help" };
export const dynamic = "force-dynamic";

export default async function StudioHelpPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  const admin = createAdminClient();
  const { data: instructor } = await admin
    .from("instructors").select("nudge, creator_course_done_at").eq("id", user!.id).maybeSingle();

  return (
    <>
        <h1 className="sec__h" style={{ fontSize: 30, marginTop: 34 }}>Help</h1>

        <div className="helpgrid">
          <Link className="helpcard" href="/studio/creator-course">
            <div className="eyebrow">Guide</div>
            <div className="helpcard__h">Making a course people finish</div>
            <p className="helpcard__p">
              Six things, fifteen minutes. The problems that come up in nearly every
              first course.
            </p>
          </Link>

          <Link className="helpcard" href="/teach#rates">
            <div className="eyebrow">Money</div>
            <div className="helpcard__h">What you earn, and when</div>
            <p className="helpcard__p">
              $18.85 per project assessed, the royalty pool, and how to check the
              arithmetic yourself.
            </p>
          </Link>

          <Link className="helpcard" href="/teach#commit">
            <div className="eyebrow">Reviewing</div>
            <div className="helpcard__h">The four working days</div>
            <p className="helpcard__p">
              What the commitment means, and what happens if you cannot make it.
            </p>
          </Link>

          <Link className="helpcard" href="/teach#terms">
            <div className="eyebrow">Terms</div>
            <div className="helpcard__h">What we have committed to</div>
            <p className="helpcard__p">
              Published rates, twelve months of your joining terms, sixty days&rsquo; notice.
            </p>
          </Link>
        </div>

        <section style={{ marginTop: 44 }}>
          <h2 className="sub__h2">Reminders</h2>
          <NudgeToggle
            off={instructor?.nudge === "off"}
            done={!!instructor?.creator_course_done_at}
          />
        </section>

        <p className="studio__hint" style={{ margin: "36px 0 40px" }}>
          Stuck on something not here? <a href="mailto:teach@yourbrand.com">teach@yourbrand.com</a> —
          a person reads every one.
        </p>
      </>
  );
}
