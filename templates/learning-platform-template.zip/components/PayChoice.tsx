"use client";

import { useState } from "react";
import type { ProviderChoice } from "@/lib/payments";

/**
 * Which payment page to send the buyer to. Hidden when only one provider
 * is configured: a choice of one is a decision to make on someone's behalf.
 *
 * Writes to a hidden input so plain form posts work, and calls back for
 * checkouts driven by a button.
 */
export default function PayChoice({ options, name = "provider", onPick, className = "" }: {
  options: ProviderChoice[];
  name?: string;
  onPick?: (id: string) => void;
  className?: string;
}) {
  const [picked, setPicked] = useState(options[0]?.id ?? "");
  if (options.length < 2) return <input type="hidden" name={name} value={picked} />;

  return (
    <fieldset className={`pay ${className}`}>
      <legend className="pay__legend">Pay with</legend>
      {options.map((o) => (
        <label key={o.id} className={`pay__opt${picked === o.id ? " is-on" : ""}`}>
          <input type="radio" name={name} value={o.id} checked={picked === o.id}
            onChange={() => { setPicked(o.id); onPick?.(o.id); }} />
          <span className="pay__txt">
            <span className="pay__name">{o.label}</span>
            <span className="pay__note">{o.note}</span>
          </span>
        </label>
      ))}
    </fieldset>
  );
}
