import { Suspense } from "react";
import Link from "next/link";
import CatalogueFilters from "./CatalogueFilters";
import CourseCard, { type CardCourse } from "@/components/CourseCard";
import { createClient } from "@/lib/supabase/server";

export const dynamic = "force-dynamic";

type SearchParams = Promise<{
  subject?: string; level?: string; free?: string; q?: string;
}>;

export async function generateMetadata({ searchParams }: { searchParams: SearchParams }) {
  const { subject, q } = await searchParams;
  return {
    title: q ? `“${q}”` : subject ? `${subject} courses` : "All courses",
    description:
      "Placeholder description by Aphinity Digital. Describe your platform in one sentence.",
  };
}

export default async function CoursesPage({ searchParams }: { searchParams: SearchParams }) {
  const { subject, level, free, q } = await searchParams;
  const supabase = await createClient();

  let courses: CardCourse[] = [];
  let heading: string;

  if (q) {
    const { data } = await supabase.rpc("search_courses", { p_query: q });
    courses = (data ?? []) as CardCourse[];
    heading = `${courses.length} result${courses.length === 1 ? "" : "s"} for “${q}”`;
  } else {
    let query = supabase.from("course_cards").select("*")
      .order("learners", { ascending: false });

    if (subject) query = query.eq("subject", subject);
    if (level) query = query.eq("level", level);
    if (free === "1") query = query.eq("is_free", true);

    const { data } = await query;
    courses = (data ?? []) as CardCourse[];
    heading = subject ?? "Every course";
  }

  const filtered = !!(subject || level || free || q);

  return (
    <>
      <header className="chero chero--list">
        <div className="wrap">
          <nav className="crumb"><Link href="/">Home</Link> / Courses</nav>
          <h1 className="chero__h" style={{ marginTop: 14 }}>{heading}</h1>
          {!q && (
            <p className="chero__p">
              Every final project is assessed by someone who does that work for a
              living, within four working days.
            </p>
          )}
        </div>
      </header>

      <section className="sec" style={{ paddingTop: 30 }}>
        <div className="wrap">
          {/* A row of dropdowns above the results, not a rail of chips beside
              them. Fixed height whatever is selected, so picking a subject
              does not move the first card. */}
          <Suspense fallback={<div className="fbar" />}>
            <CatalogueFilters />
          </Suspense>

          <div className="cat__main">
          <div className="listhead">
            <span className="num">
              {courses.length} course{courses.length === 1 ? "" : "s"}
            </span>
            {filtered && <Link className="sec__link" href="/courses">Clear everything</Link>}
          </div>

          {courses.length === 0 ? (
            <div className="empty">
              <p className="empty__h">
                {q ? "Nothing matches that" : "Nothing here yet"}
              </p>
              <p className="empty__p">
                {q
                  ? "Try a broader word, or browse by subject. If it is not here yet, that is worth knowing — tell us at hello@yourbrand.com."
                  : "Try a different subject or level, or clear the filters to see everything."}
              </p>
              <Link className="btn btn--line" href="/courses" style={{ marginTop: 20 }}>
                Show everything
              </Link>
            </div>
          ) : (
            <div className="ccards">
              {courses.map((c, i) => (
                <CourseCard key={c.slug} course={c} priority={i < 3} />
              ))}
            </div>
          )}
          </div>
        </div>
      </section>
    </>
  );
}
