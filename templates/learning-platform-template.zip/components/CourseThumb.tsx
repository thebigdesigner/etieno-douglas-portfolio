import Image from "next/image";
import { thumbnailUrl, subjectTint } from "@/lib/media";

/**
 * Falls back to a tinted panel with the subject initials rather than a
 * broken image or an empty box.
 */
export default function CourseThumb({
  path, title, subject, priority = false,
}: {
  path: string | null | undefined;
  title: string;
  subject: string;
  priority?: boolean;
}) {
  const url = thumbnailUrl(path);

  if (!url) {
    return (
      <div className={`thumb thumb--fallback thumb--${subjectTint(subject)}`} aria-hidden="true">
        <span className="thumb__initials">
          {subject.split(" ").map((w) => w[0]).join("").slice(0, 2)}
        </span>
      </div>
    );
  }

  return (
    <div className="thumb">
      <Image
        src={url}
        alt={title}
        fill
        sizes="(max-width: 700px) 100vw, 320px"
        style={{ objectFit: "cover" }}
        priority={priority}
      />
    </div>
  );
}
