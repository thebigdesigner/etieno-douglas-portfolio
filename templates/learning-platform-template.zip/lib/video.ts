/**
 * Where a topic's video comes from.
 *
 * `video_uid` is deliberately loose: it holds whatever identifies the asset
 * for whichever provider is in use. That lets a course author paste a
 * YouTube link during the test phase and switch to a paid CDN later without
 * a data migration — only the value in the column changes.
 *
 * Recognised, in order:
 *   - a full YouTube or Vimeo URL, or a bare 11-character YouTube id
 *   - a path inside the private `videos` Supabase bucket (contains a slash)
 *   - anything else: treated as a Bunny Stream asset id
 */

export type VideoSource =
  | { kind: "iframe"; src: string }
  /** A real file: rendered with <video>, which gives accurate progress. */
  | { kind: "file"; src: string }
  /** In the bucket — the caller must sign it before it can be played. */
  | { kind: "storage"; path: string };

const YT_ID = /^[A-Za-z0-9_-]{11}$/;

export function resolveVideo(videoUid: string | null | undefined): VideoSource | null {
  if (!videoUid) return null;
  const v = videoUid.trim();
  if (!v) return null;

  // YouTube. nocookie host, and modestbranding/rel to keep other people's
  // videos from being suggested at the end of a paid lesson.
  const yt =
    v.match(/(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([A-Za-z0-9_-]{11})/)?.[1]
    ?? (YT_ID.test(v) ? v : null);
  if (yt) {
    return {
      kind: "iframe",
      src: `https://www.youtube-nocookie.com/embed/${yt}?rel=0&modestbranding=1&playsinline=1`,
    };
  }

  const vimeo = v.match(/vimeo\.com\/(?:video\/)?(\d+)/)?.[1];
  if (vimeo) {
    return { kind: "iframe", src: `https://player.vimeo.com/video/${vimeo}?dnt=1` };
  }

  // Any other full URL is used as-is — an mp4 elsewhere, or a provider
  // embed we do not special-case.
  if (/^https?:\/\//.test(v)) {
    return /\.(mp4|webm|mov)(\?|$)/i.test(v) ? { kind: "file", src: v } : { kind: "iframe", src: v };
  }

  // A slash means a path inside the videos bucket.
  if (v.includes("/")) return { kind: "storage", path: v };

  const library = process.env.NEXT_PUBLIC_BUNNY_LIBRARY_ID;
  if (library) {
    return {
      kind: "iframe",
      src: `https://iframe.mediadelivery.net/embed/${library}/${v}?autoplay=false&preload=false`,
    };
  }

  return null;
}

/** Back-compat for any caller still expecting a plain string. */
export function embedUrl(videoUid: string | null): string | null {
  const r = resolveVideo(videoUid);
  return r && r.kind !== "storage" ? r.src : null;
}
