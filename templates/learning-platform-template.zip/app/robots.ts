import type { MetadataRoute } from "next";
import { siteUrl } from "@/lib/site";

export default function robots(): MetadataRoute.Robots {
  const base = siteUrl();
  return {
    rules: [
      {
        userAgent: "*",
        allow: "/",
        // Private surfaces, and anything naming a learner.
        disallow: ["/dashboard", "/learn/", "/auth/", "/join", "/reset", "/forgot", "/verify/", "/review", "/studio", "/admin", "/institution/", "/certificate/", "/console"],
      },
    ],
    sitemap: `${base}/sitemap.xml`,
  };
}
