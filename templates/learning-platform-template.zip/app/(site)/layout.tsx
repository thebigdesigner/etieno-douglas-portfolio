import SiteHeader from "@/components/SiteHeader";
import SiteFooter from "@/components/SiteFooter";
import Assistant from "@/components/Assistant";

/**
 * Wraps every page that should carry site navigation. The parentheses make
 * this a route group — it shapes the layout tree without appearing in URLs,
 * so /courses stays /courses.
 *
 * Deliberately outside this group: the auth screens, which use their own
 * centred card, and /learn, which replaces the nav with a progress bar so a
 * learner mid-lesson is not handed an exit route.
 */
export default function SiteLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <SiteHeader />
      {children}
      <SiteFooter />
      <Assistant />
    </>
  );
}
