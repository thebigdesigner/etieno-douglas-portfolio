"use client";
import { useActionState } from "react";
import { createAccount } from "@/app/actions/auth";
import type { FormState } from "@/lib/forms";
import SubmitButton from "@/components/SubmitButton";
import Alert from "@/components/Alert";

const initial: FormState = {};

/** Each intent asks only what applies to it. */
export default function DetailsForm({
  intent,
}: { intent: "learner" | "instructor" | "institution" }) {
  const [state, action] = useActionState(createAccount, initial);

  const nameHint =
    intent === "instructor"
      ? "This goes on your courses, and on every certificate you sign."
      : intent === "institution"
        ? "Your name, not the organisation's — that comes next."
        : "This is the name that goes on your certificate.";

  return (
    <form action={action} className="auth__form">
      <label className="field">
        <span className="field__label">Your name</span>
        <input name="display_name" autoComplete="name" required />
        <span className="field__hint">{nameHint}</span>
      </label>

      <label className="field">
        <span className="field__label">Email</span>
        <input name="email" type="email" autoComplete="email" required />
        {intent === "institution" && (
          <span className="field__hint">
            Use a work address if you have one — it makes verification quicker.
          </span>
        )}
      </label>

      <label className="field">
        <span className="field__label">Password</span>
        <input name="password" type="password" autoComplete="new-password" minLength={8} required />
        <span className="field__hint">At least 8 characters.</span>
      </label>

      {intent === "instructor" && (
        <label className="field">
          <span className="field__label">What do you do?</span>
          <input name="headline" required minLength={5}
            placeholder="Financial controller at a manufacturing firm" />
          <span className="field__hint">
            Your job, not your teaching. It is what makes the certificate mean something.
          </span>
        </label>
      )}

      {intent === "institution" && (
        <div className="field--flag" style={{ display: "grid", gap: 16 }}>
          <label className="field">
            <span className="field__label">Organisation name</span>
            <input name="org_name" required />
          </label>
          <label className="field">
            <span className="field__label">Country</span>
            <input name="org_country" required placeholder="Where it operates" />
          </label>
          <label className="field">
            <span className="field__label">Website (optional)</span>
            <input name="org_website" type="url" placeholder="https://" />
            <span className="field__hint">Helps us verify you faster.</span>
          </label>
        </div>
      )}

      {state.error && <Alert kind="error">{state.error}</Alert>}

      <SubmitButton>Create account</SubmitButton>

      <p className="auth__fine">
        By creating an account you agree to our{" "}
        <a href="/legal/terms">terms</a> and <a href="/legal/privacy">privacy notice</a>.
      </p>
    </form>
  );
}
