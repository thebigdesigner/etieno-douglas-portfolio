import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import AvailabilityToggle from "./AvailabilityToggle";
import CreatorNudge from "@/components/CreatorNudge";
import { slaLabel } from "@/lib/sla";
import NavIcon from "@/components/NavIcon";
import FilterBar from "@/components/FilterBar";

export const metadata = { title: "Studio" };
export const dynamic = "force-dynamic";

const STATE_LABEL: Record<string, string> = {
  draft: "Draft",
  in_review: "With Your Brand",
  revision_requested: "Changes asked for",
  published: "Live",
  unpublished: "Unpublished",
};

function money(cents: number) {
  return `$${(cents / 100).toFixed(2)}`;
}

type SearchParams = Promise<{ q?: string; state?: string; sort?: string }>;

export default async function StudioPage(
  { searchParams }: { searchParams: SearchParams }
) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const admin = createAdminClient();

  const { data: instructor } = await admin
    .from("instructors")
    .select("available, headline, proposed_course")
    .eq("id", user!.id).maybeSingle();

  // First visit answers the two remaining questions.
  if (instructor && !instructor.proposed_course) redirect("/studio/start");

  const [{ data: overview }, { data: courses }, { data: queue }, { data: recent }, { data: nudge }] =
    await Promise.all([
      admin.from("instructor_overview").select("*").eq("id", user!.id).maybeSingle(),
      admin.from("instructor_course_stats").select("*")
        .eq("instructor_id", user!.id)
        .order("published_at", { ascending: false, nullsFirst: true }),
      admin.from("review_queue_status").select("*")
        .eq("assigned_reviewer_id", user!.id).order("deadline_at").limit(4),
      admin.from("instructor_recent_reviews").select("*")
        .eq("reviewer_id", user!.id).limit(5),
      admin.rpc("should_nudge_creator_course", { p_user_id: user!.id }),
    ]);

  const o = (overview ?? {}) as Record<string, number | boolean | null>;
  const all = courses ?? [];
  /* The course list, filtered.
   *
   * An instructor with three courses does not need this; one with thirty
   * cannot find last month's draft without it. Filtered here rather than in
   * the query because instructor_course_stats is already loaded whole for the
   * counts above — filtering in SQL would mean fetching it twice.
   */
  const { q, state, sort } = await searchParams;

  const needle = (q ?? "").trim().toLowerCase();
  let shown = all.filter((c) =>
    (!needle || (c.title as string).toLowerCase().includes(needle)) &&
    (!state || c.state === state)
  );

  if (sort === "title") {
    shown = [...shown].sort((a, b) => (a.title as string).localeCompare(b.title as string));
  } else if (sort === "enrolments") {
    shown = [...shown].sort((a, b) => Number(b.enrolments ?? 0) - Number(a.enrolments ?? 0));
  }

  const live = all.filter((c) => c.state === "published");
  const drafts = all.filter((c) => c.state === "draft" || c.state === "revision_requested");
  const pending = all.filter((c) => c.state === "in_review");

  const queueTotal = Number(o.queue_total ?? 0);
  const queueLate = Number(o.queue_late ?? 0);
  const queueSoon = Number(o.queue_soon ?? 0);
  const appealsOpen = Number(o.appeals_open ?? 0);
  const returned = Number(o.courses_returned ?? 0);

  // What actually needs doing, most urgent first. An empty list is the goal.
  const todo = [
    queueLate > 0 && {
      tone: "bad" as const,
      text: `${queueLate} project${queueLate === 1 ? "" : "s"} past four working days`,
      href: "/review", cta: "Assess now",
    },
    queueSoon > 0 && {
      tone: "warn" as const,
      text: `${queueSoon} project${queueSoon === 1 ? "" : "s"} due within a day`,
      href: "/review", cta: "Open queue",
    },
    appealsOpen > 0 && {
      tone: "warn" as const,
      text: `${appealsOpen} second reading${appealsOpen === 1 ? "" : "s"} assigned to you`,
      href: "/review", cta: "Read it",
    },
    returned > 0 && {
      tone: "warn" as const,
      text: `${returned} course${returned === 1 ? "" : "s"} sent back for changes`,
      href: `/studio/${drafts.find((c) => c.state === "revision_requested")?.slug ?? ""}`,
      cta: "See what we flagged",
    },
    queueLate === 0 && queueSoon === 0 && queueTotal > 0 && {
      tone: "ok" as const,
      text: `${queueTotal} project${queueTotal === 1 ? "" : "s"} waiting, all comfortably inside four days`,
      href: "/review", cta: "Open queue",
    },
  ].filter(Boolean) as { tone: string; text: string; href: string; cta: string }[];

  return (
    <>
      <div className="dash__bar">
        <div>
          <div className="eyebrow">Studio</div>
          <h1 className="dash__title">{instructor?.headline ?? "Your studio"}</h1>
        </div>
        <AvailabilityToggle available={Boolean(o.available ?? true)} />
      </div>

      {nudge && <CreatorNudge />}

      <div className="pan">
        <div className="pan__col">
          <div className="hero__panel">
            <div className="hero__eyebrow">Review queue</div>
            <h2 className="hero__title">
              {queueLate > 0
                ? `${queueLate} project${queueLate === 1 ? "" : "s"} past four working days`
                : queueTotal > 0
                  ? `${queueTotal} project${queueTotal === 1 ? "" : "s"} waiting on you`
                  : "Queue is clear"}
            </h2>
            <p className="hero__sub">
              {queueTotal > 0
                ? "Every learner is told four working days. That promise is the product."
                : "Nothing to assess right now. New work is assigned automatically."}
            </p>
            <div className="hero__acts">
              <Link className="btn btn--white btn--lg" href="/review">
                {queueTotal > 0 ? "Open the queue" : "View queue"}
              </Link>
              <Link className="btn btn--ghost btn--lg" href="/studio/new">New course</Link>
            </div>
          </div>

          <div className="stats3">
            <Link className="stat3" href="/review">
              <div className="eyebrow">To assess</div>
              <div className={`stat3__v num${queueLate > 0 ? " is-bad" : ""}`}>{queueTotal}</div>
              <div className="stat3__n">
                {o.reliability !== null && o.reliability !== undefined
                  ? `${o.reliability}% inside four days`
                  : `${o.reviews_done ?? 0} assessed so far`}
              </div>
            </Link>
            <Link className="stat3" href="/studio/earnings">
              <div className="eyebrow">This month</div>
              <div className="stat3__v num">{money(Number(o.month_cents ?? 0))}</div>
              <div className="stat3__n">
                {money(Number(o.accrued_cents ?? 0) - Number(o.paid_cents ?? 0))} not yet paid
              </div>
            </Link>
            <div className="stat3">
              <div className="eyebrow">Learners</div>
              <div className="stat3__v num">{Number(o.learners_total ?? 0)}</div>
              <div className="stat3__n">{Number(o.learners_certified ?? 0)} certified</div>
            </div>
          </div>

          {todo.length > 0 && (
            <div className="alerts">
              {todo.map((t) => (
                <div key={t.text} className={`alert alert--${t.tone} alert--light`}>
                  <span>{t.text}</span>
                  <Link className="alert__go" href={t.href}>{t.cta} &rarr;</Link>
                </div>
              ))}
            </div>
          )}

        <section style={{ marginTop: 46 }}>
          <div className="sec__head">
            <h2 className="sub__h2">Your courses</h2>
            <Link className="sec__link" href="/studio/new">Start a new one</Link>
          </div>

          {all.length > 4 && (
            <FilterBar
              search={{ name: "q", placeholder: "Course title", value: q }}
              selects={[
                {
                  name: "state", label: "Any state", value: state,
                  options: [
                    { value: "published", label: "Live" },
                    { value: "in_review", label: "In review" },
                    { value: "draft", label: "Draft" },
                    { value: "revision_requested", label: "Changes asked for" },
                  ],
                },
                {
                  name: "sort", label: "Newest", value: sort,
                  options: [
                    { value: "title", label: "By title" },
                    { value: "enrolments", label: "Most enrolled" },
                  ],
                },
              ]}
              total={all.length}
              showing={shown.length}
              clearHref="/studio"
            />
          )}

          {all.length === 0 ? (
            <div className="empty" style={{ marginTop: 22 }}>
              <p className="empty__h">Nothing built yet</p>
              <p className="empty__p">
                Start with one course you would put your name to. Three topics, a real
                project brief and a rubric is enough to submit — and we lay most of that
                out for you.
              </p>
              <Link className="btn btn--fill btn--lg" href="/studio/new" style={{ marginTop: 20 }}>
                Start your first course
              </Link>
            </div>
          ) : (
            <div className="icourses">
              {shown.map((c) => (
                <article key={c.id} className={`icourse${c.state === "published" ? " is-live" : ""}`}>
                  <div className="icourse__top">
                    <div>
                      <div className="crs__tags" style={{ marginTop: 0 }}>
                        <span className="tag tag--blue">{c.subject}</span>
                        {c.is_free && <span className="pill pill--free">Free</span>}
                      </div>
                      <h3 className="icourse__h">{c.title}</h3>
                    </div>
                    <span className={`pill${c.state === "published" ? " pill--free" : c.state === "revision_requested" ? " pill--lock" : ""}`}>
                      {STATE_LABEL[c.state] ?? c.state}
                    </span>
                  </div>

                  {c.state === "published" ? (
                    <div className="icourse__nums">
                      <div>
                        <span className="icourse__n num">{c.enrolments}</span>
                        <span className="icourse__l">enrolled</span>
                      </div>
                      <div>
                        <span className="icourse__n num">{c.certified}</span>
                        <span className="icourse__l">certified</span>
                      </div>
                      <div>
                        <span className={`icourse__n num${Number(c.completion_pct ?? 0) < 20 && Number(c.enrolments) > 5 ? " is-warn" : ""}`}>
                          {c.completion_pct ?? 0}%
                        </span>
                        <span className="icourse__l">finish it</span>
                      </div>
                      <div>
                        <span className="icourse__n num">{c.activity_30d}</span>
                        <span className="icourse__l">topics done, 30d</span>
                      </div>
                    </div>
                  ) : (
                    <p className="icourse__draft">
                      {c.topics} topic{c.topics === 1 ? "" : "s"} so far
                      {c.state === "revision_requested" && " · we asked for changes"}
                      {c.state === "in_review" && " · we are reading it"}
                    </p>
                  )}

                  <div className="icourse__acts">
                    <Link className="btn btn--line" href={`/studio/${c.slug}`}>
                      {c.state === "published" ? "Edit" : "Keep building"}
                    </Link>
                    {c.state === "published" && (
                      <Link className="sec__link" href={`/courses/${c.slug}`}>
                        See it as a learner
                      </Link>
                    )}
                    {Number(c.awaiting) > 0 && (
                      <Link className="sec__link" href="/review">{c.awaiting} to assess</Link>
                    )}
                  </div>
                </article>
              ))}
            </div>
          )}
        </section>

        {recent && recent.length > 0 && (
          <section style={{ marginTop: 46, marginBottom: 44 }}>
            <h2 className="sub__h2">Recently assessed</h2>
            <p className="studio__hint">
              Worth a glance before a resubmission lands — you will have said something
              specific, and they will have acted on it.
            </p>
            <table className="tbl" style={{ marginTop: 16 }}>
              <thead>
                <tr><th>Learner</th><th>Course</th><th>Verdict</th><th>Attempt</th><th>When</th></tr>
              </thead>
              <tbody>
                {recent.map((r) => (
                  <tr key={r.id}>
                    <td>{r.learner_name}</td>
                    <td>{r.course_title}</td>
                    <td>
                      <span className={`pill${r.outcome === "pass" ? " pill--free" : ""}`}>
                        {r.outcome === "pass" ? "Passed" : "Changes"}
                      </span>
                    </td>
                    <td className="num">{r.attempt_no}</td>
                    <td>
                      {new Date(r.completed_at).toLocaleDateString()}
                      {!r.within_sla && <span style={{ color: "#9B2C22", fontSize: 12 }}> · late</span>}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </section>
        )}

        {pending.length > 0 && (
          <p className="studio__hint" style={{ marginBottom: 40 }}>
            {pending.length} course{pending.length === 1 ? " is" : "s are"} with us for
            review. We come back within five working days, by email.
          </p>
        )}
        </div>

        {/* Right column — the queue, and the money behind it. */}
        <div className="pan__col">
          <div className="card">
            <div className="card__head">
              <div className="card__h">Next up</div>
              <Link className="card__link" href="/review">Whole queue</Link>
            </div>
            {!queue || queue.length === 0 ? (
              <p className="empty2">Nothing assigned right now.</p>
            ) : (
              queue.map((q) => (
                <Link className="prow2" key={q.submission_id} href={`/review/${q.submission_id}`}>
                  <span
                    className={`prow2__ico${q.breached || q.due_soon ? " prow2__ico--accent" : ""}`}
                    aria-hidden="true"
                  >
                    <NavIcon name="inbox" size={17} />
                  </span>
                  <span>
                    <span className="prow2__t">{q.course_title}</span>
                    <span className="prow2__s">{q.learner_name ?? "Learner"}</span>
                  </span>
                  <span className={`tag${q.breached ? " tag--wait" : q.due_soon ? " tag--wait" : " tag--cool"}`}>
                    {slaLabel(q.deadline_at)}
                  </span>
                </Link>
              ))
            )}
          </div>

          <div className="card">
            <div className="card__head">
              <div className="card__h">Courses</div>
              <Link className="card__link" href="/studio/new">New</Link>
            </div>
            <div className="prow2">
              <span className="prow2__ico" aria-hidden="true"><NavIcon name="book" size={17} /></span>
              <span><span className="prow2__t">Live</span>
                <span className="prow2__s">Published and enrollable</span></span>
              <span className="tag tag--go num">{live.length}</span>
            </div>
            <div className="prow2">
              <span className="prow2__ico" aria-hidden="true"><NavIcon name="play" size={17} /></span>
              <span><span className="prow2__t">In draft</span>
                <span className="prow2__s">Not submitted yet</span></span>
              <span className="tag num">{drafts.length}</span>
            </div>
            <div className="prow2">
              <span className="prow2__ico prow2__ico--accent" aria-hidden="true">
                <NavIcon name="clock" size={17} />
              </span>
              <span><span className="prow2__t">With Your Brand</span>
                <span className="prow2__s">Five working days</span></span>
              <span className="tag tag--wait num">{pending.length}</span>
            </div>
          </div>

          <div className="card card--tint">
            <div className="card__h">How you get paid</div>
            <p className="card__meta" style={{ marginTop: 8, lineHeight: 1.6 }}>
              A flat fee per assessment, plus a share of the pool based on topics your
              learners actually finish. Assessing inside four days is what keeps both.
            </p>
          </div>
        </div>
      </div>
      </>
  );
}
