"use client";

import Link from "next/link";
import { useActionState } from "react";
import { useFormStatus } from "react-dom";
import { submitExam } from "@/app/actions/exam";
import { EXAM_PASS_MARK, type ExamResult } from "@/lib/learning";
import Alert from "@/components/Alert";

type Question = { id: string; prompt: string; options: { id: string; text: string }[] };

function Submit({ label }: { label: string }) {
  const { pending } = useFormStatus();
  return (
    <button className="btn btn--fill btn--lg" disabled={pending}>
      {pending ? "Marking…" : label}
    </button>
  );
}

export default function ExamPaper({
  slug, questions, requiresProject, attempts, bestPct,
}: {
  slug: string;
  questions: Question[];
  requiresProject: boolean;
  attempts: number;
  bestPct: number;
}) {
  const bound = submitExam.bind(null, slug);
  const [state, action] = useActionState<ExamResult, FormData>(bound, {});

  const cooling = state.cooldownUntil && new Date(state.cooldownUntil) > new Date();

  if (cooling) {
    const mins = Math.max(
      1, Math.ceil((new Date(state.cooldownUntil!).getTime() - Date.now()) / 60000)
    );
    return (
      <div className="quiz">
        <div className="quiz__cool">
          <p className="quiz__coolh">Take a break before the next attempt</p>
          <p className="quiz__coolp">
            Two attempts in a row came in under {EXAM_PASS_MARK}%. The exam opens again
            in about {mins} minute{mins === 1 ? "" : "s"}. Nothing is lost — go back
            over the modules in the meantime.
          </p>
        </div>
      </div>
    );
  }

  // A pass that issued a certificate, or that opened the project. Both end
  // the exam, so the paper is replaced rather than left underneath.
  if (state.passed && state.next) {
    return (
      <div className="quiz">
        <div className="quiz__pass">
          <p className="quiz__passh">Passed — {state.scorePct}%</p>
          {state.next.kind === "certificate" ? (
            <>
              <p className="quiz__passp">
                That is the course complete. Your certificate is issued and can be
                verified by anyone with the code.
              </p>
              <Link className="btn btn--fill btn--lg" href={state.next.href}>
                See your certificate
              </Link>
            </>
          ) : (
            <>
              <p className="quiz__passp">
                The final project is open. A working practitioner assesses it within
                four working days, against the rubric you have already seen.
              </p>
              <Link className="btn btn--fill btn--lg" href={state.next.href}>
                Start the project
              </Link>
            </>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="quiz">
      <div className="quiz__head">
        <h2 className="quiz__h">Final exam</h2>
        <p className="quiz__sub">
          {questions.length} question{questions.length === 1 ? "" : "s"}, {EXAM_PASS_MARK}% to
          pass. Retake as often as you need — after two misses in a row there is a
          30 minute pause.{" "}
          {requiresProject
            ? "Passing opens the final project."
            : "Passing completes the course and issues your certificate."}
        </p>
      </div>

      {attempts > 0 && !state.scorePct && (
        <p className="quiz__already">
          {attempts} previous attempt{attempts === 1 ? "" : "s"}, best {bestPct}%.
        </p>
      )}

      {/* A pass that could not issue its certificate — the assessment
          included in the price was already spent on an earlier submission.
          The score still shows, because the pass itself is recorded and they
          should not think they have to sit it again. */}
      {state.passed && !state.next && state.error && (
        <div className="quiz__pass">
          <p className="quiz__passh">Passed — {state.scorePct}%</p>
          <p className="quiz__passp">{state.error}</p>
          <Link className="btn btn--line btn--lg" href="/dashboard/submissions">My projects</Link>
        </div>
      )}

      {state.scorePct !== undefined && !state.passed && (
        <div className="quiz__fail" role="alert">
          <p className="quiz__failh">{state.scorePct}% — not this time</p>
          <p className="quiz__failp">
            You need {EXAM_PASS_MARK}%. The explanations below show where it went wrong.
          </p>
        </div>
      )}

      <form action={action} className="quiz__form">
        {questions.map((q, qi) => {
          const marked = state.review?.find((r) => r.itemId === q.id);
          return (
            <fieldset
              key={q.id}
              className={`q${marked ? (marked.correct ? " is-right" : " is-wrong") : ""}`}
            >
              <legend className="q__legend">
                <span className="q__n num">{qi + 1}</span>
                <span>{q.prompt}</span>
              </legend>
              <div className="q__opts">
                {q.options.map((o) => (
                  <label key={o.id} className="q__opt">
                    <input type="radio" name={`q_${q.id}`} value={o.id} required />
                    <span>{o.text}</span>
                  </label>
                ))}
              </div>
              {marked && marked.explanation && (
                <p className="q__exp">
                  <strong>{marked.correct ? "Correct." : "Not this one."}</strong>{" "}
                  {marked.explanation}
                </p>
              )}
            </fieldset>
          );
        })}

        {state.error && !state.passed && <Alert kind="error">{state.error}</Alert>}

        <Submit label={state.scorePct !== undefined ? "Try again" : "Submit the exam"} />
      </form>
    </div>
  );
}
