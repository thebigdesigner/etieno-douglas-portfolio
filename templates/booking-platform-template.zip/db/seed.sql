-- ============================================================================
-- Your Brand -- first tenant. Run after schema.sql.
-- Fares, times and addresses marked REPLACE are still placeholders.
-- ============================================================================
insert into tenants (slug, name, prefix, currency, settings)
values ('ace-trail', 'Your Brand', 'ATX', 'NGN', jsonb_build_object(
  'hold_minutes', 15,
  'child_fare_ratio', 0.75,
  'arrive_before_min', 30,
  'check_in_close_min', 15,
  'max_passengers', 5,
  'call_window_min', 120
))
on conflict (slug) do update set name = excluded.name, settings = excluded.settings;

with t as (select id from tenants where slug = 'ace-trail')
insert into terminals (tenant_id, code, city, name, address, phone, whatsapp, opens_at)
select t.id, x.code, x.city, x.name, x.address, x.phone, x.phone, time '06:00'
from t, (values
  ('uyo', 'North City',           'North City terminal',           'North City, North Region -- REPLACE with the street address',        '0800 000 0000'),
  ('phc', 'Coast City', 'Coast City terminal', 'Coast City, Coast Region -- REPLACE with the street address', '0800 000 0000'),
  ('cal', 'Central City',       'Central City terminal',       'Central City, Central Region -- REPLACE with the street address',  '0800 000 0000')
) as x(code, city, name, address, phone)
on conflict (tenant_id, code) do update set city = excluded.city, phone = excluded.phone;

with t as (select id from tenants where slug = 'ace-trail')
insert into vehicles (tenant_id, label, plate, capacity, seat_map)
select t.id, 'Toyota Sequoia', x.plate, 5, jsonb_build_object(
  'rows', jsonb_build_array(jsonb_build_array('D', 1), jsonb_build_array(2, 3), jsonb_build_array(4, 5)),
  'labels', jsonb_build_object('1','Front','2','Middle','3','Middle','4','Rear','5','Rear'))
from t, (values ('KJA-757YE'), ('KWL-464ZY')) as x(plate)
on conflict (tenant_id, plate) do nothing;

-- Routes: fares in kobo. REPLACE the fares, durations and departure times once confirmed.
with t as (select id from tenants where slug = 'ace-trail'),
     term as (select code, id from terminals where tenant_id = (select id from t))
insert into routes (tenant_id, from_terminal, to_terminal, fare_kobo, duration_min, operating_days, departures)
select (select id from t), a.id, b.id, x.fare, x.mins, array[2,4,6]::smallint[], x.times
from (values
  ('uyo','phc', 1800000, 180, array[time '07:00', time '14:00']),
  ('phc','uyo', 1800000, 180, array[time '07:00', time '14:00']),
  ('uyo','cal', 1200000, 120, array[time '07:30', time '15:00']),
  ('cal','uyo', 1200000, 120, array[time '07:30', time '15:00'])
) as x(from_code, to_code, fare, mins, times)
join term a on a.code = x.from_code
join term b on b.code = x.to_code
on conflict (tenant_id, from_terminal, to_terminal) do update
  set fare_kobo = excluded.fare_kobo, departures = excluded.departures, operating_days = excluded.operating_days;

-- ----------------------------------------------------------------------------
-- Trip generation. Creates the next N operating days for every active route and
-- lays out one seat row per seat. Run daily (pg_cron) or on demand.
-- ----------------------------------------------------------------------------
-- generate_trips() now lives in schema.sql, so it can be re-run daily by the cron.
-- Seed just calls it once to fill the first window.
select generate_trips('ace-trail', 30);
