"use client";

export default function PrintButton() {
  return (
    <div className="certdoc__bar">
      <button className="btn btn--fill" onClick={() => window.print()}>
        Print or save as PDF
      </button>
      <span className="certdoc__hint">
        Choose &ldquo;Save as PDF&rdquo; as the destination.
      </span>
    </div>
  );
}
