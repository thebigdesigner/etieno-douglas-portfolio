"use client";

import { useActionState, useState } from "react";
import { saveReview, removeReview } from "@/app/actions/marketplace-reviews";
import type { FormState } from "@/lib/forms";
import MkIcon from "@/components/marketplace/MkIcon";

const EMPTY: FormState = {};

/**
 * Five radio buttons wearing stars.
 *
 * Radios rather than clickable icons so the rating arrives with the form
 * on a page with no JavaScript, and so a keyboard reaches it by arrow key
 * the way a rating control is expected to behave.
 */
function StarPick({ value, onPick }: { value: number; onPick: (n: number) => void }) {
  return (
    <fieldset className="mk-rev__pick">
      <legend className="sr">Your rating</legend>
      {[1, 2, 3, 4, 5].map((n) => (
        <label key={n} className="mk-rev__star" data-on={n <= value}>
          <input
            type="radio" name="rating" value={n} checked={value === n}
            onChange={() => onPick(n)} className="sr"
          />
          <MkIcon name="star" size={26} />
          <span className="sr">{n} {n === 1 ? "star" : "stars"}</span>
        </label>
      ))}
    </fieldset>
  );
}

export default function ReviewForm({
  productId, mine,
}: {
  productId: string;
  mine: { rating: number; body: string | null } | null;
}) {
  const [state, action, pending] = useActionState(saveReview, EMPTY);
  const [, removeAction] = useActionState(removeReview, EMPTY);
  const [rating, setRating] = useState(mine?.rating ?? 0);

  return (
    <div className="mk-rev__mine">
      <form action={action} className="mk-rev__form">
        <input type="hidden" name="product_id" value={productId} />
        <p className="mk-rev__ask">{mine ? "Your review" : "How did it work out?"}</p>
        <StarPick value={rating} onPick={setRating} />
        <textarea
          name="body" rows={3} maxLength={1500}
          defaultValue={mine?.body ?? ""}
          placeholder="What it was like to use. Optional."
          className="mk-rev__text"
        />
        <div className="mk-rev__actions">
          <button className="mk-btn mk-btn--fill" disabled={pending || rating === 0}>
            {pending ? "Saving…" : mine ? "Update review" : "Post review"}
          </button>
          {mine && (
            <button formAction={removeAction} className="mk-btn mk-btn--line" formNoValidate>
              Remove
            </button>
          )}
        </div>
        {state.error && <p className="mk-rev__err" role="alert">{state.error}</p>}
        {state.ok && state.message && <p className="mk-rev__ok">{state.message}</p>}
      </form>
    </div>
  );
}
