import Link from "next/link";

export type FilterSelect = {
  name: string;
  label: string;
  value?: string;
  options: { value: string; label: string }[];
};

/**
 * The console's filter bar.
 *
 * One bar rather than a form per page. Four of the five console pages had no
 * filtering at all — they loaded everything, capped it with a limit, and
 * sliced it in JavaScript, which means the thing you are looking for may
 * simply not be in the rows that arrived.
 *
 * State lives in the URL, not in component state. A filtered console view is
 * something you send to somebody — "look at these three late reviewers" — and
 * that only works if the address bar holds the filter. It also makes the back
 * button behave, and lets the server do the filtering rather than shipping
 * every row to the browser to hide most of them.
 *
 * A plain GET form, so it works before hydration and needs no client bundle.
 */
export default function FilterBar({
  action, search, selects = [], total, showing, clearHref,
}: {
  /** Where the form submits. Defaults to the current path. */
  action?: string;
  search?: { name: string; placeholder: string; value?: string };
  selects?: FilterSelect[];
  /** How many rows exist, and how many are on screen — the console's whole
   *  problem is not knowing whether you are looking at everything. */
  total?: number;
  showing?: number;
  clearHref?: string;
}) {
  const active =
    (search?.value ? 1 : 0) + selects.filter((s) => s.value).length;

  return (
    <form className="fbar" method="get" action={action}>
      {search && (
        <input
          className="fbar__q"
          name={search.name}
          defaultValue={search.value ?? ""}
          placeholder={search.placeholder}
          aria-label={search.placeholder}
        />
      )}

      {selects.map((s) => (
        <label key={s.name} className="fbar__sel">
          <span className="sr">{s.label}</span>
          <select name={s.name} defaultValue={s.value ?? ""} aria-label={s.label}>
            <option value="">{s.label}</option>
            {s.options.map((o) => (
              <option key={o.value} value={o.value}>{o.label}</option>
            ))}
          </select>
        </label>
      ))}

      <button className="btn btn--line">Apply</button>

      {active > 0 && clearHref && (
        <Link className="fbar__clear" href={clearHref}>
          Clear{active > 1 ? ` (${active})` : ""}
        </Link>
      )}

      {typeof total === "number" && (
        <span className="fbar__count num">
          {typeof showing === "number" && showing < total
            ? `${showing} of ${total}`
            : `${total}`}
        </span>
      )}
    </form>
  );
}
