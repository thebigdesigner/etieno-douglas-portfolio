/** Shared by the Academy and marketplace sign-in, which must say the same thing. */
export const DELETED_ACCOUNT =
  "That account was deleted at its owner's request, so it cannot be reopened. If this is you and you want to come back, sign up again — it will be a fresh account.";
