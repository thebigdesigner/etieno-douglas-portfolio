-- =====================================================================
-- Sprint 1 — identity, age gating, parental consent
-- =====================================================================

-- Accounts wait for a guardian before they can do anything.
create type profile_status as enum ('active','pending_consent','suspended','deleted');

alter table profiles
  add column status            profile_status not null default 'active',
  add column minor_protections boolean        not null default false,
  add column consent_required  boolean        not null default false,
  add column email             text;

comment on column profiles.minor_protections is
  'Under 18. No marketing email, name hidden on public certificate pages, minimal retention.';

-- Device-scoped age check, written before the account exists so the gate
-- cannot be bypassed by reloading and entering a different date.
alter table age_checks
  add column consumed_at timestamptz,
  add column blocked     boolean not null default false;

create unique index age_checks_device_live
  on age_checks (device_token) where consumed_at is null;

-- Consent tokens: one to confirm, a separate one the guardian keeps to
-- manage or withdraw later.
alter table parental_consents
  add column manage_token text unique,
  add column reminded_at  timestamptz;

create index on parental_consents (token) where state = 'pending';

-- ---------------------------------------------------------------------
-- Create the profile row automatically when Supabase creates the user.
-- Metadata comes from the signup call.
-- ---------------------------------------------------------------------
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (
    id, email, display_name, date_of_birth, account_type,
    segment, guardian_email, status, minor_protections, consent_required
  )
  values (
    new.id,
    new.email,
    nullif(new.raw_user_meta_data->>'display_name', ''),
    nullif(new.raw_user_meta_data->>'date_of_birth', '')::date,
    coalesce((new.raw_user_meta_data->>'account_type')::account_type, 'adult'),
    nullif(new.raw_user_meta_data->>'segment', ''),
    nullif(new.raw_user_meta_data->>'guardian_email', ''),
    case when (new.raw_user_meta_data->>'consent_required')::boolean
         then 'pending_consent'::profile_status
         else 'active'::profile_status end,
    coalesce((new.raw_user_meta_data->>'minor_protections')::boolean, false),
    coalesce((new.raw_user_meta_data->>'consent_required')::boolean, false)
  );
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute function public.handle_new_user();

-- ---------------------------------------------------------------------
-- Confirming consent activates the account. Withdrawal suspends it.
-- ---------------------------------------------------------------------
create or replace function public.confirm_consent(p_token text, p_ip inet)
returns table (learner_id uuid, manage_token text)
language plpgsql
security definer set search_path = public
as $$
declare
  rec parental_consents%rowtype;
begin
  select * into rec
    from parental_consents
   where token = p_token and state = 'pending'
   for update;

  if not found then
    return;
  end if;

  if rec.expires_at < now() then
    update parental_consents set state = 'expired' where id = rec.id;
    return;
  end if;

  update parental_consents
     set state = 'confirmed',
         confirmed_at = now(),
         confirmed_ip = p_ip
   where id = rec.id;

  update profiles
     set status = 'active', consent_required = false
   where id = rec.learner_id;

  return query select rec.learner_id, rec.manage_token;
end;
$$;

create or replace function public.withdraw_consent(p_manage_token text)
returns boolean
language plpgsql
security definer set search_path = public
as $$
declare
  rec parental_consents%rowtype;
begin
  select * into rec
    from parental_consents
   where manage_token = p_manage_token and state = 'confirmed'
   for update;

  if not found then
    return false;
  end if;

  update parental_consents
     set state = 'withdrawn', withdrawn_at = now()
   where id = rec.id;

  -- Suspend immediately. Deletion is a separate, explicit request.
  update profiles set status = 'suspended' where id = rec.learner_id;

  return true;
end;
$$;

-- ---------------------------------------------------------------------
-- Cohort join: claim an issued seat. Runs with elevated rights because
-- the learner has no account yet at the moment of claiming.
-- ---------------------------------------------------------------------
create or replace function public.claim_cohort_seat(
  p_class_code text,
  p_username   text,
  p_user_id    uuid
)
returns boolean
language plpgsql
security definer set search_path = public
as $$
declare
  v_cohort  cohorts%rowtype;
  v_seat    cohort_seats%rowtype;
  v_claimed int;
begin
  select * into v_cohort
    from cohorts
   where class_code = p_class_code
     and state = 'active'
     and current_date between starts_on and ends_on;

  if not found then
    return false;
  end if;

  select count(*) into v_claimed
    from cohort_seats where cohort_id = v_cohort.id and user_id is not null;

  if v_claimed >= v_cohort.seat_ceiling then
    return false;                       -- ceiling reached
  end if;

  select * into v_seat
    from cohort_seats
   where cohort_id = v_cohort.id
     and lower(username) = lower(p_username)
     and user_id is null
   for update;

  if not found then
    return false;                       -- no such username, or already claimed
  end if;

  update cohort_seats
     set user_id = p_user_id, claimed_at = now()
   where id = v_seat.id;

  insert into enrolments (user_id, course_id, source, cohort_id)
  select p_user_id, cc.course_id, 'cohort', v_cohort.id
    from cohort_courses cc
   where cc.cohort_id = v_cohort.id
  on conflict (user_id, course_id) do nothing;

  return true;
end;
$$;

-- ---------------------------------------------------------------------
-- Policies
-- ---------------------------------------------------------------------
create policy own_consents on parental_consents
  for select using (auth.uid() = learner_id);

revoke all on function public.confirm_consent(text, inet)  from public, anon, authenticated;
revoke all on function public.withdraw_consent(text)        from public, anon, authenticated;
revoke all on function public.claim_cohort_seat(text, text, uuid) from public, anon, authenticated;
-- These are invoked from server code holding the service role key only.
