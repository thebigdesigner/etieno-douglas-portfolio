/**
 * GET /api/auth/staff-verify?t=TOKEN — confirms a staff member's email address after they
 * have set their own password.
 *
 * The token is signed and single-use: the login_tokens row is marked used before anything is
 * written, so a forwarded link cannot be replayed. Nothing here can change a password — it only
 * records that the address reached a real person.
 */
import { configured, select, update, fail } from '../db.js';
import { verify } from './session.js';
import { confirmPage, tokenOf } from './confirm-page.js';

const back = (res, hash) => { res.writeHead(302, { Location: `/staff#${hash}` }); res.end(); };

export default async function handler(req, res) {
  const secret = process.env.SESSION_SECRET;
  if (!secret || !configured()) return fail(res, 503, 'not_configured', 'Email verification is not switched on');

  const token = tokenOf(req);
  const claims = verify(token, secret);
  if (!claims || claims.kind !== 'staff-verify' || !claims.jti || !claims.staffId) return back(res, 'verify-expired');
  if (req.method !== 'POST') return confirmPage(res, { action: '/api/auth/staff-verify', token, title: 'Confirm your email', button: 'Confirm my email' });

  try {
    const rows = await select('login_tokens', `jti=eq.${claims.jti}&select=id,expires_at,used_at`);
    const row = rows[0];
    if (!row || row.used_at || Date.parse(row.expires_at) < Date.now()) return back(res, 'verify-expired');

    const spent = await update('login_tokens', `id=eq.${row.id}&used_at=is.null`, { used_at: new Date().toISOString() });
    if (!spent?.length) return back(res, 'verify-expired');
    await update('staff', `id=eq.${claims.staffId}`, { email_verified_at: new Date().toISOString() });
    return back(res, 'verified');
  } catch (err) {
    console.error('staff verify failed:', err.message);
    return back(res, 'verify-expired');
  }
}
