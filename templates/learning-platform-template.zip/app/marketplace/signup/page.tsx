import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { marketBase, mk } from "@/lib/marketplace/url";
import { mkNext } from "@/lib/marketplace/next";
import { studioViewer } from "@/lib/marketplace/studio";
import { siteUrlFor } from "@/lib/site";
import AuthShell from "@/components/marketplace/auth/AuthShell";
import { GoogleButton, SignupForm } from "@/components/marketplace/auth/AuthForms";

export const metadata: Metadata = { title: "Create an account" };

type Props = { searchParams: Promise<{ next?: string }> };

export default async function MarketSignup({ searchParams }: Props) {
  const [sp, base] = await Promise.all([searchParams, marketBase()]);
  const next = mkNext(sp.next);
  if (await studioViewer().catch(() => null)) redirect(mk(base, next));
  const q = next === "/" ? "" : `?next=${encodeURIComponent(next)}`;
  return (
    <AuthShell homeHref={mk(base, "/")} title="Create your account" lead="Buy files, save favourites, or open a shop and sell your own work. Free to join."
      foot={<>Already have a Your Brand account? <Link href={mk(base, `/login${q}`)} className="au__link">Sign in</Link></>}>
      <GoogleButton next={next} />
      <div className="au__or"><span>or with email</span></div>
      <SignupForm next={next} termsHref={siteUrlFor("/legal/terms")} privacyHref={siteUrlFor("/legal/privacy")} />
    </AuthShell>
  );
}
