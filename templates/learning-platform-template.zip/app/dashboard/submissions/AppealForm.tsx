"use client";
import { useActionState, useState } from "react";
import { openAppeal } from "@/app/actions/review";
import type { FormState } from "@/lib/forms";
import SubmitButton from "@/components/SubmitButton";
import Alert from "@/components/Alert";

const initial: FormState = {};

export default function AppealForm({ submissionId }: { submissionId: string }) {
  const [open, setOpen] = useState(false);
  const [state, action] = useActionState(openAppeal.bind(null, submissionId), initial);

  if (state.ok) {
    return <Alert kind="success">{state.message}</Alert>;
  }

  if (!open) {
    return (
      <button className="btn btn--line" onClick={() => setOpen(true)}>
        Ask for a second opinion
      </button>
    );
  }

  return (
    <form action={action} className="appeal">
      <label className="field">
        <span className="field__label">Which part of the rubric do you think was applied wrongly?</span>
        <textarea name="grounds" rows={4} required minLength={60} />
        <span className="field__hint">
          A second reviewer looks at it without seeing the first verdict. One appeal per
          submission, on grounds of rubric misapplication — not disagreement with the
          rubric itself.
        </span>
      </label>
      {state.error && <Alert kind="error">{state.error}</Alert>}
      <div className="appeal__btns">
        <SubmitButton>Send the appeal</SubmitButton>
        <button type="button" className="btn btn--line" onClick={() => setOpen(false)}>Cancel</button>
      </div>
    </form>
  );
}
