/**
 * Nav icons.
 *
 * One stroked set, drawn on a 24-grid, inheriting currentColor — so the rail's
 * existing hover and is-on colours apply without a second set for the dark
 * console theme.
 *
 * Deliberately not an icon library: this is twenty-odd glyphs, and pulling in
 * a dependency to ship all of them would cost more than the file it replaces.
 */

export type IconName =
  | "home" | "book" | "award" | "inbox" | "bookmark" | "search" | "user"
  | "users" | "plus" | "wallet" | "help" | "play" | "receipt" | "shield"
  | "chart" | "clock" | "scales" | "building" | "coins" | "activity"
  | "list" | "sparkle" | "logout" | "bell" | "chevron" | "lock"
  | "gear" | "pencil" | "panel" | "sun" | "moon" | "monitor" | "grid"
  | "menu" | "close" | "cart";

const PATHS: Record<IconName, string> = {
  menu:     "M3.5 6h17M3.5 12h17M3.5 18h17",
  close:    "M6 6l12 12M18 6L6 18",
  home:     "M3 10.5 12 3l9 7.5M5.5 9.5V20h13V9.5",
  book:     "M4 4.5h9a3 3 0 0 1 3 3V21a2.5 2.5 0 0 0-2.5-2.5H4zM20 4.5h-2.5a3 3 0 0 0-1.5.4",
  award:    "M12 3a5.5 5.5 0 1 1 0 11 5.5 5.5 0 0 1 0-11ZM8.5 13.5 7 21l5-2.5L17 21l-1.5-7.5",
  inbox:    "M3 13h5l1.5 3h5L16 13h5M3 13l3-8h12l3 8v6H3z",
  bookmark: "M6.5 3.5h11v17l-5.5-4-5.5 4z",
  search:   "M11 4a7 7 0 1 1 0 14 7 7 0 0 1 0-14ZM16 16l4.5 4.5",
  user:     "M12 3.5a4 4 0 1 1 0 8 4 4 0 0 1 0-8ZM4.5 20.5a7.5 7.5 0 0 1 15 0",
  users:    "M9 4a3.5 3.5 0 1 1 0 7 3.5 3.5 0 0 1 0-7ZM2.5 20a6.5 6.5 0 0 1 13 0M16 4.5a3.5 3.5 0 0 1 0 6.9M18 14.2a6.5 6.5 0 0 1 3.5 5.8",
  plus:     "M12 5v14M5 12h14",
  wallet:   "M3 7.5A2.5 2.5 0 0 1 5.5 5H18v2.5M3 7.5V18a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-2.5M3 7.5h16a2 2 0 0 1 2 2v2M21 11.5h-4a2 2 0 0 0 0 4h4",
  help:     "M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18ZM9.5 9.5a2.5 2.5 0 1 1 3.2 2.4c-.5.2-.7.6-.7 1.1v.5M12 16.8v.2",
  play:     "M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18ZM10.2 8.6l5.3 3.4-5.3 3.4z",
  receipt:  "M5 3.5h14v17l-2.3-1.5-2.4 1.5-2.3-1.5-2.4 1.5L7.3 19 5 20.5zM8.5 8h7M8.5 12h7",
  shield:   "M12 3l7 2.8v5.4c0 4.2-2.8 7.7-7 9.3-4.2-1.6-7-5.1-7-9.3V5.8zM9 12l2 2 4-4",
  chart:    "M4 20V4M4 20h16M8 17v-5M12.5 17V8M17 17v-7",
  clock:    "M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18ZM12 7.5V12l3 2",
  scales:   "M12 4v16M7 20h10M12 6.5 5 9m7-2.5L19 9M5 9l-2.5 5.5a3.5 3.5 0 0 0 5 0zM19 9l-2.5 5.5a3.5 3.5 0 0 0 5 0z",
  building: "M4 20.5V5.5A1.5 1.5 0 0 1 5.5 4h8A1.5 1.5 0 0 1 15 5.5v15M15 10h3.5A1.5 1.5 0 0 1 20 11.5v9M2.5 20.5h19M7.5 8h4M7.5 12h4M7.5 16h4",
  coins:    "M8.5 4.5c3.6 0 6.5 1.1 6.5 2.5S12.1 9.5 8.5 9.5 2 8.4 2 7s2.9-2.5 6.5-2.5ZM2 7v4c0 1.4 2.9 2.5 6.5 2.5S15 12.4 15 11V7M9 14.5c0-1.4 2.9-2.5 6.5-2.5S22 13.1 22 14.5 19.1 17 15.5 17 9 15.9 9 14.5ZM9 14.5v3c0 1.4 2.9 2.5 6.5 2.5S22 18.9 22 17.5v-3",
  activity: "M3 12h4l3 7 4-15 3 8h4",
  list:     "M4 6.5h.01M4 12h.01M4 17.5h.01M8.5 6.5H20M8.5 12H20M8.5 17.5H20",
  sparkle:  "M12 3.5l1.9 4.9 4.9 1.9-4.9 1.9L12 17.1l-1.9-4.9L5.2 10.3l4.9-1.9zM18.5 16.5l.8 2 2 .8-2 .8-.8 2-.8-2-2-.8 2-.8z",
  chevron:  "M6 9.5 12 15.5 18 9.5",
  lock:     "M6.5 10.5V8a5.5 5.5 0 0 1 11 0v2.5M5 10.5h14v9.5H5zM12 14.5v2",
  bell:     "M18 9.5a6 6 0 1 0-12 0c0 5.5-2.5 7.5-2.5 7.5h17s-2.5-2-2.5-7.5M13.7 20a2 2 0 0 1-3.4 0",
  logout:   "M15 4.5h3A1.5 1.5 0 0 1 19.5 6v12a1.5 1.5 0 0 1-1.5 1.5h-3M12 15.5 15.5 12 12 8.5M15.5 12H4",
  gear:     "M12 9a3 3 0 1 1 0 6 3 3 0 0 1 0-6ZM12 2.8l1.5 2.4 2.8-.5.6 2.8 2.6 1.1-1.1 2.6 1.8 2.2-2.2 1.8.3 2.8-2.8.3-1.4 2.5L12 19.6l-2.1 1.7-1.4-2.5-2.8-.3.3-2.8L3.8 14l1.8-2.2L4.5 9.2l2.6-1.1.6-2.8 2.8.5z",
  pencil:   "M4 20h4L19.5 8.5a2.1 2.1 0 0 0-3-3L5 17zM14.5 6.5l3 3",
  panel:    "M4.5 4.5h15v15h-15zM10 4.5v15M7.3 10.2 5.6 12l1.7 1.8",
  sun:      "M12 8a4 4 0 1 1 0 8 4 4 0 0 1 0-8ZM12 2.5v2M12 19.5v2M4.2 4.2l1.4 1.4M18.4 18.4l1.4 1.4M2.5 12h2M19.5 12h2M4.2 19.8l1.4-1.4M18.4 5.6l1.4-1.4",
  moon:     "M20 14.5A8.5 8.5 0 0 1 9.5 4a8.5 8.5 0 1 0 10.5 10.5Z",
  grid:     "M4 4h6.5v6.5H4zM13.5 4H20v6.5h-6.5zM4 13.5h6.5V20H4zM13.5 13.5H20V20h-6.5z",
  /* A bag rather than a trolley: fewer strokes, so it still reads at the
     18px the rail draws these at. */
  cart:     "M5.5 8h13l-1.1 11.2a1.5 1.5 0 0 1-1.5 1.3H8.1a1.5 1.5 0 0 1-1.5-1.3zM9 8V6.6a3 3 0 0 1 6 0V8",
  /* "Follow the system" in a light/dark control. Same 1.7 stroke and
     rounded joins as the rest, so it sits beside sun and moon evenly. */
  monitor:  "M3.5 5.5h17v10h-17zM8.5 20h7M12 15.5V20",
};

export default function NavIcon({
  name, size = 18, className,
}: { name: IconName; size?: number; className?: string }) {
  return (
    <svg
      className={className}
      width={size}
      height={size}
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="1.7"
      strokeLinecap="round"
      strokeLinejoin="round"
      aria-hidden="true"
      focusable="false"
    >
      <path d={PATHS[name]} />
    </svg>
  );
}
