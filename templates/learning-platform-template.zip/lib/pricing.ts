/**
 * Currency, and how an amount is written.
 *
 * The per-currency price table that used to live here went with 0063, along
 * with the plans it priced. Courses are quoted in one currency — see
 * SALE_CURRENCY below — so nothing here picks a price any more; it decides
 * how a price is *shown*.
 *
 * The country map and the symbol table are kept because they are the whole
 * of the work if geo-pricing returns. Doing that properly means a price per
 * currency on each course, set by its author. It does not mean running one
 * number through an exchange rate: a stored rate goes stale and quietly
 * starts underselling, and a live FX call puts a third-party outage between
 * a customer and checkout.
 */

export type Currency =
  | "USD" | "NGN" | "GHS" | "KES" | "ZAR" | "UGX" | "TZS" | "RWF"
  | "XAF" | "XOF" | "EGP" | "ZMW" | "GBP" | "EUR";

/**
 * What a course is priced and charged in.
 *
 * An author types one number into one field. Under the plan, checkout
 * resolved a currency from the visitor's country and charged that number
 * in it — so a $49 course billed a Nigerian buyer ₦49 and a British one
 * £49. Harmless while the subscription carried the revenue; the whole
 * business once a sale is the only way money arrives.
 *
 * So sales are quoted and charged in one currency, and courses.price_currency
 * records which. record_course_purchases refuses a payment taken in
 * anything else (0063), which makes this constant and that column the same
 * decision written down twice — deliberately, because the database is what
 * still holds if this file is edited carelessly.
 *
 * Geo-pricing comes back by giving each course a price per currency, not by
 * pointing resolveCurrency() at a single number again.
 */
export const SALE_CURRENCY: Currency = "USD";

/**
 * Paystack settles NGN, GHS, ZAR, KES, XOF (Côte d'Ivoire), EGP and USD —
 * and USD only once it is enabled on the account. The other entries are
 * formatting reference only; charging in them would be refused.
 */
/** Kept as reference material for the geo-pricing note above. */
export const COUNTRY_CURRENCY: Record<string, Currency> = {
  NG: "NGN", GH: "GHS", KE: "KES", ZA: "ZAR", UG: "UGX", TZ: "TZS",
  RW: "RWF", ZM: "ZMW", EG: "EGP",
  CM: "XAF", CF: "XAF", TD: "XAF", CG: "XAF", GA: "XAF", GQ: "XAF",
  CI: "XOF", SN: "XOF", BF: "XOF", ML: "XOF", NE: "XOF", TG: "XOF",
  BJ: "XOF", GW: "XOF",
  GB: "GBP",
  AT: "EUR", BE: "EUR", CY: "EUR", DE: "EUR", EE: "EUR", ES: "EUR",
  FI: "EUR", FR: "EUR", GR: "EUR", IE: "EUR", IT: "EUR", LT: "EUR",
  LU: "EUR", LV: "EUR", MT: "EUR", NL: "EUR", PT: "EUR", SI: "EUR",
  SK: "EUR", HR: "EUR",
};

export const CURRENCY_SYMBOL: Record<Currency, string> = {
  USD: "$", NGN: "₦", GHS: "GH₵", KES: "KSh", ZAR: "R", UGX: "USh",
  TZS: "TSh", RWF: "FRw", XAF: "FCFA", XOF: "CFA", EGP: "E£",
  ZMW: "K", GBP: "£", EUR: "€",
};

export function isCurrency(v: string): v is Currency {
  return Object.prototype.hasOwnProperty.call(CURRENCY_SYMBOL, v);
}

/** Zero-decimal currencies would show ".00" for no reason. */
const NO_DECIMALS: Currency[] = ["NGN", "UGX", "TZS", "RWF", "XAF", "XOF", "KES"];

export function formatPrice(ccy: Currency, amount: number): string {
  const symbol = CURRENCY_SYMBOL[ccy] ?? "";
  const n = NO_DECIMALS.includes(ccy)
    ? amount.toLocaleString("en-US")
    : amount.toLocaleString("en-US", { maximumFractionDigits: 2 });
  return `${symbol}${n}`;
}
