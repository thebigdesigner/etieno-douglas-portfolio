-- ---------------------------------------------------------------------
-- 0073 — Buyer reviews, and the house flag for Your Brand's own items.
--
-- Until now mk_products.rating and ratings_count were columns nothing
-- wrote to, so every real listing showed no stars for ever while the demo
-- catalogue showed 4.9s. This adds the table those columns were always
-- meant to be summarising, and keeps the summary in the product row so
-- the browse queries stay one read.
-- ---------------------------------------------------------------------

create table if not exists mk_reviews (
  id          uuid primary key default gen_random_uuid(),
  product_id  uuid not null references mk_products(id) on delete cascade,
  user_id     uuid not null references profiles(id) on delete cascade,
  rating      smallint not null check (rating between 1 and 5),
  body        text check (body is null or length(body) between 0 and 1500),
  created_at  timestamptz not null default now(),
  updated_at  timestamptz not null default now(),
  -- One review per person per item. Changing your mind edits the row you
  -- already have rather than adding a second opinion.
  unique (product_id, user_id)
);

create index if not exists mk_reviews_product_idx on mk_reviews (product_id, created_at desc);

-- ------------------------------------------------------------ ownership
-- A review is only worth reading if the reviewer has the thing. Paid
-- orders and free claims both count: a free item is still downloaded and
-- still used.
create or replace function mk_owns_product(p_user uuid, p_product uuid)
returns boolean language sql stable security definer set search_path = public as $$
  select exists (
    select 1 from mk_orders
     where user_id = p_user and product_id = p_product and status = 'paid'
  ) or exists (
    select 1 from mk_downloads
     where user_id = p_user and product_id = p_product
  );
$$;

-- --------------------------------------------------------- the summary
-- Recomputed from the table rather than adjusted in steps, so an edit or
-- a deletion cannot leave the average drifting away from its reviews.
create or replace function mk_refresh_rating(p_product uuid)
returns void language plpgsql security definer set search_path = public as $$
declare
  v_avg numeric;
  v_n   integer;
begin
  select round(avg(rating)::numeric, 1), count(*) into v_avg, v_n
    from mk_reviews where product_id = p_product;
  update mk_products
     set rating = v_avg,          -- null when the last review is removed
         ratings_count = coalesce(v_n, 0)
   where id = p_product;
end;
$$;

create or replace function mk_reviews_touch()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  if tg_op = 'DELETE' then
    perform mk_refresh_rating(old.product_id);
    return old;
  end if;
  if tg_op = 'UPDATE' then
    new.updated_at := now();
  end if;
  perform mk_refresh_rating(new.product_id);
  return new;
end;
$$;

drop trigger if exists mk_reviews_after on mk_reviews;
create trigger mk_reviews_after after insert or update or delete on mk_reviews
  for each row execute function mk_reviews_touch();

-- The trigger above fires after the row is written, so updated_at needs
-- setting before it: a second, before-row trigger keeps that honest.
create or replace function mk_reviews_before()
returns trigger language plpgsql set search_path = public as $$
begin
  new.updated_at := now();
  return new;
end;
$$;
drop trigger if exists mk_reviews_before_upd on mk_reviews;
create trigger mk_reviews_before_upd before update on mk_reviews
  for each row execute function mk_reviews_before();

-- ------------------------------------------------------------------ RLS
alter table mk_reviews enable row level security;

-- Reviews of a published item are public: they are the point.
drop policy if exists mk_reviews_read on mk_reviews;
create policy mk_reviews_read on mk_reviews for select using (
  exists (select 1 from mk_products p where p.id = product_id and p.state = 'published')
);

-- Writing one requires owning the item, and being yourself.
drop policy if exists mk_reviews_write on mk_reviews;
create policy mk_reviews_write on mk_reviews for insert to authenticated
  with check (user_id = auth.uid() and mk_owns_product(auth.uid(), product_id));

drop policy if exists mk_reviews_edit on mk_reviews;
create policy mk_reviews_edit on mk_reviews for update to authenticated
  using (user_id = auth.uid()) with check (user_id = auth.uid());

drop policy if exists mk_reviews_remove on mk_reviews;
create policy mk_reviews_remove on mk_reviews for delete to authenticated
  using (user_id = auth.uid());

-- ---------------------------------------------------------------------
-- The house flag.
--
-- Your Brand listing its own work was paying itself a 20% fee — money moving
-- from one Your Brand pocket to the other through a wallet, a hold and a
-- withdrawal queue. A house shop keeps the whole amount and its items
-- skip the review queue, because the reviewer and the seller are the
-- same desk.
-- ---------------------------------------------------------------------
alter table mk_creators add column if not exists house boolean not null default false;

comment on column mk_creators.house is
  'Your Brand''s own shop: no commission, items publish without review.';

-- Commission now depends on who sold it.
create or replace function mk_record_sale(p_order_id uuid, p_hold_days integer default 7)
returns void language plpgsql security definer set search_path = public as $$
declare
  v_order   mk_orders%rowtype;
  v_creator uuid;
  v_house   boolean;
  v_fee     integer;
  v_note    text;
begin
  select * into v_order from mk_orders where id = p_order_id for update;
  if not found or v_order.status <> 'paid' then return; end if;

  select c.id, c.house into v_creator, v_house
    from mk_products p join mk_creators c on c.id = p.creator_id
   where p.id = v_order.product_id;
  if v_creator is null then return; end if;

  if v_house then
    v_fee := 0;
    v_note := 'Sale of a Your Brand item, no platform fee';
  else
    v_fee := round(v_order.amount_cents * mk_commission_bp() / 10000.0);
    v_note := 'Sale, less 20% platform fee';
  end if;

  update mk_orders
     set creator_id = v_creator,
         commission_cents = v_fee,
         creator_cents = v_order.amount_cents - v_fee
   where id = p_order_id;

  insert into mk_wallet_entries (creator_id, kind, amount_cents, currency, available_at, order_id, note)
  values (v_creator, 'sale', v_order.amount_cents - v_fee, v_order.currency,
          coalesce(v_order.paid_at, now()) + make_interval(days => p_hold_days),
          p_order_id, v_note)
  on conflict (order_id, kind) do nothing;
end;
$$;

-- ---------------------------------------------------------------------
-- Telling buyers about a new version.
--
-- The item page promises "future updates are included", which until now
-- was true of the file and invisible to the person who owns it. A note
-- and a timestamp let a creator announce a new version once, and stop
-- the same announcement going out twice.
-- ---------------------------------------------------------------------
alter table mk_products add column if not exists update_note text;
alter table mk_products add column if not exists update_sent_at timestamptz;

comment on column mk_products.update_note is
  'What changed in the latest version, as told to existing buyers.';
