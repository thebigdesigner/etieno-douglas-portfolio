import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import Link from "next/link";
import AuthShell from "@/components/AuthShell";
import StepProgress from "@/components/StepProgress";
import DetailsForm from "./DetailsForm";
import { createAdminClient } from "@/lib/supabase/admin";

export const metadata = { title: "Create an account" };
export const dynamic = "force-dynamic";

const COPY: Record<string, { title: string; intro: string }> = {
  learner: {
    title: "Set up your account",
    intro: "The first topic of every course is free, so you can look around before paying for anything.",
  },
  instructor: {
    title: "Set up your teaching account",
    intro: "Then you are straight into the studio. Nobody approves you first — we review the course when you submit it, not you.",
  },
  institution: {
    title: "Set up your organisation",
    intro: "The account opens immediately. Enrolling learners needs one verification step, which usually takes two working days.",
  },
};

export default async function DetailsPage() {
  const store = await cookies();
  const token = store.get("splari_device")?.value;
  if (!token) redirect("/signup");

  const admin = createAdminClient();
  const { data: check } = await admin
    .from("age_checks").select("intent")
    .eq("device_token", token).is("consumed_at", null)
    .order("created_at", { ascending: false }).limit(1).maybeSingle();

  if (!check) redirect("/signup");

  const intent = (check.intent ?? "learner") as "learner" | "instructor" | "institution";
  const copy = COPY[intent];

  return (
    <AuthShell
      progress={<StepProgress step={3} total={3} labels={["You", "Details", "Done"]} />}
      title={copy.title}
      intro={copy.intro}
      footer={
        <>
          Already have an account? <Link href="/login">Log in</Link>
          <br />
          <Link href="/signup/age">Back a step</Link>
        </>
      }
    >
      <DetailsForm intent={intent} />
    </AuthShell>
  );
}
