"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import type { FormState } from "@/lib/forms";

type Status = "idle" | "dirty" | "saving" | "saved" | "error";

/**
 * A form that saves itself.
 *
 * The editor had a Save button under every panel, which meant an instructor
 * could type for ten minutes and lose it by clicking a different topic. Edits
 * now commit on their own; the button is gone and a small status line says
 * where things stand.
 *
 * Applied only to forms that edit something that already exists. The "add a
 * question", "add a criterion", "add a module" forms keep their buttons —
 * adding is a decision, and an autosaving one would create a row per
 * keystroke.
 *
 * Three things this has to get right:
 *  - Debounce, or every keystroke is a write.
 *  - Sequence, or a slow save of "Introducti" lands after a fast save of
 *    "Introduction" and silently reverts the field.
 *  - Blur, so leaving a field commits it now rather than in 900ms.
 */
export default function AutosaveForm({
  action, children, className, idleLabel = "Saved automatically",
}: {
  action: (prev: FormState, formData: FormData) => Promise<FormState>;
  children: React.ReactNode;
  className?: string;
  idleLabel?: string;
}) {
  const form = useRef<HTMLFormElement>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);
  const seq = useRef(0);
  const pending = useRef(false);
  const [status, setStatus] = useState<Status>("idle");
  const [message, setMessage] = useState<string | null>(null);

  const save = useCallback(async () => {
    const el = form.current;
    if (!el) return;
    if (timer.current) { clearTimeout(timer.current); timer.current = null; }

    const mine = ++seq.current;
    pending.current = false;
    setStatus("saving");

    try {
      const result = await action({}, new FormData(el));
      // A newer edit already went out; its result is the truthful one.
      if (mine !== seq.current) return;
      if (result?.error) { setStatus("error"); setMessage(result.error); }
      else { setStatus("saved"); setMessage(null); }
    } catch {
      if (mine !== seq.current) return;
      setStatus("error");
      setMessage("Could not save that. Your text is still here — try again in a moment.");
    }
  }, [action]);

  function schedule() {
    pending.current = true;
    setStatus("dirty");
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(save, 900);
  }

  // Closing the tab mid-edit. The browser will not wait for a request, so the
  // honest thing is to warn rather than pretend it saved.
  useEffect(() => {
    const warn = (e: BeforeUnloadEvent) => {
      if (pending.current) { e.preventDefault(); e.returnValue = ""; }
    };
    window.addEventListener("beforeunload", warn);
    return () => {
      window.removeEventListener("beforeunload", warn);
      if (timer.current) clearTimeout(timer.current);
    };
  }, []);

  return (
    <form
      ref={form}
      className={className}
      onChange={schedule}
      onInput={schedule}
      /* Leaving a field commits it straight away — waiting out the debounce
         after somebody has visibly moved on reads as nothing happening. */
      onBlur={() => { if (pending.current) save(); }}
      onSubmit={(e) => { e.preventDefault(); save(); }}
    >
      {children}

      <p className={`asave asave--${status}`} role="status" aria-live="polite">
        {status === "saving" && "Saving…"}
        {status === "saved" && "Saved"}
        {status === "dirty" && "Unsaved changes"}
        {status === "error" && (message ?? "Not saved")}
        {status === "idle" && idleLabel}
      </p>
    </form>
  );
}
