/**
 * The engine both assistants run on: a model that can call tools, several at once, over a few
 * rounds, until it has what it needs to answer.
 *
 * Providers, tried in order — both free for an MVP and both speaking the OpenAI chat format with
 * native tool calling, so there is one code path:
 *   GEMINI_API_KEY  Google AI Studio. Models AI_MODELS (comma list, default
 *                   gemini-3.8-flash, gemini-3.7-flash, gemini-3.5-flash-lite), each its own quota.
 *                   AI_BASE_URL overrides the endpoint (local testing, or a paid gateway later).
 *   GROQ_API_KEY    Groq. Model GROQ_MODEL (default openai/gpt-oss-120b).
 * A provider that fails (quota, outage, retired model) hands over to the next one.
 */

const PER_CALL_MS = Number(process.env.AI_CALL_TIMEOUT_MS || 15000);

export function providers() {
  const list = [];
  /* Several free Gemini models, tried in turn. Each has its own free-tier capacity, so when the
     newest one is "experiencing high demand" (a 503 that is common on the free tier) the next
     one usually answers. AI_MODELS overrides the list; AI_MODEL alone puts one model first. */
  const models = (process.env.AI_MODELS || [process.env.AI_MODEL, 'gemini-3.8-flash', 'gemini-3.7-flash', 'gemini-3.5-flash-lite'].filter(Boolean).join(','))
    .split(',').map(x => x.trim()).filter((x, i, a) => x && a.indexOf(x) === i);
  if (process.env.GEMINI_API_KEY) for (const model of models) list.push({ name: 'gemini',
    url: process.env.AI_BASE_URL || 'https://generativelanguage.googleapis.com/v1beta/openai/chat/completions',
    key: process.env.GEMINI_API_KEY, model });
  if (process.env.GROQ_API_KEY) list.push({ name: 'groq', url: 'https://api.groq.com/openai/v1/chat/completions',
    key: process.env.GROQ_API_KEY, model: process.env.GROQ_MODEL || 'openai/gpt-oss-120b' });
  return list;
}

/** Says what went wrong in terms somebody can fix. */
export function explainFailure(err) {
  const s = err && err.status;
  return s === 404 ? 'model no longer exists — set AI_MODEL / GROQ_MODEL to a current one'
    : s === 429 ? 'free-tier limit reached for now'
    : s === 503 ? 'model busy (high demand on the free tier)'
    : /abort/i.test(String(err && err.message)) ? `no answer within ${PER_CALL_MS / 1000}s`
    : s === 403 ? 'refused — key permissions or billing'
    : s === 401 ? 'key rejected'
    : String(err && err.message || err).slice(0, 120);
}

/* Busy (503), rate-limited (429) or a hiccup (500): wait a moment and try the same model once
   more before giving up on it — most of these clear within a second or two. */
async function complete(p, messages, tools, opts) {
  try { return await completeOnce(p, messages, tools, opts); }
  catch (err) {
    /* A timeout is not retried on the same model — the next model is the better bet. */
    if (![429, 500, 503].includes(err.status) || opts.deadline - Date.now() < 8000) throw err;
    await new Promise(r => setTimeout(r, 1500));
    return completeOnce(p, messages, tools, opts);
  }
}

async function completeOnce(p, messages, tools, { deadline, maxTokens }) {
  /* Each call gets at most PER_CALL_MS. A model that has not answered by then is abandoned for
     the next one — waiting out the whole budget on one stuck request is what made a question
     take 48 seconds and then fail without trying anything else. */
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), Math.max(3000, Math.min(PER_CALL_MS, deadline - Date.now())));
  try {
    const body = { model: p.model, messages, temperature: 0.2, max_tokens: maxTokens,
      /* Both models think before answering and the thinking counts towards max_tokens; low
         effort keeps a turn quick without starving the answer. */
      reasoning_effort: 'low' };
    if (tools && tools.length) { body.tools = tools; body.tool_choice = 'auto'; }
    const res = await fetch(p.url, { method: 'POST', signal: ctrl.signal,
      headers: { Authorization: `Bearer ${p.key}`, 'Content-Type': 'application/json' }, body: JSON.stringify(body) });
    if (!res.ok) {
      const e = new Error(`${p.name} ${res.status} ${(await res.text().catch(() => '')).slice(0, 200)}`);
      e.status = res.status; throw e;
    }
    const data = await res.json();
    return data.choices?.[0]?.message || {};
  } finally { clearTimeout(timer); }
}

/**
 * Runs one turn. `exec(name, args)` runs a tool and returns a JSON-able result; it is called in
 * parallel when the model asks for several tools at once. Returns { reply, used, provider } or
 * throws when every provider failed.
 */
export async function runAgent({ system, history = [], question, tools, exec, maxRounds = 6,
                                  budgetMs = 22000, maxTokens = 2000, onProvider }) {
  const list = providers();
  if (!list.length) { const e = new Error('No AI provider is configured. Set GEMINI_API_KEY (free from aistudio.google.com) in Vercel.'); e.diagnosis = e.message; throw e; }
  const deadline = Date.now() + budgetMs;
  const failures = [];

  for (const p of list) {
    if (onProvider) onProvider(p);
    const used = [];
    const messages = [{ role: 'system', content: system }, ...history, { role: 'user', content: question }];
    try {
      for (let round = 0; round < maxRounds; round++) {
        const msg = await complete(p, messages, tools, { deadline, maxTokens });
        const calls = msg.tool_calls || [];
        if (!calls.length) {
          const reply = String(msg.content || '').trim();
          if (!reply) throw new Error(`${p.name}: empty reply`);
          return { reply, used, provider: `${p.name}:${p.model}` };
        }
        messages.push({ role: 'assistant', content: msg.content || '', tool_calls: calls });
        const results = await Promise.all(calls.map(async c => {
          let args = {};
          try { args = JSON.parse(c.function?.arguments || '{}'); } catch { return { c, out: { error: 'Arguments were not valid JSON.' } }; }
          try { return { c, out: await exec(c.function?.name, args) }; }
          catch (err) { console.error('tool failed:', c.function?.name, err.message); return { c, out: { error: `The ${c.function?.name} tool failed: ${err.message}` } }; }
        }));
        for (const { c, out } of results) {
          used.push({ tool: c.function?.name, ok: !(out && out.error) });
          messages.push({ role: 'tool', tool_call_id: c.id,
            content: typeof out === 'string' ? out : JSON.stringify(out) });
        }
        if (Date.now() > deadline - 3000) break;
      }
      /* Out of rounds or time: one last call with no tools, answering from what it has. */
      messages.push({ role: 'user', content: '(Time is up. Answer now from the tool results you already have. Say plainly if anything is incomplete.)' });
      const msg = await complete(p, messages, null, { deadline: deadline + 6000, maxTokens });
      const reply = String(msg.content || '').trim();
      if (!reply) throw new Error(`${p.name}: empty reply`);
      return { reply, used, provider: `${p.name}:${p.model}` };
    } catch (err) {
      console.error('assistant provider failed:', err.message);
      failures.push(`${p.name} (${p.model}): ${explainFailure(err)}`);
      if (deadline - Date.now() < 5000) break;   // not enough time left to try another model
    }
  }
  const e = new Error('The assistant is not answering right now.');
  e.diagnosis = failures.join('; ');
  throw e;
}
