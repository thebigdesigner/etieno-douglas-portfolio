-- =====================================================================
-- 0051 — the assistant can read the lesson the learner is on
--
-- Sara has only ever seen the catalogue: titles, summaries, subjects.
-- That is enough to help somebody choose a course and useless once they
-- are inside one, where the questions are "what does this mean" and
-- "summarise this before my exam".
--
-- Giving her the lesson text needs three things to stay true, and they
-- are the reason this is a database function rather than a query in the
-- route.
--
-- 1. ENTITLEMENT. The topic id arrives from the browser, in a path. It
--    is a client-supplied identifier, so it decides nothing: this asks
--    course_entitlement for the caller, exactly as the lesson page
--    does, and returns nothing at all when the answer is no. Without
--    that, asking Sara to "summarise topic X" would be a way to read
--    paid and institution-private material that 0047 just closed.
--
-- 2. NO ANSWER KEY. quiz_items.correct and exam_items.correct are not
--    selected here and never will be. 0044 removed the public read
--    policies on those tables precisely so the key stays server-side;
--    handing it to a chat assistant would reopen the same hole through
--    a politer door. Sara can be asked to explain a concept the quiz
--    covers. She cannot be told the answers, because she does not have
--    them.
--
-- 3. THE WORK STAYS THEIRS. The project brief and rubric are returned,
--    because a learner asking "what is this project actually asking
--    for" deserves an answer. The prompt forbids drafting any part of
--    the submission. The certificate says they did the work.
-- =====================================================================

create or replace function public.assistant_topic_context(
  p_user_id uuid,
  p_topic_id uuid
)
returns table (
  course_title  text,
  course_slug   text,
  module_title  text,
  topic_title   text,
  topic_body    text,
  transcript    text,
  project_brief text,
  rubric        text
)
language plpgsql
stable
security definer set search_path = public
as $$
declare
  v_course_id uuid;
  v_allowed   boolean;
begin
  if p_user_id is null or p_topic_id is null then return; end if;

  select c.id into v_course_id
    from topics t
    join modules m on m.id = t.module_id
    join courses c on c.id = m.course_id
   where t.id = p_topic_id;

  if v_course_id is null then return; end if;

  -- The single question, asked the same way every other surface asks it.
  select e.allowed into v_allowed
    from course_entitlement(p_user_id, v_course_id) e;

  if not coalesce(v_allowed, false) then return; end if;

  return query
  select
    c.title,
    c.slug,
    m.title,
    t.title,
    t.body,
    t.transcript,
    c.project_brief,
    (select string_agg(r.title || ': ' || r.descriptor, E'\n' order by r.position)
       from rubric_criteria r where r.course_id = c.id)
  from topics t
  join modules m on m.id = t.module_id
  join courses c on c.id = m.course_id
  where t.id = p_topic_id;
end; $$;

revoke all on function public.assistant_topic_context(uuid, uuid) from public, anon, authenticated;
grant execute on function public.assistant_topic_context(uuid, uuid) to service_role;

comment on function public.assistant_topic_context(uuid, uuid) is
  'Lesson content for the assistant, gated by course_entitlement. Deliberately excludes quiz_items.correct and exam_items.correct — see 0044.';
