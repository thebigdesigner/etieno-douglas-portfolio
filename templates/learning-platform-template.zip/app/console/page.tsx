import Link from "next/link";
import { createAdminClient } from "@/lib/supabase/admin";
import { requireOwner, money } from "@/lib/owner";

export const metadata = { title: "Console" };
export const dynamic = "force-dynamic";

export default async function ConsolePage() {
  await requireOwner();
  const admin = createAdminClient();

  const [{ data: metrics }, { data: health }, { data: revenue }, { data: queue }] =
    await Promise.all([
      admin.from("launch_metrics").select("*").maybeSingle(),
      admin.from("review_health").select("*").maybeSingle(),
      admin.from("revenue_summary").select("*").limit(2),
      admin.from("review_queue_status").select("submission_id, breached, due_soon"),
    ]);

  const m = (metrics ?? {}) as Record<string, number | null>;
  const h = (health ?? {}) as Record<string, number | null>;
  const thisMonth = (revenue ?? [])[0];
  const lastMonth = (revenue ?? [])[1];

  const breached = (queue ?? []).filter((q) => q.breached).length;
  const dueSoon = (queue ?? []).filter((q) => !q.breached && q.due_soon).length;

  // Instructor cost against institutional revenue. Subscriptions are not
  // wired to a provider yet, so this is a partial picture and says so.
  const grossCents = Number(thisMonth?.institutional_cents ?? 0);
  const costCents = Number(thisMonth?.instructor_cost_cents ?? 0);

  const alerts = [
    breached > 0 && {
      tone: "bad" as const,
      text: `${breached} review${breached === 1 ? "" : "s"} past the four-day promise`,
      href: "/admin/sla",
      cta: "Reassign",
    },
    Number(h.sla_pct ?? 100) < 90 && Number(h.reviews_total ?? 0) > 5 && {
      tone: "bad" as const,
      text: `SLA adherence is ${h.sla_pct}% — the gate is 90%`,
      href: "/console/integrity",
      cta: "Look",
    },
    costCents > grossCents && grossCents > 0 && {
      tone: "warn" as const,
      text: "Instructor cost is above institutional revenue this month",
      href: "/console/money",
      cta: "Check",
    },
    Number(m.courses_live ?? 0) < 15 && {
      tone: "warn" as const,
      text: `${m.courses_live ?? 0} courses live — a catalogue starts feeling real at 15`,
      href: "/console/catalogue",
      cta: "See",
    },
  ].filter(Boolean) as { tone: "bad" | "warn"; text: string; href: string; cta: string }[];

  return (
    <>
      <div className="con__head">
        <div>
          <h1 className="con__h">Where things stand</h1>
          <p className="con__sub">
            Everything on one page. The numbers here are the same ones the gates are
            measured against.
          </p>
        </div>
      </div>

      {alerts.length > 0 && (
        <div className="alerts">
          {alerts.map((a) => (
            <div key={a.text} className={`alert alert--${a.tone}`}>
              <span>{a.text}</span>
              <Link className="alert__go" href={a.href}>{a.cta} &rarr;</Link>
            </div>
          ))}
        </div>
      )}

      <div className="kpis">
        <Link className="kpi" href="/console/money">
          <div className="eyebrow">Institutional, this month</div>
          <div className="kpi__v num">{money(grossCents)}</div>
          <div className="kpi__s">
            {lastMonth ? `${money(Number(lastMonth.institutional_cents))} last month` : "First month"}
          </div>
        </Link>
        <Link className="kpi" href="/console/money">
          <div className="eyebrow">Owed to instructors</div>
          <div className="kpi__v num">{money(costCents)}</div>
          <div className="kpi__s">Reviews and pool, this month</div>
        </Link>
        <Link className="kpi" href="/console/integrity">
          <div className="eyebrow">SLA adherence</div>
          <div className={`kpi__v num${Number(h.sla_pct ?? 100) < 90 ? " is-bad" : ""}`}>
            {h.sla_pct ?? "—"}%
          </div>
          <div className="kpi__s">{h.reviews_total ?? 0} assessments, all time</div>
        </Link>
        <Link className="kpi" href="/console/people">
          <div className="eyebrow">Learners</div>
          <div className="kpi__v num">{m.learners ?? 0}</div>
          <div className="kpi__s">{m.learners_30d ?? 0} joined in 30 days</div>
        </Link>
      </div>

      <section className="con__sec">
        <h2 className="con__h2">The gates</h2>
        <div className="gates">
          {[
            { label: "Registered learners", value: Number(m.learners ?? 0), target: 500 },
            { label: "Reviewed projects", value: Number(m.projects_passed ?? 0), target: 50 },
            { label: "SLA adherence", value: Number(h.sla_pct ?? 0), target: 90, suffix: "%" },
            { label: "Paying institutions", value: Number(m.institutions_billed ?? 0), target: 5 },
          ].map((g) => {
            const pct = Math.min(100, Math.round((g.value / g.target) * 100));
            return (
              <div key={g.label} className={`gate2${g.value >= g.target ? " is-met" : ""}`}>
                <div className="gate2__v num">
                  {g.value}{g.suffix ?? ""} <span>of {g.target}{g.suffix ?? ""}</span>
                </div>
                <div className="gate2__label">{g.label}</div>
                <div className="dcrs__bar"><span style={{ width: `${pct}%` }} /></div>
              </div>
            );
          })}
        </div>
      </section>

      <section className="con__sec">
        <h2 className="con__h2">Right now</h2>
        <div className="dash__grid">
          {[
            ["In the review queue", (queue ?? []).length, dueSoon ? `${dueSoon} due within a day` : "All comfortable"],
            ["Courses live", m.courses_live ?? 0, `${m.instructors ?? 0} instructors`],
            ["Certificates held", m.certificates ?? 0, `${h.appeals ?? 0} appeals, ${h.appeals_upheld ?? 0} upheld`],
            ["Institutions", m.institutions ?? 0, `${m.institutions_billed ?? 0} billed recently`],
          ].map(([label, value, note]) => (
            <div key={String(label)} className="dash__card">
              <div className="eyebrow">{String(label)}</div>
              <div className="dash__val num">{String(value)}</div>
              <p className="dash__note">{String(note)}</p>
            </div>
          ))}
        </div>
      </section>

      <section className="con__sec">
        <h2 className="con__h2">Day to day</h2>
        <p className="studio__hint">
          The operations surface is separate. This console is for the questions you ask
          about the business, not the queue.
        </p>
        <div className="conlinks">
          {[
            ["SLA monitor", "/admin/sla"],
            ["Verification queue", "/admin/verification"],
            ["Courses awaiting review", "/admin/courses"],
            ["Appeals", "/admin/appeals"],
            ["Pools and payouts", "/admin/payouts"],
          ].map(([label, href]) => (
            <Link key={href} className="conlink" href={href}>{label} &rarr;</Link>
          ))}
        </div>
      </section>
    </>
  );
}
