/** A marketplace-relative "next" from the query string, or "/" if it is not one. */
export function mkNext(raw: string | string[] | undefined): string {
  const v = Array.isArray(raw) ? raw[0] : raw;
  if (!v || !v.startsWith("/") || v.startsWith("//") || v.includes("\\") || v.startsWith("/marketplace")) return "/";
  return v;
}
