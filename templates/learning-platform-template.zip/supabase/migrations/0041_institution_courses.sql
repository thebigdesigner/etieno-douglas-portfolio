-- =====================================================================
-- 0041 — institutions author their own courses
--
-- owner_kind has carried 'institution' since 0030 and nothing could ever
-- create one. Turning that on raises a question the other two owners do
-- not: who is it for.
--
-- A school writing its own induction course is writing it for its own
-- cohorts. Left alone, publishing it would put it in the public
-- catalogue — course_cards returns every published course — and
-- course_entitlement would treat it as subscription-covered, so any
-- Your Brand subscriber could read another organisation's internal material.
--
-- So an institution course is private: out of the catalogue, and open
-- only to that institution's own people. It is the one kind of course
-- that is not for sale and not part of the subscription.
-- =====================================================================

-- ---------------------------------------------------------------------
-- Out of the public catalogue.
-- ---------------------------------------------------------------------
-- The existing column order has to be preserved exactly: create or replace
-- cannot rename or reorder a view's columns, and every catalogue query
-- selects by name from this one.
create or replace view public.course_cards as
 SELECT c.slug,
    c.title,
    c.summary,
    c.subject,
    c.level,
    c.hours_low,
    c.hours_high,
    c.is_free,
    c.thumbnail_path,
    c.thumbnail_alt,
    c.published_at,
    p.display_name AS instructor,
    ( SELECT count(*) AS count
           FROM enrolments e
          WHERE e.course_id = c.id) AS learners,
    ( SELECT count(*) AS count
           FROM enrolments e
          WHERE e.course_id = c.id AND e.state = 'certified'::enrolment_state) AS graduates,
    ( SELECT count(*) AS count
           FROM modules m
             JOIN topics t ON t.module_id = m.id
          WHERE m.course_id = c.id) AS topics
   FROM courses c
     LEFT JOIN profiles p ON p.id = c.instructor_id
  WHERE c.state = 'published'::course_state
    -- An institution's own material is not part of anybody else's
    -- catalogue. Their cohorts reach it through their dashboard.
    AND c.owner_kind <> 'institution'::course_owner_kind;

-- ---------------------------------------------------------------------
-- Entitlement: an institution course belongs to its institution.
-- ---------------------------------------------------------------------
create or replace function public.course_entitlement(p_user_id uuid, p_course_id uuid)
returns table (
  allowed     boolean,
  reason      text,      -- free | purchased | subscription | cohort | licensed
                         -- | institution | needs_purchase | needs_plan
                         -- | needs_licence | not_your_institution
  needs_price int
)
language plpgsql
stable
security definer set search_path = public
as $$
declare
  v_course      courses%rowtype;
  v_owned       boolean;
  v_cohort      boolean;
  v_institution uuid;
  v_licensed    boolean;
  v_member      boolean;
begin
  select * into v_course from courses where id = p_course_id;
  if not found then
    return query select false, 'no_course'::text, null::int; return;
  end if;

  -- Which institution this person belongs to, by seat or by staff
  -- membership. Needed before the free check, because an institution
  -- course marked free is still only free to its own people.
  select coalesce(
    (select co.institution_id from cohort_seats s join cohorts co on co.id = s.cohort_id
      where s.user_id = p_user_id limit 1),
    (select m.institution_id from institution_members m where m.user_id = p_user_id limit 1)
  ) into v_institution;

  if v_course.owner_kind = 'institution' then
    v_member := v_institution is not null and v_institution = v_course.institution_id;
    if v_member then
      return query select true, 'institution'::text, null::int; return;
    end if;
    -- Not theirs to read, and nothing they can do about it.
    return query select false, 'not_your_institution'::text, null::int; return;
  end if;

  if v_course.is_free then
    return query select true, 'free'::text, null::int; return;
  end if;

  select exists (
    select 1 from enrolments e
     where e.user_id = p_user_id and e.course_id = p_course_id and e.source = 'cohort'
  ) into v_cohort;

  if v_course.owner_kind = 'instructor' and v_course.price_cents is not null then
    if v_cohort then
      select exists (
        select 1 from institution_licences l
         where l.institution_id = v_institution
           and l.course_id = p_course_id
           and l.refunded_at is null
      ) into v_licensed;

      if v_licensed then
        return query select true, 'licensed'::text, null::int; return;
      end if;
      return query select false, 'needs_licence'::text, v_course.price_cents; return;
    end if;

    select exists (
      select 1 from course_purchases cp
       where cp.user_id = p_user_id and cp.course_id = p_course_id and cp.refunded_at is null
    ) into v_owned;

    if v_owned then
      return query select true, 'purchased'::text, null::int; return;
    end if;
    return query select false, 'needs_purchase'::text, v_course.price_cents; return;
  end if;

  if v_cohort then
    return query select true, 'cohort'::text, null::int; return;
  end if;

  if has_live_subscription(p_user_id) then
    return query select true, 'subscription'::text, null::int; return;
  end if;

  return query select false, 'needs_plan'::text, null::int;
end;
$$;

-- ---------------------------------------------------------------------
-- Publishing: an institution course is neither sold nor subscribed, so
-- the price check does not apply to it. Everything else does — an
-- internal course still needs topics, quizzes, an exam and a rubric.
-- ---------------------------------------------------------------------
create or replace function public.submit_course_for_review(p_course_id uuid, p_instructor_id uuid)
returns table (ok boolean, reason text)
language plpgsql security definer set search_path = public as $$
declare
  v_course courses%rowtype;
  v_topics int; v_criteria int; v_quiz int; v_empty int; v_exam int;
begin
  select * into v_course from courses where id = p_course_id and instructor_id = p_instructor_id;
  if not found then
    return query select false, 'not_yours'; return;
  end if;

  if v_course.state not in ('draft','revision_requested') then
    return query select false, 'wrong_state'; return;
  end if;

  if v_course.thumbnail_path is null then
    return query select false, 'no_thumbnail'; return;
  end if;
  if v_course.hours_low is null or v_course.hours_high is null then
    return query select false, 'no_hours'; return;
  end if;

  if v_course.owner_kind = 'instructor'
     and not v_course.is_free
     and v_course.price_cents is null then
    return query select false, 'no_price'; return;
  end if;

  v_topics := live_topic_count(p_course_id);
  if v_topics < 3 then return query select false, 'too_few_topics'; return; end if;

  select count(*) into v_empty
    from topics t join modules m on m.id = t.module_id
   where m.course_id = p_course_id
     and m.archived_at is null and t.archived_at is null
     and coalesce(length(trim(t.body)), 0) < 40
     and not exists (select 1 from topic_materials tm where tm.topic_id = t.id);
  if v_empty > 0 then return query select false, 'empty_topics'; return; end if;

  select count(*) into v_quiz
    from quiz_items q join topics t on t.id = q.topic_id
    join modules m on m.id = t.module_id
   where m.course_id = p_course_id
     and m.archived_at is null and t.archived_at is null;
  if v_quiz < 3 then return query select false, 'too_few_questions'; return; end if;

  select count(*) into v_exam from exam_items where course_id = p_course_id;
  if v_exam < 5 then return query select false, 'too_few_exam_questions'; return; end if;

  if v_course.requires_project then
    if coalesce(length(trim(v_course.project_brief)), 0) < 120 then
      return query select false, 'brief_too_short'; return;
    end if;

    select count(*) into v_criteria from rubric_criteria where course_id = p_course_id;
    if v_criteria < 2 then return query select false, 'rubric_too_thin'; return; end if;
  end if;

  update courses set state = 'in_review' where id = p_course_id;
  return query select true, null::text;
end; $$;

-- ---------------------------------------------------------------------
-- Who an institution may name as assessor: its own staff, and any active
-- practitioner. Same rule as Your Brand's — a person, with a name for the
-- certificate.
-- ---------------------------------------------------------------------
create or replace function public.institution_assessors(p_institution_id uuid)
returns table (id uuid, name text, kind text)
language sql
stable
security definer set search_path = public
as $$
  select p.id, coalesce(p.display_name, p.email), 'Your staff'
    from institution_members m join profiles p on p.id = m.user_id
   where m.institution_id = p_institution_id
  union all
  select p.id, coalesce(p.display_name, p.email), 'Practitioner'
    from instructors i join profiles p on p.id = i.id
   where i.state = 'active'
   order by 3, 2;
$$;

revoke all on function public.institution_assessors(uuid) from public, anon;
grant execute on function public.institution_assessors(uuid) to authenticated, service_role;
