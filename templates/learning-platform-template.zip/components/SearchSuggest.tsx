"use client";

import { useEffect, useId, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import NavIcon from "@/components/NavIcon";
import { avatarUrl } from "@/lib/avatar";

type Suggestion = {
  kind: "course" | "subject" | "level";
  label: string;
  meta: string;
  href: string;
  thumb?: string | null;
  free?: boolean;
};

/**
 * The search box, with suggestions under it.
 *
 * Three bars used to do three different things: the top bar was a plain GET
 * form, the catalogue had its own input, and the home page had two dropdowns
 * and no text field at all. All three are this now, so a course typed in one
 * place behaves the same as in the others.
 *
 * Notes on the fiddly parts:
 *  - Requests are debounced and sequenced. Without the sequence check, a slow
 *    reply for "te" can land after a fast one for "tech" and put the wrong
 *    list on screen.
 *  - Blur closes the list, but on a delay: a mousedown on an option fires
 *    blur before click, so closing immediately means the click lands on
 *    nothing. The options use onMouseDown to navigate for the same reason.
 *  - Arrow keys move a highlight without moving the caret, Enter takes the
 *    highlighted option or, with nothing highlighted, runs the plain search.
 */
export default function SearchSuggest({
  placeholder = "Search courses…",
  className = "",
  defaultValue = "",
  autoFocus = false,
  onSubmitExtra,
}: {
  placeholder?: string;
  className?: string;
  defaultValue?: string;
  autoFocus?: boolean;
  /** Extra query params to carry to the results page (subject, level). */
  onSubmitExtra?: () => URLSearchParams;
}) {
  const router = useRouter();
  const listId = useId();
  const [q, setQ] = useState(defaultValue);
  const [items, setItems] = useState<Suggestion[]>([]);
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(-1);
  const [loading, setLoading] = useState(false);

  const root = useRef<HTMLDivElement>(null);
  const input = useRef<HTMLInputElement>(null);
  const seq = useRef(0);
  const closeTimer = useRef<ReturnType<typeof setTimeout> | null>(null);

  useEffect(() => {
    const text = q.trim();
    if (!text) { setItems([]); setLoading(false); return; }

    const mine = ++seq.current;
    setLoading(true);
    const t = setTimeout(async () => {
      try {
        const res = await fetch(`/api/search/suggest?q=${encodeURIComponent(text)}`);
        const json = await res.json();
        if (mine !== seq.current) return;          // a newer keystroke won
        setItems(json.suggestions ?? []);
        setActive(-1);
      } catch {
        if (mine === seq.current) setItems([]);
      } finally {
        if (mine === seq.current) setLoading(false);
      }
    }, 180);

    return () => clearTimeout(t);
  }, [q]);

  useEffect(() => {
    const away = (e: MouseEvent) => {
      if (root.current && !root.current.contains(e.target as Node)) setOpen(false);
    };
    document.addEventListener("mousedown", away);
    return () => document.removeEventListener("mousedown", away);
  }, []);

  function go(href: string) {
    setOpen(false);
    input.current?.blur();
    router.push(href);
  }

  function runSearch() {
    const text = q.trim();
    const params = onSubmitExtra ? onSubmitExtra() : new URLSearchParams();
    if (text) params.set("q", text);
    const qs = params.toString();
    go(qs ? `/courses?${qs}` : "/courses");
  }

  function onKeyDown(e: React.KeyboardEvent) {
    if (e.key === "Escape") { setOpen(false); return; }
    if (e.key === "Enter") {
      e.preventDefault();
      if (open && active >= 0 && items[active]) go(items[active].href);
      else runSearch();
      return;
    }
    if (e.key !== "ArrowDown" && e.key !== "ArrowUp") return;
    if (!items.length) return;
    e.preventDefault();                       // otherwise the caret jumps
    setOpen(true);
    setActive((i) => {
      const n = items.length;
      return e.key === "ArrowDown" ? (i + 1) % n : (i <= 0 ? n - 1 : i - 1);
    });
  }

  const show = open && !!q.trim() && (items.length > 0 || !loading);

  return (
    <div className={`ssearch ${className}`.trim()} ref={root}>
      <div className="ssearch__bar">
        <NavIcon name="search" size={16} />
        <input
          ref={input}
          value={q}
          onChange={(e) => { setQ(e.target.value); setOpen(true); }}
          onFocus={() => setOpen(true)}
          onBlur={() => {
            if (closeTimer.current) clearTimeout(closeTimer.current);
            closeTimer.current = setTimeout(() => setOpen(false), 140);
          }}
          onKeyDown={onKeyDown}
          placeholder={placeholder}
          aria-label={placeholder}
          autoFocus={autoFocus}
          autoComplete="off"
          role="combobox"
          aria-expanded={show}
          aria-controls={listId}
          aria-autocomplete="list"
          aria-activedescendant={active >= 0 ? `${listId}-${active}` : undefined}
        />
        {q && (
          <button type="button" className="ssearch__clear" aria-label="Clear search"
            onMouseDown={(e) => { e.preventDefault(); setQ(""); input.current?.focus(); }}>
            ✕
          </button>
        )}
      </div>

      {show && (
        <div className="ssearch__pop" id={listId} role="listbox">
          {items.length === 0 ? (
            <p className="ssearch__none">Nothing matches “{q.trim()}” yet.</p>
          ) : (
            items.map((s, i) => {
              const thumb = s.kind === "course" ? avatarUrl(s.thumb) : null;
              return (
                <div
                  key={s.href + s.label}
                  id={`${listId}-${i}`}
                  role="option"
                  aria-selected={i === active}
                  className={`ssearch__opt${i === active ? " is-active" : ""}`}
                  onMouseEnter={() => setActive(i)}
                  onMouseDown={(e) => { e.preventDefault(); go(s.href); }}
                >
                  <span className={`ssearch__ico ssearch__ico--${s.kind}`} aria-hidden="true">
                    {thumb
                      ? <img src={thumb} alt="" />
                      : <NavIcon name={s.kind === "course" ? "book" : "grid"} size={15} />}
                  </span>
                  <span className="ssearch__body">
                    <span className="ssearch__label">{s.label}</span>
                    <span className="ssearch__meta">{s.meta}</span>
                  </span>
                  {s.free && <span className="ssearch__free">Free</span>}
                </div>
              );
            })
          )}

          <button type="button" className="ssearch__all"
            onMouseDown={(e) => { e.preventDefault(); runSearch(); }}>
            See all results
          </button>
        </div>
      )}
    </div>
  );
}
