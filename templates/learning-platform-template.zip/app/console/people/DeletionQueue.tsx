"use client";

import { useActionState, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { eraseAccount, cancelDeletion } from "@/app/actions/console";
import type { FormState } from "@/lib/forms";
import Alert from "@/components/Alert";
import SubmitButton from "@/components/SubmitButton";

const initial: FormState = {};

export type DeletionRow = {
  id: string;
  user_id: string;
  display_name: string | null;
  email: string | null;
  requested_at: string;
  due_at: string;
  reason: string | null;
  overdue: boolean;
  enrolments: number;
  certificates: number;
  purchases: number;
  courses_to_retire: number;
  blocking_courses: number;
  open_reviews: number;
};

/**
 * Requests to be erased, and the control that completes one.
 *
 * This panel is the half that was missing. The account page has always
 * told people "we complete the erasure within 30 days and will confirm by
 * email", and the request went into an events table nothing reads — so
 * the commitment could not be kept by anyone, however willing.
 *
 * The counts are shown because erasure is not reversible and the operator
 * should see what the account is attached to before doing it. They are
 * also the argument for anonymising rather than deleting: those purchases
 * and certificates do not belong solely to the person leaving.
 */
function Row({ row }: { row: DeletionRow }) {
  const [erased, doErase] = useActionState(eraseAccount.bind(null, row.user_id), initial);

  /* The withdrawal used to be a bare onClick calling the action without
   * awaiting it: nothing refreshed, no error surfaced, and the row stayed
   * on screen — so it read as a dead button. The same shape as the account
   * deletion that "did not work". */
  const [cancelling, startCancel] = useTransition();
  const [cancelMsg, setCancelMsg] = useState<FormState>(initial);
  const router = useRouter();

  return (
    <article className={`delreq${row.overdue ? " is-overdue" : ""}`}>
      <div className="delreq__head">
        <div>
          <span className="delreq__name">{row.display_name ?? "Someone"}</span>
          <span className="delreq__email">{row.email ?? "no address on file"}</span>
        </div>
        <span className={`pill${row.overdue ? "" : " pill--free"}`}
              style={row.overdue ? { background: "#FFE4EC", color: "#9B1B41" } : undefined}>
          {row.overdue ? "Overdue" : `Due ${new Date(row.due_at).toLocaleDateString()}`}
        </span>
      </div>

      <p className="delreq__meta num">
        Asked {new Date(row.requested_at).toLocaleDateString()} ·{" "}
        {row.enrolments} enrolment{row.enrolments === 1 ? "" : "s"} ·{" "}
        {row.certificates} certificate{row.certificates === 1 ? "" : "s"} ·{" "}
        {row.purchases} purchase{row.purchases === 1 ? "" : "s"}
      </p>

      {row.reason && <p className="delreq__reason">“{row.reason}”</p>}

      {erased.error && <Alert kind="error">{erased.error}</Alert>}
      {erased.ok && <Alert kind="success">{erased.message}</Alert>}
      {cancelMsg.error && <Alert kind="error">{cancelMsg.error}</Alert>}
      {cancelMsg.ok && <Alert kind="success">{cancelMsg.message}</Alert>}

      {row.blocking_courses > 0 && (
        <Alert kind="error">
          They are the named assessor on {row.blocking_courses} course
          {row.blocking_courses === 1 ? "" : "s"} somebody else owns. Erasure is
          refused until you name a replacement — retiring another party&rsquo;s
          course to clear this is not something we will do automatically.
        </Alert>
      )}
      {row.open_reviews > 0 && (
        <Alert kind="error">
          {row.open_reviews} submission{row.open_reviews === 1 ? " is" : "s are"} still
          assigned to them. Reassign from the SLA monitor first, or the work will
          sit past its deadline with nobody able to read it.
        </Alert>
      )}

      <form action={doErase} className="delreq__form">
        <p className="delreq__warn">
          Erasing clears their name, address, avatar, notes, conversations and the
          contents of anything they submitted. Enrolments, purchases, completions
          and certificates stay, attached to nobody — deleting those would rewrite
          what instructors were paid and take a practitioner’s name off their own
          record.
          {row.courses_to_retire > 0 && (
            <>
              {" "}
              {row.courses_to_retire} course{row.courses_to_retire === 1 ? "" : "s"} they
              own will be retired: no new sales, and everyone already enrolled keeps
              their place.
            </>
          )}{" "}
          Their name stays on certificates they signed — that is somebody else&rsquo;s
          credential, and blanking it would devalue work they had no part in.
        </p>
        <div className="delreq__acts">
          <input name="confirm" placeholder="Type ERASE" required
                 autoComplete="off" spellCheck={false} />
          <SubmitButton>Erase this account</SubmitButton>
          <button
            type="button"
            className="btn btn--line"
            disabled={cancelling}
            onClick={() =>
              startCancel(async () => {
                setCancelMsg(await cancelDeletion(row.user_id));
                router.refresh();
              })
            }
          >
            {cancelling ? "Withdrawing…" : "They want to stay"}
          </button>
        </div>
      </form>
    </article>
  );
}

export default function DeletionQueue({ rows }: { rows: DeletionRow[] }) {
  if (rows.length === 0) return null;

  return (
    <section className="con__sec">
      <h2 className="con__h2">
        {rows.length} account{rows.length === 1 ? "" : "s"} asked to be deleted
      </h2>
      <p className="studio__hint" style={{ marginTop: 6 }}>
        Each was told we would finish within 30 days. That is a commitment in
        writing, so an overdue row here is a promise being broken.
      </p>
      <div className="delreqs">
        {rows.map((r) => <Row key={r.id} row={r} />)}
      </div>
    </section>
  );
}
