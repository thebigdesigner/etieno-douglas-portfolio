-- =====================================================================
-- 0044 — the answer key is not public
--
-- exam_items and quiz_items each carry a `correct` column and an
-- `explanation`, and each had a policy letting anybody read the whole
-- row on any published course:
--
--   create policy public_exam_items on exam_items for select using (
--     exists (select 1 from courses c
--              where c.id = exam_items.course_id and c.state = 'published'));
--
-- There is no auth.uid() in that condition, so it is not "any learner"
-- — it is anyone at all, signed in or not, holding the anon key that
-- every visitor's browser already has. Two requests get you every
-- answer to every exam on the platform, and an exam is 80% to pass
-- with unlimited retakes. That is an `examined` certificate for
-- somebody who never read a topic.
--
-- The policies were never load-bearing. Every read of either table in
-- the entire codebase goes through the service-role client, which
-- bypasses RLS: the exam page selects id, prompt and options and
-- deliberately omits the key; grading happens in app/actions/exam.ts,
-- server-side, comparing against a key the browser is never sent. So
-- these policies granted an access nothing uses and everything else
-- was careful to avoid.
--
-- Dropped rather than narrowed. A policy that lets a learner read the
-- questions but not the answers cannot be written in RLS alone —
-- row-level security has no opinion about columns — and narrowing it
-- to enrolled learners would still hand the key to anybody enrolled.
-- The column grants go too, so a future policy cannot reopen the key
-- by accident.
-- =====================================================================

drop policy if exists public_exam_items on exam_items;
drop policy if exists public_quiz_items on quiz_items;

-- Belt and braces: even with a permissive policy added later, these
-- roles cannot read the two columns that matter.
revoke select (correct, explanation) on exam_items from anon, authenticated;
revoke select (correct, explanation) on quiz_items from anon, authenticated;

comment on column exam_items.correct is
  'Answer key. Server-side only: read exclusively by the service-role client in app/actions/exam.ts. No RLS policy exposes this table — see 0044.';
comment on column quiz_items.correct is
  'Answer key. Server-side only: read exclusively by the service-role client in app/actions/learning.ts. No RLS policy exposes this table — see 0044.';
