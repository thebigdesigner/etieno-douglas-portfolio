import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import NewCourseForm from "@/app/studio/NewCourseForm";

export const metadata = { title: "Write a course" };
export const dynamic = "force-dynamic";

export default async function InstitutionNewCoursePage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login?next=/institution/courses/new");

  const admin = createAdminClient();
  const { data: member } = await admin
    .from("institution_members").select("institution_id")
    .eq("user_id", user.id).maybeSingle();
  if (!member) redirect("/institution");

  const { data: assessors } = await admin
    .rpc("institution_assessors", { p_institution_id: member.institution_id });

  return (
    <>
      <nav className="crumb" style={{ paddingTop: 4 }}>
        <Link href="/institution/courses">Your courses</Link> / Write a course
      </nav>

      <h1 className="con__h" style={{ marginTop: 12 }}>Write a course</h1>
      <p className="con__sub" style={{ maxWidth: "60ch" }}>
        Open to your cohorts only, and not listed in the public catalogue. Somebody
        still assesses the final project — your own staff, or a practitioner — and
        their name goes on every certificate it issues.
      </p>

      <div style={{ marginTop: 22 }}>
        <NewCourseForm isInstitution assessors={assessors ?? []} />
      </div>
    </>
  );
}
