/**
 * The shop's own wait. The rail and top bar belong to the layout and stay
 * where they are, so only the page body needs standing in for: the hero
 * pair, the tiles and a row of cards, at the sizes the real ones use. The
 * shapes hold the scroll position steady, so nothing jumps when the
 * content lands.
 */
export default function MarketplaceLoading() {
  return (
    <div className="mk-load" role="status" aria-live="polite">
      <span className="sr">Loading</span>
      <div className="mk-heroes" aria-hidden="true">
        <div className="mk-skel mk-skel--hero" />
        <div className="mk-skel mk-skel--feature" />
      </div>
      <div className="mk-tiles-row" aria-hidden="true">
        <div className="mk-skel mk-skel--tile" />
        <div className="mk-skel mk-skel--tile" />
        <div className="mk-skel mk-skel--tile" />
      </div>
      <div className="mk-load__sec" aria-hidden="true">
        <div className="mk-skel mk-skel--head" />
        <div className="mk-shelf">
          {Array.from({ length: 6 }, (_, i) => (
            <div className="mk-skel mk-skel--card" key={i} />
          ))}
        </div>
      </div>
    </div>
  );
}
