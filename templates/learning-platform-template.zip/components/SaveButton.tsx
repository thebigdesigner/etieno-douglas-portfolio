"use client";

import { toggleSaved } from "@/app/actions/student";
import { useFormStatus } from "react-dom";

function Inner({ saved }: { saved: boolean }) {
  const { pending } = useFormStatus();
  return (
    <button className={`savebtn${saved ? " is-on" : ""}`} disabled={pending}
      aria-label={saved ? "Remove from saved" : "Save this course"}>
      <span aria-hidden="true">{saved ? "★" : "☆"}</span>
      {saved ? "Saved" : "Save"}
    </button>
  );
}

export default function SaveButton({ slug, saved }: { slug: string; saved: boolean }) {
  return (
    <form action={toggleSaved.bind(null, slug)}>
      <Inner saved={saved} />
    </form>
  );
}
