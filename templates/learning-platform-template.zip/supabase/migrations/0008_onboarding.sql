-- =====================================================================
-- Self-serve onboarding for instructors and institutions
-- =====================================================================

create type signup_intent as enum ('learner', 'instructor', 'institution');
create type verification_state as enum ('unverified', 'pending', 'verified', 'rejected');

-- What they said they were here for, captured at signup rather than inferred.
alter table profiles add column intent signup_intent not null default 'learner';

-- Carried from the age step through to account creation, so the intent
-- survives the page navigation without a query string to tamper with.
alter table age_checks add column intent signup_intent not null default 'learner';

-- ---------------------------------------------------------------------
-- Institutions verify with documents. Everything else about the account
-- works first — they can look around, they just cannot enrol anyone.
-- ---------------------------------------------------------------------
alter table institutions
  add column owner_id      uuid references profiles(id) on delete set null,
  add column verification  verification_state not null default 'unverified',
  add column country       text,
  add column website       text,
  add column submitted_at  timestamptz,
  add column reviewed_at   timestamptz,
  add column reviewed_by   uuid references profiles(id),
  add column review_note   text;

create index on institutions (verification) where verification = 'pending';

create table institution_documents (
  id             uuid primary key default gen_random_uuid(),
  institution_id uuid not null references institutions(id) on delete cascade,
  kind           text not null,      -- registration, letterhead, id, other
  path           text not null,
  filename       text not null,
  uploaded_at    timestamptz not null default now()
);

alter table institution_documents enable row level security;

create policy own_institution_documents on institution_documents for select using (
  exists (select 1 from institution_members m
           where m.institution_id = institution_documents.institution_id
             and m.user_id = auth.uid())
);

/**
 * Created by the person signing up, not by an operator. They get an account
 * immediately and a verification gate in front of the parts that matter.
 */
create or replace function public.register_institution(
  p_owner_id uuid, p_name text, p_contact_email text,
  p_country text, p_website text
)
returns uuid
language plpgsql security definer set search_path = public as $$
declare v_id uuid;
begin
  if exists (select 1 from institution_members where user_id = p_owner_id) then
    return null;
  end if;

  insert into institutions (name, contact_email, plan, owner_id, country, website, verification)
  values (p_name, p_contact_email, 'plus', p_owner_id, p_country, nullif(p_website, ''), 'unverified')
  returning id into v_id;

  insert into institution_members (institution_id, user_id) values (v_id, p_owner_id);
  update profiles set role = 'institution_admin' where id = p_owner_id;

  return v_id;
end; $$;

create or replace function public.submit_institution_verification(p_institution_id uuid)
returns table (ok boolean, reason text)
language plpgsql security definer set search_path = public as $$
declare v_docs int;
begin
  select count(*) into v_docs from institution_documents where institution_id = p_institution_id;
  if v_docs < 1 then
    return query select false, 'no_documents'; return;
  end if;

  update institutions
     set verification = 'pending', submitted_at = now()
   where id = p_institution_id and verification in ('unverified', 'rejected');

  if not found then return query select false, 'wrong_state'; return; end if;
  return query select true, null::text;
end; $$;

create or replace function public.decide_institution_verification(
  p_institution_id uuid, p_operator_id uuid, p_approve boolean, p_note text
)
returns boolean
language plpgsql security definer set search_path = public as $$
begin
  update institutions
     set verification = case when p_approve then 'verified'::verification_state
                             else 'rejected'::verification_state end,
         reviewed_at = now(), reviewed_by = p_operator_id, review_note = p_note
   where id = p_institution_id and verification = 'pending';
  return found;
end; $$;

/** Cohorts require a verified institution. Enforced here, not in the form. */
create or replace function public.institution_can_enrol(p_institution_id uuid)
returns boolean
language sql stable security definer set search_path = public as $$
  select verification = 'verified' from institutions where id = p_institution_id;
$$;

-- ---------------------------------------------------------------------
-- Instructors apply from inside their own account, so the row is created
-- alongside the profile rather than through a separate public form.
-- ---------------------------------------------------------------------
create or replace function public.register_instructor(p_user_id uuid)
returns boolean
language plpgsql security definer set search_path = public as $$
begin
  if exists (select 1 from instructors where id = p_user_id) then return false; end if;
  insert into instructors (id, state) values (p_user_id, 'applied');
  update profiles set role = 'instructor' where id = p_user_id;
  return true;
end; $$;

-- An applied instructor holds the role but not the permissions: course
-- creation and the review queue both check state, not role.
create or replace function public.instructor_is_active(p_user_id uuid)
returns boolean
language sql stable security definer set search_path = public as $$
  select state = 'active' from instructors where id = p_user_id;
$$;

revoke all on function public.register_institution(uuid, text, text, text, text) from public, anon, authenticated;
revoke all on function public.submit_institution_verification(uuid) from public, anon, authenticated;
revoke all on function public.decide_institution_verification(uuid, uuid, boolean, text) from public, anon, authenticated;
revoke all on function public.register_instructor(uuid) from public, anon, authenticated;

-- Verification documents: private bucket, owner-scoped writes.
insert into storage.buckets (id, name, public, file_size_limit)
values ('verification', 'verification', false, 15728640)
on conflict (id) do nothing;

create policy "institutions upload own verification"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'verification' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "institutions read own verification"
  on storage.objects for select to authenticated
  using (bucket_id = 'verification' and (storage.foldername(name))[1] = auth.uid()::text);


-- Extend the signup trigger to carry intent through from the auth metadata.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (
    id, email, display_name, date_of_birth, account_type,
    segment, guardian_email, status, minor_protections, consent_required, intent
  )
  values (
    new.id,
    new.email,
    nullif(new.raw_user_meta_data->>'display_name', ''),
    nullif(new.raw_user_meta_data->>'date_of_birth', '')::date,
    coalesce((new.raw_user_meta_data->>'account_type')::account_type, 'adult'),
    nullif(new.raw_user_meta_data->>'segment', ''),
    nullif(new.raw_user_meta_data->>'guardian_email', ''),
    case when (new.raw_user_meta_data->>'consent_required')::boolean
         then 'pending_consent'::profile_status
         else 'active'::profile_status end,
    coalesce((new.raw_user_meta_data->>'minor_protections')::boolean, false),
    coalesce((new.raw_user_meta_data->>'consent_required')::boolean, false),
    coalesce((new.raw_user_meta_data->>'intent')::signup_intent, 'learner')
  );
  return new;
end;
$$;
