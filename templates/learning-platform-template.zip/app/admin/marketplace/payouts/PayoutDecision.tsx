"use client";
import { useActionState } from "react";
import { useFormStatus } from "react-dom";
import { decidePayout } from "@/app/actions/marketplace";
import type { FormState } from "@/lib/forms";
import Alert from "@/components/Alert";

function Btn({ label, variant }: { label: string; variant: string }) {
  const { pending } = useFormStatus();
  return <button className={`btn ${variant}`} disabled={pending}>{pending ? "…" : label}</button>;
}

export default function PayoutDecision({ id, status }: { id: string; status: string }) {
  const [state, action] = useActionState<FormState, FormData>(decidePayout, {});
  if (state.ok) return <Alert kind="success">Done.</Alert>;
  return (
    <div className="app__decide">
      {status === "requested" && (
        <form action={action}>
          <input type="hidden" name="id" value={id} />
          <input type="hidden" name="decision" value="approve" />
          <Btn label="Approve" variant="btn--line" />
        </form>
      )}
      <form action={action} className="app__reject">
        <input type="hidden" name="id" value={id} />
        <input type="hidden" name="decision" value="paid" />
        <input name="reference" placeholder="Bank or Paystack transfer reference" />
        <Btn label="Mark paid" variant="btn--fill" />
      </form>
      <form action={action} className="app__reject">
        <input type="hidden" name="id" value={id} />
        <input type="hidden" name="decision" value="reject" />
        <input name="note" placeholder="Why it is being sent back" />
        <Btn label="Send back" variant="btn--line" />
      </form>
      {state.error && <Alert kind="error">{state.error}</Alert>}
    </div>
  );
}
