import type { Metadata } from "next";
import Link from "next/link";
import { marketBase, mk } from "@/lib/marketplace/url";
import AuthShell from "@/components/marketplace/auth/AuthShell";
import { ForgotForm } from "@/components/marketplace/auth/AuthForms";

export const metadata: Metadata = { title: "Reset your password", robots: { index: false } };

export default async function MarketForgot() {
  const base = await marketBase();
  return (
    <AuthShell homeHref={mk(base, "/")} title="Reset your password" lead="Enter the email on your Your Brand account and we will send a link to choose a new password."
      foot={<>Remembered it? <Link href={mk(base, "/login")} className="au__link">Back to sign in</Link></>}>
      <ForgotForm />
    </AuthShell>
  );
}
