-- =====================================================================
-- 0047 — the paywall exists in the database too
--
-- The read policies on the content tables were written when every
-- published course was free and public, and were never revisited when
-- paid courses (0030/0031) and private institution courses (0041)
-- arrived. Each says, in effect, "published means readable by anybody":
--
--   public_topics      published course  -> read any topic, body included
--   public_materials   published course  -> read every material path
--   public_modules     published course  -> read the whole structure
--   public_rubric      published course  -> read the rubric
--   public_courses     published         -> read the course row
--   public_certificate_lookup            -> USING (true)
--
-- None mentions auth.uid(). These are not "any learner" — they are
-- anyone at all, signed in or not, holding the anon key that every
-- visitor's browser is given. Verified by query against this schema:
--
--   · the full body of a $99 course's lesson, read as anon
--   · CONFIDENTIAL text from a published institution course, as anon
--   · every certificate code and reviewer name, enumerated as anon
--   · every material path, which with the storage policy below is the
--     file itself
--
-- course_entitlement guards the lesson page correctly. The database was
-- answering the same question differently, and the database is the one
-- that can be asked directly.
--
-- The fix is shaped by what actually reads these tables. Every read in
-- the codebase was traced first: modules, topic_materials,
-- rubric_criteria, certificates and course_templates are read
-- exclusively through the service-role client, which bypasses RLS, so
-- their policies grant an access nothing uses and are dropped outright.
-- Only courses and topics have user-scoped reads, so only those two
-- keep a policy, narrowed to what those pages genuinely need.
-- =====================================================================

-- ---------------------------------------------------------------------
-- Dropped: nothing reads these except the service-role client.
-- ---------------------------------------------------------------------
drop policy if exists public_modules   on modules;
drop policy if exists public_materials on topic_materials;
drop policy if exists public_rubric    on rubric_criteria;
drop policy if exists public_templates on course_templates;

-- Verification is a code lookup, not a table. The page reads it through
-- the service-role client, so `USING (true)` bought nothing and allowed
-- the whole table to be enumerated — every code and reviewer name, and
-- from there the /verify pages, walking around show_name, which exists
-- to keep minors' names off public pages.
drop policy if exists public_certificate_lookup on certificates;

-- ---------------------------------------------------------------------
-- courses: the marketing row stays public, minus private material.
--
-- Read user-scoped by the public course page, the lesson and exam
-- pages, and the submit page, so it keeps a policy. An institution's
-- course is not part of anybody else's world: 0041 took it out of the
-- catalogue, 0043 out of search, and this takes it out of the table.
-- ---------------------------------------------------------------------
drop policy if exists public_courses on courses;
create policy public_courses on courses for select using (
  state = 'published'::course_state
  and owner_kind <> 'institution'::course_owner_kind
);

-- ---------------------------------------------------------------------
-- topics: entitlement, not publication.
--
-- The lesson page reads one topic through the user-scoped client, so
-- this policy has to admit exactly what a person may actually read:
--
--   · a free-sample topic on a course that is not for sale — this is
--     what makes the public outline and the first-topic preview work,
--     and decide_course marks the first topic free on publish;
--   · every topic on a course they are entitled to, which is the same
--     question course_entitlement answers for the page.
--
-- Anything else is now invisible rather than merely un-navigated. The
-- studio and console read topics through the service-role client, so
-- authoring is unaffected.
-- ---------------------------------------------------------------------
-- The check runs inside a security-definer function rather than as a
-- join in the policy itself. A policy's own subqueries are evaluated
-- under the reader's RLS, so joining modules here would ask a table
-- that (correctly) no longer has a read policy, and the answer would
-- be "no rows" for everybody — the entitled buyer included. Asking a
-- definer function keeps the question about entitlement rather than
-- about who may read the join.
create or replace function public.topic_readable(p_topic_id uuid, p_user_id uuid)
returns boolean
language sql
stable
security definer set search_path = public
as $$
  select exists (
    select 1
      from topics t
      join modules m on m.id = t.module_id
      join courses c on c.id = m.course_id
     where t.id = p_topic_id
       and c.state = 'published'::course_state
       and (
         -- A free sample, on a course that is not sold outright and is
         -- not an institution's private material.
         (
           t.is_free
           and c.owner_kind <> 'institution'::course_owner_kind
           and not (c.owner_kind = 'instructor'::course_owner_kind
                    and c.price_cents is not null
                    and not c.is_free)
         )
         -- Or this reader is entitled to the course, by the same
         -- function the lesson page asks.
         or (
           p_user_id is not null
           and (select allowed from course_entitlement(p_user_id, c.id))
         )
       )
  );
$$;

revoke all on function public.topic_readable(uuid, uuid) from public, anon;
grant execute on function public.topic_readable(uuid, uuid) to authenticated, anon, service_role;

drop policy if exists public_topics on topics;
create policy public_topics on topics for select using (
  topic_readable(topics.id, auth.uid())
);

-- ---------------------------------------------------------------------
-- Storage: materials were readable by any signed-in account.
--
-- `bucket_id = 'materials'` with no path or entitlement condition means
-- one authenticated session could fetch every course's files — paid
-- workbooks, an institution's internal documents — given a path, and
-- the paths were readable from topic_materials above.
--
-- The lesson page serves materials as service-role signed URLs
-- (createSignedUrl in app/learn/[slug]/[topicId]/page.tsx), which does
-- not consult this policy, so removing it changes nothing a learner
-- sees. Thumbnails and avatars stay public: they are the catalogue's
-- images and people's own faces, both already shown to everyone.
-- ---------------------------------------------------------------------
drop policy if exists "authenticated read materials" on storage.objects;
