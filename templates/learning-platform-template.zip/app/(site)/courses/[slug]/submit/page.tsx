import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import SubmitForm from "./SubmitForm";

export const metadata = { title: "Submit your project" };
export const dynamic = "force-dynamic";

type Params = Promise<{ slug: string }>;

export default async function SubmitPage({ params }: { params: Params }) {
  const { slug } = await params;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect(`/login?next=/courses/${slug}/submit`);

  const { data: course } = await supabase
    .from("courses").select("id, title, project_brief")
    .eq("slug", slug).eq("state", "published").maybeSingle();
  if (!course) notFound();

  const admin = createAdminClient();

  const { data: criteria } = await admin
    .from("rubric_criteria").select("id, title, descriptor, max_score")
    .eq("course_id", course.id).order("position");

  const { data: enrolment } = await admin
    .from("enrolments").select("id, source")
    .eq("user_id", user.id).eq("course_id", course.id).maybeSingle();

  if (!enrolment) redirect(`/courses/${slug}`);

  const { data: outline } = await admin.rpc("course_outline", {
    p_course_id: course.id, p_user_id: user.id,
  });
  const rows = (outline ?? []) as { completed: boolean }[];
  const remaining = rows.filter((t) => !t.completed).length;

  const { data: last } = await admin
    .from("submissions").select("state, attempt_no, deadline_at")
    .eq("enrolment_id", enrolment.id)
    .order("attempt_no", { ascending: false }).limit(1).maybeSingle();

  const isResubmission = last?.state === "revision_requested";
  const free = isResubmission && last.attempt_no === 1;

  return (
    <main className="sec">
      <div className="wrap sub">
        <nav className="crumb">
          <Link href="/courses">Courses</Link> /{" "}
          <Link href={`/courses/${slug}`}>{course.title}</Link> / Final project
        </nav>

        <h1 className="sub__h">
          {isResubmission ? "Send your revised project" : "Submit your final project"}
        </h1>

        {remaining > 0 ? (
          <div className="empty" style={{ marginTop: 26 }}>
            <p className="empty__h">Finish the course first</p>
            <p className="empty__p">
              {remaining} topic{remaining === 1 ? "" : "s"} still to complete before the
              project opens.
            </p>
            <Link className="btn btn--fill btn--lg" href={`/courses/${slug}`} style={{ marginTop: 20 }}>
              Back to the course
            </Link>
          </div>
        ) : last?.state === "submitted" || last?.state === "assigned" || last?.state === "in_review" ? (
          <div className="underreview">
            <p className="underreview__h">Already with a reviewer</p>
            <p className="underreview__p">
              A practitioner is assessing your work. You will hear back by{" "}
              <strong>
                {new Date(last.deadline_at).toLocaleDateString(undefined, {
                  weekday: "long", day: "numeric", month: "long",
                })}
              </strong>.
            </p>
          </div>
        ) : (
          <>
            <div className="sub__brief">
              <div className="eyebrow">The brief</div>
              <p className="sub__briefp">{course.project_brief}</p>
            </div>

            {criteria && criteria.length > 0 && (
              <section className="sub__rubric">
                <h2 className="sub__h2">What your reviewer is marking</h2>
                <div className="cmt" style={{ marginTop: 16 }}>
                  {criteria.map((c, i) => (
                    <div key={c.id} className="cmt__i">
                      <span className="cmt__k">{i + 1}</span>
                      <div>
                        <div className="cmt__t">{c.title}</div>
                        <div className="cmt__d">{c.descriptor}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </section>
            )}

            {isResubmission && (
              <div className="notice" style={{ marginTop: 26 }}>
                <div>
                  <p className="notice__h">This is a resubmission</p>
                  <p className="notice__p">
                    {free
                      ? "Your first resubmission is free — nothing further is charged for it."
                      : "The assessment included in the price of this course covers this."}
                  </p>
                </div>
              </div>
            )}

            <SubmitForm slug={slug} />
          </>
        )}
      </div>
    </main>
  );
}
