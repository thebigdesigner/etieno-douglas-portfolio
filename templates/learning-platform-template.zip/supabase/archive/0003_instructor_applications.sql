-- =====================================================================
-- Instructor applications
--
-- Deliberately not tied to auth.users: an applicant should not have to
-- create an account before we have decided whether to approve them.
-- The account is created on approval and linked back to the application.
-- =====================================================================

create type application_state as enum ('submitted','reviewing','approved','rejected','withdrawn');

create table instructor_applications (
  id                uuid primary key default gen_random_uuid(),
  full_name         text not null,
  email             text not null,
  country           text,
  current_role      text not null,          -- what they do for a living now
  years_experience  int,
  linkedin_url      text,
  proposed_title    text not null,
  proposed_subject  text not null,
  proposed_segment  text not null,
  proposed_outline  text not null,
  sample_url        text,
  sample_note       text,
  review_capacity   int,                    -- projects they can assess per week
  accepts_sla       boolean not null default false,
  accepts_terms     boolean not null default false,
  state             application_state not null default 'submitted',
  reviewer_note     text,
  reviewed_by       uuid references profiles(id) on delete set null,
  reviewed_at       timestamptz,
  instructor_id     uuid references instructors(id) on delete set null,
  created_at        timestamptz not null default now()
);

create index on instructor_applications (state, created_at desc);
create unique index instructor_applications_open_email
  on instructor_applications (lower(email))
  where state in ('submitted','reviewing');

alter table instructor_applications enable row level security;
-- No public policies. Reads and writes happen through server code only.

-- ---------------------------------------------------------------------
-- Operator helpers
-- ---------------------------------------------------------------------
create or replace function public.is_operator(p_user uuid)
returns boolean
language sql
stable
security definer set search_path = public
as $$
  select exists (select 1 from profiles where id = p_user and role = 'operator');
$$;

comment on function public.is_operator is
  'Used by server code to gate the admin views. Grant the operator role in SQL, never through the UI.';
