-- =====================================================================
-- Cohort PIN lockout.
--
-- joinCohort authenticates cohort learners with a 6-digit PIN — far lower
-- entropy than a password, and previously guarded only by whatever generic
-- rate limiting Supabase Auth applies. This mirrors the pattern already
-- used for quiz retakes (quiz_cooldown_until in 0003_learning.sql): count
-- recent failures, lock out once there are too many.
-- =====================================================================

create table cohort_pin_attempts (
  id           uuid primary key default gen_random_uuid(),
  seat_id      uuid not null references cohort_seats(id) on delete cascade,
  attempted_at timestamptz not null default now()
);
create index on cohort_pin_attempts (seat_id, attempted_at desc);

alter table cohort_pin_attempts enable row level security;
-- No policies: only ever touched via the service-role client and the
-- security-definer function below, same as cohort_seats itself.

-- Five wrong PINs in fifteen minutes locks the seat for fifteen minutes.
-- Only failed attempts are logged, so a correct PIN is unaffected, and the
-- window ages out on its own without needing to be cleared on success.
create or replace function public.cohort_pin_locked_until(p_seat_id uuid)
returns timestamptz
language sql
stable
security definer set search_path = public
as $$
  select case
    when count(*) >= 5 then max(attempted_at) + interval '15 minutes'
    else null
  end
  from cohort_pin_attempts
 where seat_id = p_seat_id
   and attempted_at > now() - interval '15 minutes';
$$;

create or replace function public.record_pin_failure(p_seat_id uuid)
returns void
language sql
security definer set search_path = public
as $$
  insert into cohort_pin_attempts (seat_id) values (p_seat_id);
$$;

revoke all on function public.cohort_pin_locked_until(uuid) from public, anon, authenticated;
revoke all on function public.record_pin_failure(uuid) from public, anon, authenticated;
