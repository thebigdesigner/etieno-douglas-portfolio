import Link from "next/link";
import { subjectBlurb } from "@/lib/subjects";
import { subjectTint } from "@/lib/media";

/** The subject grid. Counts are the point — an empty subject reads as a
 *  placeholder, and a number tells somebody there is something behind it. */
export default function SubjectGrid({
  subjects,
}: { subjects: { subject: string; courses: number; free_courses: number }[] }) {
  return (
    <div className="sgrid">
      {subjects.map((s) => (
        <Link
          key={s.subject}
          className={`sgrid__c tone-${subjectTint(s.subject)}`}
          href={`/courses?subject=${encodeURIComponent(s.subject)}`}
        >
          <span className="sgrid__mark" aria-hidden="true">
            {s.subject.split(" ").map((w) => w[0]).join("").slice(0, 2)}
          </span>
          <span className="sgrid__t">{s.subject}</span>
          <span className="sgrid__b">{subjectBlurb(s.subject)}</span>
          <span className="sgrid__n num">
            {s.courses} course{s.courses === 1 ? "" : "s"}
            {s.free_courses > 0 && ` · ${s.free_courses} free`}
          </span>
        </Link>
      ))}
    </div>
  );
}
