import { NextResponse, type NextRequest } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { ARRIVAL_COOKIE } from "@/lib/arrival";
import { siteUrl } from "@/lib/site";

/** Only ever redirect within this app — an open redirect here would be
 *  handed a valid session on the way out.
 *
 *  Backslashes are rejected as well as leading double slashes. Browsers
 *  normalise `\` to `/` inside a URL, so `/\evil.com` reads as `//evil.com`
 *  in some parsers. It is not exploitable as things stand — the target is
 *  built by appending to siteUrl(), so the host is fixed before the path
 *  is ever parsed, and `https://yourbrand.com/\evil.com` stays on yourbrand.com.
 *  It is rejected anyway: that safety comes from how the caller happens to
 *  build the URL, and this function should not depend on that holding. */
function safeNext(next: string | null): string {
  if (!next) return "/dashboard";
  if (!next.startsWith("/")) return "/dashboard";
  if (next.startsWith("//")) return "/dashboard";
  if (next.includes("\\")) return "/dashboard";
  return next;
}

export async function GET(request: NextRequest) {
  /* Redirect to the site's own origin, not the request's.
   *
   * This used the origin off the incoming URL, which is the socket the
   * server is listening on. On Vercel that happened to be the real domain.
   * Behind any reverse proxy — Hostinger, Nginx, a VPS — the Node process
   * listens on 0.0.0.0:3000, so a successful LinkedIn or Google sign-in
   * ended at https://0.0.0.0:3000/dashboard: an address that exists only
   * inside the server, with the session already granted.
   *
   * siteUrl() is the answer the rest of the app already uses for exactly
   * this reason. safeNext still restricts where we may land. */
  const origin = siteUrl();
  const { searchParams } = new URL(request.url);
  const code = searchParams.get("code");
  const next = safeNext(searchParams.get("next"));

  if (code) {
    const supabase = await createClient();
    const { error } = await supabase.auth.exchangeCodeForSession(code);

    if (!error) {
      /* A suspended or erased account is refused on the password path, so
       * it has to be refused here too — otherwise OAuth is a way straight
       * back in.
       *
       * Read with the service-role client, and fail closed. This used the
       * user-scoped client, where the row is behind RLS, and asked
       * `profile?.status === "suspended"` — which is false when the read
       * returns nothing. So any reason the row did not come back (an RLS
       * change, a transient error, a profile row that does not exist yet)
       * silently admitted the account. A door that opens when the lock
       * cannot be read is not a lock.
       *
       * 'deleted' is checked as well as 'suspended'. Erasure sets it, and
       * eraseAccount has an explicit branch for the case where the
       * sign-in address could not be tombstoned — in exactly that state,
       * checking only 'suspended' would let somebody back into an account
       * that has already been erased. */
      const { data: { user } } = await supabase.auth.getUser();
      if (user) {
        const svc = createAdminClient();
        const { data: profile, error: profileError } = await svc
          .from("profiles").select("status, avatar_path").eq("id", user.id).maybeSingle();

        if (profileError || !profile) {
          console.error("auth callback: could not read profile", user.id, profileError?.message);
          await supabase.auth.signOut();
          return NextResponse.redirect(`${origin}/login?error=verification`);
        }

        /* Distinct from suspended: an erased account cannot be reopened,
         * and telling somebody at a signup screen that they are
         * "suspended" is both wrong and unactionable. */
        if (profile.status === "deleted") {
          await supabase.auth.signOut();
          return NextResponse.redirect(`${origin}/login?error=deleted`);
        }
        if (profile.status === "suspended") {
          await supabase.auth.signOut();
          return NextResponse.redirect(`${origin}/login?error=suspended`);
        }

        /* Fill in a missing picture from the provider.
         *
         * handle_new_user captures it, but only on the insert into
         * auth.users — so it cannot help somebody who signed up by email
         * and linked LinkedIn later, or anyone who signed in before 0052
         * taught the trigger to read the OIDC `picture` claim.
         *
         * Only ever fills a null. An uploaded avatar is the person's own
         * choice and must never be replaced by a provider's copy. */
        if (!profile.avatar_path) {
          const meta = user.user_metadata as Record<string, unknown> | null;
          const fromProvider =
            (typeof meta?.avatar_url === "string" && meta.avatar_url) ||
            (typeof meta?.picture === "string" && meta.picture) ||
            null;

          if (fromProvider) {
            await svc
              .from("profiles")
              .update({ avatar_path: fromProvider })
              .eq("id", user.id)
              .is("avatar_path", null);
          }
        }
      }

      // Same marker as the password paths — OAuth is a fresh login too, and
      // the cookie has to ride on this response rather than being written
      // through next/headers, which a Route Handler redirect would discard.
      const res = NextResponse.redirect(`${origin}${next}`);
      res.cookies.set(ARRIVAL_COOKIE, "1", {
        path: "/", httpOnly: true, sameSite: "lax", maxAge: 120,
      });
      return res;
    }
  }

  return NextResponse.redirect(`${origin}/login?error=verification`);
}
