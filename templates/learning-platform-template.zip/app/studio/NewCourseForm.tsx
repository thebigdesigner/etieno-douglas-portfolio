"use client";
import Link from "next/link";
import { useActionState, useState } from "react";
import { createCourse } from "@/app/actions/studio";
import type { FormState } from "@/lib/forms";
import SubmitButton from "@/components/SubmitButton";
import { SUBJECTS, LEVELS, LEVEL_LABEL } from "@/lib/subjects";
import Alert from "@/components/Alert";
import NavIcon from "@/components/NavIcon";

const initial: FormState = {};

/**
 * Creating a course asks for three things.
 *
 * Everything else this form used to collect — description, hours, price,
 * outcomes, what's included — is editable on the very next screen, which the
 * instructor lands on the moment they submit. Asking for it here meant a wall
 * of fields before a single topic existed, and asking somebody to price work
 * they have not written yet.
 *
 * Title, subject and level stay because they are what the course is filed
 * under from the first second: the slug comes from the title, and the subject
 * decides its colour and where it appears. Two dropdowns and a name is a
 * doorway; the rest is the room.
 */
type Assessor = { id: string; name: string; kind: string };

export default function NewCourseForm({
  isOperator = false, isInstitution = false, assessors = [],
}: {
  isOperator?: boolean;
  /** An institution admin authors for their organisation and nowhere else,
   *  so there is no ownership choice — only an assessor to name. */
  isInstitution?: boolean;
  assessors?: Assessor[];
}) {
  const [state, action] = useActionState(createCourse, initial);
  // Your Brand-owned by default for staff: it is what an operator is usually
  // here to do, and the alternative is a course they own personally.
  const [owner, setOwner] = useState(isOperator ? "splari" : "instructor");

  return (
    <form action={action} className="ncf">
      <div className="ncf__title">
        <span className="ncf__titleico" aria-hidden="true"><NavIcon name="book" size={20} /></span>
        <input
          name="title" required minLength={6} autoFocus
          placeholder="Name your course" aria-label="Course title"
        />
      </div>

      <div className="ncf__row ncf__row--two">
        <label className="ncf__f">
          <span className="ncf__k">Subject</span>
          <select name="subject" required defaultValue="">
            <option value="" disabled>Select</option>
            {SUBJECTS.map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
        </label>
        <label className="ncf__f">
          <span className="ncf__k">Level</span>
          <select name="level" required defaultValue="beginner">
            {LEVELS.map((l) => <option key={l} value={l}>{LEVEL_LABEL[l]}</option>)}
          </select>
        </label>
      </div>

      {/* Operators only. An instructor owns and assesses what they write —
          that is the whole arrangement — so the choice would be noise. */}
      {isInstitution && (
        <label className="ncf__f" style={{ margin: "4px 0 18px", maxWidth: 420 }}>
          <span className="ncf__k">Who assesses the projects</span>
          <select name="assessor" required defaultValue="">
            <option value="" disabled>Choose an assessor</option>
            {assessors.map((a) => (
              <option key={a.id} value={a.id}>{a.name} — {a.kind}</option>
            ))}
          </select>
          <span className="field__hint">
            Their name goes on every certificate this course issues, so it has to be
            a person. They are assigned each submission.
          </span>
        </label>
      )}

      {isOperator && (
        <div className="ncf__own">
          <div className="ncf__ownrow">
            <label className={`ncf__ownopt${owner === "splari" ? " is-on" : ""}`}>
              <input
                type="radio" name="owner" value="splari"
                checked={owner === "splari"} onChange={() => setOwner("splari")}
              />
              <span>
                <strong>Your Brand writes it</strong>
                Covered by the subscription. No price, and no royalty to anyone.
              </span>
            </label>
            <label className={`ncf__ownopt${owner === "instructor" ? " is-on" : ""}`}>
              <input
                type="radio" name="owner" value="instructor"
                checked={owner === "instructor"} onChange={() => setOwner("instructor")}
              />
              <span>
                <strong>I write it, as a practitioner</strong>
                Yours to price and sell, and it earns you royalties.
              </span>
            </label>
          </div>

          {owner === "splari" && (
            <label className="ncf__f" style={{ marginTop: 14, maxWidth: 420 }}>
              <span className="ncf__k">Who assesses the projects</span>
              <select name="assessor" required defaultValue="">
                <option value="" disabled>Choose an assessor</option>
                {assessors.map((a) => (
                  <option key={a.id} value={a.id}>{a.name} — {a.kind}</option>
                ))}
              </select>
              <span className="field__hint">
                Their name goes on every certificate this course issues, so it has to
                be a person. They are assigned each submission and paid the review fee.
              </span>
            </label>
          )}
        </div>
      )}

      <p className="ncf__note">
        That is all we need to start. The next screen is where you write it —
        modules, the exam, the rubric — and the description, hours, cover image and
        price are all there too, saved as you type. Nothing goes live until you
        send it for review.
      </p>

      {state.error && <Alert kind="error">{state.error}</Alert>}

      <div className="ncf__foot">
        <Link className="btn btn--line" href="/studio">Cancel</Link>
        <SubmitButton>Create and start writing</SubmitButton>
      </div>
    </form>
  );
}
