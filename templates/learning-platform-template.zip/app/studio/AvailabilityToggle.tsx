"use client";
import { setAvailability } from "@/app/actions/studio";
import { useFormStatus } from "react-dom";

function Btn({ available }: { available: boolean }) {
  const { pending } = useFormStatus();
  return (
    <button className={`avail${available ? " is-on" : ""}`} disabled={pending}>
      <span className="avail__dot" />
      {available ? "Taking new learners" : "Paused — no new enrolments"}
    </button>
  );
}

export default function AvailabilityToggle({ available }: { available: boolean }) {
  return (
    <form action={setAvailability.bind(null, !available)}>
      <Btn available={available} />
    </form>
  );
}
