"use server";

import { redirect } from "next/navigation";
import { siteUrl } from "@/lib/site";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import type { FormState } from "@/lib/forms";
import { sendEmail } from "@/lib/email";

const MAX_BYTES = 10 * 1024 * 1024;
const ALLOWED = ["application/pdf", "image/png", "image/jpeg"];

const KINDS: Record<string, string> = {
  registration: "Registration or incorporation document",
  letterhead: "Letter on headed paper",
  id: "Photo ID of the person signing up",
  other: "Something else",
};

async function myInstitution(userId: string) {
  const admin = createAdminClient();
  const { data } = await admin
    .from("institution_members").select("institution_id").eq("user_id", userId).maybeSingle();
  return data?.institution_id ?? null;
}

export async function uploadVerification(
  _prev: FormState,
  formData: FormData
): Promise<FormState> {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login?next=/institution/verify");

  const institutionId = await myInstitution(user.id);
  if (!institutionId) return { error: "Your account is not linked to an organisation." };

  const kind = String(formData.get("kind") ?? "");
  if (!KINDS[kind]) return { error: "Choose what this document is." };

  const file = formData.get("file");
  if (!(file instanceof File) || file.size === 0) return { error: "Choose a file to upload." };
  if (file.size > MAX_BYTES) return { error: "That file is over 10MB. Compress it and try again." };
  if (!ALLOWED.includes(file.type)) return { error: "PDF, PNG or JPEG only." };

  const admin = createAdminClient();
  const safe = file.name.replace(/[^a-zA-Z0-9._-]/g, "_").slice(-80);
  const path = `${user.id}/${institutionId}/${Date.now()}-${safe}`;

  const { error } = await admin.storage
    .from("verification").upload(path, file, { contentType: file.type });
  if (error) return { error: "Could not upload that file. Please try again." };

  await admin.from("institution_documents").insert({
    institution_id: institutionId, kind, path, filename: file.name,
  });

  revalidatePath("/institution/verify");
  return { ok: true, message: "Uploaded." };
}

export async function submitForVerification(_prev: FormState): Promise<FormState> {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const institutionId = await myInstitution(user.id);
  if (!institutionId) return { error: "Your account is not linked to an organisation." };

  const admin = createAdminClient();
  const { data } = await admin.rpc("submit_institution_verification", {
    p_institution_id: institutionId,
  });

  const row = (data ?? [])[0] as { ok: boolean; reason: string | null } | undefined;
  if (!row?.ok) {
    return {
      error: row?.reason === "no_documents"
        ? "Upload at least one document first."
        : "This has already been submitted.",
    };
  }

  const { data: operators } = await admin
    .from("profiles").select("email").eq("role", "operator");
  const { data: institution } = await admin
    .from("institutions").select("name").eq("id", institutionId).maybeSingle();

  for (const op of operators ?? []) {
    if (!op.email) continue;
    await sendEmail({
      to: op.email,
      subject: `Verification to review — ${institution?.name ?? "an organisation"}`,
      text: `${institution?.name ?? "An organisation"} has submitted verification documents.\n\n${siteUrl()}/admin/verification`,
      html: `<p><strong>${institution?.name ?? "An organisation"}</strong> has submitted verification documents.</p><p><a href="${siteUrl()}/admin/verification">Review them</a></p>`,
    });
  }

  revalidatePath("/institution/verify");
  return { ok: true, message: "Submitted. We usually come back within two working days." };
}

export async function decideVerification(
  institutionId: string,
  approve: boolean,
  _prev: FormState,
  formData: FormData
): Promise<FormState> {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const admin = createAdminClient();
  const { data: profile } = await admin
    .from("profiles").select("role").eq("id", user.id).maybeSingle();
  if (profile?.role !== "operator") return { error: "Operators only." };

  const note = String(formData.get("note") ?? "").trim();
  if (!approve && note.length < 10) {
    return { error: "Say why, so they know what to fix. They see this." };
  }

  const { data: ok } = await admin.rpc("decide_institution_verification", {
    p_institution_id: institutionId,
    p_operator_id: user.id,
    p_approve: approve,
    p_note: note || null,
  });

  if (!ok) return { error: "That organisation is not awaiting a decision." };

  const { data: institution } = await admin
    .from("institutions").select("name, contact_email").eq("id", institutionId).maybeSingle();

  if (institution?.contact_email) {
    await sendEmail({
      to: institution.contact_email,
      subject: approve
        ? `${institution.name} is verified`
        : `We need something else from ${institution.name}`,
      text: approve
        ? `You are verified. You can create cohorts and enrol learners now.\n\n${siteUrl()}/institution`
        : `We could not verify ${institution.name} with what you sent.\n\n${note}\n\nUpload something else here: ${siteUrl()}/institution/verify`,
      html: approve
        ? `<p>You are verified. You can create cohorts and enrol learners now.</p><p><a href="${siteUrl()}/institution">Open your dashboard</a></p>`
        : `<p>We could not verify <strong>${institution.name}</strong> with what you sent.</p><p>${note}</p><p><a href="${siteUrl()}/institution/verify">Upload something else</a></p>`,
    });
  }

  revalidatePath("/admin/verification");
  return { ok: true, message: approve ? "Verified." : "Sent back to them." };
}
