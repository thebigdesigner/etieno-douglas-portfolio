import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { categoryBySlug } from "@/lib/marketplace/categories";
import { getAuthor, getAuthors, isDemo, listProducts, getProduct, similarProducts, recentBuyers } from "@/lib/marketplace/catalog";
import { compact, price, shortDate } from "@/lib/marketplace/format";
import { marketBase, mk } from "@/lib/marketplace/url";
import MkIcon from "@/components/marketplace/MkIcon";
import ProductPreview from "@/components/marketplace/ProductPreview";
import AddToCart from "@/components/marketplace/AddToCart";
import BuyNow from "@/components/marketplace/BuyNow";
import PayChoice from "@/components/PayChoice";
import { availableProviders } from "@/lib/payments";
import { Avatar, DemoNote, ProductGrid, SectionHead, Stars } from "@/components/marketplace/bits";
import Reviews from "@/components/marketplace/Reviews";
import { reviewsFor, reviewStanding, summarise } from "@/lib/marketplace/reviews";
import { createClient } from "@/lib/supabase/server";

type Props = {
  params: Promise<{ slug: string }>;
  searchParams: Promise<{ licence?: string; checkout?: string }>;
};

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const p = await getProduct((await params).slug);
  if (!p) return {};
  return { title: p.title, description: p.summary };
}

export default async function ItemPage({ params, searchParams }: Props) {
  const [{ slug }, sp, base] = await Promise.all([params, searchParams, marketBase()]);
  const p = await getProduct(slug);
  if (!p) notFound();

  // Real people, so: initials only, and none at all below the threshold.
  const buyers = await recentBuyers(p.id);

  const [author, similarPool, byAuthor, demo] = await Promise.all([
    getAuthor(p.author),
    similarProducts(p, 12),
    listProducts({ author: p.author, perPage: 5 }),
    isDemo(),
  ]);

  // Reviews. The demo catalogue has no rows behind its ratings, so the
  // section is only read for real items rather than showing an empty
  // panel under a placeholder's 4.9.
  const viewer = demo ? null : (await (await createClient()).auth.getUser()).data.user;
  const reviews = demo ? [] : await reviewsFor(p.id, viewer?.id);
  const standing = demo ? { owns: false, mine: null } : await reviewStanding(p.id, viewer?.id);
  const more = byAuthor.items.filter((x) => x.slug !== p.slug).slice(0, 4);
  // A creator who owns a whole category would otherwise fill both rows
  // with the same four cards. Similar means "someone else's, like this".
  const shown = new Set(more.map((x) => x.slug));
  const similar = similarPool.filter((x) => !shown.has(x.slug)).slice(0, 4);
  const authors = await getAuthors([...similar, ...more].map((x) => x.author));
  const cat = categoryBySlug(p.category);
  const sub = cat?.subcategories.find((s) => s.slug === p.subcategory);
  const free = p.priceCents === 0;
  const licence = sp.licence === "commercial" && p.commercialCents ? "commercial" : "personal";
  const tried = sp.checkout === "1";

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Product",
    name: p.title,
    description: p.summary,
    brand: author?.name,
    offers: { "@type": "Offer", price: (p.priceCents / 100).toFixed(2), priceCurrency: "USD", availability: "https://schema.org/InStock" },
    ...(p.ratings ? { aggregateRating: { "@type": "AggregateRating", ratingValue: p.rating, reviewCount: p.ratings } } : {}),
  };

  return (
    <>
      {demo && <DemoNote />}
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />

      <nav className="mk-crumbs" aria-label="Breadcrumb">
        <Link href={mk(base, "/")}>Marketplace</Link>
        <span aria-hidden="true">/</span>
        {cat && <><Link href={mk(base, `/${cat.slug}`)}>{cat.name}</Link><span aria-hidden="true">/</span></>}
        <span aria-current="page">{p.title}</span>
      </nav>

      <div className="mk-item">
        <div className="mk-item__main">
          <figure className="mk-item__stage">
            <ProductPreview product={p} className="mk-item__img" />
          </figure>
          {/*
            Only for generated covers, where each variant genuinely draws
            something different. An item with an uploaded cover has one
            image, and printing it three times in a row reads as a broken
            gallery rather than a preview. Real screenshots will replace
            this when items can carry more than one image.
          */}
          {!p.coverUrl && (
            <div className="mk-item__thumbs" aria-hidden="true">
              {[1, 2, 3].map((v) => (
                <div key={v} className="mk-item__thumb"><ProductPreview product={p} variant={v} className="mk-item__img" label="" /></div>
              ))}
            </div>
          )}

          <section className="mk-panel">
            <SectionHead title="About this item" icon="file" />
            <p className="mk-item__summary">{p.summary}</p>
            <h3 className="mk-item__h3">What you get</h3>
            <ul className="mk-checks">
              {p.includes.map((line) => (
                <li key={line}><MkIcon name="check" size={16} />{line}</li>
              ))}
            </ul>
            {p.tags.length > 0 && (
              <ul className="mk-tags" aria-label="Tags">
                {p.tags.map((t) => (
                  <li key={t}><Link href={`${mk(base, "/search")}?q=${encodeURIComponent(t)}`}>{t}</Link></li>
                ))}
              </ul>
            )}
          </section>

          {!demo && (
            <Reviews
              productId={p.id}
              reviews={reviews}
              summary={summarise(reviews)}
              owns={standing.owns}
              mine={standing.mine ? { rating: standing.mine.rating, body: standing.mine.body } : null}
              signedIn={!!viewer}
            />
          )}
        </div>

        <aside className="mk-item__side">
          <div className="mk-panel mk-buy">
            <h1 className="mk-buy__h">{p.title}</h1>
            {author && (
              <Link href={mk(base, `/author/${author.handle}`)} className="mk-buy__by">
                <Avatar name={author.name} hue={author.hue} size={34} />
                <span>
                  <span className="mk-buy__name">{author.name}</span>
                  <span className="mk-buy__loc">{author.location}</span>
                </span>
              </Link>
            )}
            {/* Silent on a new listing: "0 downloads" beside no rating is
                a row of bad news about an item nobody has had a chance to
                buy yet. */}
            {(p.downloads > 0 || p.ratings > 0) && (
              <div className="mk-buy__stats">
                <Stars rating={p.rating} count={p.ratings} showValue />
                {p.downloads > 0 && (
                  <span className="num"><MkIcon name="download" size={14} />{p.downloads.toLocaleString("en-US")} downloads</span>
                )}
              </div>
            )}

            {tried && (
              <p className="mk-buy__note" role="status">
                Checkout for marketplace items is not switched on yet. Nothing has been charged.
              </p>
            )}

            <form method="get" className="mk-buy__form">
              <input type="hidden" name="checkout" value="1" />
              {free ? (
                <p className="mk-buy__free">Free for personal and commercial use.</p>
              ) : (
                <fieldset className="mk-lic">
                  <legend className="sr">Licence</legend>
                  <label className="mk-lic__opt">
                    <input type="radio" name="licence" value="personal" defaultChecked={licence === "personal"} />
                    <span className="mk-lic__txt">
                      <span className="mk-lic__name">Personal</span>
                      <span className="mk-lic__desc">Your own projects and one client project, not for resale.</span>
                    </span>
                    <span className="mk-lic__price num">{price(p.priceCents, p.currency)}</span>
                  </label>
                  {p.commercialCents && (
                    <label className="mk-lic__opt">
                      <input type="radio" name="licence" value="commercial" defaultChecked={licence === "commercial"} />
                      <span className="mk-lic__txt">
                        <span className="mk-lic__name">Commercial</span>
                        <span className="mk-lic__desc">Products you sell, unlimited client work and paid ads.</span>
                      </span>
                      <span className="mk-lic__price num">{price(p.commercialCents, p.currency)}</span>
                    </label>
                  )}
                </fieldset>
              )}
              {!free && <PayChoice options={availableProviders(p.currency)} />}
              <BuyNow slug={p.slug} free={free} libraryHref={mk(base, "/library")} />
              {!free && <AddToCart product={p} cartHref={mk(base, "/cart")} />}
            </form>
            <p className="mk-buy__fine">One payment, no subscription. Future updates are included.</p>
          </div>

          {/*
            Downloads, and the initials of a few recent buyers.

            The four coloured dots that used to sit here were decoration
            coloured from the rating, next to the words "people use this" —
            they invited a reader to count them as evidence. These are real
            people, which is why they are initials only: no names, no
            links, nobody who has opted out, and nothing at all until three
            different people have bought, since two letters beside a niche
            product can identify someone.

            Exact figures below a thousand for a related reason: "0k" and
            "1k" flatter a number that should speak plainly. And no panel
            at all on an item nobody has bought yet, which beats "0 people
            use this" under every new listing.
          */}
          {p.downloads > 0 && (
            <div className="mk-panel mk-reach">
              <SectionHead title="Downloads" icon="users" />
              <div className="mk-reach__row">
                {buyers.length > 0 && (
                  <span className="mk-reach__stack" aria-hidden="true">
                    {buyers.map((initials: string, i: number) => (
                      <span key={i} className="mk-av mk-av--dot" data-hue={(i * 2 + 1) % 6}>{initials}</span>
                    ))}
                  </span>
                )}
                <span className="mk-reach__n num">{p.downloads < 1000 ? p.downloads : compact(p.downloads)}</span>
                <span className="mk-reach__l">{p.downloads === 1 ? "person has this" : "people have this"}</span>
              </div>
            </div>
          )}

          <dl className="mk-panel mk-facts">
            <div><dt>Category</dt><dd>{cat?.name}{sub ? `, ${sub.name}` : ""}</dd></div>
            <div><dt>Formats</dt><dd>{p.formats.join(", ")}</dd></div>
            {p.duration && <div><dt>Length</dt><dd className="num">{p.duration}</dd></div>}
            <div><dt>File size</dt><dd className="num">{p.fileSize}</dd></div>
            <div><dt>Published</dt><dd>{shortDate(p.publishedAt)}</dd></div>
            <div><dt>Last updated</dt><dd>{shortDate(p.updatedAt)}</dd></div>
          </dl>
        </aside>
      </div>

      {more.length > 0 && author && (
        <section className="mk-sec">
          <SectionHead title={`More from ${author.name}`} href={mk(base, `/author/${author.handle}`)} linkLabel="See portfolio" />
          <ProductGrid items={more} base={base} authors={authors} />
        </section>
      )}

      {similar.length > 0 && (
        <section className="mk-sec">
          <SectionHead title="Similar items" href={cat ? mk(base, `/${cat.slug}`) : undefined} linkLabel={cat ? `All ${cat.name.toLowerCase()}` : undefined} />
          <ProductGrid items={similar} base={base} authors={authors} />
        </section>
      )}
    </>
  );
}
