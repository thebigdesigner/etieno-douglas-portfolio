import type { Metadata } from "next";
import { marketBase } from "@/lib/marketplace/url";
import CartView from "@/components/marketplace/CartView";
import { availableProviders } from "@/lib/payments";
import { CURRENCIES, readCurrency } from "@/lib/currency";

export const metadata: Metadata = { title: "Cart · Your Brand Marketplace" };

export default async function CartPage() {
  const base = await marketBase();
  const payOptions = Object.fromEntries(CURRENCIES.map((c) => [c, availableProviders(c)]));
  return <CartView base={base} payOptions={payOptions} ccy={await readCurrency()} />;
}
