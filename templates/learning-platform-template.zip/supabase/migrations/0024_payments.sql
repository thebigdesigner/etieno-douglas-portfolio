-- =====================================================================
-- Payments (Flutterwave).
--
-- `subscriptions` and `cert_allowances` existed from 0001 but nothing
-- ever wrote to them, so hasAccess() always returned false and the
-- paywall had nothing behind it. This is the write side.
--
-- Two rules shape it:
--   1. Activation is one function, not application code. Granting access
--      and provisioning the year's certification allowance must either
--      both happen or neither — a learner who paid and got no allowance
--      is a support ticket, and the reverse is theft.
--   2. Every webhook is recorded before it is acted on, keyed by the
--      provider's own id. Flutterwave retries, so the same event will
--      arrive more than once and must not grant twice.
-- =====================================================================

-- The raw event log. Kept separately from subscriptions so a payment
-- dispute can be reconstructed from what the provider actually sent.
create table payment_events (
  id           uuid primary key default gen_random_uuid(),
  provider     text not null default 'flutterwave',
  event_type   text not null,
  provider_ref text not null,
  tx_ref       text,
  user_id      uuid references profiles(id) on delete set null,
  amount_cents int,
  currency     text,
  payload      jsonb not null,
  handled_at   timestamptz,
  received_at  timestamptz not null default now(),
  unique (provider, provider_ref, event_type)
);
create index on payment_events (user_id, received_at desc);
create index on payment_events (tx_ref);

alter table payment_events enable row level security;
-- No policy: only the service role touches this.

-- A checkout we started, so a returning customer can be matched to the
-- plan they chose even if the provider's metadata is lost.
create table checkout_intents (
  tx_ref     text primary key,
  user_id    uuid not null references profiles(id) on delete cascade,
  plan       plan_tier not null,
  cycle      text not null default 'monthly',   -- monthly | annual
  amount_cents int not null,
  currency   text not null,
  created_at timestamptz not null default now(),
  completed_at timestamptz
);
create index on checkout_intents (user_id, created_at desc);

alter table checkout_intents enable row level security;
create policy "own intents" on checkout_intents for select to authenticated
  using (user_id = auth.uid());

-- How many assessments a year each tier includes.
create or replace function plan_allowance(p_plan plan_tier)
returns int language sql immutable as $$
  select case p_plan when 'starter' then 1 when 'plus' then 3 else 5 end;
$$;

-- ---------------------------------------------------------------------
-- Activate or renew. Idempotent on (provider, provider_ref): calling it
-- twice for the same payment is a no-op, which is what makes webhook
-- retries safe.
-- ---------------------------------------------------------------------
create or replace function activate_subscription(
  p_user_id      uuid,
  p_plan         plan_tier,
  p_provider     text,
  p_provider_ref text,
  p_cycle        text default 'monthly'
)
returns uuid
language plpgsql
security definer
set search_path = public
as $$
declare
  v_id       uuid;
  v_start    timestamptz := now();
  v_end      timestamptz;
  v_included int := plan_allowance(p_plan);
begin
  v_end := case when p_cycle = 'annual'
                then v_start + interval '1 year'
                else v_start + interval '1 month' end;

  -- Already recorded this exact payment: do nothing and return it.
  select id into v_id from subscriptions
   where provider = p_provider and provider_ref = p_provider_ref;
  if found then return v_id; end if;

  -- One active subscription per learner. A renewal or plan change
  -- supersedes rather than stacks.
  update subscriptions
     set status = 'cancelled', cancelled_at = now()
   where user_id = p_user_id and status = 'active';

  insert into subscriptions (
    user_id, plan, provider, provider_ref, status,
    current_period_start, current_period_end
  )
  values (p_user_id, p_plan, p_provider, p_provider_ref, 'active', v_start, v_end)
  returning id into v_id;

  -- The allowance runs with the billing period. Certifications do not
  -- roll over, which is why a fresh row is created rather than topped up.
  insert into cert_allowances (user_id, period_start, period_end, included)
  values (p_user_id, v_start, v_end, v_included);

  return v_id;
end;
$$;

create or replace function cancel_subscription(p_user_id uuid)
returns void
language plpgsql
security definer
set search_path = public
as $$
begin
  -- Cancelled, not deleted: access runs to the end of the paid period,
  -- and hasAccess() reads status, so this takes effect when the provider
  -- stops renewing rather than immediately.
  update subscriptions
     set status = 'cancelled', cancelled_at = now()
   where user_id = p_user_id and status = 'active';
end;
$$;

revoke all on function activate_subscription(uuid, plan_tier, text, text, text)
  from public, anon, authenticated;
revoke all on function cancel_subscription(uuid) from public, anon;
grant execute on function cancel_subscription(uuid) to authenticated, service_role;
grant execute on function activate_subscription(uuid, plan_tier, text, text, text)
  to service_role;
