"use client";

import { useActionState, useState, useTransition } from "react";
import { addExamItem, removeExamItem, setRequiresProject } from "@/app/actions/studio";
import type { FormState } from "@/lib/forms";
import SubmitButton from "@/components/SubmitButton";
import Alert from "@/components/Alert";
import Section from "./Section";

export type ExamItem = {
  id: string;
  position: number;
  prompt: string;
  options: { id: string; text: string }[];
  correct: string[];
  explanation: string | null;
};

const initial: FormState = {};
const LETTERS = ["a", "b", "c", "d"] as const;

/**
 * The final exam, and the decision about what this course certifies.
 *
 * Every course ends in an exam. The project after it is the instructor's
 * choice, and it is the more consequential of the two controls on this
 * screen — turning it off changes what the certificate says, so the copy
 * spells that out rather than presenting it as a preference.
 */
export default function ExamSection({
  courseId, slug, items, requiresProject, readonly,
}: {
  courseId: string;
  slug: string;
  items: ExamItem[];
  requiresProject: boolean;
  readonly?: boolean;
}) {
  const [state, action] = useActionState(addExamItem.bind(null, courseId, slug), initial);
  const [pending, startTransition] = useTransition();
  // Optimistic, because the switch is the thing the surrounding copy reacts
  // to — waiting for the round trip would leave the explanation describing
  // the option they just turned off.
  const [requires, setRequires] = useState(requiresProject);

  function toggle(next: boolean) {
    setRequires(next);
    startTransition(() => { setRequiresProject(courseId, slug, next); });
  }

  return (
    <Section
      title="Final exam"
      summary={
        items.length === 0
          ? "Nothing yet — five questions minimum"
          : `${items.length} question${items.length === 1 ? "" : "s"}, 80% to pass`
      }
      done={items.length >= 5}
    >
      <p className="studio__hint" style={{ marginTop: 0 }}>
        Sat once every topic is finished. Marked automatically, 80% to pass, unlimited
        retakes with a 30 minute pause after two failures in a row.
      </p>

      {/* ---- what this course certifies ---- */}
      <div className="examopt">
        <div className="examopt__row">
          <div>
            <div className="examopt__t">Require a final project</div>
            <div className="examopt__d">
              {requires
                ? "A working practitioner assesses the project and the certificate carries their name."
                : "Passing the exam completes the course. The certificate says the learner passed the examination, and carries nobody’s name."}
            </div>
          </div>
          <button
            type="button"
            role="switch"
            aria-checked={requires}
            aria-label="Require a final project"
            className={`examopt__sw${requires ? " is-on" : ""}`}
            disabled={readonly || pending}
            onClick={() => toggle(!requires)}
          >
            <span />
          </button>
        </div>

        {!requires && (
          <p className="examopt__warn">
            Worth being sure. A certificate with a practitioner’s name on it is the
            thing learners are paying for; an examined one is a different, quieter
            claim. Both are honest — they are just not the same.
          </p>
        )}
      </div>

      {items.length > 0 && (
        <div className="cmt" style={{ marginTop: 18 }}>
          {items.map((q, i) => (
            <div key={q.id} className="cmt__i">
              <span className="cmt__k">{i + 1}</span>
              <div style={{ minWidth: 0 }}>
                <div className="cmt__t">{q.prompt}</div>
                <div className="cmt__d">
                  {q.options.map((o) => (
                    <span key={o.id} className={q.correct.includes(o.id) ? "examq__right" : undefined}>
                      {o.text}
                      {q.correct.includes(o.id) ? " ✓" : ""}
                      {"  ·  "}
                    </span>
                  ))}
                </div>
                {q.explanation && <div className="cmt__d">{q.explanation}</div>}
              </div>
              {!readonly && (
                <form action={removeExamItem.bind(null, q.id, slug)}>
                  <button className="examq__x" aria-label="Remove question">✕</button>
                </form>
              )}
            </div>
          ))}
        </div>
      )}

      {!readonly && (
        <form action={action} className="auth__form" style={{ marginTop: 22, maxWidth: 620 }}>
          <label className="field">
            <span className="field__label">Question</span>
            <textarea name="prompt" rows={2} required minLength={10} />
          </label>

          <fieldset className="examq__opts">
            <legend className="field__label">Options — mark the correct one</legend>
            {LETTERS.map((id) => (
              <label key={id} className="examq__opt">
                <input type="radio" name="correct" value={id} required={id === "a"} />
                <input
                  name={`opt_${id}`}
                  placeholder={id === "a" || id === "b" ? "Required" : "Optional"}
                  required={id === "a" || id === "b"}
                />
              </label>
            ))}
            <span className="field__hint">
              Two options minimum, four maximum. The radio marks the answer.
            </span>
          </fieldset>

          <label className="field">
            <span className="field__label">Why that is the answer</span>
            <textarea name="explanation" rows={2} />
            <span className="field__hint">
              Shown after a wrong attempt. The exam is the last thing they do, so this
              is the last chance to teach anything.
            </span>
          </label>

          {state.error && <Alert kind="error">{state.error}</Alert>}
          {state.ok && <Alert kind="success">{state.message}</Alert>}
          <SubmitButton>Add question</SubmitButton>
        </form>
      )}
    </Section>
  );
}
