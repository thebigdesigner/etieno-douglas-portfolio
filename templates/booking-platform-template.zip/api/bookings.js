/**
 * POST /api/bookings — create a booking and hold its seats.
 *
 * The seats are taken by claim_seats() inside Postgres, so two people choosing the last seat
 * at the same moment cannot both succeed: one gets the booking, the other gets 409 seat_taken.
 * Fares are read from the trip, never from the browser.
 */
import { opsAlert } from './_lib/ops-alert.js';
import { configured, select, insert, update, rpc, tenant, audit, makeReference, tripContext, fail, limited, clientIp, departsAt, lagosToday, lookupBlocked, lookupMissed } from './_lib/db.js';
import { storageConfigured, signedUpload } from './_lib/storage.js';
import crypto from 'node:crypto';

/* The last seven digits: 0803…, +234803… and 234803… are the same person. */
const last7 = s => String(s || '').replace(/\D/g, '').slice(-7);
import { customerFrom } from './_lib/auth/session.js';
import { applyCredit, cancelRequest } from './_lib/customer-actions.js';
import { legsOf } from './_lib/legs.js';
import { cancellationQuote } from './_lib/cancel-policy.js';
import { claimBooking, exportMyData, dataRequest } from './_lib/account-actions.js';

const PHONE = /^\+?\d[\d\s-]{8,}$/;


/**
 * GET /api/bookings?mine=1 — the signed-in customer's own bookings.
 *
 * Bookings are matched on the email address the customer signed in with, because a booking
 * carries contact details rather than an account id — someone can book without an account at
 * all. A booking made under a different email is still reachable by reference through
 * Find my booking, and the page says so rather than pretending the list is complete.
 */
async function listMine(req, res) {
  const secret = process.env.SESSION_SECRET;
  if (!secret) return res.status(200).json({ bookings: [], signedIn: false });

  const user = customerFrom(req, secret);
  if (!user || !user.email) return res.status(200).json({ bookings: [], signedIn: false });
  const email = String(user.email).trim().toLowerCase();

  const t = await tenant();
  const FIELDS = `&select=id,reference,status,total_kobo,contact_phone,contact_email,created_at,channel,` +
    `passengers(full_name,seat_no,status,pax_type,fare_kobo,trip:trips(id,status,depart_date,depart_time,driver:drivers(name),vehicle:vehicles(label,plate),route:routes(from_terminal,to_terminal))),` +
    `payments(status,amount_kobo,channel,provider,created_at,settled_at),refunds(status,amount_kobo,created_at,decided_at)`;
  /* Exact match on the lowercased address. This was ilike, where '_' matches any single
     character — j_doe@… was shown jxdoe@…'s bookings. Addresses are stored lowercased since
     September 2026, and db/schema.sql lowercases the older rows. Plus any booking the customer
     added to the account with its reference and phone number. */
  const own = await select('bookings', `tenant_id=eq.${t.id}&contact_email=eq.${encodeURIComponent(email)}${FIELDS}&order=created_at.desc&limit=100`);
  const claims = await select('booking_claims', `tenant_id=eq.${t.id}&email=eq.${encodeURIComponent(email)}&select=booking_id`).catch(() => []);
  const extraIds = claims.map(c => c.booking_id).filter(id => !own.some(b => b.id === id));
  const claimed = extraIds.length ? await select('bookings', `tenant_id=eq.${t.id}&id=in.(${extraIds.join(',')})${FIELDS}`) : [];
  const rows = [...own, ...claimed.map(b => ({ ...b, claimed: true }))].sort((a, b) => b.created_at.localeCompare(a.created_at));

  const terminals = await select('terminals', `tenant_id=eq.${t.id}&select=id,code,city,name,address,phone,lat,lng`);
  const city = id => terminals.find(x => x.id === id)?.city || '';
  const term = id => { const x = terminals.find(y => y.id === id); return x ? { code: x.code, city: x.city, name: x.name, address: x.address, phone: x.phone, lat: x.lat, lng: x.lng } : null; };
  const todayStr = lagosToday();

  /* Trail points, read from the ledger rather than a stored total, so the balance shown is
     always the sum of things the customer can see listed. */
  const cfg = (t.settings || {}).loyalty || {};
  const scheme = {
    enabled: cfg.enabled !== false,
    perTrip: Number(cfg.points_per_trip ?? 10),
    perCoupon: Number(cfg.points_per_coupon ?? 100),
    couponValue: Number(cfg.coupon_value_kobo ?? 500000) / 100
  };
  /* Case-insensitive, but with LIKE's own wildcards escaped: unescaped, '_' in an address
     matched any character, and a customer could be shown someone else's points and coupon
     codes. */
  const exact = encodeURIComponent(email.replace(/[\\%_]/g, m => '\\' + m));
  const ledger = await select('loyalty_ledger',
    `tenant_id=eq.${t.id}&customer_email=ilike.${exact}&select=points,reason,note,created_at&order=created_at.desc&limit=60`);
  const coupons = await select('coupons',
    `tenant_id=eq.${t.id}&customer_email=ilike.${exact}&select=code,value_kobo,issued_at,expires_at,redeemed_at&order=issued_at.desc`);

  const balance = ledger.reduce((a, r) => a + r.points, 0);
  const trips = ledger.filter(r => r.reason === 'trip').length;

  res.setHeader('Cache-Control', 'no-store');
  /* Customer notifications, same split as the staff side. Derived from the customer's own
     bookings — their trip is tomorrow, a payment never completed, a credit is waiting — so
     nothing is stored and nothing can go stale. Plus any notice a manager addressed to
     customers or to this person's email. */
  const notices = [];
  const soonDay = new Date(Date.now() + 36 * 3600000).toISOString().slice(0, 10);
  for (const b of rows) {
    const trip = b.passengers[0]?.trip;
    const date = trip?.depart_date || null;
    const paid = (b.payments || []).filter(p => p.status === 'success').reduce((a, p) => a + p.amount_kobo, 0);
    const live = date && date >= todayStr && !['cancelled', 'refunded', 'expired'].includes(b.status);
    if (!live) continue;
    if (b.status === 'pending' || paid < b.total_kobo) {
      notices.push({ key: `unpaid:${b.reference}`, kind: 'warning', reference: b.reference,
        title: `${b.reference} is not paid for yet`,
        body: 'Your seat is only held until payment goes through.' });
    } else if (date <= soonDay) {
      notices.push({ key: `soon:${b.reference}`, kind: 'notice', reference: b.reference,
        title: `Your trip to ${city(trip?.route?.to_terminal)} is on ${date}`,
        body: `Departs ${String(trip.depart_time).slice(0, 5)}. Arrive 30 minutes before; check-in closes 15 minutes before.` });
    } else {
      notices.push({ key: `ticket:${b.reference}`, kind: 'notice', reference: b.reference,
        title: `Your ticket for ${date} is ready`, body: 'Open it any time from Find my booking.' });
    }
  }
  for (const c of coupons) {
    if (c.redeemed_at || (c.expires_at && Date.parse(c.expires_at) < Date.now())) continue;
    notices.push({ key: `credit:${c.code}`, kind: 'notice',
      title: `You have a \u20a6${Number(c.value_kobo / 100).toLocaleString('en-NG')} travel credit`,
      body: `Quote ${c.code} at any terminal when you book.` });
  }

  let broadcast = [];
  try {
    /* Broadcasts plus anything addressed to this customer. The address match was an unescaped
       ilike inside or=(…), where '_' is a wildcard; it is filtered exactly here instead. */
    const rowsN = (await select('notifications',
      `tenant_id=eq.${t.id}&or=(audience_role.eq.customers,audience_email.not.is.null)` +
      `&order=created_at.desc&limit=100&select=id,kind,title,body,created_at,expires_at,audience_role,audience_email`))
      .filter(n => n.audience_role === 'customers' || String(n.audience_email || '').toLowerCase() === email)
      .slice(0, 10);
    broadcast = rowsN.filter(n => !n.expires_at || Date.parse(n.expires_at) > Date.now())
      .map(n => ({ key: `notice:${n.id}`, kind: n.kind, title: n.title, body: n.body, at: n.created_at }));
  } catch (err) { console.error('customer notices failed:', err.message); }

  return res.status(200).json({
    signedIn: true, email: user.email,
    notifications: [...broadcast, ...notices],
    loyalty: {
      ...scheme,
      balance, trips,
      toNext: scheme.perCoupon > 0 ? Math.max(0, scheme.perCoupon - (balance % scheme.perCoupon)) : null,
      history: ledger.slice(0, 20).map(r => ({ points: r.points, reason: r.reason, note: r.note, at: r.created_at })),
      coupons: coupons.map(c => ({
        code: c.code, value: c.value_kobo / 100, issued: c.issued_at, expires: c.expires_at,
        used: Boolean(c.redeemed_at),
        expired: Boolean(c.expires_at && !c.redeemed_at && Date.parse(c.expires_at) < Date.now())
      }))
    },
    bookings: rows.map(b => {
      const { legs, people } = legsOf(b.passengers, city);
      const lead = legs[0];
      const paid = (b.payments || []).filter(p => p.status === 'success').reduce((a, p) => a + p.amount_kobo, 0);
      const last = legs[legs.length - 1];
      /* Per-leg detail the account page shows on the "next trip" card: where to go, who drives. */
      const tripOf = l => (b.passengers.find(p => p.trip && p.trip.depart_date === l.date && String(p.trip.depart_time).slice(0, 5) === l.time) || {}).trip || {};
      const quote = cancellationQuote({ status: b.status, legs, passengers: b.passengers, payments: b.payments, settings: t.settings });
      const refund = (b.refunds || []).sort((x, y) => y.created_at.localeCompare(x.created_at))[0];
      return {
        ref: b.reference, status: b.status, claimed: Boolean(b.claimed), bookedAt: b.created_at, channel: b.channel,
        from: lead?.from || '', to: lead?.to || '',
        date: lead?.date || null, time: lead?.time || null,
        seats: lead?.seats || [],
        legs: legs.map(l => { const tr = tripOf(l); return { dir: l.dir, from: l.from, to: l.to, date: l.date, time: l.time, seats: l.seats,
          tripStatus: tr.status || null, driver: tr.driver?.name || null, vehicle: [tr.vehicle?.label, tr.vehicle?.plate].filter(Boolean).join(' ') || null,
          terminal: term(tr.route?.from_terminal), arrival: term(tr.route?.to_terminal) }; }),
        passengers: people,
        fares: (b.passengers || []).map(p => ({ name: p.full_name, type: p.pax_type, fare: (p.fare_kobo || 0) / 100 })),
        total: b.total_kobo / 100, paid: paid / 100,
        payments: (b.payments || []).filter(p => ['success', 'reversed'].includes(p.status)).map(p => ({
          amount: p.amount_kobo / 100, method: p.channel || p.provider, at: p.settled_at || p.created_at,
          kind: p.amount_kobo < 0 ? 'refund' : p.channel === 'coupon' ? 'credit' : 'payment', reversed: p.status === 'reversed' })),
        refund: refund ? { amount: refund.amount_kobo / 100, status: refund.status, requested: refund.created_at, decided: refund.decided_at } : null,
        cancellation: quote.allowed ? { allowed: true, refund: quote.refundKobo / 100, band: quote.band } : { allowed: false },
        phone: b.contact_phone,
        /* A round trip stays "upcoming" until its return has gone. */
        upcoming: Boolean(last?.date && last.date >= todayStr && !['cancelled', 'refunded', 'expired'].includes(b.status))
      };
    })
  });
}

export default async function handler(req, res) {
  if (!configured()) return fail(res, 503, 'not_configured', 'Database not configured');

  /* Receipt uploads ride on this endpoint rather than a new function — the twelfth serverless
     slot is the last one, and this is the same customer and the same authentication. */
  const act = req.method === 'POST' && req.body && req.body.action;
  if (act === 'claim' || act === 'data-request') {
    try { return await (act === 'claim' ? claimBooking : dataRequest)(req, res); }
    catch (err) { console.error(`${act} failed:`, err.message); return fail(res, 500, 'server', 'Something went wrong. Please try again.'); }
  }
  if (act === 'apply-credit' || act === 'cancel-request') {
    try { return await (act === 'apply-credit' ? applyCredit : cancelRequest)(req, res); }
    catch (err) { console.error(`${act} failed:`, err.message); return fail(res, 500, 'server', 'Something went wrong. Please try again or call the terminal.'); }
  }
  if (act === 'proof-slot' || act === 'proof-submit') {
    try { return await proofRoute(req, res, act); }
    catch (err) { console.error('receipt failed:', err.message); return fail(res, 500, 'server', 'Could not handle that receipt'); }
  }

  if (req.method === 'GET') {
    if (req.query && req.query.export === '1') {
      try { return await exportMyData(req, res); }
      catch (err) { console.error('export failed:', err.message); return fail(res, 500, 'server', 'Could not prepare your data'); }
    }
    if (!req.query || req.query.mine !== '1') return fail(res, 400, 'bad_request', 'Unknown request');
    try { return await listMine(req, res); }
    catch (err) { console.error('my bookings failed:', err.message); return fail(res, 500, 'server', 'Could not load your bookings'); }
  }
  if (req.method !== 'POST') return fail(res, 405, 'method', 'GET or POST only');

  const { passengers = [], contact = {}, kin = {} } = req.body || {};
  /* The public endpoint only ever takes web bookings. It used to accept a channel from the
     browser, so anyone could file a booking as 'terminal' and have it audited as staff. */
  const channel = 'web';

  /* One booking, one or two legs. A round trip used to send only the outbound leg: the return
     seats were never held, the customer paid for one direction and believed they had both.
     Now every leg is priced, held and ticketed under the same reference, and paid together. */
  const legsIn = Array.isArray(req.body?.legs) ? req.body.legs : [{ tripId: req.body?.tripId, seats: req.body?.seats }];
  if (!legsIn.length || legsIn.length > 2) return fail(res, 400, 'bad_trip', 'A booking is one way or a round trip');
  for (const l of legsIn) {
    if (!/^[0-9a-f-]{36}$/i.test(l?.tripId || '')) return fail(res, 400, 'bad_trip', 'Unknown trip');
    if (!Array.isArray(l.seats) || !l.seats.length || l.seats.length > 20 || l.seats.some(s => !Number.isInteger(s) || s < 1 || s > 80))
      return fail(res, 400, 'bad_seats', 'Choose at least one valid seat');
    if (new Set(l.seats).size !== l.seats.length) return fail(res, 400, 'bad_seats', 'Duplicate seat');
    if (passengers.length !== l.seats.length) return fail(res, 400, 'bad_passengers', 'One seat per passenger on each leg');
  }
  if (new Set(legsIn.map(l => l.tripId)).size !== legsIn.length) return fail(res, 400, 'bad_trip', 'The two legs must be different departures');
  if (passengers.some(p => !p || String(p.name || '').trim().length < 3)) return fail(res, 400, 'bad_passengers', 'Every passenger needs a full name');
  if (!PHONE.test(String(contact.phone || '').trim())) return fail(res, 400, 'bad_phone', 'Enter a valid phone number');
  /* Email is required now, not optional. The ticket, the QR, the credit notices and the account
     all travel by email; a booking without one is a passenger we cannot reach and a ticket that
     exists only in the browser that made it. */
  if (!String(contact.email || '').trim()) return fail(res, 400, 'no_email', 'Enter an email address — the ticket is sent there');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(contact.email).trim())) return fail(res, 400, 'bad_email', 'Check the email address');
  /* Infants under two ride on a lap and need no seat — the site says so. The API used to seat
     them at ₦0, which let a script take a whole vehicle for nothing. Online, every seat is paid. */
  if (passengers.some(p => p && p.type === 'infant'))
    return fail(res, 400, 'infant_no_seat', 'Infants under 2 travel on a lap and do not need a seat. Tell the desk at check-in.');

  /* A hold takes seats off sale, so creating one is limited like a login is: per connection and
     per phone number, counted in the database. Generous enough for a family re-trying a card
     that failed, tight enough that a script cannot sit on every departure. Mobile networks put
     many customers behind one address, which is why the per-IP number is the looser one. */
  const ip = clientIp(req);
  const phoneKey = String(contact.phone).replace(/\D/g, '').slice(-10);
  if (await limited(`hold:ip:${ip}`, 12, 600) || await limited(`hold:phone:${phoneKey}`, 4, 1800))
    return fail(res, 429, 'too_many', 'Too many bookings started in a short time. Please wait a few minutes, or call the terminal.');

  let bookingId = null;
  try {
    const t = await tenant();
    const settings = t.settings || {};
    const holdMins = Number(settings.hold_minutes ?? 15);
    const childRatio = Number(settings.child_fare_ratio ?? 0.75);
    const closeMin = Number(settings.check_in_close_min ?? 15);

    const legs = [];
    for (const l of legsIn) {
      const rows = await select('trips', `id=eq.${l.tripId}&tenant_id=eq.${t.id}&status=eq.scheduled&select=id,fare_kobo,depart_date,depart_time`);
      if (!rows.length) return fail(res, 404, 'no_trip', 'That departure is no longer available');
      /* Same cut-off the timetable uses: once check-in has closed, the departure is not on sale.
         The listing already hid it; a request aimed straight at the API did not. */
      if (departsAt(rows[0].depart_date, rows[0].depart_time) <= new Date(Date.now() + closeMin * 60000))
        return fail(res, 409, 'closed', 'Booking for that departure has closed. Please choose a later one.');
      legs.push({ trip: rows[0], seats: l.seats });
    }
    if (legs.length === 2 && departsAt(legs[1].trip.depart_date, legs[1].trip.depart_time) <= departsAt(legs[0].trip.depart_date, legs[0].trip.depart_time))
      return fail(res, 400, 'bad_return', 'The return has to leave after the outbound trip');

    // Server-side pricing. The browser never sends an amount.
    const priced = legs.flatMap(({ trip, seats }) => passengers.map((p, i) => {
      const type = p.type === 'child' ? 'child' : 'adult';
      const fare = Math.round(trip.fare_kobo * (type === 'child' ? childRatio : 1));
      return { tripId: trip.id, name: String(p.name).trim().slice(0, 120), type, fare, seat: seats[i] };
    }));
    const total = priced.reduce((a, p) => a + p.fare, 0);

    const reference = makeReference(t.prefix, await tripContext(t.id, legs[0].trip.id));
    const [booking] = await insert('bookings', [{
      tenant_id: t.id, reference, channel,
      status: 'pending',
      contact_name: String(contact.name || priced[0].name).slice(0, 120),
      contact_phone: String(contact.phone).trim().slice(0, 32),
      contact_email: String(contact.email).trim().toLowerCase().slice(0, 160),
      kin_name: kin.name ? String(kin.name).slice(0, 120) : null,
      kin_phone: kin.phone ? String(kin.phone).slice(0, 32) : null,
      total_kobo: total,
      hold_expires_at: new Date(Date.now() + holdMins * 60000).toISOString()
    }]);
    bookingId = booking.id;

    // The moment of truth, once per leg. Throws seat_taken if anyone beat us to a seat.
    for (const { trip, seats } of legs)
      await rpc('claim_seats', { p_trip_id: trip.id, p_seats: seats, p_booking: booking.id, p_hold_mins: holdMins });

    await insert('passengers', priced.map(p => ({
      booking_id: booking.id, trip_id: p.tripId, seat_no: p.seat,
      full_name: p.name, pax_type: p.type, fare_kobo: p.fare
    })), 'return=minimal');

    await audit({
      tenant_id: t.id, actor_type: 'customer',
      action: 'booking.created', entity: 'booking', entity_id: booking.id,
      detail: { reference, legs: legs.map(l => ({ trip_id: l.trip.id, seats: l.seats })), total_kobo: total, channel }
    });

    const legOut = ({ trip, seats }) => ({ id: trip.id, date: trip.depart_date, time: String(trip.depart_time).slice(0, 5), seats });
    return res.status(201).json({
      reference, bookingId: booking.id, total: total / 100,
      holdExpiresAt: booking.hold_expires_at,
      trip: legOut(legs[0]), seats: legs[0].seats,       // the first leg, as before, for older pages
      legs: legs.map(legOut)
    });
  } catch (err) {
    if (bookingId) {
      // Never leave a half-made booking holding nothing.
      try { await rpc('release_booking', { p_booking: bookingId, p_status: 'cancelled' }); } catch {}
    }
    if (err.code === 'seat_taken') return fail(res, 409, 'seat_taken', 'Someone just took that seat. Please choose another.');
    if (err.code === 'seat_missing') return fail(res, 400, 'seat_missing', 'That seat does not exist on this vehicle.');

    /* "Could not complete the booking" told nobody anything, and this is the one endpoint where
       a failure costs a sale. The two that actually happen are a schema that did not finish
       running and a database the deployment cannot reach — both fixable in a minute once named.
       db/schema.sql is applied top to bottom and stops at the first error, so claim_seats, which
       is defined well down the file, can be missing while everything above it is fine. */
    const detail = [err && err.message, err && err.details && JSON.stringify(err.details)].filter(Boolean).join(' ');
    console.error('booking failed:', detail, err && err.stack);
    await opsAlert('booking:error', { severity: 'urgent', title: 'Online bookings are failing',
      detail: { error: detail.slice(0, 300), what_to_do: 'Open Vercel → Logs for /api/bookings. Customers cannot book online until this is fixed.' } });

    /* Belt and braces: if a stale row still owns the seat, say so in the customer's terms
       rather than showing them a server error. Same words as losing a race for the seat,
       because from where they are standing it is the same thing. */
    if (/duplicate key|23505/i.test(detail)) {
      return fail(res, 409, 'seat_taken', 'That seat is no longer available. Please choose another.');
    }
    if (/claim_seats|PGRST202|function .* does not exist/i.test(detail)) {
      return fail(res, 500, 'schema_behind',
        'Seats cannot be held right now. Run db/schema.sql in Supabase — claim_seats is missing.');
    }
    if (/column .* does not exist|42703|schema cache|PGRST20[0-9]/i.test(detail)) {
      return fail(res, 500, 'schema_behind',
        'The database is missing something this booking needs. Run db/schema.sql in Supabase.');
    }
    if (/relationship|foreign key|PGRST200/i.test(detail)) {
      return fail(res, 500, 'schema_behind',
        'The database is missing a link between two tables. Run db/schema.sql in Supabase.');
    }
    return fail(res, 500, 'server', 'Could not complete the booking. The reason is in the Vercel logs for /api/bookings.');
  }
}

/* ------------------------------------------------------- transfer receipts
   Authenticated the same way the ticket is: reference plus the phone number the booking was
   made with. No session needed — a passenger who paid by transfer may never have signed in. */
async function proofRoute(req, res, action) {
  const t = await tenant();
  const ref = String(req.body.reference || '').toUpperCase();
  const phone = String(req.body.phone || '');
  if (!/^[A-Z]{2,5}-[A-Z0-9]{4,10}(-[A-Z0-9]{2,6})?$/.test(ref)) return fail(res, 400, 'bad_reference', 'Check the reference');
  if (last7(phone).length < 7) return fail(res, 400, 'bad_phone', 'Enter the phone number used to book');
  if (await lookupBlocked(req, phone)) return fail(res, 429, 'too_many', 'Too many attempts. Please wait a few minutes.');

  const rows = await select('bookings',
    `tenant_id=eq.${t.id}&reference=eq.${ref}&select=id,status,total_kobo,contact_phone,hold_expires_at`);
  /* Same answer for a wrong reference and a wrong phone: no fishing. */
  if (!rows.length || last7(rows[0].contact_phone) !== last7(phone)) {
    await lookupMissed(req, phone);
    return fail(res, 404, 'not_found', 'No booking found for that reference and phone number');
  }
  const b = rows[0];
  if (['cancelled', 'refunded', 'expired'].includes(b.status))
    return fail(res, 409, 'closed', `That booking is ${b.status}.`);
  if (b.status === 'confirmed')
    return fail(res, 409, 'already_paid', 'That booking is already paid for.');

  if (action === 'proof-slot') {
    if (!storageConfigured()) return fail(res, 503, 'no_storage', 'Receipts cannot be uploaded right now.');
    const ext = ({ 'image/jpeg': 'jpg', 'image/png': 'png', 'image/webp': 'webp',
                   'image/heic': 'heic', 'application/pdf': 'pdf' })[String(req.body.mime || '')];
    if (!ext) return fail(res, 400, 'bad_type', 'Send a photo or a PDF');
    const bytes = Number(req.body.bytes || 0);
    if (!Number.isFinite(bytes) || bytes <= 0 || bytes > 8 * 1024 * 1024)
      return fail(res, 400, 'too_big', 'That file is over 8MB — a photo of the receipt is enough');
    const path = `${t.id}/${b.id}/${crypto.randomUUID()}.${ext}`;
    try {
      const slot = await signedUpload(path);
      return res.status(200).json({ uploadUrl: slot.url, path });
    } catch (err) {
      console.error('upload slot failed:', err.message);
      return fail(res, 503, 'no_storage', 'Receipts cannot be uploaded right now.');
    }
  }

  if (action === 'proof-submit') {
    const path = String(req.body.path || '');
    /* Only a path this tenant and this booking could have been given. */
    if (!path.startsWith(`${t.id}/${b.id}/`)) return fail(res, 400, 'bad_path', 'That upload does not belong to this booking');

    const paid = await select('payments', `tenant_id=eq.${t.id}&booking_id=eq.${b.id}&status=eq.success&select=amount_kobo`);
    const already = paid.reduce((a, p) => a + p.amount_kobo, 0);

    const row = {
      tenant_id: t.id, booking_id: b.id, storage_path: path,
      mime: String(req.body.mime || '').slice(0, 60) || null,
      bytes: Number(req.body.bytes) || null,
      sender_name: String(req.body.senderName || '').trim().slice(0, 120) || null,
      bank: String(req.body.bank || '').trim().slice(0, 80) || null,
      amount_kobo: b.total_kobo - already
    };
    /* One receipt awaiting a decision per booking, enforced by a partial unique index. Somebody
       who photographs the same transfer three times should give the desk one thing to look at,
       not three — and three approvals would take the fare three times. A resend replaces what
       is waiting rather than being refused: the second photograph is usually the clearer one. */
    const waiting = await select('payment_proofs',
      `booking_id=eq.${b.id}&tenant_id=eq.${t.id}&status=eq.pending&select=id&limit=1`);
    if (waiting.length) {
      await update('payment_proofs', `id=eq.${waiting[0].id}&tenant_id=eq.${t.id}`, row);
    } else {
      await insert('payment_proofs', [row], 'return=minimal');
    }

    /* The seat has to survive the wait. A transfer can take an hour on a bad day, and a hold
       that lapses while the desk is looking at the receipt loses a paying customer. */
    /* How long a seat waits on a transfer is a manager's decision, not a number in this file:
       too short loses a customer who has genuinely paid, too long holds seats hostage on a busy
       Saturday. Set in Terminals; sixty minutes unless they say otherwise. */
    const holdMins = Math.min(Math.max(Number((t.settings || {}).transfer_hold_minutes ?? 60), 5), 720);
    /* Once per booking, not once per upload. Re-sending a photo used to restart the clock, so a
       booking could be kept on hold for ever by uploading any picture every fifty minutes.
       extend_hold moves both clocks — the booking's and the seats' — and is capped from the
       moment the booking was made. */
    if (!waiting.length) {
      await rpc('extend_hold', { p_booking: b.id, p_minutes: holdMins, p_cap_minutes: holdMins + 30 });
    }

    await audit({ tenant_id: t.id, actor_type: 'customer', action: 'payment.proof_submitted',
      entity: 'booking', entity_id: b.id, detail: { reference: ref, bank: req.body.bank || null } });

    return res.status(201).json({
      ok: true,
      heldUntil: until,
      message: 'Received. The terminal will check it and confirm your seat — usually within the hour.'
    });
  }

  return fail(res, 400, 'bad_request', 'Unknown request');
}
