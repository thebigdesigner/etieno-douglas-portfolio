import type { Metadata } from "next";
import { NewItemView, OpenShopView } from "@/components/marketplace/studio/views";
import { studioGate } from "../../gate";

export const metadata: Metadata = { title: "New item · Studio", robots: { index: false } };

export default async function NewItemPage() {
  const g = await studioGate("/studio/items/new");
  if ("block" in g) return g.block;
  if (!g.viewer.shop) return <OpenShopView suggestedName={g.viewer.email?.split("@")[0] ?? ""} />;
  return <NewItemView base={g.base} shopName={g.viewer.shop.displayName} />;
}
