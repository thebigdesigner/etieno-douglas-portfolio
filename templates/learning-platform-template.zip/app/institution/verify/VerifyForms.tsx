"use client";
import { useActionState } from "react";
import { uploadVerification, submitForVerification } from "@/app/actions/verification";
import type { FormState } from "@/lib/forms";
import SubmitButton from "@/components/SubmitButton";
import FileDrop from "@/components/FileDrop";
import Alert from "@/components/Alert";

const initial: FormState = {};

type Doc = { id: string; kind: string; filename: string; uploaded_at: string };

const LABELS: Record<string, string> = {
  registration: "Registration document",
  letterhead: "Headed letter",
  id: "Photo ID",
  other: "Other",
};

export default function VerifyForms({ docs, canSubmit }: { docs: Doc[]; canSubmit: boolean }) {
  const [upState, upload] = useActionState(uploadVerification, initial);
  const [subState, submit] = useActionState(submitForVerification, initial);

  if (subState.ok) {
    return <Alert kind="success">{subState.message}</Alert>;
  }

  return (
    <>
      <form action={upload} className="auth__form" style={{ marginTop: 30 }}>
        <label className="field">
          <span className="field__label">What is this document?</span>
          <select name="kind" required defaultValue="">
            <option value="" disabled>Choose one</option>
            <option value="registration">Registration or incorporation document</option>
            <option value="letterhead">Letter on headed paper</option>
            <option value="id">Photo ID</option>
            <option value="other">Something else</option>
          </select>
        </label>
        <div className="field">
          <span className="field__label">File</span>
          <FileDrop
            name="file" required accept=".pdf,.png,.jpg,.jpeg" preview
            hint="PDF or an image of the document."
          />
        </div>
        {upState.error && <Alert kind="error">{upState.error}</Alert>}
        {upState.ok && <Alert kind="success">{upState.message}</Alert>}
        <SubmitButton>Upload</SubmitButton>
      </form>

      {docs.length > 0 && (
        <section style={{ marginTop: 34 }}>
          <h2 className="sub__h2">Uploaded</h2>
          <div className="rq" style={{ marginTop: 16 }}>
            {docs.map((d) => (
              <div key={d.id} className="rq__row" style={{ gridTemplateColumns: "1fr auto" }}>
                <div>
                  <div className="rq__course">{d.filename}</div>
                  <div className="rq__learner">{LABELS[d.kind] ?? d.kind}</div>
                </div>
                <span className="rq__sub num">
                  {new Date(d.uploaded_at).toLocaleDateString()}
                </span>
              </div>
            ))}
          </div>
        </section>
      )}

      <form action={submit} style={{ marginTop: 30, paddingTop: 24, borderTop: "1px solid var(--line)" }}>
        {subState.error && <Alert kind="error">{subState.error}</Alert>}
        <button className="btn btn--fill btn--lg" disabled={!canSubmit}>
          Send for verification
        </button>
        {!canSubmit && (
          <p className="studio__hint" style={{ marginTop: 10 }}>
            Upload at least one document first.
          </p>
        )}
      </form>
    </>
  );
}
