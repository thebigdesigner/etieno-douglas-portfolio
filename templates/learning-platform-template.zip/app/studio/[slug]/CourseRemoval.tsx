"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { deleteCourse, retireCourse } from "@/app/actions/studio";
import Alert from "@/components/Alert";

/**
 * Removing a course, from whichever surface owns it.
 *
 * Two verbs, because they are two different acts and the difference is the
 * whole point. Deleting cascades to enrolments and from there to
 * certificates, so it is offered only on a draft nobody has touched.
 * Retiring takes a live course out of the catalogue, search and the cart
 * and leaves every certificate it issued exactly where it is.
 *
 * Both confirm first. Neither is undoable from the UI, and a course is
 * hours of somebody's writing.
 */
export default function CourseRemoval({
  courseId, state, backHref,
}: {
  courseId: string;
  state: string;
  /** Where to go once the course is gone. */
  backHref: string;
}) {
  const [asking, setAsking] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [pending, start] = useTransition();
  const router = useRouter();

  const isDraft = state === "draft" || state === "revision_requested";
  const isLive = state === "published";

  // Nothing to offer on a course that is in review or already retired:
  // one is mid-decision, the other is already withdrawn.
  if (!isDraft && !isLive) return null;

  const run = () =>
    start(async () => {
      setError(null);
      const result = isDraft ? await deleteCourse(courseId) : await retireCourse(courseId);
      if (result.error) {
        setError(result.error);
        setAsking(false);
        return;
      }
      router.push(backHref);
      router.refresh();
    });

  return (
    <div className="crem">
      {error && <Alert kind="error">{error}</Alert>}

      {!asking ? (
        <button className="crem__open" onClick={() => setAsking(true)} disabled={pending}>
          {isDraft ? "Delete this draft" : "Retire this course"}
        </button>
      ) : (
        <div className="crem__ask">
          <p className="crem__q">
            {isDraft
              ? "Delete this draft? Everything written in it goes — modules, topics, the exam and the rubric. This cannot be undone."
              : "Retire this course? It stops being listed and cannot be bought or started. Everyone part-way through keeps their place, and every certificate it has issued stays valid."}
          </p>
          <div className="crem__acts">
            <button className="btn btn--line" onClick={() => setAsking(false)} disabled={pending}>
              Keep it
            </button>
            <button className="crem__go" onClick={run} disabled={pending}>
              {pending ? "…" : isDraft ? "Yes, delete it" : "Yes, retire it"}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
