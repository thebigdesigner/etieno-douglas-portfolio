import Link from "next/link";
import MkIcon from "@/components/marketplace/MkIcon";
import { marketBase, mk } from "@/lib/marketplace/url";

/**
 * Inside the marketplace shell, so a dead item link leaves the visitor in
 * the shop with the rail and search still in reach — not on the Academy's
 * 404 offering courses.
 */
export default async function MarketNotFound() {
  const base = await marketBase();
  return (
    <div className="mk-empty mk-empty--page">
      <MkIcon name="search" size={30} />
      <h1>That item is not in the marketplace</h1>
      <p>It may have been removed by its creator, or the link is mistyped. Search for it, or start from the top.</p>
      <Link className="mk-btn mk-btn--fill" href={mk(base, "/")}>Back to the marketplace</Link>
    </div>
  );
}
