import Link from "next/link";
import AuthShell from "@/components/AuthShell";
import StepProgress from "@/components/StepProgress";
import OAuthButtons from "@/components/OAuthButtons";
import IntentPicker from "./IntentPicker";

export const metadata = { title: "Create an account" };

type SearchParams = Promise<{ intent?: string }>;

export default async function SignupPage({ searchParams }: { searchParams: SearchParams }) {
  const { intent } = await searchParams;
  const preset = ["instructor", "institution"].includes(intent ?? "") ? intent! : null;

  return (
    <AuthShell
      progress={<StepProgress step={1} total={3} labels={["You", "Details", "Done"]} />}
      title="What brings you to Your Brand?"
      intro="Each of these works a little differently, so we will only ask you what is relevant."
      footer={
        <>
          Already have an account? <Link href="/login">Log in</Link>
          <br />
          Joining with a class code? <Link href="/join">Use your username</Link>
        </>
      }
    >
      <IntentPicker preset={preset} />
      <OAuthButtons note="Signing in with Google or LinkedIn creates a learner account, and confirms you are 18 or over. To teach or enrol a group, use the options above." />
    </AuthShell>
  );
}
