-- =====================================================================
-- Four categories the catalogue actually needs.
--
-- The original twelve were asset types — UI kits, fonts, 3D — which left
-- nowhere to put an n8n workflow, a business plan kit, a CV pack or a
-- creator's sponsorship templates. Those are the things Your Brand is being
-- built to sell, so they get categories of their own rather than being
-- filed under "Guides & workbooks" and never found.
--
-- The slugs live in lib/marketplace/categories.ts; this constraint is what
-- stops a row arriving with a category the code has no icon or filters for.
-- =====================================================================

alter table mk_products drop constraint if exists mk_products_category_check;
alter table mk_products add constraint mk_products_category_check
  check (category in (
    'ui-kits','web-templates','presentations','graphics','icons','fonts',
    'music','sound-effects','video-templates','3d','ebooks','code',
    'ai-automation','business','career','creator'));
