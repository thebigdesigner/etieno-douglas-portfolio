"use client";
import { useActionState, useState } from "react";
import { resolveAppeal } from "@/app/actions/review";
import type { FormState } from "@/lib/forms";
import SubmitButton from "@/components/SubmitButton";
import Alert from "@/components/Alert";

type Criterion = { id: string; title: string; descriptor: string; max_score: number };

const initial: FormState = {};

export default function AppealDecision({
  appealId, criteria,
}: { appealId: string; criteria: Criterion[] }) {
  const [state, action] = useActionState(resolveAppeal.bind(null, appealId), initial);
  const [outcome, setOutcome] = useState("");

  return (
    <form action={action} className="rvw__form">
      <h2 className="sub__h2">Your reading</h2>

      {criteria.length > 0 && (
        <div className="cmt" style={{ marginTop: 4 }}>
          {criteria.map((c, i) => (
            <div key={c.id} className="cmt__i">
              <span className="cmt__k">{i + 1}</span>
              <div>
                <div className="cmt__t">{c.title}</div>
                <div className="cmt__d">{c.descriptor}</div>
              </div>
            </div>
          ))}
        </div>
      )}

      <div className="rvw__verdict">
        <span className="field__label">Does it meet the rubric?</span>
        <div className="rvw__vopts">
          <label className={`rvw__v${outcome === "pass" ? " is-on" : ""}`}>
            <input type="radio" name="outcome" value="pass" required onChange={() => setOutcome("pass")} />
            <span>
              <strong>Yes — it passes</strong>
              <em>The original verdict is overturned and a certificate issues</em>
            </span>
          </label>
          <label className={`rvw__v${outcome === "revise" ? " is-on" : ""}`}>
            <input type="radio" name="outcome" value="revise" required onChange={() => setOutcome("revise")} />
            <span>
              <strong>No — changes still needed</strong>
              <em>The original verdict stands</em>
            </span>
          </label>
        </div>
      </div>

      <label className="field">
        <span className="field__label">Your reasoning</span>
        <textarea name="feedback" rows={9} required minLength={80} />
        <span className="field__hint">
          The learner reads this. Point at the rubric, not at the other reviewer.
        </span>
      </label>

      {state.error && <Alert kind="error">{state.error}</Alert>}
      <SubmitButton>Record the second reading</SubmitButton>
    </form>
  );
}
