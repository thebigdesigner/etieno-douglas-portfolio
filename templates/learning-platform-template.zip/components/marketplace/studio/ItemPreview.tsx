"use client";

import type { Product } from "@/lib/marketplace/types";
import { categoryBySlug } from "@/lib/marketplace/categories";
import { price } from "@/lib/marketplace/format";
import ProductPreview from "@/components/marketplace/ProductPreview";

/**
 * What a buyer will see, updating as the form is filled in.
 *
 * The same cover renderer and the same card the storefront uses, so this
 * is a preview rather than an impression of one. Everything it shows is
 * drawn from the fields beside it; nothing is invented to fill a gap,
 * because a preview that flatters an empty form is worse than none.
 */
export type PreviewFields = {
  title: string; category: string; subcategory: string; summary: string;
  includes: string[]; tags: string[]; formats: string[];
  priceCents: number | null; commercialCents: number | null;
};

export default function ItemPreview({ f, shopName }: { f: PreviewFields; shopName: string }) {
  const cat = categoryBySlug(f.category);
  const sub = cat?.subcategories.find((s) => s.slug === f.subcategory);
  const titled = f.title.trim();

  // A stub in the storefront's own shape: the cover art is generated from
  // the title and category, which is exactly what a real listing does
  // until a cover image is uploaded in step 2.
  const stub: Product = {
    id: "preview", slug: "preview", title: titled || "Your item's title",
    category: f.category || "ui-kits", subcategory: f.subcategory || "",
    author: shopName, priceCents: f.priceCents ?? 0, commercialCents: f.commercialCents,
    currency: "USD", rating: 0, ratings: 0, downloads: 0,
    publishedAt: new Date().toISOString(), updatedAt: new Date().toISOString(),
    formats: f.formats, tags: f.tags, summary: f.summary, includes: f.includes,
    fileSize: "", coverUrl: null, trending: false, featured: false,
  };

  const priced = f.priceCents !== null;
  const free = f.priceCents === 0;

  return (
    <aside className="st-look" aria-label="Preview">
      <div className="st-look__sticky">
        <h2 className="st-look__h">Preview</h2>
        <p className="st-look__p">
          How this looks to a buyer. The cover is drawn from your title and category until you upload
          your own in step 2.
        </p>

        <div className="st-look__card">
          <article className="mkc">
            <span className="mkc__link">
              <span className="mkc__media"><ProductPreview product={stub} className="mkc__img" label="" /></span>
              <span className="mkc__title">{stub.title}</span>
            </span>
            {/* No stars: a new item has no ratings, and showing empty ones
                here would suggest it launches with a score. */}
            <span className="st-look__by">{shopName}</span>
            <span className={`mk-price num${free ? " is-free" : ""}`}>
              {priced ? price(stub.priceCents) : "—"}
            </span>
          </article>
        </div>

        <dl className="st-look__facts">
          <div><dt>Category</dt><dd>{cat ? `${cat.name}${sub ? `, ${sub.name}` : ""}` : "Not chosen yet"}</dd></div>
          <div><dt>Formats</dt><dd>{f.formats.length ? f.formats.join(", ") : "None ticked"}</dd></div>
          <div>
            <dt>Licences</dt>
            <dd>
              {!priced ? "No price yet"
                : free ? "Free, personal and commercial"
                : f.commercialCents
                  ? `${price(f.priceCents!)} personal · ${price(f.commercialCents)} commercial`
                  : `${price(f.priceCents!)}, one licence`}
            </dd>
          </div>
        </dl>

        {f.includes.length > 0 && (
          <div className="st-look__inc">
            <span className="st-look__inch">What is included</span>
            <ul>{f.includes.slice(0, 6).map((line, i) => <li key={i}>{line}</li>)}</ul>
          </div>
        )}

        {f.summary.trim() && <p className="st-look__sum">{f.summary.trim().slice(0, 240)}</p>}

        {f.tags.length > 0 && (
          <div className="st-look__tags">{f.tags.slice(0, 8).map((t) => <span key={t}>{t}</span>)}</div>
        )}
      </div>
    </aside>
  );
}
