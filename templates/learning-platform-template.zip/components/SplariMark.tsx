/**
 * The Your Brand mark — the wordmark's own letterform, not a drawn icon.
 *
 * The brand is set in Jost 700 with a blue full stop after it. At 40px there
 * is only room for the first letter, so the mark is that: the S and the stop,
 * in the same face, weight and tracking as the wordmark on the marketing
 * pages. Nothing is redrawn, so it cannot drift away from the logotype the
 * rest of the site uses.
 */
export default function SplariMark({ className }: { className?: string }) {
  return (
    <span className={`smark${className ? ` ${className}` : ""}`} aria-hidden="true">
      S<span className="smark__dot">.</span>
    </span>
  );
}
