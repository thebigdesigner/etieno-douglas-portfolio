import { createAdminClient } from "@/lib/supabase/admin";
import FilterBar from "@/components/FilterBar";
import { requireOwner } from "@/lib/owner";
import PersonRow from "./PersonRow";
import DeletionQueue, { type DeletionRow } from "./DeletionQueue";

export const metadata = { title: "People" };
export const dynamic = "force-dynamic";

type SearchParams = Promise<{ q?: string; role?: string }>;

export default async function PeoplePage({ searchParams }: { searchParams: SearchParams }) {
  const owner = await requireOwner();
  const { q, role } = await searchParams;
  const admin = createAdminClient();

  let query = admin
    .from("profiles")
    .select("id, display_name, email, role, status, account_type, created_at")
    .order("created_at", { ascending: false })
    .limit(60);

  if (q) query = query.or(`display_name.ilike.%${q}%,email.ilike.%${q}%`);
  if (role) query = query.eq("role", role);

  const { data: people } = await query;

  // Deletion requests, oldest first: the one closest to its deadline is
  // the one that matters.
  const { data: deletions } = await admin
    .from("deletion_queue").select("*")
    .eq("state", "pending")
    .order("due_at", { ascending: true });

  return (
    <>
      <div className="con__head">
        <div>
          <h1 className="con__h">People</h1>
          <p className="con__sub">
            Everyone with an account. Changing a role, granting an allowance or
            suspending somebody is logged against your name and shows up in the audit.
          </p>
        </div>
      </div>

      {/* The same bar as every other console page. It had its own before,
          which is how two pages end up filtering differently. */}
      {/* Above the roster on purpose. These carry a deadline; browsing
          the list of accounts does not. */}
      <DeletionQueue rows={(deletions ?? []) as DeletionRow[]} />

      <FilterBar
        search={{ name: "q", placeholder: "Name or email", value: q }}
        selects={[
          {
            name: "role", label: "Any role", value: role,
            options: [
              { value: "learner", label: "Learners" },
              { value: "instructor", label: "Instructors" },
              { value: "institution_admin", label: "Institution admins" },
              { value: "operator", label: "Operators" },
            ],
          },
        ]}
        showing={(people ?? []).length}
        clearHref="/console/people"
      />

      {(!people || people.length === 0) ? (
        <div className="empty" style={{ marginTop: 26 }}>
          <p className="empty__h">Nobody matches</p>
          <p className="empty__p">Try a different search.</p>
        </div>
      ) : (
        <div className="people">
          {people.map((p) => (
            <PersonRow key={p.id} person={p} isSelf={p.id === owner.id} />
          ))}
        </div>
      )}
    </>
  );
}
