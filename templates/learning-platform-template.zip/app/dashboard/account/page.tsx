import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { hasAccess } from "@/lib/access";
import AccountForms from "./AccountForms";

export const metadata = { title: "Account" };
export const dynamic = "force-dynamic";

export default async function AccountPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const admin = createAdminClient();

  const { data: profile } = await admin
    .from("profiles")
    .select("*")
    .eq("id", user!.id).maybeSingle();

  const subscribed = await hasAccess(user!.id);
  const isCohortAccount = (user!.email ?? "").endsWith("@cohort.splari.internal");

  // Enough to make the page about them, not just a stack of forms.
  const { data: certs } = await admin
    .from("certificates").select("id, enrolments!inner(user_id)")
    .eq("enrolments.user_id", user!.id);

  const { count: enrolled } = await admin
    .from("enrolments").select("id", { count: "exact", head: true }).eq("user_id", user!.id);

  return (
    <AccountForms
      displayName={profile?.display_name ?? ""}
      email={isCohortAccount ? null : (profile?.email ?? user!.email ?? "")}
      accountType={profile?.account_type ?? "adult"}
      subscribed={subscribed}
      avatarPath={profile?.avatar_path ?? null}
      role={profile?.role ?? "learner"}
      memberSince={profile?.created_at ?? null}
      certificates={(certs ?? []).length}
      enrolments={enrolled ?? 0}
      showPurchases={profile?.show_purchases ?? true}
    />
  );
}
