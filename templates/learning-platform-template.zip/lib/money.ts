/**
 * Which currency a visitor sees.
 *
 * Three, each with its own price list set by hand — never a dollar figure
 * through an exchange rate. Adding a fourth means adding it here, to the
 * check constraints in 0070, and to the studio's price fields.
 */
export const CURRENCIES = ["USD", "GBP", "NGN"] as const;
export type Ccy = (typeof CURRENCIES)[number];

export const CCY_LABEL: Record<Ccy, string> = { USD: "US dollars", GBP: "Pounds", NGN: "Naira" };
export const CCY_SYMBOL: Record<Ccy, string> = { USD: "$", GBP: "£", NGN: "₦" };
export const CCY_SHORT: Record<Ccy, string> = { USD: "USD $", GBP: "GBP £", NGN: "NGN ₦" };
export const DEFAULT_CCY: Ccy = "USD";
export const CCY_COOKIE = "splari_ccy";

export function isCcy(v: unknown): v is Ccy {
  return typeof v === "string" && (CURRENCIES as readonly string[]).includes(v);
}

/**
 * Prices as whole units in the currency shown. Naira drops the kobo
 * entirely — nobody writes ₦25,000.00 — and dollars and pounds drop the
 * decimals when they are zero.
 */
export function money(cents: number, ccy: Ccy = DEFAULT_CCY): string {
  if (cents === 0) return "Free";
  const n = cents / 100;
  const sym = CCY_SYMBOL[ccy];
  if (ccy === "NGN") return `${sym}${Math.round(n).toLocaleString("en-NG")}`;
  return `${sym}${Number.isInteger(n) ? n.toLocaleString("en-GB") : n.toFixed(2)}`;
}
