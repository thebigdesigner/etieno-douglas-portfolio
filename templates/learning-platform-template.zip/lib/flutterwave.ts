/**
 * LEGACY — Your Brand now takes payments through Paystack (lib/paystack.ts).
 * Kept only so fulfilment can still verify Flutterwave payments made just
 * before the switch. Delete with app/api/webhooks/flutterwave once the
 * transition window in MARKETPLACE.md has passed.
 *
 * Flutterwave v3.
 *
 * v4 exists but is still public beta and moves to OAuth; v3 is the current
 * production API and takes a static secret key, so that is what this uses.
 * Everything provider-specific lives here — the rest of the app talks in
 * courses and users.
 *
 * The plan tables that used to sit here went with 0063. Nothing is sold on a
 * recurring basis now, so `paymentPlan` below is vestigial too: it is left on
 * CheckoutArgs because it costs nothing and removing it would be the only
 * thing standing between here and a future subscription, but no caller sets
 * it.
 */

function secret() {
  const key = process.env.FLW_SECRET_KEY;
  if (!key) throw new Error("FLW_SECRET_KEY is not set");
  return key;
}

export type CheckoutArgs = {
  txRef: string;
  amount: number;
  currency: string;
  email: string;
  name?: string | null;
  redirectUrl: string;
  /** Flutterwave payment plan id — set to subscribe rather than one-off. */
  paymentPlan?: string | number;
  meta?: Record<string, string>;
};

/** Returns the hosted checkout URL to send the customer to. */
export async function createCheckout(a: CheckoutArgs): Promise<string> {
  const res = await fetch("https://api.flutterwave.com/v3/payments", {
    method: "POST",
    headers: {
      Authorization: `Bearer ${secret()}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      tx_ref: a.txRef,
      amount: a.amount,
      currency: a.currency,
      redirect_url: a.redirectUrl,
      customer: { email: a.email, name: a.name ?? undefined },
      customizations: {
        title: "Your Brand",
        description: "Every course, and your certifications",
      },
      ...(a.paymentPlan ? { payment_plan: a.paymentPlan } : {}),
      meta: a.meta,
    }),
  });

  const data = await res.json();
  if (!res.ok || data.status !== "success" || !data.data?.link) {
    console.error("flutterwave checkout failed", res.status, data);
    throw new Error("Could not start checkout");
  }
  return data.data.link as string;
}

export type Verified = {
  ok: boolean;
  txRef: string;
  amount: number;
  currency: string;
  providerRef: string;
  email: string | null;
  planId: string | null;
};

/**
 * Confirms with Flutterwave directly. Never trust the redirect back or the
 * webhook body alone — both are attacker-reachable; this call is not.
 */
export async function verifyByReference(txRef: string): Promise<Verified | null> {
  const res = await fetch(
    `https://api.flutterwave.com/v3/transactions/verify_by_reference?tx_ref=${encodeURIComponent(txRef)}`,
    { headers: { Authorization: `Bearer ${secret()}` }, cache: "no-store" }
  );

  const body = await res.json();
  if (!res.ok || body.status !== "success" || !body.data) return null;

  const d = body.data;
  return {
    ok: d.status === "successful",
    txRef: d.tx_ref,
    amount: Number(d.amount),
    currency: d.currency,
    providerRef: String(d.id),
    email: d.customer?.email ?? null,
    planId: d.plan ? String(d.plan) : null,
  };
}
