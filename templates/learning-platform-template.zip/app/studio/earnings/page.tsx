import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";

export const metadata = { title: "Earnings" };
export const dynamic = "force-dynamic";

const TYPE_LABEL: Record<string, string> = {
  review: "Project assessed",
  pool_individual: "Subscription pool",
  pool_institution: "Institutional pool",
  referral: "Referral",
  adjustment: "Adjustment",
};

function money(cents: number) {
  return `$${(cents / 100).toFixed(2)}`;
}

export default async function EarningsPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  const admin = createAdminClient();

  const { data: entries } = await admin
    .from("earnings_entries")
    .select("id, type, amount_cents, note, created_at")
    .eq("instructor_id", user!.id)
    .order("created_at", { ascending: false })
    .limit(60);

  const { data: payouts } = await admin
    .from("payout_runs")
    .select("week_start, amount_cents, state, paid_at")
    .eq("instructor_id", user!.id)
    .order("week_start", { ascending: false })
    .limit(12);

  const { data: pools } = await admin
    .from("pool_periods")
    .select("period_month, source, pool_cents, completions, rate_per_completion_cents")
    .order("period_month", { ascending: false })
    .limit(6);

  const total = (entries ?? []).reduce((sum, e) => sum + e.amount_cents, 0);
  const paid = (payouts ?? [])
    .filter((p) => p.state === "paid")
    .reduce((sum, p) => sum + p.amount_cents, 0);
  const reviews = (entries ?? []).filter((e) => e.type === "review").length;

  return (
    <>
        <h1 className="sec__h" style={{ fontSize: 30, marginTop: 34 }}>Earnings</h1>

        <div className="dash__grid" style={{ marginTop: 24 }}>
          <div className="dash__card">
            <div className="eyebrow">Accrued</div>
            <div className="dash__val num">{money(total)}</div>
            <p className="dash__note">Everything credited to you.</p>
          </div>
          <div className="dash__card">
            <div className="eyebrow">Paid out</div>
            <div className="dash__val num">{money(paid)}</div>
            <p className="dash__note">Weekly, above the $20 threshold.</p>
          </div>
          <div className="dash__card">
            <div className="eyebrow">Projects assessed</div>
            <div className="dash__val num">{reviews}</div>
            <p className="dash__note">$18.85 each, credited on completion.</p>
          </div>
        </div>

        <section style={{ marginTop: 46 }}>
          <h2 className="sub__h2">How the pool was worked out</h2>
          <p className="studio__hint">
            35% of subscription revenue and 30% of institutional revenue, divided by
            completed topics across the catalogue. Check the arithmetic yourself.
          </p>
          {(!pools || pools.length === 0) ? (
            <p className="studio__hint" style={{ marginTop: 14 }}>No pool calculated yet.</p>
          ) : (
            <table className="tbl" style={{ marginTop: 18 }}>
              <thead>
                <tr><th>Month</th><th>Source</th><th>Pool</th><th>Completions</th><th>Per completion</th></tr>
              </thead>
              <tbody>
                {pools.map((p) => (
                  <tr key={`${p.period_month}-${p.source}`}>
                    <td>{new Date(p.period_month).toLocaleDateString(undefined, { month: "short", year: "numeric" })}</td>
                    <td>{p.source === "individual" ? "Subscriptions" : "Institutions"}</td>
                    <td>{money(p.pool_cents)}</td>
                    <td>{p.completions}</td>
                    <td>${(Number(p.rate_per_completion_cents) / 100).toFixed(4)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>

        <section style={{ marginTop: 46 }}>
          <h2 className="sub__h2">Statement</h2>
          {(!entries || entries.length === 0) ? (
            <p className="studio__hint" style={{ marginTop: 14 }}>Nothing yet.</p>
          ) : (
            <table className="tbl" style={{ marginTop: 18 }}>
              <thead><tr><th>Date</th><th>What</th><th>Amount</th></tr></thead>
              <tbody>
                {entries.map((e) => (
                  <tr key={e.id}>
                    <td>{new Date(e.created_at).toLocaleDateString()}</td>
                    <td>{TYPE_LABEL[e.type] ?? e.type}{e.note ? ` — ${e.note}` : ""}</td>
                    <td>{money(e.amount_cents)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>

        <section style={{ margin: "46px 0 30px" }}>
          <h2 className="sub__h2">Payout runs</h2>
          {(!payouts || payouts.length === 0) ? (
            <p className="studio__hint" style={{ marginTop: 14 }}>No runs yet.</p>
          ) : (
            <table className="tbl" style={{ marginTop: 18 }}>
              <thead><tr><th>Week</th><th>State</th><th>Amount</th></tr></thead>
              <tbody>
                {payouts.map((p) => (
                  <tr key={p.week_start}>
                    <td>{new Date(p.week_start).toLocaleDateString()}</td>
                    <td>{p.state.replace("_", " ")}</td>
                    <td>{money(p.amount_cents)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
          <p className="studio__hint" style={{ marginTop: 14 }}>
            Something look wrong? Raise it within thirty days and we will show you the
            underlying figures.
          </p>
        </section>
      </>
  );
}
