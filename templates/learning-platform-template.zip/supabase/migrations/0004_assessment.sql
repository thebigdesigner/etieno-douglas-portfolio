-- =====================================================================
-- Sprint 5 — submission, assessment, certificates
-- =====================================================================

-- ---------------------------------------------------------------------
-- One published business calendar. The four-working-day promise has to
-- mean the same thing in every country, so it is not per-learner.
-- ---------------------------------------------------------------------
create or replace function public.add_working_days(p_from timestamptz, p_days int)
returns timestamptz
language plpgsql
stable
security definer set search_path = public
as $$
declare
  cursor_ts timestamptz := p_from;
  added     int := 0;
begin
  while added < p_days loop
    cursor_ts := cursor_ts + interval '1 day';
    if extract(isodow from cursor_ts) < 6
       and not exists (select 1 from business_holidays h where h.day = cursor_ts::date)
    then
      added := added + 1;
    end if;
  end loop;
  return cursor_ts;
end;
$$;

-- ---------------------------------------------------------------------
-- Submission. Checks the allowance, sets the deadline, assigns a reviewer.
-- A resubmission after a "revise" verdict does not consume another one.
-- ---------------------------------------------------------------------
create or replace function public.create_submission(
  p_user_id uuid,
  p_course_id uuid,
  p_body text,
  p_files text[]
)
returns table (submission_id uuid, deadline timestamptz, error text)
language plpgsql
security definer set search_path = public
as $$
declare
  v_enrolment    enrolments%rowtype;
  v_prev         submissions%rowtype;
  v_attempt      int := 1;
  v_consumes     boolean := true;
  v_allowance    cert_allowances%rowtype;
  v_reviewer     uuid;
  v_deadline     timestamptz;
  v_id           uuid;
  v_topics_left  int;
begin
  select * into v_enrolment
    from enrolments
   where user_id = p_user_id and course_id = p_course_id;

  if not found then
    return query select null::uuid, null::timestamptz, 'not_enrolled'::text; return;
  end if;

  -- Every topic must be complete before the project opens.
  select count(*) into v_topics_left
    from topics t join modules m on m.id = t.module_id
   where m.course_id = p_course_id
     and t.id not in (
       select tc.topic_id from topic_completions tc where tc.enrolment_id = v_enrolment.id
     );

  if v_topics_left > 0 then
    return query select null::uuid, null::timestamptz, 'topics_incomplete'::text; return;
  end if;

  select * into v_prev
    from submissions
   where enrolment_id = v_enrolment.id
   order by attempt_no desc
   limit 1;

  if found then
    if v_prev.state in ('submitted','assigned','in_review') then
      return query select null::uuid, null::timestamptz, 'already_under_review'::text; return;
    end if;
    if v_prev.state = 'passed' then
      return query select null::uuid, null::timestamptz, 'already_passed'::text; return;
    end if;
    v_attempt := v_prev.attempt_no + 1;
    -- One free resubmission after a revise verdict.
    if v_prev.state = 'revision_requested' and v_attempt = 2 then
      v_consumes := false;
    end if;
  end if;

  if v_consumes then
    if v_enrolment.source = 'cohort' then
      v_consumes := false;              -- covered by the institution's plan
    else
      select * into v_allowance
        from cert_allowances
       where user_id = p_user_id
         and now() between period_start and period_end
       order by period_end desc
       limit 1;

      if not found then
        return query select null::uuid, null::timestamptz, 'no_plan'::text; return;
      end if;
      if v_allowance.used >= (v_allowance.included + v_allowance.purchased) then
        return query select null::uuid, null::timestamptz, 'allowance_spent'::text; return;
      end if;

      update cert_allowances set used = used + 1 where id = v_allowance.id;
    end if;
  end if;

  select c.instructor_id into v_reviewer from courses c where c.id = p_course_id;
  v_deadline := add_working_days(now(), 4);

  insert into submissions (
    enrolment_id, attempt_no, state, body, file_paths,
    assigned_reviewer_id, deadline_at, consumed_allowance
  )
  values (
    v_enrolment.id, v_attempt,
    case when v_reviewer is null then 'submitted' else 'assigned' end,
    p_body, p_files, v_reviewer, v_deadline, v_consumes
  )
  returning id into v_id;

  update enrolments set state = 'submitted' where id = v_enrolment.id;

  return query select v_id, v_deadline, null::text;
end;
$$;

-- ---------------------------------------------------------------------
-- Recording a verdict. On a pass, the certificate is issued here so the
-- two can never disagree.
-- ---------------------------------------------------------------------
create or replace function public.record_review(
  p_submission_id uuid,
  p_reviewer_id uuid,
  p_outcome review_outcome,
  p_feedback text,
  p_scores jsonb
)
returns table (certificate_code text, error text)
language plpgsql
security definer set search_path = public
as $$
declare
  v_sub       submissions%rowtype;
  v_enrolment enrolments%rowtype;
  v_profile   profiles%rowtype;
  v_reviewer  text;
  v_code      text;
  v_in_sla    boolean;
begin
  select * into v_sub from submissions where id = p_submission_id for update;
  if not found then
    return query select null::text, 'not_found'::text; return;
  end if;
  if v_sub.state in ('passed','abandoned') then
    return query select null::text, 'already_decided'::text; return;
  end if;

  v_in_sla := now() <= v_sub.deadline_at;

  insert into reviews (submission_id, reviewer_id, outcome, feedback, scores, within_sla)
  values (p_submission_id, p_reviewer_id, p_outcome, p_feedback, p_scores, v_in_sla);

  select * into v_enrolment from enrolments where id = v_sub.enrolment_id;
  select * into v_profile   from profiles   where id = v_enrolment.user_id;

  select coalesce(pr.display_name, 'Your Brand reviewer') into v_reviewer
    from profiles pr where pr.id = p_reviewer_id;

  -- $18.85 per assessed project, credited on completion rather than enrolment.
  insert into earnings_entries (instructor_id, type, amount_cents, ref_id, note)
  values (p_reviewer_id, 'review', 1885, p_submission_id, 'Project assessment');

  if p_outcome = 'pass' then
    update submissions set state = 'passed' where id = p_submission_id;
    update enrolments  set state = 'certified' where id = v_enrolment.id;

    v_code := 'SPL-' || upper(substr(encode(gen_random_bytes(6), 'hex'), 1, 4))
              || '-' || upper(substr(encode(gen_random_bytes(6), 'hex'), 1, 4));

    insert into certificates (enrolment_id, code, reviewer_name, show_name)
    values (
      v_enrolment.id, v_code, v_reviewer,
      not coalesce(v_profile.minor_protections, false)
    );

    return query select v_code, null::text;
  else
    update submissions set state = 'revision_requested' where id = p_submission_id;
    update enrolments  set state = 'topics_complete' where id = v_enrolment.id;
    return query select null::text, null::text;
  end if;
end;
$$;

-- ---------------------------------------------------------------------
-- SLA cover. The promise is Your Brand's, not the instructor's: at day three
-- an operator is alerted, at day four the item moves to a reserve.
-- ---------------------------------------------------------------------
create or replace view public.review_queue_status as
select s.id                                   as submission_id,
       s.state,
       s.submitted_at,
       s.deadline_at,
       s.assigned_reviewer_id,
       s.escalated_at,
       c.title                                as course_title,
       p.display_name                         as learner_name,
       (now() > s.deadline_at)                as breached,
       (now() > s.deadline_at - interval '1 day') as due_soon
  from submissions s
  join enrolments e on e.id = s.enrolment_id
  join courses    c on c.id = e.course_id
  join profiles   p on p.id = e.user_id
 where s.state in ('submitted','assigned','in_review');

create or replace function public.reassign_to_reserve(p_submission_id uuid, p_reserve_id uuid)
returns boolean
language plpgsql
security definer set search_path = public
as $$
begin
  update submissions
     set assigned_reviewer_id = p_reserve_id,
         reassigned_at = now(),
         state = 'assigned'
   where id = p_submission_id
     and state in ('submitted','assigned','in_review');
  return found;
end;
$$;

-- ---------------------------------------------------------------------
-- Appeals: one per submission, to a reviewer who cannot see the first
-- verdict, and never back to the original reviewer.
-- ---------------------------------------------------------------------
create or replace function public.open_appeal(p_submission_id uuid, p_grounds text)
returns boolean
language plpgsql
security definer set search_path = public
as $$
begin
  if exists (select 1 from appeals where submission_id = p_submission_id) then
    return false;
  end if;
  if not exists (
    select 1 from submissions
     where id = p_submission_id and state = 'revision_requested'
  ) then
    return false;
  end if;

  insert into appeals (submission_id, grounds) values (p_submission_id, p_grounds);
  return true;
end;
$$;

-- ---------------------------------------------------------------------
-- Policies
-- ---------------------------------------------------------------------
create policy own_submissions on submissions for select using (
  exists (select 1 from enrolments e
           where e.id = submissions.enrolment_id and e.user_id = auth.uid())
  or auth.uid() = submissions.assigned_reviewer_id
);

create policy own_reviews on reviews for select using (
  exists (
    select 1 from submissions s join enrolments e on e.id = s.enrolment_id
     where s.id = reviews.submission_id
       and (e.user_id = auth.uid() or s.assigned_reviewer_id = auth.uid())
  )
);

create policy own_certificates on certificates for select using (
  exists (select 1 from enrolments e
           where e.id = certificates.enrolment_id and e.user_id = auth.uid())
);

revoke all on function public.create_submission(uuid, uuid, text, text[]) from public, anon, authenticated;
revoke all on function public.record_review(uuid, uuid, review_outcome, text, jsonb) from public, anon, authenticated;
revoke all on function public.reassign_to_reserve(uuid, uuid) from public, anon, authenticated;
revoke all on function public.open_appeal(uuid, text) from public, anon, authenticated;

-- ---------------------------------------------------------------------
-- Storage for project submissions. Private bucket; access goes through
-- signed URLs issued server-side.
-- ---------------------------------------------------------------------
insert into storage.buckets (id, name, public, file_size_limit)
values ('submissions', 'submissions', false, 52428800)
on conflict (id) do nothing;

-- Learners upload only into their own folder.
create policy "learners upload own submissions"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'submissions' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "learners read own submissions"
  on storage.objects for select to authenticated
  using (bucket_id = 'submissions' and (storage.foldername(name))[1] = auth.uid()::text);
