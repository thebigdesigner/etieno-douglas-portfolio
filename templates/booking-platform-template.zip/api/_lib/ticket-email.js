/**
 * Builds and sends a ticket email from a booking that the database says is paid.
 * Shared by /api/ticket (customer asks for a resend) and the Paystack webhook (automatic).
 *
 * The QR is rendered here, server-side, because email clients cannot run scripts.
 */
import { createRequire } from 'module';
import zlib from 'zlib';
import { select, tenant } from './db.js';
import { legsOf } from './legs.js';

const require_ = createRequire(import.meta.url);
const qrcode = require_('./qrcode.cjs');

const esc = s => String(s == null ? '' : s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const naira = n => '₦' + Number(n || 0).toLocaleString('en-NG');

function qrMatrix(text) {
  const q = qrcode(0, 'M'); q.addData(text); q.make();
  const n = q.getModuleCount();
  return Array.from({ length: n }, (_, r) => Array.from({ length: n }, (_, c) => (q.isDark(r, c) ? 1 : 0)));
}

/** Minimal PNG writer — no image dependencies on the server. */
function qrPng(matrix, scale = 6, quiet = 4) {
  const n = matrix.length, size = (n + quiet * 2) * scale;
  const row = new Uint8Array(size * 3), raw = [];
  for (let y = 0; y < size; y++) {
    const my = Math.floor(y / scale) - quiet;
    row.fill(255);
    if (my >= 0 && my < n) {
      for (let x = 0; x < size; x++) {
        const mx = Math.floor(x / scale) - quiet;
        if (mx >= 0 && mx < n && matrix[my][mx]) { row[x * 3] = 0x15; row[x * 3 + 1] = 0x17; row[x * 3 + 2] = 0x1c; }
      }
    }
    raw.push(0, ...row);
  }
  const crcTable = (() => { const t = []; for (let i = 0; i < 256; i++) { let c = i; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; t[i] = c >>> 0; } return t; })();
  const crc = buf => { let c = 0xffffffff; for (const b of buf) c = crcTable[(c ^ b) & 0xff] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; };
  const chunk = (type, body) => {
    const len = Buffer.alloc(4); len.writeUInt32BE(body.length);
    const t = Buffer.from(type, 'ascii'), c = Buffer.alloc(4); c.writeUInt32BE(crc(Buffer.concat([t, body])));
    return Buffer.concat([len, t, body, c]);
  };
  const ihdr = Buffer.alloc(13);
  ihdr.writeUInt32BE(size, 0); ihdr.writeUInt32BE(size, 4); ihdr[8] = 8; ihdr[9] = 2;
  return Buffer.concat([
    Buffer.from([137, 80, 78, 71, 13, 10, 26, 10]),
    chunk('IHDR', ihdr),
    chunk('IDAT', zlib.deflateSync(Buffer.from(raw), { level: 9 })),
    chunk('IEND', Buffer.alloc(0))
  ]);
}

function html({ reference, legs, passengers, total, method, arriveBefore, checkInClose }) {
  const rows = legs.map(l => `
    <tr><td style="padding:14px 0;border-bottom:1px solid #e7e9ee">
      <div style="font:600 12px/1.4 Arial,sans-serif;color:#6b7280">${esc(l.dir || 'Outbound')}</div>
      <div style="font:700 17px/1.4 Arial,sans-serif;color:#15171c">${esc(l.from)} &rarr; ${esc(l.to)}</div>
      <div style="font:400 14px/1.5 Arial,sans-serif;color:#15171c">${esc(l.date)} at ${esc(l.time)} &middot; seat${l.seats.length > 1 ? 's' : ''} ${esc(l.seats.join(', '))}</div>
    </td></tr>`).join('');
  return `<!doctype html><html><body style="margin:0;background:#f4f5f7;padding:24px 12px">
  <table role="presentation" width="100%"><tr><td align="center">
    <table role="presentation" width="560" style="max-width:560px;background:#fff;border-radius:14px;overflow:hidden">
      <tr><td style="background:#15171c;padding:24px">
        <div style="font:800 26px/1 Arial,sans-serif;color:#fff;letter-spacing:1px">${esc(reference)}</div>
        <div style="font:400 13px/1.5 Arial,sans-serif;color:#b9bcc4;padding-top:8px">Booking reference &mdash; show this at the terminal</div>
      </td></tr>
      <tr><td style="padding:8px 24px 0"><table role="presentation" width="100%">${rows}</table></td></tr>
      <tr><td style="padding:18px 24px 0" align="center">
        <img src="cid:ticketqr" width="170" height="170" alt="QR code for booking ${esc(reference)}" style="display:block;border:1px solid #e7e9ee;border-radius:10px">
        <div style="font:400 12px/1.6 Arial,sans-serif;color:#6b7280;padding-top:8px">Terminal staff can scan this code</div>
      </td></tr>
      <tr><td style="padding:18px 24px 24px">
        <div style="font:400 14px/1.7 Arial,sans-serif;color:#15171c">
          Passengers: ${esc(passengers.join(', '))}<br>Paid: <strong>${esc(naira(total))}</strong>${method ? ` by ${esc(method)}` : ''}
        </div>
        <div style="font:400 13px/1.7 Arial,sans-serif;color:#6b7280;padding-top:14px;border-top:1px solid #e7e9ee;margin-top:14px">
          Arrive ${arriveBefore} minutes before departure; check-in closes ${checkInClose} minutes before.
          Bags are checked at the terminal. Bring an ID matching the lead passenger's name.
        </div>
      </td></tr>
    </table>
    <div style="font:400 12px Arial,sans-serif;color:#6b7280;padding:16px">Your Brand &mdash; first for service</div>
  </td></tr></table></body></html>`;
}

/**
 * Loads the booking, refuses unless it is confirmed, and emails the stored record.
 * Returns { sent: true } or throws. Nothing here is taken from the caller except the reference.
 */
export async function sendTicketEmail(reference) {
  const key = process.env.RESEND_API_KEY, from = process.env.TICKET_FROM;
  if (!key || !from) { const e = new Error('email not configured'); e.code = 'not_configured'; throw e; }

  const t = await tenant();
  const rows = await select('bookings',
    `tenant_id=eq.${t.id}&reference=eq.${reference}&select=reference,status,total_kobo,contact_email,` +
    `passengers(full_name,seat_no,trip:trips(depart_date,depart_time,route:routes(from_terminal,to_terminal))),` +
    `payments(status,channel)`);
  const b = rows[0];
  if (!b) { const e = new Error('booking not found'); e.code = 'not_found'; throw e; }
  if (b.status !== 'confirmed') { const e = new Error('booking is not paid'); e.code = 'not_paid'; throw e; }
  if (!b.contact_email) { const e = new Error('no email on this booking'); e.code = 'no_email'; throw e; }

  const terminals = await select('terminals', `tenant_id=eq.${t.id}&select=id,city`);
  const cityOf = id => terminals.find(x => x.id === id)?.city || '';
  const settings = t.settings || {};
  /* Every leg of the booking goes on the ticket — a round trip used to show only the way out. */
  const { legs, people } = legsOf(b.passengers, cityOf);
  const paid = (b.payments || []).find(p => p.status === 'success' && p.channel !== 'coupon') || (b.payments || []).find(p => p.status === 'success');
  const site = (process.env.SITE_URL || '').replace(/\/$/, '');
  const payload = site ? `${site}/booking/${b.reference}` : b.reference;

  const attachments = [];
  try { attachments.push({ filename: `${b.reference}.png`, content: qrPng(qrMatrix(payload)).toString('base64'), content_id: 'ticketqr' }); } catch { /* send without it */ }

  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      from, to: [b.contact_email],
      subject: `Your Your Brand ticket — ${b.reference}`,
      html: html({
        reference: b.reference, legs,
        passengers: people,
        total: b.total_kobo / 100, method: paid?.channel || null,
        arriveBefore: settings.arrive_before_min ?? 30,
        checkInClose: settings.check_in_close_min ?? 15
      }),
      attachments
    })
  });
  if (!res.ok) throw new Error(`resend ${res.status}`);
  return { sent: true, to: b.contact_email };
}
