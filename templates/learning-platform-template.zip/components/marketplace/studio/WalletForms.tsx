"use client";

import { useActionState, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { cancelPayout, requestPayout, savePayoutAccount } from "@/app/actions/marketplace";
import type { FormState } from "@/lib/forms";
import type { PayoutAccount } from "@/lib/marketplace/wallet";
import { CCY_LABEL, CCY_SYMBOL, money, type Ccy } from "@/lib/money";
import StudioSubmit from "./StudioSubmit";



function Msg({ s }: { s: FormState }) {
  if (s.error) return <p className="st-msg st-msg--err" role="alert">{s.error}</p>;
  if (s.ok && s.message) return <p className="st-msg st-msg--ok" role="status">{s.message}</p>;
  return null;
}

/**
 * Where withdrawals in one currency are sent. Shown masked once saved.
 * A creator paid in naira and pounds keeps two accounts, because the money
 * genuinely goes to two places.
 */
export function PayoutAccountForm({ account, currency }: { account: PayoutAccount | null; currency: Ccy }) {
  const [state, action] = useActionState<FormState, FormData>(savePayoutAccount, {});
  const [editing, setEditing] = useState(!account);

  if (account && !editing) {
    const tail = account.accountNumber?.slice(-4) ?? "";
    return (
      <div className="st-acct">
        <div>
          <span className="st-acct__name">{account.accountName}</span>
          <span className="st-acct__bank">{account.bankName} · ••••{tail} · {account.currency}</span>
        </div>
        <button type="button" className="mk-btn mk-btn--line" onClick={() => setEditing(true)}>Change</button>
      </div>
    );
  }

  return (
    <form action={action} className="st-form">
      <input type="hidden" name="currency" value={currency} />
      <div className="st-row">
        <label className="st-field">
          <span className="st-field__label">Country</span>
          <select name="country" defaultValue={account?.country ?? "NG"}>
            <option value="NG">Nigeria</option><option value="GH">Ghana</option>
            <option value="KE">Kenya</option><option value="ZA">South Africa</option>
            <option value="OT">Somewhere else</option>
          </select>
        </label>
      </div>
      <label className="st-field">
        <span className="st-field__label">Bank</span>
        <input name="bank_name" required maxLength={80} defaultValue={account?.bankName ?? ""} placeholder="GTBank" />
      </label>
      <div className="st-row">
        <label className="st-field">
          <span className="st-field__label">Account number</span>
          <input name="account_number" required inputMode="numeric" pattern="[0-9]{6,20}"
            defaultValue={account?.accountNumber ?? ""} placeholder="0123456789" />
        </label>
        <label className="st-field">
          <span className="st-field__label">Account name</span>
          <input name="account_name" required maxLength={80} defaultValue={account?.accountName ?? ""} />
        </label>
      </div>
      <span className="st-field__hint">The name on the account must match your own; we cannot pay a third party.</span>
      <Msg s={state} />
      <div className="st-actions">
        <StudioSubmit>Save payout details</StudioSubmit>
        {account && <button type="button" className="mk-btn mk-btn--line" onClick={() => setEditing(false)}>Cancel</button>}
      </div>
    </form>
  );
}

export function RequestPayoutForm({ availableCents, minCents, hasAccount, currency }: {
  availableCents: number; minCents: number; hasAccount: boolean; currency: Ccy;
}) {
  const [state, action] = useActionState<FormState, FormData>(requestPayout, {});
  const canWithdraw = hasAccount && availableCents >= minCents;

  return (
    <form action={action} className="st-form">
      <input type="hidden" name="currency" value={currency} />
      <label className="st-field">
        <span className="st-field__label">Amount to withdraw ({CCY_LABEL[currency]})</span>
        <span className="st-money"><span>{CCY_SYMBOL[currency]}</span>
          <input name="amount" inputMode="decimal" required disabled={!canWithdraw}
            defaultValue={availableCents >= minCents
              ? (currency === "NGN" ? String(Math.round(availableCents / 100)) : (availableCents / 100).toFixed(2))
              : ""} />
        </span>
        <span className="st-field__hint">
          {hasAccount
            ? `Available now: ${money(availableCents, currency)}. Smallest withdrawal ${money(minCents, currency)}.`
            : "Add your bank details below before withdrawing."}
        </span>
      </label>
      <Msg s={state} />
      {canWithdraw ? <StudioSubmit>Request withdrawal</StudioSubmit>
        : <button type="button" className="mk-btn mk-btn--fill" disabled>Request withdrawal</button>}
    </form>
  );
}

export function CancelPayout({ id }: { id: string }) {
  const [pending, start] = useTransition();
  const router = useRouter();
  return (
    <button type="button" className="st-linkbtn" disabled={pending}
      onClick={() => start(async () => { await cancelPayout(id); router.refresh(); })}>
      Cancel
    </button>
  );
}
