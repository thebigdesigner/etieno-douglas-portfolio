/**
 * The page an emailed link opens.
 *
 * A one-time link must not be spent by a GET. Mail providers and company security filters
 * (Outlook Safe Links, Mimecast, Gmail's scanners) open every link in a message to check it,
 * and a link that signs in on GET is used up by the scanner before the customer taps it —
 * they get "link expired" on a link they have never opened. So GET only shows a button; the
 * button POSTs the same token back, and only that POST spends it.
 */
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

export function confirmPage(res, { action, token, title, button, detail = 'Tap the button to finish. The link works once.', danger = false }) {
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('X-Robots-Tag', 'noindex, nofollow');
  res.status(200).end(`<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><meta name="robots" content="noindex">
<title>${esc(title)} — Your Brand</title>
<style>
  body{margin:0;min-height:100vh;display:grid;place-items:center;background:#f4f5f7;font:400 16px/1.5 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;color:#15171c}
  main{background:#fff;border-radius:16px;padding:32px 28px;max-width:380px;width:calc(100% - 32px);box-shadow:0 8px 30px rgba(16,24,40,.08);text-align:center}
  h1{font-size:21px;margin:0 0 8px}p{margin:0 0 22px;color:#555}
  button{font:700 16px system-ui,sans-serif;background:#59ED05;color:#15171c;border:0;border-radius:10px;padding:14px 26px;width:100%;cursor:pointer}
  button.danger{background:#15171c;color:#fff}
  .aside{margin:16px 0 0;font-size:14px}.aside a{color:#15171c}
</style></head><body><main>
<h1>${esc(title)}</h1><p>${esc(detail)}</p>
<form method="post" action="${esc(action)}"><input type="hidden" name="t" value="${esc(token)}">
<button type="submit"${danger ? ' class="danger"' : ''}>${esc(button)}</button></form>
<p class="aside"><a href="/">Go back to the site</a></p>
</main></body></html>`);
}

/** The token from either the query string (GET) or the posted form (POST). */
export const tokenOf = req => String((req.method === 'POST' ? req.body?.t : req.query?.t) || '');
