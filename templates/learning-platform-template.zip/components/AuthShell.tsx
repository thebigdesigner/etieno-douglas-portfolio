import Link from "next/link";

export default function AuthShell({
  eyebrow, title, intro, children, footer, progress,
}: {
  eyebrow?: string;
  title: string;
  intro?: string;
  children?: React.ReactNode;
  footer?: React.ReactNode;
  progress?: React.ReactNode;
}) {
  return (
    <main className="auth">
      <div className="auth__card">
        <Link className="logo auth__logo" href="/">Your Brand<span>.</span></Link>
        {progress}
        {eyebrow && <div className="eyebrow">{eyebrow}</div>}
        <h1 className="auth__h">{title}</h1>
        {intro && <p className="auth__intro">{intro}</p>}
        {children}
        {footer && <div className="auth__foot">{footer}</div>}
      </div>
    </main>
  );
}
