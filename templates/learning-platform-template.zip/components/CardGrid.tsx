import Link from "next/link";

export type PanelCard = {
  title: string;
  detail: string;
  href: string;
  cta: string;
  tint?: "sky" | "mint" | "cream" | "pink" | "wash";
};

/** The wide promotional panels. Used for the things somebody might do next,
 *  rather than the things they must. */
export default function CardGrid({ cards }: { cards: PanelCard[] }) {
  return (
    <div className="panels">
      {cards.map((c) => (
        <article key={c.title} className={`panel panel--${c.tint ?? "wash"}`}>
          <h3 className="panel__h">{c.title}</h3>
          <p className="panel__p">{c.detail}</p>
          <Link className="panel__cta" href={c.href}>{c.cta}</Link>
        </article>
      ))}
    </div>
  );
}
