import { requireOwner } from "@/lib/owner";
import { createAdminClient } from "@/lib/supabase/admin";
import AppShell from "@/components/AppShell";
import { consoleNav } from "@/lib/app-nav";

export const metadata = { robots: { index: false, follow: false } };

export default async function ConsoleLayout({ children }: { children: React.ReactNode }) {
  const owner = await requireOwner();

  const admin = createAdminClient();
  const { data: queue } = await admin.from("review_queue_status").select("breached");
  const breached = (queue ?? []).filter((q) => q.breached).length;

  /* The bell was mounted on the learner dashboard and nowhere else, so
     everything waiting on somebody here was invisible unless they opened
     the right page — including the two promises with clocks on them, the
     four-day assessment and the thirty-day erasure. */
  const { data: notifications } = await admin
    .rpc("operator_notifications", { p_user_id: owner.id });
  const { data: me } = await admin
    .from("profiles").select("notifications_seen_at").eq("id", owner.id).maybeSingle();
  const seenAt = me?.notifications_seen_at
    ? new Date(me.notifications_seen_at).getTime() : 0;
  const unread = (notifications ?? [])
    .filter((n: { at: string }) => new Date(n.at).getTime() > seenAt).length;

  return (
    <div className="con">
      <AppShell
        brand="Console"
        notifications={notifications ?? []}
        unread={unread}
        name={owner.name ?? owner.email}
        groups={consoleNav(breached)}
        searchPlaceholder="Search people and certificates…"
        /* Every other surface sets this; the console did not, so AppShell
           fell back to its learner default and both the logo and the account
           menu's first item took an operator to /dashboard. */
        homeHref="/console"
      >
        {children}
      </AppShell>
    </div>
  );
}
