import Link from "next/link";
import type { Category, ProductQuery, Sort } from "@/lib/marketplace/types";
import { CATEGORIES, countLabel } from "@/lib/marketplace/categories";
import { getAuthors, isDemo, listProducts, categoryCounts } from "@/lib/marketplace/catalog";
import { mk } from "@/lib/marketplace/href";
import FilterToggle from "@/components/marketplace/FilterToggle";
import FilterForm from "@/components/marketplace/FilterForm";
import MkIcon from "@/components/marketplace/MkIcon";
import CategoryTiles from "@/components/marketplace/CategoryTiles";
import { DemoNote, ProductGrid } from "@/components/marketplace/bits";

/**
 * One results page for every way into the catalogue: a category, all
 * items, or a search. Envato's shape — filters down the left, a toolbar
 * with the count and the sort, the grid, then pages.
 */

export type RawParams = Record<string, string | string[] | undefined>;

const SORTS: { value: Sort; label: string }[] = [
  { value: "popular", label: "Most popular" },
  { value: "newest", label: "Newest" },
  { value: "rating", label: "Highest rated" },
  { value: "price-asc", label: "Price: low to high" },
  { value: "price-desc", label: "Price: high to low" },
];

const one = (v: string | string[] | undefined) => (Array.isArray(v) ? v[0] : v) ?? "";
const many = (v: string | string[] | undefined) => (Array.isArray(v) ? v : v ? [v] : []);

export function parseQuery(params: RawParams, category?: Category): ProductQuery {
  const sort = one(params.sort) as Sort;
  const price = one(params.price);
  const rating = Number(one(params.rating));
  const page = Number(one(params.page));
  const sub = one(params.sub);
  return {
    category: category?.slug,
    subcategory: category?.subcategories.some((s) => s.slug === sub) ? sub : undefined,
    q: one(params.q).trim().slice(0, 100) || undefined,
    price: price === "free" || price === "paid" ? price : undefined,
    formats: many(params.format).slice(0, 10),
    minRating: rating >= 1 && rating <= 5 ? rating : undefined,
    sort: SORTS.some((s) => s.value === sort) ? sort : "popular",
    page: Number.isInteger(page) && page > 0 ? page : 1,
  };
}

/** Rebuild the query string with some keys changed. Empty values drop out. */
function withParams(q: ProductQuery, change: Record<string, string | undefined>): string {
  const sp = new URLSearchParams();
  const set = (k: string, v?: string) => { if (v) sp.append(k, v); };
  set("q", q.q); set("sub", q.subcategory); set("price", q.price);
  q.formats?.forEach((f) => set("format", f));
  set("rating", q.minRating ? String(q.minRating) : undefined);
  set("sort", q.sort !== "popular" ? q.sort : undefined);
  set("page", q.page && q.page > 1 ? String(q.page) : undefined);
  for (const [k, v] of Object.entries(change)) { sp.delete(k); set(k, v); }
  const s = sp.toString();
  return s ? `?${s}` : "";
}

export default async function Browse({
  base, category, params, title, intro,
}: {
  base: string;
  category?: Category;
  params: RawParams;
  title: string;
  intro?: string;
}) {
  const query = parseQuery(params, category);
  const [result, demo] = await Promise.all([listProducts(query), isDemo()]);
  const authors = await getAuthors(result.items.map((p) => p.author));

  const path = category ? mk(base, `/${category.slug}`) : query.q ? mk(base, "/search") : mk(base, "/all");
  const formats = category ? category.formats : [...new Set(CATEGORIES.flatMap((c) => c.formats))].slice(0, 12);
  const filtered = Boolean(query.subcategory || query.price || query.formats?.length || query.minRating);
  const formId = "mk-filters";

  return (
    <>
      {demo && <DemoNote />}

      <nav className="mk-crumbs" aria-label="Breadcrumb">
        <Link href={mk(base, "/")}>Marketplace</Link>
        <span aria-hidden="true">/</span>
        <span aria-current="page">{category?.name ?? (query.q ? "Search" : "All items")}</span>
      </nav>

      <header className="mk-bh">
        <h1 className="mk-bh__h">{title}</h1>
        {intro && <p className="mk-bh__p">{intro}</p>}
      </header>

      {category && (
        <div className="mk-chips" role="list" aria-label={`${category.name} types`}>
          <Link role="listitem" className={`mk-chip${!query.subcategory ? " is-on" : ""}`}
            href={`${path}${withParams(query, { sub: undefined, page: undefined })}`}>All</Link>
          {category.subcategories.map((s) => (
            <Link role="listitem" key={s.slug} className={`mk-chip${query.subcategory === s.slug ? " is-on" : ""}`}
              href={`${path}${withParams(query, { sub: s.slug, page: undefined })}`}>{s.name}</Link>
          ))}
        </div>
      )}

      {!category && !query.q && <CategoryTiles base={base} counts={await categoryCounts()} />}

      <div className="mk-browse">
        <aside className="mk-filters" aria-label="Filters">
          <FilterForm id={formId} action={path} className="mk-filters__form">
            {query.q && <input type="hidden" name="q" value={query.q} />}
            {query.subcategory && <input type="hidden" name="sub" value={query.subcategory} />}
            <input type="hidden" name="page" defaultValue="" />

            <div className="mk-filters__top">
              <h2 className="mk-filters__h"><MkIcon name="sliders" size={16} />Filters</h2>
              <FilterToggle />
              {filtered && (
                <Link className="mk-filters__clear" href={`${path}${query.q ? `?q=${encodeURIComponent(query.q)}` : ""}`}>Clear</Link>
              )}
            </div>

            <fieldset className="mk-fg">
              <legend>Price</legend>
              {[["", "Any price"], ["free", "Free"], ["paid", "Paid"]].map(([v, l]) => (
                <label key={v} className="mk-opt">
                  <input type="radio" name="price" value={v} defaultChecked={(query.price ?? "") === v} />
                  <span>{l}</span>
                </label>
              ))}
            </fieldset>

            <fieldset className="mk-fg">
              <legend>File format</legend>
              {formats.map((f) => (
                <label key={f} className="mk-opt">
                  <input type="checkbox" name="format" value={f} defaultChecked={query.formats?.includes(f)} />
                  <span>{f}</span>
                </label>
              ))}
            </fieldset>

            <fieldset className="mk-fg">
              <legend>Rating</legend>
              {[["", "Any rating"], ["4.5", "4.5 and up"], ["4", "4 and up"]].map(([v, l]) => (
                <label key={v} className="mk-opt">
                  <input type="radio" name="rating" value={v} defaultChecked={String(query.minRating ?? "") === v} />
                  <span>{l}</span>
                </label>
              ))}
            </fieldset>

            <button type="submit" className="mk-btn mk-btn--line mk-filters__apply">Apply filters</button>
          </FilterForm>
        </aside>

        <div className="mk-results">
          <div className="mk-bar">
            <p className="mk-bar__n" aria-live="polite">
              {countLabel(category, result.total)}
              {query.q && <> for <strong>“{query.q}”</strong></>}
            </p>
            <label className="mk-sort">
              <span>Sort by</span>
              <select name="sort" form={formId} defaultValue={query.sort}>
                {SORTS.map((s) => <option key={s.value} value={s.value}>{s.label}</option>)}
              </select>
            </label>
          </div>

          {result.items.length > 0 ? (
            <ProductGrid items={result.items} base={base} authors={authors} />
          ) : (
            <div className="mk-empty">
              <MkIcon name="search" size={28} />
              <h2>No items match {query.q ? `“${query.q}”` : "these filters"}</h2>
              <p>Try a broader word, or remove a filter.</p>
              <Link className="mk-btn mk-btn--line" href={filtered ? path : mk(base, "/all")}>
                {filtered ? "Clear filters" : "Browse all items"}
              </Link>
            </div>
          )}

          {result.pages > 1 && (
            <nav className="mk-pages" aria-label="Pages">
              {result.page > 1 && (
                <Link href={`${path}${withParams(query, { page: String(result.page - 1) })}`} rel="prev">Previous</Link>
              )}
              {Array.from({ length: result.pages }, (_, i) => i + 1).map((n) => (
                <Link key={n} href={`${path}${withParams(query, { page: n > 1 ? String(n) : undefined })}`}
                  className={n === result.page ? "is-on" : undefined} aria-current={n === result.page ? "page" : undefined}>{n}</Link>
              ))}
              {result.page < result.pages && (
                <Link href={`${path}${withParams(query, { page: String(result.page + 1) })}`} rel="next">Next</Link>
              )}
            </nav>
          )}
        </div>
      </div>
    </>
  );
}
