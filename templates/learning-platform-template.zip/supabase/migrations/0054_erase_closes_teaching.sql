-- =====================================================================
-- 0054 — erasing a practitioner has to close their teaching too
--
-- 0053 anonymised the person and left everything they were responsible
-- for running. Tested against this schema, erasing a practitioner who
-- had a live course produced:
--
--   · a $49 course still published, still in the catalogue, still
--     buyable, listed as taught by "Deleted account" — and its price
--     includes an assessment by a named practitioner who no longer
--     exists. Your Brand would have gone on taking money for a promise it
--     could not keep, which is the one thing the product cannot do.
--   · instructors.state still 'active', so they stayed in
--     eligible_assessors() and could be named on new courses and
--     offered as an SLA reserve.
--   · any submission on that course assigned to somebody who cannot
--     sign in, so it would sit past its deadline forever.
--
-- So erasure now closes the teaching as well as the person:
--
--   1. Courses they OWN and that are live are retired. Nothing is
--      deleted and nobody loses access — retire_course only stops new
--      sales and delists. Learners part-way through keep their place
--      and their certificates.
--
--   2. Their practitioner record is suspended, which takes them out of
--      eligible_assessors() and every reserve list.
--
--   3. Erasure is REFUSED while they are the named assessor on a course
--      somebody else owns. A Your Brand or institution course with their
--      name on it needs a human to choose a replacement — that is not a
--      decision this function can make, and silently retiring another
--      party's course would be worse than asking. The operator sees the
--      reason and reassigns first.
--
-- ---------------------------------------------------------------------
-- WHAT IS DELIBERATELY KEPT: reviewer_name on issued certificates
-- ---------------------------------------------------------------------
-- certificates.reviewer_name holds the erased person's real name, and
-- it stays. That is a decision, not an oversight.
--
-- The certificate's whole meaning is that a named practitioner assessed
-- the work. Blanking the name would not erase a fact about the leaver so
-- much as devalue a credential belonging to somebody else — the learner,
-- who did the work and had no part in this request. It is a record of a
-- professional act performed in a professional capacity, not a profile.
--
-- It is worth saying out loud to the person before they confirm, and the
-- console panel does. If a specific request ever needs to go further,
-- that should be a considered decision on a named certificate, not a
-- side effect of a routine erasure.
-- =====================================================================

create or replace function public.erase_account(p_user_id uuid, p_actor uuid)
returns table (ok boolean, reason text)
language plpgsql security definer set search_path = public as $$
declare
  v_blocking int;
  v_course   record;
begin
  if not exists (select 1 from profiles where id = p_user_id) then
    return query select false, 'no_account'; return;
  end if;

  /* Somebody else's course with their name on it as the assessor.
   * Refused rather than guessed: choosing who assesses a course in
   * their place is a judgement, and quietly retiring an organisation's
   * private course or a Your Brand course to get an erasure through would
   * be a worse outcome than asking an operator to reassign it. */
  select count(*) into v_blocking
    from courses c
   where c.instructor_id = p_user_id
     and c.owner_kind <> 'instructor'::course_owner_kind
     and c.state in ('published', 'in_review');

  if v_blocking > 0 then
    return query select false, 'assessor_on_other_courses'; return;
  end if;

  -- Their own live courses stop being sold. Nothing is deleted: buyers
  -- and enrolled learners keep everything they already have.
  for v_course in
    select id from courses
     where instructor_id = p_user_id
       and owner_kind = 'instructor'::course_owner_kind
       and state = 'published'
  loop
    perform retire_course(v_course.id, p_actor);
  end loop;

  -- Out of eligible_assessors() and every reserve list.
  update instructors set state = 'suspended', accepts_reviews = false, available = false
   where id = p_user_id;

  -- The person.
  update profiles set
    display_name       = 'Deleted account',
    email              = null,
    date_of_birth      = null,
    guardian_email     = null,
    segment            = null,
    avatar_path        = null,
    avatar_alt         = null,
    marketing_opt_in   = false,
    status             = 'deleted'
  where id = p_user_id;

  -- Their name comes off every public certificate they HOLD. The name on
  -- certificates they SIGNED stays — see the note at the top.
  update certificates c set show_name = false
    from enrolments e
   where e.id = c.enrolment_id and e.user_id = p_user_id;

  update submissions s set body = null, file_paths = '{}'
    from enrolments e
   where e.id = s.enrolment_id and e.user_id = p_user_id;

  delete from topic_notes where user_id = p_user_id;
  delete from assistant_turns t using assistant_threads th
   where th.id = t.thread_id and th.user_id = p_user_id;
  delete from assistant_threads where user_id = p_user_id;
  delete from assistant_usage where bucket_key = 'user:' || p_user_id::text;
  delete from saved_courses where user_id = p_user_id;
  delete from dismissed_suggestions where user_id = p_user_id;
  delete from cart_items where user_id = p_user_id;

  update events set user_id = null where user_id = p_user_id;
  update cohort_seats set user_id = null where user_id = p_user_id;

  update deletion_requests
     set state = 'completed', completed_at = now(), completed_by = p_actor
   where user_id = p_user_id and state = 'pending';

  perform log_admin_action(p_actor, 'erase_account', 'profile', p_user_id::text,
                           'Erasure completed; records anonymised', null);

  return query select true, null::text;
end; $$;

-- ---------------------------------------------------------------------
-- The queue shows what will be in the way before anyone presses ERASE.
-- ---------------------------------------------------------------------
create or replace view public.deletion_queue as
select
  d.id,
  d.user_id,
  d.requested_at,
  d.due_at,
  d.reason,
  d.state,
  d.completed_at,
  p.display_name,
  p.email,
  now() > d.due_at as overdue,
  (select count(*) from enrolments e where e.user_id = d.user_id)        as enrolments,
  (select count(*) from certificates c join enrolments e on e.id = c.enrolment_id
    where e.user_id = d.user_id)                                          as certificates,
  (select count(*) from course_purchases cp where cp.user_id = d.user_id) as purchases,
  -- Their own live courses: erasure retires these automatically.
  (select count(*) from courses c
    where c.instructor_id = d.user_id
      and c.owner_kind = 'instructor'::course_owner_kind
      and c.state = 'published')                                          as courses_to_retire,
  -- Somebody else's courses they assess: these block erasure until an
  -- operator names a replacement.
  (select count(*) from courses c
    where c.instructor_id = d.user_id
      and c.owner_kind <> 'instructor'::course_owner_kind
      and c.state in ('published','in_review'))                           as blocking_courses,
  -- Work still waiting on them, which will never be reviewed otherwise.
  (select count(*) from submissions s
    where s.assigned_reviewer_id = d.user_id
      and s.state in ('submitted','assigned','in_review'))                as open_reviews
from deletion_requests d
join profiles p on p.id = d.user_id;

-- ---------------------------------------------------------------------
-- Withdrawing a request has to put back what was there before.
--
-- Cancelling restored the account to 'active' unconditionally. An
-- account suspended by an operator for abuse, which then asked to be
-- deleted, would come back unsuspended — the withdrawal quietly undoing
-- a moderation decision that had nothing to do with it.
--
-- So the status before the request is recorded when the request is made,
-- and that is what a withdrawal restores.
-- ---------------------------------------------------------------------
alter table deletion_requests
  add column if not exists prior_status profile_status;

comment on column deletion_requests.prior_status is
  'What the account status was before the request. A withdrawal restores this, so cancelling cannot un-suspend an account suspended for another reason.';

create or replace function public.request_account_deletion(
  p_user_id uuid, p_reason text default null
) returns table (ok boolean, reason text, due_at timestamptz)
language plpgsql security definer set search_path = public as $$
declare
  v_due   timestamptz;
  v_prior profile_status;
begin
  if exists (select 1 from deletion_requests d
              where d.user_id = p_user_id and d.state = 'pending') then
    select d.due_at into v_due from deletion_requests d
     where d.user_id = p_user_id and d.state = 'pending';
    return query select false, 'already_requested', v_due; return;
  end if;

  select status into v_prior from profiles where id = p_user_id;
  if v_prior is null then
    return query select false, 'no_account', null::timestamptz; return;
  end if;

  if exists (select 1 from profiles where id = p_user_id and role = 'operator') then
    return query select false, 'operator_account', null::timestamptz; return;
  end if;

  insert into deletion_requests (user_id, reason, prior_status)
  values (p_user_id, nullif(trim(coalesce(p_reason, '')), ''), v_prior)
  returning deletion_requests.due_at into v_due;

  update profiles set status = 'suspended' where id = p_user_id;

  update certificates c
     set revoked_at = now(),
         revoke_reason = 'Account deleted at the holder''s request'
    from enrolments e
   where e.id = c.enrolment_id
     and e.user_id = p_user_id
     and c.revoked_at is null;

  return query select true, null::text, v_due;
end; $$;

create or replace function public.cancel_deletion_request(p_user_id uuid, p_actor uuid)
returns table (ok boolean, restored_to text)
language plpgsql security definer set search_path = public as $$
declare
  v_prior profile_status;
begin
  select prior_status into v_prior from deletion_requests
   where user_id = p_user_id and state = 'pending';

  if not found then return query select false, null::text; return; end if;

  update deletion_requests
     set state = 'cancelled', completed_at = now(), completed_by = p_actor
   where user_id = p_user_id and state = 'pending';

  -- Back to whatever it was, which is usually 'active' and is sometimes
  -- deliberately not.
  update profiles set status = coalesce(v_prior, 'active'::profile_status)
   where id = p_user_id;

  perform log_admin_action(p_actor, 'cancel_deletion', 'profile', p_user_id::text,
                           'Deletion request withdrawn', null);

  return query select true, coalesce(v_prior, 'active')::text;
end; $$;

revoke all on function public.cancel_deletion_request(uuid, uuid) from public, anon, authenticated;
grant execute on function public.cancel_deletion_request(uuid, uuid) to service_role;
