"use client";

import Link from "next/link";
import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";

/**
 * The strip pitches the subscription, so it is for people who do not have
 * one. Hiding only its text left an empty dark band across the top of every
 * page, so the whole bar goes.
 *
 * Nothing is lost by removing it for signed-in visitors: "For institutions"
 * and "Teach on Your Brand" are both already in the nav row directly below.
 *
 * Rendered only once auth is known, and only when signed out. The cost is a
 * small pop-in for logged-out visitors; the alternative is a dark band that
 * appears and then vanishes for everybody who is logged in, which is worse.
 */
export default function AnnouncementBar() {
  const [signedIn, setSignedIn] = useState<boolean | null>(null);

  useEffect(() => {
    const supabase = createClient();
    let cancelled = false;
    supabase.auth.getUser().then(({ data }) => {
      if (!cancelled) setSignedIn(!!data.user);
    });
    return () => { cancelled = true; };
  }, []);

  if (signedIn !== false) return null;

  return (
    <div className="ann">
      <div className="ann__in">
        <div className="ann__l">
          <span className="ann__dot" />
          {/* Wrapped so it can be truncated on a narrow screen — a bare text
              node cannot carry text-overflow. */}
          <span className="ann__msg">
            Designed and built by Aphinity Digital for brands that want to grow.
          </span>{" "}
          <Link href="/#pricing">How pricing works</Link>
        </div>
        <div className="ann__r">
          <Link href="/institutions">For institutions</Link>
          <Link href="/teach">Teach on Your Brand</Link>
        </div>
      </div>
    </div>
  );
}
