import type { Metadata } from "next";
import { myItems } from "@/lib/marketplace/studio";
import { DashboardView, OpenShopView } from "@/components/marketplace/studio/views";
import { studioGate } from "./gate";

export const metadata: Metadata = { title: "Studio", robots: { index: false } };

export default async function StudioPage() {
  const g = await studioGate("/studio");
  if ("block" in g) return g.block;
  const { viewer, base } = g;
  if (!viewer.shop) return <OpenShopView suggestedName={viewer.email?.split("@")[0] ?? ""} />;
  return <DashboardView shop={viewer.shop} items={await myItems(viewer.shop.id)} base={base} />;
}
