-- =====================================================================
-- Sprint 8 — final exams, optional projects, two kinds of certificate
--
-- Every course ends in an exam. The project after it is optional, set per
-- course by the instructor.
--
-- That splits the credential in two, which is the decision this migration
-- encodes:
--   'assessed' — a practitioner read the project and signed it. The
--                certificate carries their name. Unchanged from today.
--   'examined' — the learner passed the final exam. No name, because
--                nobody assessed anything; the certificate says so.
-- Existing certificates are all 'assessed' by definition.
-- =====================================================================

-- ---------------------------------------------------------------------
-- Per-course switch. Default true, so every course that exists today
-- keeps requiring the project it was published with.
-- ---------------------------------------------------------------------
alter table courses
  add column if not exists requires_project boolean not null default true;

comment on column courses.requires_project is
  'False issues an examined certificate on passing the final exam. True keeps the practitioner-assessed project as the last gate.';

-- ---------------------------------------------------------------------
-- Exam questions. Same shape as quiz_items, keyed to the course rather
-- than a topic, so the studio editor and the grader can share their
-- handling of options and the answer key.
-- ---------------------------------------------------------------------
create table if not exists exam_items (
  id          uuid primary key default gen_random_uuid(),
  course_id   uuid not null references courses(id) on delete cascade,
  position    int  not null default 0,
  prompt      text not null,
  options     jsonb not null,     -- [{id, text}]
  correct     jsonb not null,     -- [option ids]
  explanation text
);

create index if not exists exam_items_course on exam_items (course_id, position);

create table if not exists exam_attempts (
  id           uuid primary key default gen_random_uuid(),
  enrolment_id uuid not null references enrolments(id) on delete cascade,
  score_pct    int  not null,
  passed       boolean not null,
  attempted_at timestamptz not null default now()
);

create index if not exists exam_attempts_enrolment
  on exam_attempts (enrolment_id, attempted_at desc);

-- ---------------------------------------------------------------------
-- Prompts are readable on a published course; the answer key never is.
-- Same split as quiz_items: grading runs server-side with the service
-- role, so `correct` is simply never selected from the client.
-- ---------------------------------------------------------------------
alter table exam_items    enable row level security;
alter table exam_attempts enable row level security;

drop policy if exists public_exam_items on exam_items;
create policy public_exam_items on exam_items for select using (
  exists (select 1 from courses c where c.id = exam_items.course_id and c.state = 'published')
);

drop policy if exists own_exam_attempts on exam_attempts;
create policy own_exam_attempts on exam_attempts for select using (
  exists (select 1 from enrolments e
           where e.id = exam_attempts.enrolment_id and e.user_id = auth.uid())
);

-- ---------------------------------------------------------------------
-- Cooldowns. Two consecutive failures pause retakes.
--
-- The exam pause is 30 minutes. Topic quizzes drop to 10: a quiz is a
-- checkpoint inside a module and half an hour was long enough to end the
-- session, which is not what a checkpoint is for. The exam is the gate on
-- a credential, so it keeps the longer pause.
-- ---------------------------------------------------------------------
create or replace function public.quiz_cooldown_until(p_enrolment_id uuid, p_topic_id uuid)
returns timestamptz
language sql
stable
security definer set search_path = public
as $$
  select case
    when count(*) filter (where not passed) = 2 then max(attempted_at) + interval '10 minutes'
    else null
  end
  from (
    select passed, attempted_at
      from quiz_attempts
     where enrolment_id = p_enrolment_id and topic_id = p_topic_id
     order by attempted_at desc
     limit 2
  ) recent;
$$;

create or replace function public.exam_cooldown_until(p_enrolment_id uuid)
returns timestamptz
language sql
stable
security definer set search_path = public
as $$
  select case
    when count(*) filter (where not passed) = 2 then max(attempted_at) + interval '30 minutes'
    else null
  end
  from (
    select passed, attempted_at
      from exam_attempts
     where enrolment_id = p_enrolment_id
     order by attempted_at desc
     limit 2
  ) recent;
$$;

-- ---------------------------------------------------------------------
-- One call for everything the exam screen needs to decide what to show.
-- ---------------------------------------------------------------------
create or replace function public.course_exam_state(p_course_id uuid, p_user_id uuid)
returns table (
  enrolment_id     uuid,
  item_count       int,
  topics_left      int,
  passed           boolean,
  attempts         int,
  best_pct         int,
  cooldown_until   timestamptz,
  requires_project boolean
)
language sql
stable
security definer set search_path = public
as $$
  with e as (
    select id from enrolments
     where user_id = p_user_id and course_id = p_course_id
     limit 1
  )
  select
    (select id from e),
    (select count(*)::int from exam_items x where x.course_id = p_course_id),
    (select count(*)::int
       from topics t join modules m on m.id = t.module_id
      where m.course_id = p_course_id
        and t.id not in (
          select tc.topic_id from topic_completions tc
           where tc.enrolment_id = (select id from e))),
    coalesce((select bool_or(a.passed) from exam_attempts a
               where a.enrolment_id = (select id from e)), false),
    coalesce((select count(*)::int from exam_attempts a
               where a.enrolment_id = (select id from e)), 0),
    coalesce((select max(a.score_pct)::int from exam_attempts a
               where a.enrolment_id = (select id from e)), 0),
    exam_cooldown_until((select id from e)),
    (select c.requires_project from courses c where c.id = p_course_id);
$$;

-- ---------------------------------------------------------------------
-- Two kinds of certificate.
--
-- reviewer_name stays not-null because every existing row has one; an
-- examined certificate records the empty string and is identified by kind,
-- never by whether the name happens to be blank.
-- ---------------------------------------------------------------------
do $$ begin
  if not exists (select 1 from pg_type where typname = 'certificate_kind') then
    create type certificate_kind as enum ('assessed','examined');
  end if;
end $$;

alter table certificates
  add column if not exists kind certificate_kind not null default 'assessed';

comment on column certificates.kind is
  'assessed = a named practitioner read the project. examined = passed the final exam, nobody assessed it.';

-- ---------------------------------------------------------------------
-- Issue an examined certificate.
--
-- Deliberately mirrors create_submission's preconditions rather than
-- trusting the caller: every topic complete, the exam passed, the course
-- actually exam-only, and an allowance to spend. A certificate is the one
-- thing in this system that must never be issuable by asking nicely.
-- ---------------------------------------------------------------------
create or replace function public.issue_exam_certificate(p_user_id uuid, p_course_id uuid)
returns table (code text, error text)
language plpgsql
security definer set search_path = public
as $$
declare
  v_enrolment  enrolments%rowtype;
  v_profile    profiles%rowtype;
  v_course     courses%rowtype;
  v_allowance  cert_allowances%rowtype;
  v_topics_left int;
  v_passed     boolean;
  v_code       text;
begin
  select * into v_course from courses where id = p_course_id;
  if not found then
    return query select null::text, 'no_course'::text; return;
  end if;

  if v_course.requires_project then
    return query select null::text, 'project_required'::text; return;
  end if;

  select * into v_enrolment
    from enrolments where user_id = p_user_id and course_id = p_course_id;
  if not found then
    return query select null::text, 'not_enrolled'::text; return;
  end if;

  -- Already issued. Hand back the existing code rather than minting a
  -- second one — a double submit must not cost a second allowance.
  select c.code into v_code
    from certificates c
   where c.enrolment_id = v_enrolment.id and c.revoked_at is null
   limit 1;
  if v_code is not null then
    return query select v_code, null::text; return;
  end if;

  select count(*) into v_topics_left
    from topics t join modules m on m.id = t.module_id
   where m.course_id = p_course_id
     and t.id not in (
       select tc.topic_id from topic_completions tc where tc.enrolment_id = v_enrolment.id);

  if v_topics_left > 0 then
    return query select null::text, 'topics_incomplete'::text; return;
  end if;

  select coalesce(bool_or(passed), false) into v_passed
    from exam_attempts where enrolment_id = v_enrolment.id;

  if not v_passed then
    return query select null::text, 'exam_not_passed'::text; return;
  end if;

  -- Cohort learners are covered by their institution, exactly as on the
  -- project path.
  if v_enrolment.source <> 'cohort' then
    select * into v_allowance
      from cert_allowances
     where user_id = p_user_id
       and now() between period_start and period_end
     order by period_end desc
     limit 1;

    if not found then
      return query select null::text, 'no_plan'::text; return;
    end if;
    if v_allowance.used >= (v_allowance.included + v_allowance.purchased) then
      return query select null::text, 'allowance_spent'::text; return;
    end if;

    update cert_allowances set used = used + 1 where id = v_allowance.id;
  end if;

  select * into v_profile from profiles where id = p_user_id;

  v_code := 'SPL-' || upper(substr(encode(gen_random_bytes(6), 'hex'), 1, 4))
            || '-' || upper(substr(encode(gen_random_bytes(6), 'hex'), 1, 4));

  insert into certificates (enrolment_id, code, reviewer_name, show_name, kind)
  values (
    v_enrolment.id, v_code, '',
    not coalesce(v_profile.minor_protections, false),
    'examined'
  );

  update enrolments set state = 'certified' where id = v_enrolment.id;

  return query select v_code, null::text;
end;
$$;

-- ---------------------------------------------------------------------
-- The project now opens only after the exam is passed.
--
-- Restated in full because create or replace cannot patch a body — and
-- while restating it, two pre-existing bugs came out. The 0004 version
-- inserted into columns named `files` and `reviewer_id`; submissions has
-- `file_paths` and `assigned_reviewer_id`, and never had the other two.
-- Postgres does not resolve column names inside a plpgsql body until the
-- statement executes, so the function was created cleanly and then failed
-- every time a learner pressed submit. It also never recorded
-- consumed_allowance, so a free resubmission after a "changes needed"
-- verdict was indistinguishable from a paid one.
-- ---------------------------------------------------------------------
create or replace function public.create_submission(
  p_user_id uuid,
  p_course_id uuid,
  p_body text,
  p_files text[]
)
returns table (submission_id uuid, deadline timestamptz, error text)
language plpgsql
security definer set search_path = public
as $$
declare
  v_enrolment    enrolments%rowtype;
  v_prev         submissions%rowtype;
  v_attempt      int := 1;
  v_consumes     boolean := true;
  v_allowance    cert_allowances%rowtype;
  v_reviewer     uuid;
  v_deadline     timestamptz;
  v_id           uuid;
  v_topics_left  int;
  v_has_exam     int;
  v_exam_passed  boolean;
begin
  select * into v_enrolment
    from enrolments
   where user_id = p_user_id and course_id = p_course_id;

  if not found then
    return query select null::uuid, null::timestamptz, 'not_enrolled'::text; return;
  end if;

  -- Every topic must be complete before the project opens.
  select count(*) into v_topics_left
    from topics t join modules m on m.id = t.module_id
   where m.course_id = p_course_id
     and t.id not in (
       select tc.topic_id from topic_completions tc where tc.enrolment_id = v_enrolment.id
     );

  if v_topics_left > 0 then
    return query select null::uuid, null::timestamptz, 'topics_incomplete'::text; return;
  end if;

  -- And so must the exam, where the course has one. Courses published
  -- before exams existed have no items, and are not held up by this.
  select count(*) into v_has_exam from exam_items where course_id = p_course_id;

  if v_has_exam > 0 then
    select coalesce(bool_or(passed), false) into v_exam_passed
      from exam_attempts where enrolment_id = v_enrolment.id;

    if not v_exam_passed then
      return query select null::uuid, null::timestamptz, 'exam_not_passed'::text; return;
    end if;
  end if;

  select * into v_prev
    from submissions
   where enrolment_id = v_enrolment.id
   order by attempt_no desc
   limit 1;

  if found then
    if v_prev.state in ('submitted','assigned','in_review') then
      return query select null::uuid, null::timestamptz, 'already_under_review'::text; return;
    end if;
    if v_prev.state = 'passed' then
      return query select null::uuid, null::timestamptz, 'already_passed'::text; return;
    end if;
    v_attempt := v_prev.attempt_no + 1;
    if v_prev.state = 'revision_requested' and v_attempt = 2 then
      v_consumes := false;
    end if;
  end if;

  if v_consumes then
    if v_enrolment.source = 'cohort' then
      v_consumes := false;
    else
      select * into v_allowance
        from cert_allowances
       where user_id = p_user_id
         and now() between period_start and period_end
       order by period_end desc
       limit 1;

      if not found then
        return query select null::uuid, null::timestamptz, 'no_plan'::text; return;
      end if;
      if v_allowance.used >= (v_allowance.included + v_allowance.purchased) then
        return query select null::uuid, null::timestamptz, 'allowance_spent'::text; return;
      end if;

      update cert_allowances set used = used + 1 where id = v_allowance.id;
    end if;
  end if;

  select c.instructor_id into v_reviewer from courses c where c.id = p_course_id;
  v_deadline := add_working_days(now(), 4);

  -- Real column names. The 0004 body inserted into `files` and
  -- `reviewer_id`; the table has `file_paths` and `assigned_reviewer_id`.
  -- A plpgsql body is not checked against the schema until it runs, so this
  -- has been failing at the moment of submission ever since — see the note
  -- at the top of this file.
  insert into submissions (enrolment_id, attempt_no, body, file_paths, state,
                           assigned_reviewer_id, deadline_at, consumed_allowance)
  values (v_enrolment.id, v_attempt, p_body, p_files, 'submitted',
          v_reviewer, v_deadline, v_consumes)
  returning id into v_id;

  -- 'in_review' is not a member of enrolment_state — the enum runs
  -- not_started, in_progress, topics_complete, submitted, certified,
  -- lapsed. Third bug in this same function, same reason: unresolved
  -- until the statement actually ran.
  update enrolments set state = 'submitted' where id = v_enrolment.id;

  return query select v_id, v_deadline, null::text;
end;
$$;
