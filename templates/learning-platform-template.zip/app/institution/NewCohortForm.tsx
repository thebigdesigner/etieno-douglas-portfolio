"use client";
import { useActionState } from "react";
import { createCohort } from "@/app/actions/institution";
import type { FormState } from "@/lib/forms";
import SubmitButton from "@/components/SubmitButton";
import Alert from "@/components/Alert";

const initial: FormState = {};

export default function NewCohortForm({
  courses,
}: { courses: { id: string; title: string; subject: string }[] }) {
  const [state, action] = useActionState(createCohort, initial);

  return (
    <form action={action} className="auth__form" style={{ maxWidth: 640 }}>
      <label className="field">
        <span className="field__label">Cohort name</span>
        <input name="name" required placeholder="Year 10 — Digital Skills" />
        <span className="field__hint">Usernames are generated from this.</span>
      </label>

      <div className="studio__two">
        <label className="field">
          <span className="field__label">Starts</span>
          <input name="starts_on" type="date" required />
        </label>
        <label className="field">
          <span className="field__label">Ends</span>
          <input name="ends_on" type="date" required />
        </label>
      </div>

      <label className="field">
        <span className="field__label">Seat ceiling</span>
        <input name="seat_ceiling" type="number" min={1} max={2000} defaultValue={30} required />
        <span className="field__hint">
          Set it generously — you are only billed for learners who actually start.
        </span>
      </label>

      <fieldset className="field">
        <legend className="field__label">Courses</legend>
        <div className="checks">
          {courses.length === 0 ? (
            <p className="studio__hint">No published courses yet.</p>
          ) : courses.map((c) => (
            <label key={c.id} className="check">
              <input type="checkbox" name="courses" value={c.id} />
              <span>{c.title} <em>{c.subject}</em></span>
            </label>
          ))}
        </div>
      </fieldset>

      {state.error && <Alert kind="error">{state.error}</Alert>}
      <SubmitButton>Create cohort and issue usernames</SubmitButton>
    </form>
  );
}
