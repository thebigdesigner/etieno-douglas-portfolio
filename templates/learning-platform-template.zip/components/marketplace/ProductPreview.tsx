import type { Product, PreviewKind } from "@/lib/marketplace/types";
import { categoryBySlug } from "@/lib/marketplace/categories";
import { MK_PATHS } from "@/components/marketplace/MkIcon";

/**
 * The cover an item gets until its creator uploads one.
 *
 * Drawn, not fetched, and drawn as the thing itself: a font shows its
 * specimen, a track shows its waveform, a deck shows a slide. A grey box
 * with a file icon would tell a buyer nothing, and a stock photo would lie
 * about what is in the download. Seeded from the slug so an item looks the
 * same on every visit and on every page it appears.
 *
 * Colours come from the theme's saturated tile pairs and the BAP set, so a
 * page of these reads as Your Brand rather than as a random palette generator.
 */

type Pal = { bg: string; ink: string; a: string; b: string; soft: string; card: string; dark?: boolean };

const PALETTES: Pal[] = [
  { bg: "#E4E9F7", ink: "#19244E", a: "#F36B2E", b: "#253C96", soft: "#C4E7E5", card: "#FFFFFF" },
  { bg: "#EDE9FE", ink: "#3A248F", a: "#6C4DF6", b: "#F2547D", soft: "#FFE4EC", card: "#FFFFFF" },
  { bg: "#FFF0CE", ink: "#7A4E00", a: "#F6A609", b: "#F36B2E", soft: "#FFE4EC", card: "#FFFFFF" },
  { bg: "#D3F6F3", ink: "#065E5A", a: "#0FB5AE", b: "#253C96", soft: "#E2F7DA", card: "#FFFFFF" },
  { bg: "#FFE4EC", ink: "#9B1B41", a: "#F2547D", b: "#F6A609", soft: "#FFF0CE", card: "#FFFFFF" },
  { bg: "#19244E", ink: "#F4F6FC", a: "#F36B2E", b: "#5FC9E8", soft: "#253C96", card: "#223172", dark: true },
  { bg: "#0C4356", ink: "#F2FAFC", a: "#C4E7E5", b: "#F59A1E", soft: "#12556B", card: "#0A3A4B", dark: true },
  { bg: "#E2F7DA", ink: "#2C6318", a: "#5FBF3F", b: "#253C96", soft: "#D3F6F3", card: "#FFFFFF" },
];

function hash(s: string): number {
  let h = 2166136261;
  for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); }
  return h >>> 0;
}

/** mulberry32. Small, fast, and the same sequence for the same seed. */
function rng(seed: number) {
  let a = seed;
  return () => {
    a |= 0; a = (a + 0x6d2b79f5) | 0;
    let t = Math.imul(a ^ (a >>> 15), 1 | a);
    t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function wrap(text: string, max: number, lines = 2): string[] {
  const out: string[] = [];
  let line = "";
  for (const w of text.split(/\s+/)) {
    if ((line + " " + w).trim().length > max && line) { out.push(line); line = w; }
    else line = (line + " " + w).trim();
  }
  if (line) out.push(line);
  if (out.length > lines) { out.length = lines; out[lines - 1] = out[lines - 1].replace(/\W*$/, "") + "…"; }
  return out;
}

const shortTitle = (t: string) => t.split(/ — | - |,/)[0].trim();

type Ctx = { p: Product; r: () => number; c: Pal; v: number };

// ------------------------------------------------------------------ kinds
function UI({ p, r, c }: Ctx) {
  if (p.subcategory === "mobile") {
    const phone = (x: number, y: number, tilt: number, accent: string) => (
      <g transform={`rotate(${tilt} ${x + 60} ${y + 110})`}>
        <rect x={x} y={y} width="120" height="226" rx="20" fill={c.card} />
        <rect x={x + 44} y={y + 9} width="32" height="6" rx="3" fill={c.bg} />
        <rect x={x + 14} y={y + 30} width="92" height="54" rx="10" fill={accent} />
        <rect x={x + 22} y={y + 42} width="40" height="6" rx="3" fill="#fff" opacity=".8" />
        <rect x={x + 22} y={y + 56} width="58" height="12" rx="4" fill="#fff" />
        {[0, 1, 2].map((i) => (
          <g key={i}>
            <circle cx={x + 26} cy={y + 108 + i * 30} r="9" fill={c.bg} />
            <rect x={x + 42} y={y + 102 + i * 30} width={40 + r() * 20} height="5" rx="2.5" fill={c.ink} opacity=".75" />
            <rect x={x + 42} y={y + 111 + i * 30} width="30" height="4" rx="2" fill={c.ink} opacity=".3" />
          </g>
        ))}
        <rect x={x + 14} y={y + 196} width="92" height="18" rx="9" fill={c.ink} />
      </g>
    );
    return <>{phone(92, 44, -6, c.a)}{phone(196, 30, 5, c.b)}</>;
  }
  const bars = Array.from({ length: 7 }, () => 20 + r() * 50);
  return (
    <>
      <rect x="36" y="34" width="328" height="232" rx="14" fill={c.card} />
      <circle cx="54" cy="52" r="4" fill={c.a} /><circle cx="67" cy="52" r="4" fill={c.b} /><circle cx="80" cy="52" r="4" fill={c.soft} />
      <rect x="36" y="68" width="328" height="1.5" fill={c.bg} />
      <rect x="56" y="92" width="120" height="12" rx="4" fill={c.ink} />
      <rect x="56" y="112" width="96" height="12" rx="4" fill={c.ink} />
      <rect x="56" y="134" width="110" height="5" rx="2.5" fill={c.ink} opacity=".3" />
      <rect x="56" y="144" width="84" height="5" rx="2.5" fill={c.ink} opacity=".3" />
      <rect x="56" y="162" width="62" height="20" rx="10" fill={c.a} />
      <rect x="200" y="86" width="144" height="100" rx="10" fill={c.bg} />
      {bars.map((h, i) => (
        <rect key={i} x={214 + i * 18} y={172 - h} width="10" height={h} rx="3" fill={i % 3 === 0 ? c.a : c.b} />
      ))}
      {[0, 1, 2].map((i) => (
        <g key={i}>
          <rect x={56 + i * 100} y="202" width="88" height="46" rx="8" fill={c.bg} />
          <rect x={66 + i * 100} y="214" width="40" height="5" rx="2.5" fill={c.ink} opacity=".7" />
          <rect x={66 + i * 100} y="226" width="56" height="10" rx="3" fill={i === 1 ? c.a : c.ink} />
        </g>
      ))}
    </>
  );
}

function Slides({ p, r, c }: Ctx) {
  const lines = wrap(shortTitle(p.title), 18);
  const bars = Array.from({ length: 5 }, () => 18 + r() * 52);
  return (
    <>
      <rect x="84" y="30" width="270" height="170" rx="8" fill={c.soft} transform="rotate(6 219 115)" />
      <rect x="66" y="44" width="270" height="170" rx="8" fill={c.card} opacity=".65" transform="rotate(3 201 129)" />
      <rect x="46" y="66" width="290" height="186" rx="8" fill={c.card} />
      <rect x="46" y="66" width="10" height="186" fill={c.a} />
      {lines.map((l, i) => (
        <text key={i} x="74" y={108 + i * 24} fontSize="20" fontWeight="700" fill={c.dark ? c.ink : c.ink}
          style={{ fontFamily: "var(--font-splari), sans-serif" }}>{l}</text>
      ))}
      <rect x="74" y={128 + lines.length * 14} width="90" height="5" rx="2.5" fill={c.ink} opacity=".3" />
      <rect x="74" y={140 + lines.length * 14} width="70" height="5" rx="2.5" fill={c.ink} opacity=".3" />
      {bars.map((h, i) => (
        <rect key={i} x={226 + i * 18} y={232 - h} width="11" height={h} rx="2" fill={i === 3 ? c.a : c.b} />
      ))}
      <rect x="222" y="232" width="96" height="1.5" fill={c.ink} opacity=".25" />
    </>
  );
}

function Graphic({ p, r, c }: Ctx) {
  if (p.subcategory === "patterns") {
    const tiles = [];
    for (let y = 0; y < 6; y++) for (let x = 0; x < 8; x++) {
      const cx = 25 + x * 50, cy = 25 + y * 50;
      const fill = (x + y) % 3 === 0 ? c.a : (x + y) % 3 === 1 ? c.b : c.ink;
      tiles.push(
        <g key={`${x}-${y}`}>
          <rect x={cx - 15} y={cy - 15} width="30" height="30" fill={fill} />
          <rect x={cx - 15} y={cy - 15} width="30" height="30" fill={fill} transform={`rotate(45 ${cx} ${cy})`} />
          <circle cx={cx} cy={cy} r="7" fill={c.bg} />
        </g>
      );
    }
    return <>{tiles}</>;
  }
  if (p.subcategory === "textures") {
    return (
      <>
        <rect width="400" height="300" fill={c.b} />
        {Array.from({ length: 70 }, (_, i) => {
          const x = r() * 400, y = r() * 300, w = 20 + r() * 90;
          return <rect key={i} x={x} y={y} width={w} height={2 + r() * 5} rx="2" fill={c.bg} opacity={0.15 + r() * 0.35}
            transform={`rotate(${-20 + r() * 40} ${x} ${y})`} />;
        })}
        {Array.from({ length: 5 }, (_, i) => (
          <circle key={i} cx={60 + i * 70} cy={150 + (i % 2 ? -40 : 40)} r="28" fill="none" stroke={c.bg} strokeWidth="6" opacity=".55" />
        ))}
      </>
    );
  }
  const h1 = 170 + r() * 30, h2 = 200 + r() * 30;
  return (
    <>
      <circle cx={110 + r() * 180} cy="98" r="46" fill={c.a} />
      <path d={`M0 ${h1} C 90 ${h1 - 60}, 180 ${h1 + 20}, 400 ${h1 - 40} V300 H0Z`} fill={c.b} opacity=".85" />
      <path d={`M0 ${h2} C 120 ${h2 - 30}, 250 ${h2 + 40}, 400 ${h2 - 10} V300 H0Z`} fill={c.ink} />
      {Array.from({ length: 6 }, (_, i) => (
        <circle key={i} cx={40 + r() * 320} cy={30 + r() * 80} r={2 + r() * 3} fill={c.dark ? c.ink : c.card} />
      ))}
    </>
  );
}

function Icons({ r, c }: Ctx) {
  const names = Object.keys(MK_PATHS) as (keyof typeof MK_PATHS)[];
  const start = Math.floor(r() * names.length);
  const cells = [];
  for (let y = 0; y < 3; y++) for (let x = 0; x < 5; x++) {
    const i = y * 5 + x;
    const name = names[(start + i * 3) % names.length];
    const on = i === 6;
    cells.push(
      <g key={i}>
        <rect x={34 + x * 68} y={40 + y * 76} width="56" height="56" rx="14" fill={on ? c.a : c.card} />
        <svg x={48 + x * 68} y={54 + y * 76} width="28" height="28" viewBox="0 0 24 24" fill="none"
          stroke={on ? "#fff" : c.dark ? c.ink : c.ink} strokeWidth="1.7" strokeLinecap="round" strokeLinejoin="round">
          <path d={MK_PATHS[name]} />
        </svg>
      </g>
    );
  }
  return <>{cells}</>;
}

const FONT_STACK: Record<string, string> = {
  serif: "Georgia, 'Times New Roman', serif",
  "sans-serif": "var(--font-splari), 'Helvetica Neue', Arial, sans-serif",
  display: "Impact, 'Arial Black', 'Helvetica Neue', sans-serif",
  script: "'Brush Script MT', 'Segoe Script', 'Snell Roundhand', cursive",
  mono: "ui-monospace, 'SFMono-Regular', Menlo, Consolas, monospace",
};

function Font({ p, c }: Ctx) {
  const stack = p.tags.includes("monospace") ? FONT_STACK.mono : FONT_STACK[p.subcategory] ?? FONT_STACK.serif;
  const name = shortTitle(p.title);
  return (
    <g style={{ fontFamily: stack }}>
      <text x="30" y="200" fontSize="170" fill={c.a} fontWeight={p.subcategory === "display" ? 400 : 700}
        fontStyle={p.subcategory === "serif" ? "italic" : "normal"}>Aa</text>
      <text x="232" y="96" fontSize="30" fill={c.ink} fontWeight="700">{name.split(" ")[0]}</text>
      <text x="232" y="126" fontSize="15" fill={c.ink} opacity=".7">ABCDEFGHIJKLM</text>
      <text x="232" y="148" fontSize="15" fill={c.ink} opacity=".7">nopqrstuvwxyz</text>
      <text x="232" y="170" fontSize="15" fill={c.ink} opacity=".7">ẹ ọ ṣ ɛ ɔ 0123</text>
      <rect x="30" y="236" width="340" height="1.5" fill={c.ink} opacity=".2" />
      <text x="30" y="266" fontSize="17" fill={c.ink}>The quick brown fox jumps over</text>
    </g>
  );
}

function Audio({ p, r, c }: Ctx) {
  const n = 58;
  const played = 0.32 + r() * 0.2;
  const bars = Array.from({ length: n }, (_, i) => {
    const env = Math.sin((i / n) * Math.PI) * 0.7 + 0.3;
    return 8 + r() * 70 * env;
  });
  return (
    <>
      <circle cx="62" cy="62" r="24" fill={c.a} />
      <path d="M55 50v24l20-12z" fill="#fff" />
      <text x="100" y="58" fontSize="13" fontWeight="600" fill={c.ink} style={{ fontFamily: "var(--font-splari), sans-serif" }}>
        {p.category === "music" ? "Preview" : "Sample"}
      </text>
      <text x="100" y="76" fontSize="12" fill={c.ink} opacity=".6" style={{ fontFamily: "var(--font-splari), sans-serif" }}>
        {p.formats.join(" / ")}
      </text>
      {bars.map((h, i) => (
        <rect key={i} x={30 + i * 6} y={180 - h / 2} width="3.4" height={h} rx="1.7"
          fill={i / n < played ? c.a : c.ink} opacity={i / n < played ? 1 : 0.35} />
      ))}
      {p.duration && (
        <text x="370" y="266" textAnchor="end" fontSize="14" fontWeight="600" fill={c.ink}
          style={{ fontFamily: "var(--font-splari), sans-serif" }}>{p.duration}</text>
      )}
    </>
  );
}

function Video({ p, r, c }: Ctx) {
  const lines = wrap(shortTitle(p.title).toUpperCase(), 14);
  const id = `v${hash(p.slug)}`;
  return (
    <>
      <defs>
        <linearGradient id={id} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0" stopColor={c.b} /><stop offset="1" stopColor={c.dark ? c.bg : c.ink} />
        </linearGradient>
      </defs>
      <rect width="400" height="300" fill={`url(#${id})`} />
      <circle cx={300 + r() * 40} cy="70" r="90" fill={c.a} opacity=".9" />
      <path d="M-20 260 L420 150 L420 200 L-20 310Z" fill={c.soft} opacity=".35" />
      {lines.map((l, i) => (
        <text key={i} x="34" y={128 + i * 38} fontSize="34" fontWeight="800" fill="#fff" letterSpacing="-1"
          style={{ fontFamily: "var(--font-splari), sans-serif" }}>{l}</text>
      ))}
      {p.duration && (
        <g>
          <rect x="316" y="252" width="56" height="24" rx="8" fill="#000" opacity=".55" />
          <text x="344" y="268" textAnchor="middle" fontSize="12" fontWeight="600" fill="#fff"
            style={{ fontFamily: "var(--font-splari), sans-serif" }}>{p.duration}</text>
        </g>
      )}
    </>
  );
}

function Cube3D({ r, c }: Ctx) {
  const cube = (x: number, y: number, s: number, key: string) => (
    <g key={key}>
      <path d={`M${x} ${y} l${s} ${s / 2} l${-s} ${s / 2} l${-s} ${-s / 2}z`} fill={c.dark ? c.soft : c.card} />
      <path d={`M${x - s} ${y + s / 2} l${s} ${s / 2} v${s} l${-s} ${-s / 2}z`} fill={c.a} />
      <path d={`M${x + s} ${y + s / 2} l${-s} ${s / 2} v${s} l${s} ${-s / 2}z`} fill={c.b} />
    </g>
  );
  const s = 42;
  const layout: [number, number][] = [[0, 0], [1, 0], [0, 1], [1, 1], [2, 0]];
  const tall = Math.floor(r() * 4);
  return (
    <>
      <ellipse cx="200" cy="248" rx="150" ry="26" fill={c.ink} opacity=".12" />
      {layout.map(([gx, gy], i) => {
        const x = 200 + (gx - gy) * s, y = 110 + (gx + gy) * (s / 2);
        return (
          <g key={i}>
            {cube(x, y, s, `b${i}`)}
            {i === tall && cube(x, y - s, s, `t${i}`)}
          </g>
        );
      })}
    </>
  );
}

function Book({ p, c }: Ctx) {
  const lines = wrap(shortTitle(p.title), 13, 3);
  return (
    <>
      <rect x="138" y="36" width="164" height="232" rx="6" fill={c.ink} opacity=".18" transform="translate(10 8)" />
      <rect x="130" y="34" width="164" height="232" rx="6" fill={c.dark ? c.card : c.b} />
      <rect x="130" y="34" width="14" height="232" fill="#000" opacity=".18" />
      <rect x="160" y="62" width="40" height="6" rx="3" fill={c.a} />
      {lines.map((l, i) => (
        <text key={i} x="160" y={100 + i * 26} fontSize="21" fontWeight="700" fill="#fff"
          style={{ fontFamily: "var(--font-splari), sans-serif" }}>{l}</text>
      ))}
      {p.subcategory === "planners"
        ? Array.from({ length: 4 }, (_, i) => (
            <rect key={i} x="160" y={190 + i * 14} width="110" height="1.5" fill="#fff" opacity=".4" />
          ))
        : <circle cx="250" cy="220" r="26" fill={c.a} />}
    </>
  );
}

function Code({ p, r, c }: Ctx) {
  const colours = [c.a, c.b, "#5FC9E8", "#C4E7E5", "#F59A1E"];
  const ext = p.formats.includes("PHP") ? "php" : p.formats.includes("Python") ? "py" : "tsx";
  const file = `${p.slug.split("-")[0]}.${ext}`;
  return (
    <>
      <rect x="30" y="32" width="340" height="236" rx="12" fill="#0B2530" />
      <rect x="30" y="32" width="340" height="30" rx="12" fill="#12556B" />
      <rect x="30" y="50" width="340" height="12" fill="#12556B" />
      <circle cx="48" cy="47" r="4" fill={c.a} /><circle cx="61" cy="47" r="4" fill="#F59A1E" /><circle cx="74" cy="47" r="4" fill="#5FC9E8" />
      <text x="96" y="51" fontSize="12" fill="#C4E7E5" style={{ fontFamily: "ui-monospace, Menlo, monospace" }}>{file}</text>
      {Array.from({ length: 10 }, (_, i) => {
        const indent = [0, 1, 2, 2, 1, 2, 3, 2, 1, 0][i] * 16;
        let x = 70 + indent;
        const toks = 1 + Math.floor(r() * 3);
        return (
          <g key={i}>
            <text x="44" y={86 + i * 18} fontSize="10" fill="#7FA3B1" style={{ fontFamily: "ui-monospace, Menlo, monospace" }}>{i + 1}</text>
            {Array.from({ length: toks }, (_, t) => {
              const w = 18 + r() * 60;
              const el = <rect key={t} x={x} y={79 + i * 18} width={w} height="7" rx="3.5" fill={colours[(i + t) % colours.length]} opacity=".85" />;
              x += w + 8;
              return el;
            })}
          </g>
        );
      })}
    </>
  );
}

const DRAW: Record<PreviewKind, (c: Ctx) => React.ReactNode> = {
  ui: UI, slides: Slides, graphic: Graphic, icons: Icons, font: Font,
  audio: Audio, video: Video, "3d": Cube3D, book: Book, code: Code,
};

export default function ProductPreview({
  product, variant = 0, className, label,
}: { product: Product; variant?: number; className?: string; label?: string }) {
  if (product.coverUrl) {
    // eslint-disable-next-line @next/next/no-img-element
    return <img className={className} src={product.coverUrl} alt={label ?? product.title} loading="lazy" />;
  }
  const kind = categoryBySlug(product.category)?.preview ?? "graphic";
  const seed = hash(product.slug) + variant * 7919;
  const c = PALETTES[(hash(product.slug) + variant) % PALETTES.length];
  const Draw = DRAW[kind];
  return (
    <svg
      className={className} viewBox="0 0 400 300" preserveAspectRatio="xMidYMid slice"
      role="img" aria-label={label ?? `Preview of ${product.title}`}
    >
      <rect width="400" height="300" fill={c.bg} />
      {Draw({ p: product, r: rng(seed), c, v: variant })}
    </svg>
  );
}
