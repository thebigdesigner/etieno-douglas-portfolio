"use client";

import { useRef, useState } from "react";
import NavIcon from "@/components/NavIcon";
import Alert from "@/components/Alert";

/**
 * A drop zone rather than a bare `<input type="file">`.
 *
 * The native control renders as an OS button plus "No file chosen", which
 * looks like a different decade and gives no feedback until submit. This
 * keeps the real input (so forms, validation and server actions are
 * unchanged) and hides it behind a label that can be clicked or dropped on.
 */
export default function FileDrop({
  name,
  accept,
  multiple = false,
  required = false,
  maxBytes,
  hint,
  preview = false,
  onError,
}: {
  name: string;
  accept?: string;
  multiple?: boolean;
  required?: boolean;
  /** Refused in the browser so an oversized file never leaves the machine. */
  maxBytes?: number;
  hint?: string;
  /** Show an image thumbnail of the chosen file. */
  preview?: boolean;
  onError?: (message: string | null) => void;
}) {
  const input = useRef<HTMLInputElement>(null);
  const [over, setOver] = useState(false);
  const [files, setFiles] = useState<File[]>([]);
  const [thumb, setThumb] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  function fail(message: string | null) {
    setErr(message);
    onError?.(message);
  }

  function take(list: FileList | null) {
    const picked = Array.from(list ?? []);
    if (picked.length === 0) return;

    if (maxBytes) {
      const big = picked.find((f) => f.size > maxBytes);
      if (big) {
        fail(`${big.name} is over ${Math.round(maxBytes / (1024 * 1024))}MB.`);
        setFiles([]);
        setThumb(null);
        if (input.current) input.current.value = "";
        return;
      }
    }

    fail(null);
    setFiles(picked);
    if (preview && picked[0]?.type.startsWith("image/")) {
      setThumb(URL.createObjectURL(picked[0]));
    } else {
      setThumb(null);
    }
  }

  function onDrop(e: React.DragEvent) {
    e.preventDefault();
    setOver(false);
    // Assigning to the real input keeps the form submission identical to a
    // click-to-browse pick — no hidden state the server never sees.
    if (input.current && e.dataTransfer.files.length) {
      input.current.files = e.dataTransfer.files;
      take(e.dataTransfer.files);
    }
  }

  return (
    <div className="fdrop__wrap">
      <label
        className={`fdrop${over ? " is-over" : ""}${files.length ? " is-set" : ""}`}
        onDragOver={(e) => { e.preventDefault(); setOver(true); }}
        onDragLeave={() => setOver(false)}
        onDrop={onDrop}
      >
        <input
          ref={input}
          type="file"
          name={name}
          accept={accept}
          multiple={multiple}
          required={required}
          onChange={(e) => take(e.target.files)}
        />

        {thumb ? (
          <img className="fdrop__thumb" src={thumb} alt="" />
        ) : (
          <span className="fdrop__ico" aria-hidden="true">
            <NavIcon name={files.length ? "award" : "plus"} size={20} />
          </span>
        )}

        <span className="fdrop__b">
          <span className="fdrop__t">
            {files.length === 0
              ? "Drop a file here, or click to browse"
              : files.length === 1
                ? files[0].name
                : `${files.length} files selected`}
          </span>
          {hint && files.length === 0 && <span className="fdrop__h">{hint}</span>}
          {files.length > 0 && (
            <span className="fdrop__h">
              {(files.reduce((n, f) => n + f.size, 0) / 1024 / 1024).toFixed(1)} MB · click to change
            </span>
          )}
        </span>
      </label>

      {err && <Alert kind="error">{err}</Alert>}
    </div>
  );
}
