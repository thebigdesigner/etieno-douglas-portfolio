-- =====================================================================
-- Sprints 6 and 7 — instructor tools, institutions, invoicing, payouts
-- =====================================================================

-- ---------------------------------------------------------------------
-- Instructor applications
-- ---------------------------------------------------------------------
alter table instructors
  add column proposed_course text,
  add column work_sample     text,
  add column decided_at      timestamptz,
  add column decided_by      uuid references profiles(id),
  add column decision_note   text;

create index on instructors (state) where state = 'applied';

create or replace function public.apply_as_instructor(
  p_user_id uuid, p_headline text, p_bio text,
  p_proposed_course text, p_work_sample text
)
returns boolean
language plpgsql security definer set search_path = public as $$
begin
  if exists (select 1 from instructors where id = p_user_id) then
    return false;
  end if;
  insert into instructors (id, state, headline, bio, proposed_course, work_sample)
  values (p_user_id, 'applied', p_headline, p_bio, p_proposed_course, p_work_sample);
  return true;
end; $$;

create or replace function public.decide_application(
  p_instructor_id uuid, p_operator_id uuid, p_approve boolean, p_note text
)
returns boolean
language plpgsql security definer set search_path = public as $$
begin
  update instructors
     set state = case when p_approve then 'active'::instructor_state else 'rejected'::instructor_state end,
         approved_at = case when p_approve then now() else null end,
         decided_at = now(), decided_by = p_operator_id, decision_note = p_note
   where id = p_instructor_id and state = 'applied';

  if not found then return false; end if;

  if p_approve then
    update profiles set role = 'instructor' where id = p_instructor_id;
  end if;
  return true;
end; $$;

-- ---------------------------------------------------------------------
-- Course publication. The rubric gate is the one place we push back hard:
-- an inconsistent credential is worth nothing, and inconsistency starts
-- with a vague rubric rather than a careless reviewer.
-- ---------------------------------------------------------------------
create or replace function public.submit_course_for_review(p_course_id uuid, p_instructor_id uuid)
returns table (ok boolean, reason text)
language plpgsql security definer set search_path = public as $$
declare
  v_course courses%rowtype;
  v_topics int; v_criteria int; v_quiz int;
begin
  select * into v_course from courses where id = p_course_id and instructor_id = p_instructor_id;
  if not found then return query select false, 'not_yours'; return; end if;
  if v_course.state not in ('draft','revision_requested') then
    return query select false, 'wrong_state'; return;
  end if;

  select count(*) into v_topics
    from topics t join modules m on m.id = t.module_id where m.course_id = p_course_id;
  if v_topics < 3 then return query select false, 'too_few_topics'; return; end if;

  select count(*) into v_quiz
    from quiz_items q join topics t on t.id = q.topic_id
    join modules m on m.id = t.module_id where m.course_id = p_course_id;
  if v_quiz < 3 then return query select false, 'too_few_questions'; return; end if;

  if coalesce(length(trim(v_course.project_brief)), 0) < 120 then
    return query select false, 'brief_too_short'; return;
  end if;

  select count(*) into v_criteria from rubric_criteria where course_id = p_course_id;
  if v_criteria < 2 then return query select false, 'rubric_too_thin'; return; end if;

  update courses set state = 'in_review' where id = p_course_id;
  return query select true, null::text;
end; $$;

create or replace function public.decide_course(
  p_course_id uuid, p_publish boolean, p_note text
)
returns boolean
language plpgsql security definer set search_path = public as $$
begin
  if p_publish then
    -- The first topic of every course is free.
    update topics set is_free = true
     where id = (
       select t.id from topics t join modules m on m.id = t.module_id
        where m.course_id = p_course_id
        order by m.position, t.position limit 1
     );
    update courses set state = 'published', published_at = coalesce(published_at, now())
     where id = p_course_id and state = 'in_review';
  else
    update courses set state = 'revision_requested' where id = p_course_id and state = 'in_review';
  end if;
  return found;
end; $$;

-- Instructors manage their own draft content.
create policy instructor_own_courses on courses for all
  using (instructor_id = auth.uid()) with check (instructor_id = auth.uid());

create policy instructor_own_modules on modules for all using (
  exists (select 1 from courses c where c.id = modules.course_id and c.instructor_id = auth.uid())
) with check (
  exists (select 1 from courses c where c.id = modules.course_id and c.instructor_id = auth.uid())
);

create policy instructor_own_topics on topics for all using (
  exists (select 1 from modules m join courses c on c.id = m.course_id
           where m.id = topics.module_id and c.instructor_id = auth.uid())
) with check (
  exists (select 1 from modules m join courses c on c.id = m.course_id
           where m.id = topics.module_id and c.instructor_id = auth.uid())
);

alter table rubric_criteria enable row level security;
create policy public_rubric on rubric_criteria for select using (true);
create policy instructor_own_rubric on rubric_criteria for all using (
  exists (select 1 from courses c where c.id = rubric_criteria.course_id and c.instructor_id = auth.uid())
) with check (
  exists (select 1 from courses c where c.id = rubric_criteria.course_id and c.instructor_id = auth.uid())
);

create policy own_earnings on earnings_entries for select using (instructor_id = auth.uid());
create policy own_payouts  on payout_runs     for select using (instructor_id = auth.uid());

-- ---------------------------------------------------------------------
-- Institutions
-- ---------------------------------------------------------------------
create or replace function public.create_institution(
  p_name text, p_contact_email text, p_plan plan_tier, p_admin_user_id uuid
)
returns uuid
language plpgsql security definer set search_path = public as $$
declare v_id uuid;
begin
  insert into institutions (name, contact_email, plan)
  values (p_name, p_contact_email, p_plan) returning id into v_id;

  if p_admin_user_id is not null then
    insert into institution_members (institution_id, user_id) values (v_id, p_admin_user_id);
    update profiles set role = 'institution_admin' where id = p_admin_user_id;
  end if;
  return v_id;
end; $$;

/**
 * Provisioning seats rather than handing out an open code is what closes the
 * revenue leak: a shared class code alone gets nobody in, because joining also
 * needs a username from this list.
 */
create or replace function public.provision_seats(p_cohort_id uuid, p_count int)
returns int
language plpgsql security definer set search_path = public as $$
declare
  v_cohort cohorts%rowtype;
  v_existing int;
  v_prefix text;
  i int;
begin
  select * into v_cohort from cohorts where id = p_cohort_id;
  if not found then return 0; end if;

  select count(*) into v_existing from cohort_seats where cohort_id = p_cohort_id;
  if v_existing + p_count > v_cohort.seat_ceiling then
    p_count := v_cohort.seat_ceiling - v_existing;
  end if;
  if p_count <= 0 then return 0; end if;

  v_prefix := lower(regexp_replace(split_part(v_cohort.name, ' ', 1), '[^a-zA-Z0-9]', '', 'g'));
  if v_prefix = '' then v_prefix := 'learner'; end if;

  for i in (v_existing + 1)..(v_existing + p_count) loop
    insert into cohort_seats (cohort_id, username)
    values (p_cohort_id, v_prefix || lpad(i::text, 3, '0'))
    on conflict (cohort_id, username) do nothing;
  end loop;

  return p_count;
end; $$;

create or replace function public.reset_seat_pin(p_seat_id uuid)
returns boolean
language plpgsql security definer set search_path = public as $$
begin
  update cohort_seats set pin_hash = null where id = p_seat_id;
  return found;
end; $$;

create or replace view public.cohort_progress as
select cs.cohort_id,
       cs.id                as seat_id,
       cs.username,
       cs.user_id,
       p.display_name,
       cs.claimed_at,
       count(distinct tc.topic_id)                       as topics_done,
       max(tc.completed_at)                              as last_active,
       count(distinct s.id) filter (where s.state = 'passed')     as projects_passed,
       count(distinct s.id) filter (where s.state in ('submitted','assigned','in_review')) as projects_pending
  from cohort_seats cs
  left join profiles p          on p.id = cs.user_id
  left join enrolments e        on e.user_id = cs.user_id and e.cohort_id = cs.cohort_id
  left join topic_completions tc on tc.enrolment_id = e.id
  left join submissions s        on s.enrolment_id = e.id
 group by cs.cohort_id, cs.id, cs.username, cs.user_id, p.display_name, cs.claimed_at;

-- ---------------------------------------------------------------------
-- Monthly invoice. Active means at least one topic completed that month —
-- joining or watching part of a video does not count.
-- ---------------------------------------------------------------------
create or replace function public.generate_invoice(p_institution_id uuid, p_month date)
returns table (invoice_id uuid, active_count int, amount_cents int)
language plpgsql security definer set search_path = public as $$
declare
  v_start date := date_trunc('month', p_month)::date;
  v_end   date := (date_trunc('month', p_month) + interval '1 month')::date;
  v_plan  plan_tier;
  v_unit  int;
  v_active int;
  v_seats  int;
  v_id     uuid;
begin
  select plan into v_plan from institutions where id = p_institution_id;
  if v_plan is null then return; end if;

  v_unit := case v_plan when 'starter' then 1100 when 'plus' then 1300 else 1500 end;

  select count(distinct e.user_id) into v_active
    from enrolments e
    join cohorts c on c.id = e.cohort_id
    join topic_completions tc on tc.enrolment_id = e.id
   where c.institution_id = p_institution_id
     and tc.completed_at >= v_start and tc.completed_at < v_end;

  select count(*) into v_seats
    from cohort_seats cs join cohorts c on c.id = cs.cohort_id
   where c.institution_id = p_institution_id and cs.user_id is null;

  insert into invoices (institution_id, period_month, active_count, seats_unused,
                        unit_cents, amount_cents, state, issued_at)
  values (p_institution_id, v_start, v_active, coalesce(v_seats, 0),
          v_unit, v_active * v_unit, 'issued', now())
  on conflict (institution_id, period_month) do update
     set active_count = excluded.active_count,
         seats_unused = excluded.seats_unused,
         unit_cents   = excluded.unit_cents,
         amount_cents = excluded.amount_cents
  returning id into v_id;

  return query select v_id, v_active, v_active * v_unit;
end; $$;

-- ---------------------------------------------------------------------
-- Royalty pool. 35% of subscription revenue, 30% of institutional, divided
-- by completed topics. Instructors can audit this from their dashboard.
-- ---------------------------------------------------------------------
create or replace function public.calculate_pool(p_month date, p_source revenue_source, p_revenue_cents bigint)
returns uuid
language plpgsql security definer set search_path = public as $$
declare
  v_start date := date_trunc('month', p_month)::date;
  v_end   date := (date_trunc('month', p_month) + interval '1 month')::date;
  v_rate  numeric(5,4) := case p_source when 'individual' then 0.35 else 0.30 end;
  v_pool  bigint := floor(p_revenue_cents * v_rate);
  v_completions int;
  v_per    numeric(12,4);
  v_id     uuid;
begin
  select count(*) into v_completions
    from topic_completions
   where revenue_source = p_source
     and completed_at >= v_start and completed_at < v_end;

  if v_completions = 0 then return null; end if;
  v_per := v_pool::numeric / v_completions;

  insert into pool_periods (period_month, source, revenue_cents, pool_rate,
                            pool_cents, completions, rate_per_completion_cents)
  values (v_start, p_source, p_revenue_cents, v_rate, v_pool, v_completions, v_per)
  on conflict (period_month, source) do update
     set revenue_cents = excluded.revenue_cents, pool_cents = excluded.pool_cents,
         completions = excluded.completions,
         rate_per_completion_cents = excluded.rate_per_completion_cents,
         calculated_at = now()
  returning id into v_id;

  -- Credit each instructor their share of completions on their own courses.
  insert into earnings_entries (instructor_id, type, amount_cents, ref_id, note)
  select c.instructor_id,
         case p_source when 'individual' then 'pool_individual' else 'pool_institution' end,
         floor(count(*) * v_per)::int,
         v_id,
         to_char(v_start, 'Mon YYYY') || ' pool, ' || count(*) || ' completions'
    from topic_completions tc
    join enrolments e on e.id = tc.enrolment_id
    join courses    c on c.id = e.course_id
   where tc.revenue_source = p_source
     and tc.completed_at >= v_start and tc.completed_at < v_end
     and c.instructor_id is not null
   group by c.instructor_id
  having floor(count(*) * v_per) > 0;

  return v_id;
end; $$;

create or replace function public.run_payouts(p_week_start date, p_threshold_cents int default 2000)
returns int
language plpgsql security definer set search_path = public as $$
declare v_rows int;
begin
  with balances as (
    select ee.instructor_id, sum(ee.amount_cents)::int as accrued
      from earnings_entries ee
     where not exists (
       select 1 from payout_runs pr
        where pr.instructor_id = ee.instructor_id
          and pr.state = 'paid'
          and ee.created_at < pr.paid_at
     )
     group by ee.instructor_id
  )
  insert into payout_runs (week_start, instructor_id, amount_cents, state)
  select p_week_start, instructor_id, accrued,
         case when accrued >= p_threshold_cents then 'scheduled' else 'below_threshold' end
    from balances where accrued > 0
  on conflict (week_start, instructor_id) do update set amount_cents = excluded.amount_cents;

  get diagnostics v_rows = row_count;
  return v_rows;
end; $$;

-- Institution admins see only their own institution.
create policy institution_own on institutions for select using (
  exists (select 1 from institution_members m
           where m.institution_id = institutions.id and m.user_id = auth.uid())
);
create policy institution_own_cohorts on cohorts for select using (
  exists (select 1 from institution_members m
           where m.institution_id = cohorts.institution_id and m.user_id = auth.uid())
);
create policy institution_own_invoices on invoices for select using (
  exists (select 1 from institution_members m
           where m.institution_id = invoices.institution_id and m.user_id = auth.uid())
);

revoke all on function public.apply_as_instructor(uuid, text, text, text, text) from public, anon, authenticated;
revoke all on function public.decide_application(uuid, uuid, boolean, text) from public, anon, authenticated;
revoke all on function public.submit_course_for_review(uuid, uuid) from public, anon, authenticated;
revoke all on function public.decide_course(uuid, boolean, text) from public, anon, authenticated;
revoke all on function public.create_institution(text, text, plan_tier, uuid) from public, anon, authenticated;
revoke all on function public.provision_seats(uuid, int) from public, anon, authenticated;
revoke all on function public.reset_seat_pin(uuid) from public, anon, authenticated;
revoke all on function public.generate_invoice(uuid, date) from public, anon, authenticated;
revoke all on function public.calculate_pool(date, revenue_source, bigint) from public, anon, authenticated;
revoke all on function public.run_payouts(date, int) from public, anon, authenticated;
