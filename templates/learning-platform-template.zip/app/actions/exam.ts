"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { EXAM_PASS_MARK, type ExamResult } from "@/lib/learning";
import { track } from "@/lib/track";
import { sweepCertificateEmails } from "@/lib/certificate-email";

/**
 * Grade the final exam.
 *
 * Structured to match submitQuiz deliberately: the answer key is selected
 * with the service role and never reaches the client, the attempt is
 * recorded whether it passes or not, and the cooldown is checked before any
 * grading happens rather than after.
 *
 * What it adds is the fork at the end. A pass on a course that requires a
 * project opens the project; on an exam-only course it issues the examined
 * certificate there and then, because there is nothing else left to do and
 * making somebody click again to collect it would be ceremony.
 */
export async function submitExam(
  slug: string,
  _prev: ExamResult,
  formData: FormData
): Promise<ExamResult> {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect(`/login?next=/learn/${slug}/exam`);

  const admin = createAdminClient();

  const { data: course } = await admin
    .from("courses").select("id, requires_project").eq("slug", slug).maybeSingle();
  if (!course) return { error: "That course is not available." };

  const { data: enrolment } = await admin
    .from("enrolments").select("id")
    .eq("user_id", user.id).eq("course_id", course.id).maybeSingle();
  if (!enrolment) return { error: "You are not enrolled on this course." };

  // The gate the exam itself enforces. course_exam_state is the same call
  // the page uses, so the screen and the action cannot disagree about
  // whether somebody is allowed to sit it.
  const { data: stateRows } = await admin.rpc("course_exam_state", {
    p_course_id: course.id, p_user_id: user.id,
  });
  const examState = Array.isArray(stateRows) ? stateRows[0] : stateRows;

  if (!examState || Number(examState.item_count ?? 0) === 0) {
    return { error: "This course has no exam." };
  }
  if (Number(examState.topics_left ?? 0) > 0) {
    return { error: "Finish every topic before sitting the exam." };
  }
  if (examState.cooldown_until && new Date(examState.cooldown_until) > new Date()) {
    await track("exam_cooldown", user.id, { slug });
    return { cooldownUntil: examState.cooldown_until as string };
  }

  const { data: items } = await admin
    .from("exam_items").select("id, correct, explanation")
    .eq("course_id", course.id).order("position");
  if (!items || items.length === 0) return { error: "This course has no exam." };

  let correctCount = 0;
  const review: NonNullable<ExamResult["review"]> = [];

  for (const item of items) {
    const given = formData.getAll(`q_${item.id}`).map(String).sort();
    const expected = (item.correct as string[]).slice().sort();
    const isCorrect =
      given.length === expected.length && given.every((v, i) => v === expected[i]);

    if (isCorrect) correctCount += 1;
    review.push({ itemId: item.id, correct: isCorrect, explanation: item.explanation });
  }

  const scorePct = Math.round((correctCount / items.length) * 100);
  const passed = scorePct >= EXAM_PASS_MARK;

  await admin.from("exam_attempts").insert({
    enrolment_id: enrolment.id, score_pct: scorePct, passed,
  });

  if (!passed) {
    await track("exam_failed", user.id, { slug, scorePct });
    return { scorePct, passed, review };
  }

  await track("exam_passed", user.id, { slug, scorePct });
  revalidatePath(`/learn/${slug}/exam`);
  revalidatePath("/dashboard");

  if (course.requires_project) {
    return {
      scorePct, passed, review,
      next: { kind: "project", href: `/courses/${slug}/submit` },
    };
  }

  // Exam-only: the certificate is issued by the database, which re-checks
  // every precondition itself. If it refuses, say so plainly rather than
  // claiming a pass that produced nothing.
  const { data: issued } = await admin.rpc("issue_exam_certificate", {
    p_user_id: user.id, p_course_id: course.id,
  });
  const result = Array.isArray(issued) ? issued[0] : issued;

  if (!result?.code) {
    return {
      scorePct, passed, review,
      error:
        result?.error === "allowance_spent"
          ? "You passed, but this year's certifications are already used. Your pass is saved — open your plan to add one."
          : result?.error === "no_plan"
            ? "You passed. A plan is needed to issue the certificate; your pass is saved until then."
            : "You passed, but the certificate could not be issued. Support can sort this out.",
    };
  }

  await track("certificate_issued", user.id, { slug, kind: "examined" });
  revalidatePath("/dashboard/certificates");

  // Send it now rather than waiting for the nightly sweep. The sweep still
  // exists as the backstop for certificates created outside the app — an
  // upheld appeal, a direct insert — but a learner who just passed should
  // not wait until 6am to be told.
  await sweepCertificateEmails(5);

  return {
    scorePct, passed, review,
    next: { kind: "certificate", href: `/certificate/${result.code}`, code: result.code },
  };
}
