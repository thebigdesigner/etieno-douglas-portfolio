/**
 * What a customer gets back if they cancel now — the same rules /refunds publishes, worked out
 * from the operator's settings. Used by the booking lookup (to show the figure before anyone
 * commits) and by the cancellation itself (to record it), so the two can never disagree.
 *
 *   more than cancel_free_hours before the first departure   the cash paid, in full
 *   between no_refund_hours and cancel_free_hours            cash paid less cancel_fee_pct
 *   within no_refund_hours, or once the trip has gone        nothing
 *
 * Travel credits are not cash: only what was actually paid comes back. A booking that was never
 * paid can always be cancelled; that just releases the seats.
 */
import { departsAt } from './db.js';

export function cancellationQuote({ status, legs, passengers, payments, settings, now = Date.now() }) {
  const s = settings || {};
  const freeH = Number(s.cancel_free_hours ?? 24), feePct = Number(s.cancel_fee_pct ?? 25), noneH = Number(s.no_refund_hours ?? 2);
  const no = reason => ({ allowed: false, reason, refundKobo: 0, cashPaidKobo: 0 });

  if (['cancelled', 'refunded', 'expired'].includes(status)) return no(`This booking is already ${status}.`);
  if ((passengers || []).some(p => ['checked_in', 'boarded', 'no_show'].includes(p.status)))
    return no('A passenger on this booking has already checked in, so it can no longer be cancelled online.');
  if ((legs || []).some(l => l.status && !['scheduled', 'boarding'].includes(l.status)))
    return no('This trip has already left or was cancelled by us. Call the terminal about a refund.');

  const first = (legs || []).map(l => departsAt(l.date, l.time)).sort((a, b) => a - b)[0];
  const hours = first ? (first - now) / 3600e3 : 0;
  if (!first || hours <= 0) return no('This trip has already left.');

  if (status === 'pending') return { allowed: true, band: 'unpaid', refundKobo: 0, cashPaidKobo: 0, hoursToGo: hours };

  const cash = (payments || []).filter(p => p.status === 'success' && p.channel !== 'coupon').reduce((a, p) => a + p.amount_kobo, 0);
  let refund = 0, band = 'none';
  if (hours >= freeH) { refund = cash; band = 'free'; }
  else if (hours >= noneH) { refund = Math.round((cash * (100 - feePct) / 100) / 100) * 100; band = 'fee'; }
  return { allowed: true, band, refundKobo: Math.max(0, refund), cashPaidKobo: cash, hoursToGo: hours, feePct, freeHours: freeH, noRefundHours: noneH };
}
