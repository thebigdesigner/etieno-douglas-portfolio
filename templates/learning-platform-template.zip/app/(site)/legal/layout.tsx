import Link from "next/link";

const PAGES = [
  { label: "Privacy", href: "/legal/privacy" },
  { label: "Terms", href: "/legal/terms" },
  { label: "Data processing", href: "/legal/data-processing" },
  { label: "Security", href: "/legal/security" },
];

export default function LegalLayout({ children }: { children: React.ReactNode }) {
  return (
    <main className="sec">
      <div className="wrap legal">
        <nav className="crumb"><Link href="/">Home</Link> / Legal</nav>
        <div className="legal__nav">
          {PAGES.map((p) => (
            <Link key={p.href} href={p.href}>{p.label}</Link>
          ))}
        </div>
        <article className="legal__body">{children}</article>
        <p className="legal__note">
          Questions about any of this? <Link href="/contact">Get in touch</Link>.
        </p>
      </div>
    </main>
  );
}
