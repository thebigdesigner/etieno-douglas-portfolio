import Link from "next/link";
import { requireOwner } from "@/lib/owner";
import { createAdminClient } from "@/lib/supabase/admin";
import NewCourseForm from "@/app/studio/NewCourseForm";

export const metadata = { title: "Write a course", robots: { index: false, follow: false } };
export const dynamic = "force-dynamic";

/**
 * Writing a course as Your Brand, on Your Brand's own surface.
 *
 * The form is the instructor's, because it is the same job; the shell, the
 * guard and the breadcrumb are the console's, because the person doing it is
 * not an instructor.
 */
export default async function ConsoleNewCoursePage() {
  const owner = await requireOwner();

  // eligible_assessors reads the role column, and the owner's authority
  // deliberately does not live there — it lives in OWNER_EMAILS. In a
  // database with no active practitioners and no operator profiles, the
  // RPC returns nothing, and a required dropdown with no options is a
  // form that cannot be submitted. The person opening this page has
  // already passed the allowlist, so they are always offered.
  const { data } = await createAdminClient().rpc("eligible_assessors");
  const fromDb: { id: string; name: string; kind: string }[] = data ?? [];
  const assessors = fromDb.some((a) => a.id === owner.id)
    ? fromDb
    : [{ id: owner.id, name: owner.name ?? owner.email, kind: "Your Brand" }, ...fromDb];

  return (
    <>
      <nav className="crumb" style={{ paddingTop: 4 }}>
        <Link href="/console/catalogue">Catalogue</Link> / Write a course
      </nav>

      <h1 className="con__h" style={{ marginTop: 12 }}>Write a course</h1>
      <p className="con__sub" style={{ maxWidth: "60ch" }}>
        A course Your Brand owns is covered by the subscription and carries no price.
        Somebody still has to assess its projects, and their name goes on every
        certificate it issues.
      </p>

      <div style={{ marginTop: 22 }}>
        <NewCourseForm isOperator assessors={assessors} />
      </div>
    </>
  );
}
