"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { PASS_MARK, type QuizResult } from "@/lib/learning";
import { track } from "@/lib/track";


/* ------------------------------------------------------------------ */
/* Enrol. Individual learners get an enrolment on demand. Enrolling is   */
/* not the paywall — the gate is per topic, in the learn page, where     */
/* isBeyondFreeModule and hasAccess decide together.                     */
/* ------------------------------------------------------------------ */
export async function enrol(slug: string) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect(`/login?next=/courses/${slug}`);

  const { data: course } = await supabase
    .from("courses").select("id").eq("slug", slug).eq("state", "published").maybeSingle();
  if (!course) redirect("/courses");

  const admin = createAdminClient();
  await track("course_started", user.id, { slug });
  await admin.from("enrolments")
    .upsert(
      { user_id: user.id, course_id: course.id, source: "individual", state: "in_progress" },
      { onConflict: "user_id,course_id", ignoreDuplicates: true }
    );

  const { data: outline } = await admin.rpc("course_outline", {
    p_course_id: course.id, p_user_id: user.id,
  });

  const next = (outline ?? []).find((t: { completed: boolean; unlocked: boolean }) =>
    !t.completed && t.unlocked
  ) ?? (outline ?? [])[0];

  if (!next) redirect(`/courses/${slug}`);
  redirect(`/learn/${slug}/${next.topic_id}`);
}

/* ------------------------------------------------------------------ */
/* Mark a topic with no quiz as complete.                              */
/* ------------------------------------------------------------------ */
export async function completeTopic(slug: string, topicId: string) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect(`/login?next=/learn/${slug}/${topicId}`);

  const admin = createAdminClient();

  const { data: enrolment } = await admin
    .from("enrolments").select("id, source")
    .eq("user_id", user.id)
    .eq("course_id", (await courseIdFor(slug)) ?? "")
    .maybeSingle();
  if (!enrolment) redirect(`/courses/${slug}`);

  const { data: items } = await admin
    .from("quiz_items").select("id").eq("topic_id", topicId).limit(1);
  if (items && items.length > 0) {
    // Has a quiz — completion comes from passing it, not from clicking.
    return;
  }

  await recordCompletion(enrolment.id, enrolment.source, topicId);
  await track("topic_completed", user.id, { topicId, slug, via: "read" });
  revalidatePath(`/learn/${slug}/${topicId}`);
  redirect(await nextTopicUrl(slug, topicId));
}

/* ------------------------------------------------------------------ */
/* Grade a quiz. The answer key never leaves the server.               */
/* ------------------------------------------------------------------ */
export async function submitQuiz(
  slug: string,
  topicId: string,
  _prev: QuizResult,
  formData: FormData
): Promise<QuizResult> {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect(`/login?next=/learn/${slug}/${topicId}`);

  const courseId = await courseIdFor(slug);
  if (!courseId) return { error: "That course is not available." };

  const admin = createAdminClient();
  const { data: enrolment } = await admin
    .from("enrolments").select("id, source")
    .eq("user_id", user.id).eq("course_id", courseId).maybeSingle();
  if (!enrolment) return { error: "You are not enrolled on this course." };

  const { data: cooldown } = await admin.rpc("quiz_cooldown_until", {
    p_enrolment_id: enrolment.id, p_topic_id: topicId,
  });
  if (cooldown && new Date(cooldown) > new Date()) {
    await track("quiz_cooldown", user.id, { topicId, slug });
    return { cooldownUntil: cooldown as string };
  }

  const { data: items } = await admin
    .from("quiz_items").select("id, correct, explanation").eq("topic_id", topicId);
  if (!items || items.length === 0) return { error: "This topic has no quiz." };

  let correctCount = 0;
  const review: NonNullable<QuizResult["review"]> = [];
  const answers: Record<string, string[]> = {};

  for (const item of items) {
    const given = formData.getAll(`q_${item.id}`).map(String).sort();
    answers[item.id] = given;

    const expected = (item.correct as string[]).slice().sort();
    const isCorrect =
      given.length === expected.length && given.every((v, i) => v === expected[i]);

    if (isCorrect) correctCount += 1;
    review.push({ itemId: item.id, correct: isCorrect, explanation: item.explanation });
  }

  const scorePct = Math.round((correctCount / items.length) * 100);
  const passed = scorePct >= PASS_MARK;

  await admin.from("quiz_attempts").insert({
    enrolment_id: enrolment.id,
    topic_id: topicId,
    score_pct: scorePct,
    passed,
    answers,
  });

  if (passed) {
    await recordCompletion(enrolment.id, enrolment.source, topicId);
    await track("topic_completed", user.id, { topicId, slug, scorePct, via: "quiz" });
    revalidatePath(`/learn/${slug}/${topicId}`);
  } else {
    await track("quiz_failed", user.id, { topicId, slug, scorePct });
  }

  return { scorePct, passed, review };
}

/* ------------------------------------------------------------------ */
/* Helpers                                                             */
/* ------------------------------------------------------------------ */
async function courseIdFor(slug: string): Promise<string | null> {
  const admin = createAdminClient();
  const { data } = await admin
    .from("courses").select("id").eq("slug", slug).eq("state", "published").maybeSingle();
  return data?.id ?? null;
}

/**
 * revenue_source is recorded at completion time. The royalty pool divides
 * individual and institutional completions at different rates, and this
 * cannot be reconstructed reliably afterwards.
 */
async function recordCompletion(enrolmentId: string, source: string, topicId: string) {
  const admin = createAdminClient();
  await admin.from("topic_completions").upsert(
    {
      enrolment_id: enrolmentId,
      topic_id: topicId,
      revenue_source: source === "cohort" ? "institution" : "individual",
    },
    { onConflict: "enrolment_id,topic_id", ignoreDuplicates: true }
  );
}

export async function nextTopicUrl(slug: string, currentTopicId: string) {
  /* The user comes from the session, never from the caller.
   *
   * This took a userId parameter and passed it straight to course_outline,
   * which reports what that person has completed and unlocked. A server
   * action is a public endpoint, so the parameter was an invitation to ask
   * about somebody else's progress by supplying their id — the same
   * "the id is just a client-supplied identifier" rule the review pages
   * already follow. Nothing called it with an id anyway. */
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return `/courses/${slug}`;

  const courseId = await courseIdFor(slug);
  if (!courseId) return `/courses/${slug}`;

  const admin = createAdminClient();
  const { data: outline } = await admin.rpc("course_outline", {
    p_course_id: courseId, p_user_id: user.id,
  });

  const list = (outline ?? []) as { topic_id: string; completed: boolean; unlocked: boolean }[];
  const idx = list.findIndex((t) => t.topic_id === currentTopicId);
  const next = list[idx + 1];

  if (!next) return `/courses/${slug}?done=1`;
  return `/learn/${slug}/${next.topic_id}`;
}

