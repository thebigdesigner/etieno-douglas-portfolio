"use client";

import { useActionState, useState } from "react";
import { saveNote } from "@/app/actions/student";
import type { FormState } from "@/lib/forms";
import { useFormStatus } from "react-dom";

const initial: FormState = {};

function Save() {
  const { pending } = useFormStatus();
  return (
    <button className="btn btn--line" disabled={pending}>
      {pending ? "Saving…" : "Save note"}
    </button>
  );
}

export default function Notes({
  topicId, existing,
}: { topicId: string; existing: string | null }) {
  const [open, setOpen] = useState(!!existing);
  const [state, action] = useActionState(saveNote.bind(null, topicId), initial);

  if (!open) {
    return (
      <button className="notes__open" onClick={() => setOpen(true)}>
        + Make a note on this topic
      </button>
    );
  }

  return (
    <form action={action} className="notes">
      <div className="notes__head">
        <span className="notes__t">Your notes</span>
        <span className="notes__p">Private — nobody assessing your project sees these.</span>
      </div>
      <textarea
        name="body"
        rows={5}
        defaultValue={existing ?? ""}
        placeholder="Anything worth remembering when you come back to this."
      />
      <div className="notes__acts">
        <Save />
        {state.ok && <span className="notes__saved">{state.message}</span>}
        {state.error && <span className="notes__err">{state.error}</span>}
      </div>
    </form>
  );
}
