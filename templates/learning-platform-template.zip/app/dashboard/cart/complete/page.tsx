import Link from "next/link";
import { redirect } from "next/navigation";
import { fulfilPayment } from "@/lib/fulfil";

export const metadata = { title: "Purchase complete" };
export const dynamic = "force-dynamic";

// Paystack returns ?reference= (and ?trxref=, the same value). tx_ref is
// what Flutterwave sent, still accepted for payments made before the switch.
type Params = Promise<{ reference?: string; trxref?: string; tx_ref?: string; status?: string }>;

/**
 * Where the provider sends a buyer back to.
 *
 * Fulfils from here as well as from the webhook, because whichever arrives
 * first should grant access — a learner staring at a spinner while a webhook
 * queues is how a successful payment comes to feel like a failed one.
 * fulfilPayment verifies with the provider itself and is idempotent, so
 * calling it from two places is safe by design rather than by luck.
 */
export default async function CartCompletePage({ searchParams }: { searchParams: Params }) {
  const sp = await searchParams;
  const txRef = sp.reference ?? sp.trxref ?? sp.tx_ref;
  const status = sp.status;

  if (!txRef || status === "cancelled") redirect("/dashboard/cart?error=checkout");

  const result = await fulfilPayment(txRef);

  return (
    <>
      <div className="dash__bar">
        <div>
          <div className="eyebrow">Your learning</div>
          <h1 className="dash__title">
            {result.ok ? "That's yours now" : "We could not confirm that payment"}
          </h1>
        </div>
      </div>

      <div className="card">
        {result.ok ? (
          <>
            <p className="card__meta" style={{ maxWidth: "52ch" }}>
              Your courses are open, and each one includes the assessment of its final
              project. Nothing expires — they stay in My courses.
            </p>
            <Link className="btn btn--fill btn--lg" href="/dashboard/courses" style={{ marginTop: 18 }}>
              Go to my courses
            </Link>
          </>
        ) : (
          <>
            <p className="card__meta" style={{ maxWidth: "52ch" }}>
              If money left your account, nothing is lost — the payment is recorded, and
              this page will confirm it once the provider does. Give it a minute and
              reload; if it still says this, send us the reference below.
            </p>
            <p className="card__meta" style={{ marginTop: 10 }}>
              Reference <strong>{txRef}</strong>
            </p>
            <Link className="btn btn--line" href="/contact" style={{ marginTop: 18 }}>
              Contact support
            </Link>
          </>
        )}
      </div>
    </>
  );
}
