import Link from "next/link";
import MkIcon from "@/components/marketplace/MkIcon";

/**
 * Full-screen frame for the marketplace account screens: the photo fills
 * the left half, the form sits alone on the right with the brand above it
 * and a way back to the shop. The marketplace frame steps aside for these
 * routes (see MarketFrame), so nothing competes with the form.
 * On a phone the photo drops away and the form takes the screen.
 */
export default function AuthShell({ title, lead, children, foot, homeHref }: {
  title: string; lead: string; children: React.ReactNode; foot?: React.ReactNode; homeHref: string;
}) {
  return (
    <main className="auf">
      <div className="auf__art" aria-hidden="true">
        <img src="/marketplace/banners/feature-portrait.jpg" alt="" className="auf__img" />
        <div className="auf__cap">
          <span className="auf__brand">Your Brand Marketplace</span>
          <span className="auf__tag">Templates, fonts, sounds and graphics from independent creators.</span>
        </div>
      </div>
      <div className="auf__side">
        <header className="auf__top">
          <Link href={homeHref} className="auf__logo">
            <span className="auf__logo-s">Your Brand</span>
            <span className="auf__logo-m">Marketplace</span>
          </Link>
          <Link href={homeHref} className="auf__back"><MkIcon name="arrow-left" size={16} />Back to the marketplace</Link>
        </header>
        <div className="auf__body">
          <h1 className="au__h">{title}</h1>
          <p className="au__lead">{lead}</p>
          {children}
          {foot && <div className="au__foot">{foot}</div>}
        </div>
      </div>
    </main>
  );
}
