"use client";
import { useActionState } from "react";
import { confirmAdult } from "@/app/actions/auth";
import type { FormState } from "@/lib/forms";
import SubmitButton from "@/components/SubmitButton";
import Alert from "@/components/Alert";

const initial: FormState = {};

export default function AdultForm() {
  const [state, action] = useActionState(confirmAdult, initial);

  return (
    <form action={action} className="auth__form">
      <label className="confirm">
        <input type="checkbox" name="adult" value="yes" required />
        <span>
          <strong>I am 18 or over</strong>
          <em>Your Brand does not accept learners under 18.</em>
        </span>
      </label>

      {state.error && <Alert kind="error">{state.error}</Alert>}

      <SubmitButton>Continue</SubmitButton>
    </form>
  );
}
