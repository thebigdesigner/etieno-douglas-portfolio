-- =====================================================================
-- 0050 — a cron run leaves a trace
--
-- CRON_SECRET was never set in Vercel, so every scheduled run returned
-- 401 and no certificate email, SLA warning or weekly digest was ever
-- sent. It went unnoticed for months for one reason, recorded in the
-- handover:
--
--   "A cron returning 401 and a cron with nothing to do look identical
--    from outside."
--
-- That is the thing to fix. Not the secret — the secret was a
-- five-second change — but the absence of any signal distinguishing
-- working-and-quiet from broken-and-quiet.
--
-- So this records three outcomes, not one:
--
--   ok           the job ran and did whatever it does
--   failed       the job ran and threw
--   unauthorised the request arrived and was rejected
--
-- The third matters most and is the one a "log successes" table would
-- have missed. It separates the two failures that look the same from
-- outside:
--
--   rows saying 'unauthorised'  -> Vercel is calling, the secret is wrong
--   no rows at all              -> Vercel is not calling
--
-- Those have completely different fixes, and telling them apart was
-- exactly what was impossible before.
-- =====================================================================

create table if not exists cron_runs (
  id          uuid primary key default gen_random_uuid(),
  job         text not null,
  outcome     text not null check (outcome in ('ok','failed','unauthorised')),
  started_at  timestamptz not null default now(),
  finished_at timestamptz,
  ms          int,
  detail      jsonb,
  error       text
);

create index if not exists cron_runs_job_time on cron_runs (job, started_at desc);

-- Kept small. These are heartbeats, not an audit trail: the last handful
-- per job answers every question the panel asks, and an unbounded table
-- of them would be the largest thing in the database within a year.
create or replace function public.record_cron_run(
  p_job text, p_outcome text, p_ms int default null,
  p_detail jsonb default null, p_error text default null
) returns void
language plpgsql security definer set search_path = public as $$
begin
  insert into cron_runs (job, outcome, finished_at, ms, detail, error)
  values (p_job, p_outcome, now(), p_ms, p_detail, p_error);

  delete from cron_runs
   where job = p_job
     and id not in (
       select id from cron_runs where job = p_job order by started_at desc limit 50
     );
end; $$;

-- Service-role only, like everything else these routes touch.
alter table cron_runs enable row level security;
revoke all on function public.record_cron_run(text, text, int, jsonb, text)
  from public, anon, authenticated;
grant execute on function public.record_cron_run(text, text, int, jsonb, text) to service_role;

-- ---------------------------------------------------------------------
-- What the console reads: one row per job, with how late it is.
--
-- The expected cadence is stated here rather than in the page, because
-- it comes from vercel.json and the two should be changed together.
-- ---------------------------------------------------------------------
create or replace view public.cron_health as
with jobs (job, label, schedule, every_hours) as (
  values
    ('certificates', 'Certificate and sale emails', 'Daily at 06:00',   24),
    ('sla',          'SLA warnings',                'Weekdays at 08:00', 24),
    ('digest',       'Weekly digest',               'Mondays at 07:00',  168)
),
last_any as (
  select distinct on (job) job, outcome, started_at, ms, detail, error
    from cron_runs order by job, started_at desc
),
last_ok as (
  select distinct on (job) job, started_at as last_ok_at
    from cron_runs where outcome = 'ok' order by job, started_at desc
)
select
  j.job,
  j.label,
  j.schedule,
  la.outcome                                   as last_outcome,
  la.started_at                                as last_run_at,
  la.ms,
  la.detail,
  la.error,
  lo.last_ok_at,
  -- Grace of a quarter of the interval before calling a job late: a
  -- scheduler that fires a few minutes after the hour is not a fault.
  (lo.last_ok_at is null
   or lo.last_ok_at < now() - make_interval(hours => j.every_hours + greatest(j.every_hours / 4, 1)))
                                               as overdue
from jobs j
left join last_any la on la.job = j.job
left join last_ok  lo on lo.job = j.job;
