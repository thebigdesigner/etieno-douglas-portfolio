"use client";
import { useActionState } from "react";
import { useFormStatus } from "react-dom";
import { reviewItem } from "@/app/actions/marketplace";
import type { FormState } from "@/lib/forms";
import Alert from "@/components/Alert";

function Btn({ label, variant }: { label: string; variant: string }) {
  const { pending } = useFormStatus();
  return <button className={`btn ${variant}`} disabled={pending}>{pending ? "…" : label}</button>;
}

export default function ItemDecision({ id }: { id: string }) {
  const [state, action] = useActionState<FormState, FormData>(reviewItem, {});
  if (state.ok) return <Alert kind="success">Done.</Alert>;
  return (
    <div className="app__decide">
      <form action={action}>
        <input type="hidden" name="id" value={id} />
        <input type="hidden" name="decision" value="approve" />
        <Btn label="Publish" variant="btn--fill" />
      </form>
      <form action={action} className="app__reject">
        <input type="hidden" name="id" value={id} />
        <input type="hidden" name="decision" value="reject" />
        <input name="note" placeholder="What the creator needs to change" />
        <Btn label="Send back" variant="btn--line" />
      </form>
      {state.error && <Alert kind="error">{state.error}</Alert>}
    </div>
  );
}
