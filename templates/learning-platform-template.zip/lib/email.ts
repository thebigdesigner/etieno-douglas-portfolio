/**
 * Transactional email. Resend in production; console in development so the
 * consent flow is testable before a sending domain is verified.
 */

type SendArgs = { to: string; subject: string; html: string; text: string };

export async function sendEmail({ to, subject, html, text }: SendArgs) {
  const key = process.env.RESEND_API_KEY;
  const from = process.env.EMAIL_FROM || "Your Brand <onboarding@resend.dev>";

  if (!key) {
    console.log("\n──────── EMAIL (not sent — RESEND_API_KEY unset) ────────");
    console.log("To:      ", to);
    console.log("Subject: ", subject);
    console.log(text);
    console.log("─────────────────────────────────────────────────────────\n");
    return { ok: true, simulated: true };
  }

  const res = await fetch("https://api.resend.com/emails", {
    method: "POST",
    headers: { Authorization: `Bearer ${key}`, "Content-Type": "application/json" },
    body: JSON.stringify({ from, to, subject, html, text }),
  });

  if (!res.ok) {
    console.error("Resend error:", await res.text());
    return { ok: false, simulated: false };
  }
  return { ok: true, simulated: false };
}
