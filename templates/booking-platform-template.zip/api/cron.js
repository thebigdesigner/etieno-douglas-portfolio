/**
 * Daily housekeeping, called by Vercel Cron.
 *
 * Two jobs, both of which the site quietly breaks without:
 *
 *   generate_trips  Departures are rows, not rules. The seed created 30 days' worth; once that
 *                   window passes the booking page simply shows nothing, with no error anywhere
 *                   to notice. This rolls the horizon forward every night.
 *   expire_holds    Unpaid holds keep their seats. Sweeping them puts abandoned checkouts back
 *                   on sale.
 *
 * Vercel sends an Authorization: Bearer <CRON_SECRET> header on scheduled invocations. The same
 * secret works as ?key= so it can be triggered by hand while testing.
 */
import { configured, rpc, fail, select, tenant, lagosToday } from './_lib/db.js';
import { opsAlert, resolveAlert } from './_lib/ops-alert.js';

/**
 * Health checks — ?job=health runs only these (hourly, from Supabase: see CONTINUE-HERE.md);
 * the nightly run does them too. Each check that fails raises an alert; each that passes closes
 * its alert, so the dashboard shows what is wrong now, not what was wrong once.
 */
async function health() {
  const t = await tenant();
  const ago = min => new Date(Date.now() - min * 60000).toISOString();
  const results = {};
  const check = async (key, failing, alert) => {
    results[key] = failing ? 'FAILING' : 'ok';
    if (failing) await opsAlert(key, alert); else await resolveAlert(key);
  };

  // Holds should be swept every two minutes by pg_cron. Old unpaid holds mean the job stopped.
  const stale = await select('bookings', `tenant_id=eq.${t.id}&status=eq.pending&hold_expires_at=lt.${ago(20)}&select=reference&limit=50`);
  await check('health:holds', stale.length > 0, { severity: 'urgent', title: 'Seat holds are not being released',
    detail: { stuck_bookings: stale.length, why: 'The expire-holds job in Supabase (pg_cron) is not running, so abandoned checkouts keep seats off sale.',
      what_to_do: "Supabase → Database → Cron: check 'expire-holds' is active." } });

  // Departures are generated 45 days ahead every night. A short horizon means that job failed.
  const far = await select('trips', `tenant_id=eq.${t.id}&status=eq.scheduled&select=depart_date&order=depart_date.desc&limit=1`);
  const horizon = far[0]?.depart_date || null;
  const soon = new Date(Date.now() + 7 * 864e5).toISOString().slice(0, 10);
  await check('health:schedule', !horizon || horizon < soon, { severity: 'urgent', title: 'Departures are running out',
    detail: { last_departure_on_sale: horizon || 'none', what_to_do: 'The nightly job that creates departures is failing — check Vercel → Logs for /api/cron.' } });

  // Card payments started but none confirmed: the webhook is not getting through.
  const started = await select('payments', `tenant_id=eq.${t.id}&provider=eq.paystack&created_at=gte.${ago(360)}&select=status&limit=200`);
  const confirmed = started.filter(p => p.status === 'success').length;
  await check('health:webhook', started.length >= 3 && confirmed === 0, { severity: 'urgent', title: 'Card payments are not confirming',
    detail: { started_last_6h: started.length, confirmed: 0, what_to_do: 'Check the webhook URL and secret in the Paystack dashboard, and Vercel → Logs for /api/payments/webhook.' } });

  // Money taken with no seat, still not dealt with an hour later.
  const stranded = await select('payments', `tenant_id=eq.${t.id}&needs_attention=not.is.null&attention_handled_at=is.null&created_at=lt.${ago(60)}&select=id&limit=50`);
  await check('health:stranded', stranded.length > 0, { severity: 'urgent', title: `${stranded.length} payment${stranded.length === 1 ? '' : 's'} with no seat still waiting`,
    detail: { what_to_do: 'Dashboard → notifications: re-seat or refund each one, then mark it dealt with.' }, everyMin: 180 });

  // Refunds owed to customers who cancelled online, waiting more than two days.
  const owed = await select('refunds', `tenant_id=eq.${t.id}&status=eq.pending&created_at=lt.${ago(2880)}&select=amount_kobo&limit=100`);
  await check('health:refunds', owed.length > 0, { severity: 'warning', title: `${owed.length} refund${owed.length === 1 ? '' : 's'} waiting more than 2 days`,
    detail: { total: '₦' + Math.round(owed.reduce((a, r) => a + r.amount_kobo, 0) / 100).toLocaleString('en-NG'), what_to_do: 'Send them in Paystack, then mark them refunded on the dashboard.' }, everyMin: 1440 });

  // Customer messages nobody has answered for a day.
  const waiting = await select('feedback', `tenant_id=eq.${t.id}&handled_at=is.null&created_at=lt.${ago(1440)}&select=id&limit=100`).catch(() => []);
  await check('health:messages', waiting.length > 0, { severity: 'warning', title: `${waiting.length} customer message${waiting.length === 1 ? '' : 's'} unanswered for over a day`,
    detail: { what_to_do: 'Dashboard → Messages.' }, everyMin: 1440 });

  // No bookings at all for two days while departures are on sale: the site may be broken.
  const recent = await select('bookings', `tenant_id=eq.${t.id}&created_at=gte.${ago(2880)}&select=id&limit=1`);
  await check('health:quiet', !recent.length && Boolean(horizon), { severity: 'warning', title: 'No bookings in the last 2 days',
    detail: { what_to_do: 'Try a booking on the website yourself. If it works, this is just a quiet spell.' }, everyMin: 1440 });

  return results;
}

const HORIZON_DAYS = 45;

export default async function handler(req, res) {
  const secret = process.env.CRON_SECRET;
  if (!secret) return fail(res, 503, 'not_configured', 'CRON_SECRET is not set');

  const bearer = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  const key = bearer || (req.query && req.query.key) || '';
  if (key !== secret) return fail(res, 401, 'unauthorised', 'Bad cron key');

  if (!configured()) return fail(res, 503, 'not_configured', 'Database is not configured');

  const slug = process.env.TENANT_SLUG || 'ace-trail';
  const out = { ranAt: new Date().toISOString(), tenant: slug };

  if (req.query && req.query.job === 'health') {
    try { out.health = await health(); return res.status(200).json(out); }
    catch (err) { console.error('health check failed:', err.message); return fail(res, 500, 'server', err.message); }
  }

  /* Each job reports its own failure rather than taking the whole run down with it —
     a schedule that cannot extend should not also stop holds from expiring. */
  try {
    out.tripsCreated = await rpc('generate_trips', { p_tenant_slug: slug, p_days: HORIZON_DAYS });
  } catch (err) {
    console.error('generate_trips failed:', err.message);
    out.tripsError = err.message;
  }

  try {
    out.holdsExpired = await rpc('expire_holds', {});
    /* Positions are for a journey in progress, not a movement history. Anything older than a
       week goes — see the note on trip_locations in db/schema.sql. */
    let purged = 0;
    try { purged = await rpc('purge_locations', { p_days: 7 }); }
    catch (err) { console.error('location purge failed:', err.message); }
    out.locationsPurged = purged;
    /* Sign-in attempts are for rate limiting, not a permanent record of who typed what. */
    try { out.attemptsPurged = await rpc('purge_auth_attempts', { p_days: 30 }); }
    catch (err) { console.error('attempt purge failed:', err.message); }
  } catch (err) {
    console.error('expire_holds failed:', err.message);
    out.holdsError = err.message;
  }

  try { out.health = await health(); } catch (err) { console.error('health check failed:', err.message); }
  if (out.tripsError || out.holdsError) await opsAlert('cron:nightly', { severity: 'urgent', title: 'The nightly housekeeping job failed',
    detail: { trips: out.tripsError, holds: out.holdsError } });
  else await resolveAlert('cron:nightly');

  const failed = Boolean(out.tripsError || out.holdsError);
  console.log('cron:', JSON.stringify(out));
  return res.status(failed ? 500 : 200).json(out);
}
