"use client";

import Link from "next/link";
import { useState } from "react";
import NavIcon from "@/components/NavIcon";

type Row = {
  topic_id: string;
  module_title: string;
  topic_title: string;
  pos: number;
  is_free: boolean;
  has_quiz: boolean;
  completed: boolean;
  unlocked: boolean;
};

type Material = {
  id: string;
  kind: string;
  title: string;
  href: string | null;
  size_bytes: number | null;
};

function size(bytes: number | null) {
  if (!bytes) return null;
  const mb = bytes / (1024 * 1024);
  return mb >= 1 ? `${mb.toFixed(1)} MB` : `${Math.round(bytes / 1024)} KB`;
}

/**
 * The playlist rail beside the video.
 *
 * Contents, resources and the transcript were three blocks stacked below
 * the lesson, so reaching the next topic meant scrolling past all of them.
 * As tabs beside the player they cost no vertical space and the next topic
 * is always one click away.
 */
export default function LessonPanel({
  rows, slug, currentId, materials, transcript,
}: {
  rows: Row[]; slug: string; currentId: string;
  materials: Material[]; transcript: string | null;
}) {
  const tabs = [
    { id: "contents", label: "Contents", n: rows.length },
    ...(materials.length ? [{ id: "resources", label: "Resources", n: materials.length }] : []),
    ...(transcript ? [{ id: "transcript", label: "Transcript", n: null }] : []),
  ] as { id: string; label: string; n: number | null }[];

  const [tab, setTab] = useState("contents");
  const done = rows.filter((r) => r.completed).length;

  return (
    <aside className="lpanel">
      <div className="lpanel__tabs" role="tablist">
        {tabs.map((t) => (
          <button
            key={t.id}
            role="tab"
            aria-selected={tab === t.id}
            className={`lpanel__tab${tab === t.id ? " is-on" : ""}`}
            onClick={() => setTab(t.id)}
          >
            {t.label}
            {t.n !== null && <span className="lpanel__n num">{t.n}</span>}
          </button>
        ))}
      </div>

      {tab === "contents" && (
        <>
          <div className="lpanel__prog">
            <span className="num">{done} of {rows.length} done</span>
            <span className="lpanel__bar">
              <span style={{ width: `${rows.length ? (done / rows.length) * 100 : 0}%` }} />
            </span>
          </div>

          <div className="lpanel__list">
            {rows.map((t) => {
              const here = t.topic_id === currentId;
              const openable = t.unlocked || t.is_free;
              const inner = (
                <>
                  <span className={`lrow__ico${t.completed ? " is-done" : ""}${openable ? "" : " is-locked"}`}>
                    <NavIcon
                      name={t.completed ? "award" : openable ? "play" : "lock"}
                      size={14}
                    />
                  </span>
                  <span className="lrow__b">
                    <span className="lrow__t">{t.topic_title}</span>
                    <span className="lrow__m">
                      {t.module_title}
                      {t.has_quiz && " · quiz"}
                    </span>
                  </span>
                  <span className="lrow__n num">{String(t.pos).padStart(2, "0")}</span>
                </>
              );

              return openable ? (
                <Link
                  key={t.topic_id}
                  href={`/learn/${slug}/${t.topic_id}`}
                  className={`lrow${here ? " is-here" : ""}`}
                  aria-current={here ? "page" : undefined}
                >
                  {inner}
                </Link>
              ) : (
                <div key={t.topic_id} className="lrow is-off">{inner}</div>
              );
            })}
          </div>
        </>
      )}

      {tab === "resources" && (
        <div className="lpanel__list">
          {materials.map((m) => (
            <a
              key={m.id}
              className="lrow"
              href={m.href ?? "#"}
              target="_blank"
              rel="noopener noreferrer"
            >
              <span className="lrow__ico">
                <NavIcon name={m.kind === "link" ? "search" : "receipt"} size={14} />
              </span>
              <span className="lrow__b">
                <span className="lrow__t">{m.title}</span>
                <span className="lrow__m">
                  {m.kind}
                  {size(m.size_bytes) && ` · ${size(m.size_bytes)}`}
                </span>
              </span>
            </a>
          ))}
        </div>
      )}

      {tab === "transcript" && (
        <div className="lpanel__tx">{transcript}</div>
      )}
    </aside>
  );
}
