"use client";
import { useEffect } from "react";
import { clearCart } from "@/lib/marketplace/cart";

/** The purchase went through, so the browser's cart is finished with. */
export default function CartDone() {
  useEffect(() => { clearCart(); }, []);
  return null;
}
