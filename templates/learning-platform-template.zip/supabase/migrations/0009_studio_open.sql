-- =====================================================================
-- Open studio access, course templates, mixed materials, assistant
-- =====================================================================

-- ---------------------------------------------------------------------
-- Anyone can build. The gate moves from the person to the first
-- publication — Udemy's shape rather than Alison's.
-- ---------------------------------------------------------------------
create type creator_nudge as enum ('weekly', 'off');

alter table instructors
  add column onboarded_at      timestamptz,
  add column creator_course_done_at timestamptz,
  add column nudge             creator_nudge not null default 'weekly',
  add column nudge_last_shown  timestamptz;

-- Signing up as an instructor now lands in 'active' with nothing published.
-- Identity and practitioner checks happen at the publication gate.
create or replace function public.register_instructor(p_user_id uuid)
returns boolean
language plpgsql security definer set search_path = public as $$
begin
  if exists (select 1 from instructors where id = p_user_id) then return false; end if;
  insert into instructors (id, state, onboarded_at) values (p_user_id, 'active', now());
  update profiles set role = 'instructor' where id = p_user_id;
  return true;
end; $$;

-- A short questionnaire, not an application. Nothing is blocked on it.
create or replace function public.save_instructor_intro(
  p_user_id uuid, p_headline text, p_bio text, p_experience text
)
returns boolean
language plpgsql security definer set search_path = public as $$
begin
  update instructors
     set headline = p_headline, bio = p_bio, proposed_course = p_experience
   where id = p_user_id;
  return found;
end; $$;

create or replace function public.set_nudge(p_user_id uuid, p_nudge creator_nudge)
returns boolean
language plpgsql security definer set search_path = public as $$
begin
  update instructors set nudge = p_nudge where id = p_user_id;
  return found;
end; $$;

/**
 * Weekly, and only for people who have not finished it. Suppressed entirely
 * once they opt out — the switch has to be real or the nudge is nagging.
 */
create or replace function public.should_nudge_creator_course(p_user_id uuid)
returns boolean
language sql stable security definer set search_path = public as $$
  select coalesce(
    (select nudge = 'weekly'
        and creator_course_done_at is null
        and (nudge_last_shown is null or nudge_last_shown < now() - interval '7 days')
       from instructors where id = p_user_id),
    false);
$$;

create or replace function public.mark_nudge_shown(p_user_id uuid)
returns void
language sql security definer set search_path = public as $$
  update instructors set nudge_last_shown = now() where id = p_user_id;
$$;

-- ---------------------------------------------------------------------
-- Templates. The point is not a layout — it is removing the blank page.
-- Each one seeds a module skeleton, a project brief pattern and a rubric.
-- ---------------------------------------------------------------------
create table course_templates (
  id          text primary key,
  name        text not null,
  tagline     text not null,
  best_for    text not null,
  shape       jsonb not null,     -- [{ module, topics: [..] }]
  brief_hint  text not null,
  criteria    jsonb not null,     -- [{ title, descriptor }]
  position    int  not null
);

alter table course_templates enable row level security;
create policy public_templates on course_templates for select using (true);

alter table courses add column template_id text references course_templates(id);

insert into course_templates (id, name, tagline, best_for, shape, brief_hint, criteria, position) values
('walkthrough', 'Walk them through a task',
 'Four modules that build one deliverable step by step.',
 'Software, tools, anything procedural',
 '[{"module":"What you are building","topics":["The finished thing","What you need first"]},
   {"module":"The core steps","topics":["Step one","Step two","Step three"]},
   {"module":"Where it goes wrong","topics":["Common mistakes","How to check your work"]},
   {"module":"Doing it for real","topics":["A harder version","What to do next"]}]'::jsonb,
 'Ask them to produce the same deliverable for a situation you describe — not the one you demonstrated. Give them the inputs and let them do the work.',
 '[{"title":"Produced a working result","descriptor":"The deliverable does what the brief asked, and would function if used for real."},
   {"title":"Made sound choices","descriptor":"Where the brief left room for judgement, the decisions taken are defensible and explained."},
   {"title":"Fit for the audience","descriptor":"Someone who has to use or maintain this could pick it up without asking questions."}]'::jsonb,
 1),

('diagnostic', 'Teach them to read a situation',
 'Build judgement rather than procedure.',
 'Finance, operations, management, analysis',
 '[{"module":"What you are looking at","topics":["The pieces","What each one tells you"]},
   {"module":"Reading it together","topics":["What healthy looks like","What to be suspicious of"]},
   {"module":"Making the call","topics":["Weighing the evidence","Explaining it to someone else"]}]'::jsonb,
 'Give them a real situation with real numbers or documents, and ask for an assessment plus a recommendation. The recommendation is what you are marking.',
 '[{"title":"Read the material correctly","descriptor":"Draws accurate conclusions from what was provided, without misreading or inventing detail."},
   {"title":"Prioritised well","descriptor":"The things flagged first are the ones that matter most, with a reason for each."},
   {"title":"Written for the decision-maker","descriptor":"Plain language, no unexplained jargon, and a recommendation somebody could act on."}]'::jsonb,
 2),

('build', 'Have them make something from nothing',
 'A blank page to a finished piece of work.',
 'Creative, writing, design, entrepreneurship',
 '[{"module":"Before you start","topics":["What makes these good","Finding your angle"]},
   {"module":"Making a first version","topics":["Getting it down","Structure"]},
   {"module":"Making it good","topics":["Editing","Common weaknesses"]},
   {"module":"Finishing","topics":["Knowing when it is done","Putting it out"]}]'::jsonb,
 'Ask for the finished piece, plus a short note on the choices they made. The note is often more revealing than the work.',
 '[{"title":"The work stands on its own","descriptor":"It achieves what this kind of piece is meant to achieve, without needing explanation."},
   {"title":"Deliberate choices","descriptor":"The decisions were made rather than defaulted into, and they can say why."},
   {"title":"Finished, not abandoned","descriptor":"Edited and complete. Nothing left obviously unresolved."}]'::jsonb,
 3),

('foundations', 'Start them from zero',
 'Assume nothing. Get them to competent.',
 'High school, first-time learners, digital skills',
 '[{"module":"Getting oriented","topics":["Why this matters","The words you will need"]},
   {"module":"The basics","topics":["First idea","Second idea","Putting them together"]},
   {"module":"Practising","topics":["A guided example","One on your own"]},
   {"module":"Where next","topics":["What you can do now","What to learn after this"]}]'::jsonb,
 'Keep it concrete and small. A beginner needs a task they can finish, not a project that proves the ceiling.',
 '[{"title":"Understood the fundamentals","descriptor":"Uses the core ideas correctly, even if the execution is simple."},
   {"title":"Completed the task","descriptor":"Followed it through to something finished rather than stopping partway."},
   {"title":"Can explain their thinking","descriptor":"Able to say why they did it that way, in their own words."}]'::jsonb,
 4),

('blank', 'Start from nothing',
 'An empty course. Structure it yourself.',
 'You already know exactly what you are making',
 '[]'::jsonb,
 'Describe exactly what they should produce, and what a good version looks like. Vague briefs produce vague verdicts.',
 '[]'::jsonb,
 5);

-- ---------------------------------------------------------------------
-- Mixed materials. A topic is a video *and* notes *and* a worksheet,
-- rather than one type each.
-- ---------------------------------------------------------------------
create type material_kind as enum ('video', 'pdf', 'slides', 'download', 'link', 'audio');

create table topic_materials (
  id          uuid primary key default gen_random_uuid(),
  topic_id    uuid not null references topics(id) on delete cascade,
  kind        material_kind not null,
  title       text not null,
  path        text,               -- storage path, for uploads
  url         text,               -- external, for links and video assets
  size_bytes  bigint,
  position    int not null default 1,
  created_at  timestamptz not null default now()
);

create index on topic_materials (topic_id, position);
alter table topic_materials enable row level security;

create policy public_materials on topic_materials for select using (
  exists (
    select 1 from topics t join modules m on m.id = t.module_id
      join courses c on c.id = m.course_id
     where t.id = topic_materials.topic_id and c.state = 'published'
  )
);

create policy instructor_own_materials on topic_materials for all using (
  exists (
    select 1 from topics t join modules m on m.id = t.module_id
      join courses c on c.id = m.course_id
     where t.id = topic_materials.topic_id and c.instructor_id = auth.uid()
  )
) with check (
  exists (
    select 1 from topics t join modules m on m.id = t.module_id
      join courses c on c.id = m.course_id
     where t.id = topic_materials.topic_id and c.instructor_id = auth.uid()
  )
);

insert into storage.buckets (id, name, public, file_size_limit)
values ('materials', 'materials', false, 104857600)
on conflict (id) do nothing;

create policy "instructors upload materials"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'materials' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "authenticated read materials"
  on storage.objects for select to authenticated
  using (bucket_id = 'materials');

-- ---------------------------------------------------------------------
-- Free courses. Alison's model, and the fastest route to a catalogue
-- worth browsing: a practitioner will write one to be read before they
-- will write one to be sold.
-- ---------------------------------------------------------------------
alter table courses add column is_free boolean not null default false;

-- ---------------------------------------------------------------------
-- Assistant. Answers from the catalogue only.
-- ---------------------------------------------------------------------
create table assistant_threads (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid references profiles(id) on delete set null,
  session_id text not null,
  created_at timestamptz not null default now()
);

create table assistant_turns (
  id          uuid primary key default gen_random_uuid(),
  thread_id   uuid not null references assistant_threads(id) on delete cascade,
  role        text not null check (role in ('user', 'assistant')),
  content     text not null,
  cited       jsonb,               -- course slugs the answer drew on
  tokens      int,
  created_at  timestamptz not null default now()
);

create index on assistant_turns (thread_id, created_at);
create unique index on assistant_threads (session_id);

-- Rate limiting. The endpoint is unauthenticated, so without this it is a
-- way for somebody to spend our money.
create table assistant_usage (
  bucket_key text not null,        -- ip or user id
  window_start timestamptz not null,
  turns      int not null default 0,
  primary key (bucket_key, window_start)
);

create or replace function public.assistant_allow(p_key text, p_limit int default 20)
returns boolean
language plpgsql security definer set search_path = public as $$
declare
  v_window timestamptz := date_trunc('hour', now());
  v_turns  int;
begin
  insert into assistant_usage (bucket_key, window_start, turns)
  values (p_key, v_window, 1)
  on conflict (bucket_key, window_start)
    do update set turns = assistant_usage.turns + 1
  returning turns into v_turns;

  delete from assistant_usage where window_start < now() - interval '2 days';
  return v_turns <= p_limit;
end; $$;

/** What the assistant is allowed to know: published courses, nothing else. */
create or replace function public.assistant_catalogue()
returns table (
  slug text, title text, summary text, subject text, segment text,
  is_free boolean, topics text
)
language sql stable security definer set search_path = public as $$
  select c.slug, c.title, c.summary, c.subject, c.segment, c.is_free,
         string_agg(t.title, '; ' order by m.position, t.position) as topics
    from courses c
    left join modules m on m.course_id = c.id
    left join topics  t on t.module_id = m.id
   where c.state = 'published'
   group by c.slug, c.title, c.summary, c.subject, c.segment, c.is_free;
$$;

revoke all on function public.save_instructor_intro(uuid, text, text, text) from public, anon, authenticated;
revoke all on function public.set_nudge(uuid, creator_nudge) from public, anon, authenticated;
revoke all on function public.mark_nudge_shown(uuid) from public, anon, authenticated;
revoke all on function public.assistant_allow(text, int) from public, anon, authenticated;


-- ---------------------------------------------------------------------
-- Publication gate, extended. Every topic needs something in it, and the
-- rubric still has to be specific enough to produce consistent verdicts.
-- ---------------------------------------------------------------------
create or replace function public.submit_course_for_review(p_course_id uuid, p_instructor_id uuid)
returns table (ok boolean, reason text)
language plpgsql security definer set search_path = public as $$
declare
  v_course courses%rowtype;
  v_topics int; v_criteria int; v_quiz int; v_empty int;
begin
  select * into v_course from courses where id = p_course_id and instructor_id = p_instructor_id;
  if not found then return query select false, 'not_yours'; return; end if;
  if v_course.state not in ('draft','revision_requested') then
    return query select false, 'wrong_state'; return;
  end if;

  select count(*) into v_topics
    from topics t join modules m on m.id = t.module_id where m.course_id = p_course_id;
  if v_topics < 3 then return query select false, 'too_few_topics'; return; end if;

  -- A topic with neither text nor a material is an empty page.
  select count(*) into v_empty
    from topics t join modules m on m.id = t.module_id
   where m.course_id = p_course_id
     and coalesce(length(trim(t.body)), 0) < 40
     and not exists (select 1 from topic_materials tm where tm.topic_id = t.id);
  if v_empty > 0 then return query select false, 'empty_topics'; return; end if;

  select count(*) into v_quiz
    from quiz_items q join topics t on t.id = q.topic_id
    join modules m on m.id = t.module_id where m.course_id = p_course_id;
  if v_quiz < 3 then return query select false, 'too_few_questions'; return; end if;

  if coalesce(length(trim(v_course.project_brief)), 0) < 120 then
    return query select false, 'brief_too_short'; return;
  end if;

  select count(*) into v_criteria from rubric_criteria where course_id = p_course_id;
  if v_criteria < 2 then return query select false, 'rubric_too_thin'; return; end if;

  update courses set state = 'in_review' where id = p_course_id;
  return query select true, null::text;
end; $$;
