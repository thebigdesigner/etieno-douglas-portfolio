import { runJob } from "@/lib/cron";
import { sweepCertificateEmails, sweepSaleEmails } from "@/lib/certificate-email";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

/**
 * Outbound notifications for anything the database created and could not
 * send mail about: certificates issued, courses sold.
 *
 * Cheap when there is nothing to do — two partial-indexed queries returning
 * no rows — so it can run often, which matters because both of these are
 * only useful near the moment they become true.
 */
export async function GET(request: Request) {
  return runJob("certificates", request, async () => {
    // Sequential rather than parallel: both share one mail provider and its
    // rate limit, and neither is urgent enough to race the other.
    const certificates = await sweepCertificateEmails();
    const sales = await sweepSaleEmails();
    return { certificates, sales };
  });
}
