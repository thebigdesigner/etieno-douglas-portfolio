import { cookies, headers } from "next/headers";
import { cache } from "react";
import { CCY_COOKIE, DEFAULT_CCY, isCcy, type Ccy } from "@/lib/money";

/**
 * Which currency *this request* is priced in. Split from lib/money.ts so
 * that client components can format prices without pulling request
 * headers into the browser bundle.
 */

export * from "@/lib/money";

/** Only these countries default to something other than dollars. */
const BY_COUNTRY: Record<string, Ccy> = {
  NG: "NGN",
  GB: "GBP", UK: "GBP", IM: "GBP", JE: "GBP", GG: "GBP",
};


/**
 * The country a request appears to come from, as reported by whatever sits
 * in front of the app. Deliberately only a *default*: Nigerian mobile
 * traffic often geolocates to wherever the carrier's gateway is, and VPNs
 * make it worse. A visitor's own choice always wins, and is remembered.
 */
async function countryFromRequest(): Promise<string | null> {
  const h = await headers();
  const raw =
    h.get("cf-ipcountry") ??            // Cloudflare
    h.get("x-vercel-ip-country") ??     // Vercel
    h.get("x-geo-country") ??           // some proxies
    h.get("x-country-code");
  const code = raw?.trim().toUpperCase();
  return code && /^[A-Z]{2}$/.test(code) ? code : null;
}

/**
 * The currency to price in for this request: the visitor's saved choice,
 * else a guess from their country, else dollars. Cached per request so a
 * page with twenty prices on it resolves once.
 */
export const readCurrency = cache(async (): Promise<Ccy> => {
  const chosen = (await cookies()).get(CCY_COOKIE)?.value;
  if (isCcy(chosen)) return chosen;
  const country = await countryFromRequest();
  return (country && BY_COUNTRY[country]) || DEFAULT_CCY;
});

/** True when the visitor has picked, rather than been guessed at. */
export const currencyIsChosen = cache(async (): Promise<boolean> =>
  isCcy((await cookies()).get(CCY_COOKIE)?.value));

