import Link from "next/link";
import { Suspense } from "react";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { hasAccess } from "@/lib/access";
import DashTabs from "@/components/DashTabs";
import CourseRow, { type RowCourse } from "@/components/CourseRow";
import CourseCard, { type CardCourse } from "@/components/CourseCard";
import NavIcon from "@/components/NavIcon";
import StatList from "@/components/StatList";
import InsightNote from "@/components/InsightNote";
import Avatar from "@/components/Avatar";
import CourseHero, { type HeroCourse } from "@/components/CourseHero";
import { profileProgress } from "@/lib/profile-progress";
import { hasArrived } from "@/lib/arrival";

export const metadata = { title: "Courses and certificates" };
export const dynamic = "force-dynamic";

type SearchParams = Promise<{ view?: string }>;
type OutlineRow = { topic_id: string; completed: boolean; unlocked: boolean };

export default async function DashboardPage({ searchParams }: { searchParams: SearchParams }) {
  const { view = "progress" } = await searchParams;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const admin = createAdminClient();

  const [{ data: me }, { data: stats }, { data: enrolled }, { data: saved }] = await Promise.all([
    admin.from("profiles").select("display_name, avatar_path").eq("id", user!.id).maybeSingle(),
    admin.from("learner_stats").select("*").eq("id", user!.id).maybeSingle(),
    admin.from("learner_courses").select("*").eq("user_id", user!.id)
      .order("last_active", { ascending: false, nullsFirst: false }),
    admin.from("saved_courses")
      .select("courses(slug, title, summary, subject, level, hours_low, hours_high, is_free, thumbnail_path)")
      .eq("user_id", user!.id),
  ]);

  const profileName = me?.display_name?.split(" ")[0] ?? null;
  const s = (stats ?? {}) as Record<string, number | string | null>;
  const all = (enrolled ?? []) as RowCourse[];

  const inProgress = all.filter((c) => Number(c.pct ?? 0) < 100);
  const completed = all.filter((c) => Number(c.pct ?? 0) >= 100);
  const certified = all.filter((c) => c.certificate_code);

  const savedCourses: CardCourse[] = [];
  for (const row of saved ?? []) {
    const c = row.courses as unknown as CardCourse | null;
    if (c) savedCourses.push(c);
  }

  // The next unlocked topic, so a row goes straight back into the work.
  // One course_outline call per row, in parallel — but only for the rows
  // actually on screen, and only the first page of them. This used to fan
  // out across every enrolment the learner had ever started.
  const shown = (view === "completed" ? completed : inProgress).slice(0, 12);
  const withNext = await Promise.all(
    shown.map(async (c) => {
      if (Number(c.pct ?? 0) >= 100) return c;
      const { data: outline } = await admin.rpc("course_outline", {
        p_course_id: c.course_id, p_user_id: user!.id,
      });
      const rows = (outline ?? []) as OutlineRow[];
      const next = rows.find((t) => !t.completed && t.unlocked) ?? rows[0];
      return { ...c, nextTopicId: next?.topic_id ?? null };
    })
  );

  const hasBought = await hasAccess(user!.id);
  const weekly = Number(s.topics_this_week ?? 0);

  // Setup progress, not course progress. The card below used to show topic
  // completion under a "Complete profile" button — two different numbers
  // sharing one label. Cohort accounts carry no real email, which the
  // shared model already counts as an outstanding step.
  const setup = profileProgress({
    displayName: me?.display_name ?? "",
    email: (user!.email ?? "").endsWith("@cohort.splari.internal")
      ? null : (user!.email ?? null),
    avatarPath: me?.avatar_path ?? null,
    enrolments: all.length,
    subscribed: hasBought,
    certificates: certified.length,
  });

  // The hero answers one question: what do I open right now.
  const next = inProgress[0] as (RowCourse & { nextTopicId?: string | null }) | undefined;
  const nextWithTopic = withNext.find((c) => c.slug === next?.slug) as
    (RowCourse & { nextTopicId?: string | null }) | undefined;
  // Nothing under way means a new learner, who gets a suggestion instead.
  const { data: suggestion } = next
    ? { data: null }
    : await admin.rpc("suggested_course", { p_user_id: user!.id });
  const suggested = Array.isArray(suggestion) ? suggestion[0] : suggestion;

  const heroCourse: HeroCourse | null = next
    ? {
        // learner_courses does not carry summary or hours_low, so the
        // continue card leans on progress instead of a blurb — which is
        // the more useful thing to show someone already partway in.
        slug: next.slug, title: next.title, summary: null,
        subject: next.subject ?? null,
        thumbnailPath: next.thumbnail_path ?? null, thumbnailAlt: null,
        hoursLow: null, hoursHigh: next.hours_high ?? null,
        pct: Number(next.pct ?? 0),
        topicsDone: next.topics_done ?? 0, topicsTotal: next.topics_total ?? 0,
        nextTopicId: nextWithTopic?.nextTopicId ?? null,
      }
    : suggested
      ? {
          slug: suggested.slug, title: suggested.title, summary: suggested.summary,
          subject: suggested.subject,
          thumbnailPath: suggested.thumbnail_path, thumbnailAlt: suggested.thumbnail_alt,
          hoursLow: suggested.hours_low, hoursHigh: suggested.hours_high,
          learners: Number(suggested.learners ?? 0),
        }
      : null;

  // The pace note. This was a fixed sentence promising a fortnight to
  // everybody with a non-zero weekly count — the same fortnight whether they
  // had two topics left or forty. Worked out from the learner's own rate and
  // what is actually outstanding, and only shown when both are known and the
  // answer is worth reading.
  const topicsLeft = inProgress.reduce(
    (n, c) => n + Math.max(0, Number(c.topics_total ?? 0) - Number(c.topics_done ?? 0)), 0);
  const weeksLeft = weekly > 0 && topicsLeft > 0 ? Math.ceil(topicsLeft / weekly) : null;
  const pace =
    weeksLeft === null
      ? null
      : {
          // Dismissal is keyed to the fact, so a new week says it again.
          id: `${weekly}-${topicsLeft}`,
          text:
            `${weekly} topic${weekly === 1 ? "" : "s"} finished this week. ` +
            `${topicsLeft} left across your open courses — about ` +
            `${weeksLeft} week${weeksLeft === 1 ? "" : "s"} at this rate.`,
        };

  // The greeting, in three states.
  //
  //   arrived + nothing on the account  -> "Welcome, X"      (first time)
  //   arrived                            -> "Welcome back, X" (just logged in)
  //   navigated here from another page   -> "Hey, X"
  //
  // "Arrived" is the one-shot cookie every sign-in sets and the middleware
  // burns on this render. First-time is read from the account rather than
  // from how they signed up, so somebody who created an account months ago
  // and is only now opening it still gets welcomed rather than welcomed back.
  const arrived = await hasArrived();
  const untouched = all.length === 0 && savedCourses.length === 0;
  const greeting = arrived
    ? untouched
      ? profileName ? `Welcome, ${profileName}` : "Welcome to Your Brand"
      : profileName ? `Welcome back, ${profileName}` : "Welcome back"
    : profileName ? `Hey, ${profileName}` : "Hey there";

  const awaitingRows = all.filter(
    (c) => c.submission_state && ["submitted", "assigned", "in_review"].includes(c.submission_state)
  );

  return (
    <>
      {/* Full width, across both columns. The artwork is a texture rather
          than a composed graphic now, so a wide crop costs nothing. */}
      <div className="dash__bar">
        <div>
          <div className="eyebrow">Your dashboard</div>
          <h1 className="dash__title">{greeting}</h1>
        </div>
      </div>

      <div className="pan">
        <div className="pan__col">
          {heroCourse && (
            <CourseHero
              course={heroCourse}
              mode={next ? "continue" : "suggestion"}
              firstName={profileName}
            />
          )}

          {!hasBought && (
            <section className="promo">
              <h2 className="promo__h">Buy a course once, and it is yours</h2>
              <p className="promo__p">
                From $30, with the assessment of your final project included — marked
                by somebody who does that work for a living. Nothing to renew.
              </p>
              <Link className="promo__cta" href="/courses">Browse the catalogue</Link>
            </section>
          )}

          {/* The tiles as they were, each one now a link. */}
          <StatList
            stats={[
              { label: "Courses", value: Number(s.courses_started ?? 0),
                icon: "book", tone: "peach", href: "/dashboard/courses" },
              { label: "Being assessed", value: awaitingRows.length,
                icon: "inbox", tone: "blue", href: "/dashboard/submissions" },
              { label: "Certificates", value: Number(s.certificates ?? 0),
                icon: "award", tone: "green", href: "/dashboard/certificates" },
              { label: "Topics this week", value: weekly,
                icon: "sparkle", tone: "purple", href: "/dashboard/courses" },
            ]}
          />

          {view === "progress" && pace && (
            <InsightNote id={pace.id}>
              {pace.text}
            </InsightNote>
          )}

          {view === "progress" && !hasBought && all.length > 0 && (
            <div className="insight insight--warn">
              <span className="insight__ico" aria-hidden="true">!</span>
              <span>
                You are on the free first module. Buying the course opens the rest and
                includes the assessment of your project — your progress carries over.
              </span>
              <Link className="insight__go" href="/dashboard/courses">My courses</Link>
            </div>
          )}

          <div className="card">
            <div className="card__head">
              <div className="card__h">Your courses</div>
              <Link className="card__link" href="/dashboard/courses">See all</Link>
            </div>

            <Suspense fallback={<div className="dtabs" />}>
              <DashTabs tabs={[
                { label: "In progress", value: "progress", count: inProgress.length },
                { label: "Completed", value: "completed", count: completed.length },
                { label: "Certificates", value: "certificates", count: certified.length },
                { label: "Saved", value: "saved", count: savedCourses.length },
              ]} />
            </Suspense>

            {view === "saved" ? (
              savedCourses.length === 0 ? (
                <Empty
                  title="Nothing saved yet"
                  body="Star a course while you are browsing and it waits here. Useful when you find three you want and have time for one."
                />
              ) : (
                <div className="ccards ccards--list">
                  {/* A list, like the other three tabs in this panel. */}
                  {savedCourses.map((c) => <CourseCard key={c.slug} course={c} />)}
                </div>
              )
            ) : view === "certificates" ? (
              certified.length === 0 ? (
                <Empty
                  title="No certificates yet"
                  body="Finish a course, submit the final project, and a working practitioner assesses it within four working days."
                />
              ) : (
                <div className="crows">
                  {certified.map((c) => <CourseRow key={c.enrolment_id} course={c} />)}
                </div>
              )
            ) : withNext.length === 0 ? (
              <Empty
                title={view === "completed" ? "Nothing finished yet" : "You have not started anything"}
                body={
                  view === "completed"
                    ? "Courses you finish every topic of will appear here, ready for the final project."
                    : "The first topic of every course is free, so you can look around before deciding on anything."
                }
              />
            ) : (
              <div className="crows">
                {withNext.map((c) => <CourseRow key={c.enrolment_id} course={c} />)}
              </div>
            )}
          </div>
        </div>

        {/* Right column — what is happening without you. */}
        <div className="pan__col">
          {/* One job: get the account finished. So it stops appearing the
              moment there is nothing left to prompt for, rather than sitting
              at 100% holding the best slot on the page forever. */}
          {!setup.complete && (
            <div className="card pcard">
              <div
                className="pcard__pic"
                style={{ "--pct": setup.pct } as React.CSSProperties}
              >
                <Avatar name={me?.display_name} path={me?.avatar_path} size={72} />
                <span className="pcard__ring" aria-hidden="true" />
              </div>
              <div className="pcard__name">{me?.display_name ?? "Your account"}</div>
              <div className="pcard__pct">
                <strong className="num">{setup.pct}%</strong> of your profile set up
              </div>

              <ul className="pcard__todo">
                {setup.remaining.slice(0, 3).map((step) => (
                  <li key={step.label}>
                    <Link href={step.href}>
                      <span className="pcard__tick" aria-hidden="true" />
                      <span className="pcard__todolabel">{step.label}</span>
                      <span className="pcard__todopct num">+{step.pct}%</span>
                    </Link>
                  </li>
                ))}
              </ul>

              {setup.remaining.length > 3 && (
                <div className="pcard__sub num">
                  {setup.remaining.length - 3} more after that
                </div>
              )}

              <Link className="btn btn--line pcard__cta" href="/dashboard/account">
                Finish setting up
              </Link>
            </div>
          )}

          <div className="card">
            <div className="card__head">
              <div className="card__h">Being assessed</div>
              <Link className="card__link" href="/dashboard/submissions">See all</Link>
            </div>
            {awaitingRows.length === 0 ? (
              <p className="empty2">Nothing with a reviewer right now.</p>
            ) : (
              awaitingRows.slice(0, 4).map((c) => (
                <div className="prow2" key={c.enrolment_id}>
                  <span className="prow2__ico prow2__ico--accent" aria-hidden="true">
                    <NavIcon name="inbox" size={17} />
                  </span>
                  <span>
                    <span className="prow2__t">{c.title}</span>
                    <span className="prow2__s">Four working days from submission</span>
                  </span>
                  <span className="tag tag--wait">
                    {c.submission_state === "in_review" ? "In review" : "Queued"}
                  </span>
                </div>
              ))
            )}
          </div>

          <div className="card">
            <div className="card__head">
              <div className="card__h">Certificates</div>
              <Link className="card__link" href="/dashboard/certificates">See all</Link>
            </div>
            {certified.length === 0 ? (
              <p className="empty2">Your first one lands here once a project passes.</p>
            ) : (
              certified.slice(0, 4).map((c) => (
                <div className="prow2" key={c.enrolment_id}>
                  <span className="prow2__ico" aria-hidden="true">
                    <NavIcon name="award" size={17} />
                  </span>
                  <span>
                    <span className="prow2__t">{c.title}</span>
                    <span className="prow2__s num">{c.certificate_code}</span>
                  </span>
                  <span className="tag tag--go">Passed</span>
                </div>
              ))
            )}
          </div>

          <div className="card card--tint">
            <div className="card__h">How assessment works</div>
            <p className="card__meta" style={{ marginTop: 8, lineHeight: 1.6 }}>
              Every final project is read by someone who does that work for a living,
              against a rubric published before you start. You get written feedback
              either way, and one free resubmission if changes are needed.
            </p>
          </div>
        </div>
      </div>
    </>
  );
}

function Empty({ title, body }: { title: string; body: string }) {
  return (
    <div className="empty" style={{ marginTop: 24 }}>
      <p className="empty__h">{title}</p>
      <p className="empty__p">{body}</p>
      <Link className="btn btn--fill btn--lg" href="/courses" style={{ marginTop: 20 }}>
        Browse courses
      </Link>
    </div>
  );
}
