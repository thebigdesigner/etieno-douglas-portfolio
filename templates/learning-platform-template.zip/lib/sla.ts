/** Human-readable time remaining against the four-working-day promise. */
export function slaLabel(deadlineIso: string, now: Date = new Date()): string {
  const deadline = new Date(deadlineIso);
  const ms = deadline.getTime() - now.getTime();

  if (ms <= 0) {
    const overHours = Math.floor(-ms / 3600_000);
    if (overHours < 24) return `${overHours}h overdue`;
    return `${Math.floor(overHours / 24)}d overdue`;
  }

  const hours = Math.floor(ms / 3600_000);
  if (hours < 24) return `${hours}h left`;
  const days = Math.floor(hours / 24);
  return `${days}d ${hours % 24}h left`;
}
