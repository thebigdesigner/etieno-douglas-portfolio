import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import MarketingHome from "@/components/MarketingHome";

export const dynamic = "force-dynamic";

/**
 * Somebody already signed in does not need the sales pitch — they land on
 * whichever surface is theirs. Everyone else gets the marketing page.
 */
export default async function HomePage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  if (user) {
    const { data: profile } = await supabase
      .from("profiles").select("role").eq("id", user.id).maybeSingle();

    if (profile?.role === "instructor") redirect("/studio");
    if (profile?.role === "institution_admin") redirect("/institution");
    if (profile?.role === "operator") redirect("/admin/sla");
    redirect("/dashboard");
  }

  return <MarketingHome />;
}
