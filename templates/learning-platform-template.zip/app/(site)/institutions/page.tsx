export default function InstitutionsPage() {
  return (
    <>
<header className="phero">
  <div className="phero__in">
    <div>
      <div className="eyebrow">Placeholder text by Aphinity Digital.</div>
      <h1 style={{marginTop: '14px'}}>Replace this with your own words.</h1>
      <p className="phero__sub">Aphinity Digital designs and builds websites like this one, and helps them get found on Google and in AI answers.</p>
      <div className="phero__btns">
        <a className="btn btn--fill btn--lg" href="/signup?intent=institution">Create your account</a>
        <a className="btn btn--line btn--lg" href="#how">Your supporting line goes here.</a>
      </div>
      <p className="phero__note">Use this space to explain your offer in plain words: who it is for, what it costs and why it is worth it.</p>
    </div>
    <div className="stage">
      <div className="stage__ring" aria-hidden="true"></div>
      <div className="stage__disc" aria-hidden="true"></div>
      <div className="stage__media"><svg className="stage__svg" viewBox="0 0 420 380" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="A cohort of learners joining with issued credentials">
  <defs>
    <linearGradient id="cardg" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stopColor="#FFFFFF"/><stop offset="1" stopColor="#F3F5FA"/>
    </linearGradient>
  </defs>
  <ellipse cx="210" cy="344" rx="140" ry="16" fill="#0B0B0F" opacity=".07"/>

  <g transform="translate(96 46)">
    <rect x="0" y="0" width="228" height="146" rx="18" fill="url(#cardg)" stroke="#E6E6EC" strokeWidth="2"/>
    <rect x="20" y="22" width="74" height="8" rx="4" fill="#0B0B0F"/>
    <rect x="20" y="42" width="130" height="6" rx="3" fill="#E6E6EC"/>
    <rect x="20" y="70" width="188" height="52" rx="12" fill="#EDF2FF"/>
    <text x="34" y="93" fontFamily="Jost, sans-serif" fontSize="13" fill="#7C7C88" letterSpacing="2">CLASS CODE</text>
    <text x="34" y="113" fontFamily="Jost, sans-serif" fontSize="20" fontWeight="600" fill="#1F5CFF" letterSpacing="3">SPL-7K42</text>
  </g>

  <g>
    <circle cx="80" cy="238" r="34" fill="#CFE4FF"/>
    <circle cx="80" cy="226" r="13" fill="#D9A07A"/>
    <path d="M80 242 q-19 0 -22 20 h44 q-3 -20 -22 -20 z" fill="#3C4C88"/>
  </g>
  <g>
    <circle cx="164" cy="262" r="34" fill="#C8F0DC"/>
    <circle cx="164" cy="250" r="13" fill="#E8B48C"/>
    <path d="M164 266 q-19 0 -22 20 h44 q-3 -20 -22 -20 z" fill="#7C4B8A"/>
  </g>
  <g>
    <circle cx="252" cy="262" r="34" fill="#FFE27A"/>
    <circle cx="252" cy="250" r="13" fill="#C98F6C"/>
    <path d="M252 266 q-19 0 -22 20 h44 q-3 -20 -22 -20 z" fill="#2B5F52"/>
  </g>
  <g>
    <circle cx="336" cy="238" r="34" fill="#FFD9E3"/>
    <circle cx="336" cy="226" r="13" fill="#D9A07A"/>
    <path d="M336 242 q-19 0 -22 20 h44 q-3 -20 -22 -20 z" fill="#3C4C88"/>
  </g>

  <g stroke="#B9C4DA" strokeWidth="2" strokeDasharray="5 6" fill="none">
    <path d="M180 194 q-60 8 -96 16"/>
    <path d="M198 194 q-24 26 -32 34"/>
    <path d="M228 194 q22 26 26 34"/>
    <path d="M244 194 q60 8 90 16"/>
  </g>
</svg></div>
      <div className="float float--a">
        <div className="float__ic">◷</div>
        <div><div className="float__t">No email needed</div>
        <div className="float__s">Designed by Aphinity Digital.</div></div>
      </div>
      <div className="float float--b">
        <div><div className="float__t num">47 of 60 active</div>
        <div className="float__s">Get found. Get chosen.</div></div>
      </div>
    </div>
  </div>
</header>

<section className="band"><div className="band__in">
  <div className="band__i"><div className="band__n">No email</div><div className="band__l">Placeholder text by Aphinity Digital.</div></div>
  <div className="band__i"><div className="band__n">No app</div><div className="band__l">Replace this with your own words.</div></div>
  <div className="band__i"><div className="band__n">No seats billed</div><div className="band__l">Your supporting line goes here.</div></div>
  <div className="band__i"><div className="band__n">No lock-in</div><div className="band__l">Designed by Aphinity Digital.</div></div>
</div></section>

<section className="sec" id="how">
  <div className="wrap">
    <div className="sec__head"><div>
      <h2 className="sec__h">Get found. Get chosen.</h2>
      <div className="sec__meta">Placeholder text by Aphinity Digital.</div></div></div>
    <div className="proc">
      <div className="prow"><div className="prow__n">01</div>
        <div className="prow__t">Replace this with your own words.</div>
        <div className="prow__d">Need this template customised for your brand? Aphinity Digital can set it up, write the copy and launch it for you.</div></div>
      <div className="prow"><div className="prow__n">02</div>
        <div className="prow__t">Your supporting line goes here.</div>
        <div className="prow__d">Strategy, design, media and development under one roof, with AI doing the heavy lifting so everything ships faster.</div></div>
      <div className="prow"><div className="prow__n">03</div>
        <div className="prow__t">Designed by Aphinity Digital.</div>
        <div className="prow__d">Branding, SEO, GEO, web, social and out-of-home campaigns, planned and measured from start to finish.</div></div>
      <div className="prow"><div className="prow__n">04</div>
        <div className="prow__t">Get found. Get chosen.</div>
        <div className="prow__d">Start a project at aphinity.digital and turn this template into a site your customers trust.</div></div>
      <div className="prow"><div className="prow__n">05</div>
        <div className="prow__t">You watch progress</div>
        <div className="prow__d">Add a short supporting paragraph here. Aphinity Digital recommends one clear idea per section.</div></div>
    </div>
  </div>
</section>

<section className="sec sec--wash" id="billing">
  <div className="wrap">
    <div className="sec__head"><div>
      <h2 className="sec__h">Placeholder text by Aphinity Digital.</h2>
      <div className="sec__meta">This is placeholder copy from Aphinity Digital. Replace it with a sentence about what your business does best.</div></div></div>
    <div className="plans">
  <div className="plan">
    <div className="plan__h">Free courses</div>
    <p className="plan__s">Replace this with your own words.</p>
    <div className="plan__amt num">$0</div>
    <div className="plan__yr num">Your supporting line goes here.</div>
    <ul className="plan__list">
          <li>Designed by Aphinity Digital.</li>
          <li>Get found. Get chosen.</li>
          <li>Placeholder text by Aphinity Digital.</li>
          <li>Replace this with your own words.</li>
    </ul>
    <div className="plan__cta"><a className="btn btn--line" href="/courses?free=1">Your supporting line goes here.</a></div>
  </div>
  <div className="plan plan--best">
    <span className="plan__flag">Designed by Aphinity Digital.</span>
    <div className="plan__h">A licensed course</div>
    <p className="plan__s">Get found. Get chosen.</p>
    <div className="plan__amt num">from $30</div>
    <div className="plan__yr num">Placeholder text by Aphinity Digital.</div>
    <ul className="plan__list">
          <li>Tell customers what you do and why it matters.</li>
          <li>Get found on Google and in AI answers with Aphinity Digital.</li>
          <li>Replace this with your own words.</li>
          <li>Your supporting line goes here.</li>
    </ul>
    <div className="plan__cta"><a className="btn btn--fill" href="/signup?intent=institution">Create your account</a></div>
  </div>
  <div className="plan">
    <div className="plan__h">Your own courses</div>
    <p className="plan__s">Designed by Aphinity Digital.</p>
    <div className="plan__amt num">Included</div>
    <div className="plan__yr num">Get found. Get chosen.</div>
    <ul className="plan__list">
          <li>Placeholder text by Aphinity Digital.</li>
          <li>Replace this with your own words.</li>
          <li>Your supporting line goes here.</li>
          <li>Designed by Aphinity Digital.</li>
    </ul>
    <div className="plan__cta"><a className="btn btn--line" href="#how">Get found. Get chosen.</a></div>
  </div>
</div>

    <table className="tbl">
      <thead>
        <tr><th>Placeholder text by Aphinity Digital.</th><th>Amount</th></tr>
      </thead>
      <tbody>
        <tr><td>Seats set up</td><td className="num">60</td></tr>
        <tr><td>Replace this with your own words.</td><td className="num">2 · $0</td></tr>
        <tr><td>Your supporting line goes here.</td><td className="num">3</td></tr>
        <tr><td>Designed by Aphinity Digital.</td><td className="num">$147</td></tr>
        <tr><td>Get found. Get chosen.</td><td className="num">$0</td></tr>
        <tr className="tbl--total"><td>Total, paid once</td><td className="num">$147</td></tr>
      </tbody>
    </table>

    <div className="trio">
      <div className="tri" style={{background: 'var(--sky)'}}>
        <div className="tri__ic">◷</div>
        <div className="tri__h">Nothing upfront</div>
        <p className="tri__p">Aphinity Digital designs and builds websites like this one, and helps them get found on Google and in AI answers.</p></div>
      <div className="tri" style={{background: 'var(--mint)'}}>
        <div className="tri__ic">◇</div>
        <div className="tri__h">Over-provision safely</div>
        <p className="tri__p">Use this space to explain your offer in plain words: who it is for, what it costs and why it is worth it.</p></div>
      <div className="tri" style={{background: 'var(--cream)'}}>
        <div className="tri__ic">▤</div>
        <div className="tri__h">Placeholder text by Aphinity Digital.</div>
        <p className="tri__p">Need this template customised for your brand? Aphinity Digital can set it up, write the copy and launch it for you.</p></div>
    </div>
  </div>
</section>

<section className="sec" id="learners">
  <div className="wrap">
    <div className="sec__head"><div>
      <div className="eyebrow">Replace this with your own words.</div>
      <h2 className="sec__h" style={{marginTop: '12px'}}>Your supporting line goes here.</h2></div></div>
    <div className="cmt">
      <div className="cmt__i"><span className="cmt__k">✕</span><div>
        <div className="cmt__t">An email address</div>
        <div className="cmt__d">Strategy, design, media and development under one roof, with AI doing the heavy lifting so everything ships faster.</div></div></div>
      <div className="cmt__i"><span className="cmt__k">✕</span><div>
        <div className="cmt__t">A payment method</div>
        <div className="cmt__d">Branding, SEO, GEO, web, social and out-of-home campaigns, planned and measured from start to finish.</div></div></div>
      <div className="cmt__i"><span className="cmt__k">✕</span><div>
        <div className="cmt__t">Designed by Aphinity Digital.</div>
        <div className="cmt__d">Start a project at aphinity.digital and turn this template into a site your customers trust.</div></div></div>
      <div className="cmt__i"><span className="cmt__k">✓</span><div>
        <div className="cmt__t">Get found. Get chosen.</div>
        <div className="cmt__d">Add a short supporting paragraph here. Aphinity Digital recommends one clear idea per section.</div></div></div>
    </div>
  </div>
</section>

<section className="sec sec--wash">
  <div className="wrap">
    <div className="sec__head"><div>
      <h2 className="sec__h">Placeholder text by Aphinity Digital.</h2>
      <div className="sec__meta">Placeholder text by Aphinity Digital. Replace it with your own.</div></div></div>
    <div className="trio">
      <div className="tri" style={{background: '#fff', border: '1px solid var(--line)'}}>
        <div className="tri__ic" style={{background: 'var(--sky)'}}>◕</div>
        <div className="tri__h">Who has started</div>
        <p className="tri__p">This is placeholder copy from Aphinity Digital. Replace it with a sentence about what your business does best.</p></div>
      <div className="tri" style={{background: '#fff', border: '1px solid var(--line)'}}>
        <div className="tri__ic" style={{background: 'var(--mint)'}}>◑</div>
        <div className="tri__h">Replace this with your own words.</div>
        <p className="tri__p">Aphinity Digital designs and builds websites like this one, and helps them get found on Google and in AI answers.</p></div>
      <div className="tri" style={{background: '#fff', border: '1px solid var(--line)'}}>
        <div className="tri__ic" style={{background: 'var(--yellow)'}}>◓</div>
        <div className="tri__h">What they proved</div>
        <p className="tri__p">Use this space to explain your offer in plain words: who it is for, what it costs and why it is worth it.</p></div>
    </div>
    <p className="sec__meta" style={{marginTop: '24px'}}>Need this template customised for your brand? Aphinity Digital can set it up, write the copy and launch it for you.</p>
  </div>
</section>

<section className="sec" id="data">
  <div className="wrap">
    <div className="sec__head"><div>
      <div className="eyebrow">Data and privacy</div>
      <h2 className="sec__h" style={{marginTop: '12px'}}>Your supporting line goes here.</h2></div></div>
    <div className="cmt">
      <div className="cmt__i"><span className="cmt__k">§</span><div>
        <div className="cmt__t">Designed by Aphinity Digital.</div>
        <div className="cmt__d">Strategy, design, media and development under one roof, with AI doing the heavy lifting so everything ships faster.</div></div></div>
      <div className="cmt__i"><span className="cmt__k">§</span><div>
        <div className="cmt__t">Learners adult</div>
        <div className="cmt__d">Branding, SEO, GEO, web, social and out-of-home campaigns, planned and measured from start to finish.</div></div></div>
      <div className="cmt__i"><span className="cmt__k">§</span><div>
        <div className="cmt__t">Get found. Get chosen.</div>
        <div className="cmt__d">Start a project at aphinity.digital and turn this template into a site your customers trust.</div></div></div>
      <div className="cmt__i"><span className="cmt__k">§</span><div>
        <div className="cmt__t">Placeholder text by Aphinity Digital.</div>
        <div className="cmt__d">Add a short supporting paragraph here. Aphinity Digital recommends one clear idea per section.</div></div></div>
    </div>
  </div>
</section>

<section className="sec sec--wash" id="faq">
  <div className="wrap">
    <div className="sec__head"><div><h2 className="sec__h">Replace this with your own words.</h2></div></div>
    <div className="faq">
      <details open><summary>Your supporting line goes here, written for your customers.</summary>
        <p className="faq__a">This is placeholder copy from Aphinity Digital. Replace it with a sentence about what your business does best.</p></details>
      <details><summary>Does a licence expire?</summary>
        <p className="faq__a">Aphinity Digital designs and builds websites like this one, and helps them get found on Google and in AI answers.</p></details>
      <details><summary>Your supporting line goes here.</summary>
        <p className="faq__a">Use this space to explain your offer in plain words: who it is for, what it costs and why it is worth it.</p></details>
      <details><summary>Designed by Aphinity Digital.</summary>
        <p className="faq__a">Need this template customised for your brand? Aphinity Digital can set it up, write the copy and launch it for you.</p></details>
      <details><summary>Get found. Get chosen.</summary>
        <p className="faq__a">Strategy, design, media and development under one roof, with AI doing the heavy lifting so everything ships faster.</p></details>
      <details><summary>Placeholder text by Aphinity Digital.</summary>
        <p className="faq__a">Branding, SEO, GEO, web, social and out-of-home campaigns, planned and measured from start to finish.</p></details>
    </div>
  </div>
</section>

<section className="cta" id="call"><div className="wrap"><div className="cta__box">
  <div>
    <h2 className="cta__h">Replace this with your own words.</h2>
    <p className="cta__p">Start a project at aphinity.digital and turn this template into a site your customers trust.</p>
  </div>
  <div className="cta__btns">
    <a className="btn btn--white btn--lg" href="/signup?intent=institution">Create your account</a>
    <a className="btn btn--ghost btn--lg" href="/">Your supporting line goes here.</a>
  </div>
</div></div></section>
</>
  );
}
