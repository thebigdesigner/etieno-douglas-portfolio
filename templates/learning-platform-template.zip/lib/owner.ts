import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";

/**
 * The owner console is guarded by two things, not one.
 *
 * A role column alone is a single point of failure: anyone who compromises an
 * operator account, or anyone with write access to the database, inherits the
 * lot. The allowlist lives in the environment, so taking someone's access away
 * is a deploy rather than an UPDATE.
 */
function allowlist(): string[] {
  return (process.env.OWNER_EMAILS ?? "")
    .split(",")
    .map((e) => e.trim().toLowerCase())
    .filter(Boolean);
}

/**
 * Is this address on the allowlist?
 *
 * Exported so the two gates can agree. requireOwner lets an allowlisted
 * address into the console; requireRole checked only profiles.role, so an
 * allowlisted owner whose role was not literally 'operator' could open the
 * console, click into a course, and be bounced to the learner dashboard with
 * no explanation.
 *
 * The allowlist stays the thing that grants — it lives in the environment, so
 * taking access away is a deploy rather than an UPDATE, and a compromised
 * database cannot hand anybody the console. This just stops the role column
 * from silently disagreeing with it.
 */
export function isOwnerEmail(email: string | null | undefined): boolean {
  const list = allowlist();
  if (list.length === 0 || !email) return false;
  return list.includes(email.toLowerCase());
}

export type Owner = { id: string; email: string; name: string | null };

export async function requireOwner(): Promise<Owner> {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login?next=/console");

  const email = (user.email ?? "").toLowerCase();
  const list = allowlist();

  // An empty allowlist locks everybody out rather than letting everybody in.
  if (list.length === 0 || !list.includes(email)) {
    redirect("/dashboard");
  }

  const admin = createAdminClient();
  const { data: profile } = await admin
    .from("profiles").select("display_name").eq("id", user.id).maybeSingle();

  return { id: user.id, email, name: profile?.display_name ?? null };
}

/** Every action taken on somebody else's account leaves a record. */
export async function auditLog(
  owner: Owner,
  action: string,
  subject: string | null,
  detail: Record<string, unknown> = {}
) {
  const admin = createAdminClient();
  await admin.rpc("admin_log", {
    p_actor: owner.id,
    p_actor_email: owner.email,
    p_action: action,
    p_subject: subject,
    p_detail: detail,
  });
}

export function money(cents: number | null | undefined): string {
  return `$${((cents ?? 0) / 100).toLocaleString("en-US", {
    minimumFractionDigits: 2, maximumFractionDigits: 2,
  })}`;
}
