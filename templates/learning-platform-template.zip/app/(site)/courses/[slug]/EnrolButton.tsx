"use client";
import { enrol } from "@/app/actions/learning";
import { useFormStatus } from "react-dom";

function Inner({ started, signedIn }: { started: boolean; signedIn: boolean }) {
  const { pending } = useFormStatus();
  const label = !signedIn ? "Start the free topic" : started ? "Continue learning" : "Start this course";
  return (
    <button className="btn btn--fill btn--lg enrol__btn" disabled={pending}>
      {pending ? "One moment…" : label}
    </button>
  );
}

export default function EnrolButton({
  slug, started, signedIn,
}: { slug: string; started: boolean; signedIn: boolean }) {
  return (
    <form action={enrol.bind(null, slug)}>
      <Inner started={started} signedIn={signedIn} />
    </form>
  );
}
