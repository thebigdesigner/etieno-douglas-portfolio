"use client";

import { useEffect, useRef, useState } from "react";

/**
 * On a phone the filter panel pushed every result below the fold: a full
 * screen of checkboxes before the first item. It now folds shut there and
 * this button opens it. Wider screens never see the button, and the
 * panel stays open, because it sits beside the grid instead of above it.
 */
export default function FilterToggle() {
  const ref = useRef<HTMLButtonElement>(null);
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const panel = ref.current?.closest(".mk-filters");
    if (!panel) return;
    if (open) panel.setAttribute("data-open", ""); else panel.removeAttribute("data-open");
  }, [open]);
  return (
    <button ref={ref} type="button" className="mk-filters__toggle" aria-expanded={open}
      onClick={() => setOpen((o) => !o)}>
      {open ? "Hide" : "Show"}
    </button>
  );
}
