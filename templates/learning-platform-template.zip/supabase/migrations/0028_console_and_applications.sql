-- =====================================================================
-- 0028 — reprise of 0010 and 0018, which are recorded as applied but
-- never landed.
--
-- Both aborted on a syntax error and the failure went unnoticed, so the
-- migration history says they ran while the database says otherwise
-- (to_regclass returns null for instructor_applications and every console
-- view). Editing those two files cannot help: the CLI will not re-run a
-- version it has already recorded. So their contents are repeated here,
-- with the two defects fixed:
--
--   0010  ee.type is the enum earning_type, and `like` has no operator for
--         it — Postgres rejects `earning_type ~~ unknown` outright. Cast to
--         text.
--   0018  `current_role` is a reserved word; an unquoted column by that
--         name is a syntax error. Renamed to current_work. Nothing in the
--         app referenced it, so this costs nothing.
--
-- Every statement is idempotent, because how much of each file landed
-- before it aborted depends on whether the runner wrapped it in a
-- transaction, and that is not knowable from here.
-- =====================================================================

-- ============ from 0010: owner console ============

create table if not exists admin_audit (
  id          bigserial primary key,
  actor_id    uuid references profiles(id) on delete set null,
  actor_email text not null,
  action      text not null,
  subject     text,                -- what was acted on
  detail      jsonb,
  created_at  timestamptz not null default now()
);

create index if not exists admin_audit_created on admin_audit (created_at desc);
create index if not exists admin_audit_actor on admin_audit (actor_id, created_at desc);

alter table admin_audit enable row level security;
-- Written and read through the service role only; no policy grants access.

-- ---------------------------------------------------------------------
-- Money. Kept as one view so the numbers on the console and the numbers
-- in a board pack cannot drift apart.
-- ---------------------------------------------------------------------
create or replace view public.revenue_summary as
with months as (
  select generate_series(
    date_trunc('month', now()) - interval '11 months',
    date_trunc('month', now()),
    interval '1 month'
  )::date as month
)
select m.month,
       coalesce((
         select sum(i.amount_cents) from invoices i
          where i.period_month = m.month and i.state in ('issued','paid')
       ), 0)                                                      as institutional_cents,
       coalesce((
         select count(*) from certificates c
          where date_trunc('month', c.issued_at)::date = m.month
       ), 0)                                                      as certificates_issued,
       coalesce((
         select sum(ee.amount_cents) from earnings_entries ee
          where date_trunc('month', ee.created_at)::date = m.month
       ), 0)                                                      as instructor_cost_cents,
       coalesce((
         select count(*) from profiles p
          where date_trunc('month', p.created_at)::date = m.month
            and p.status = 'active'
       ), 0)                                                      as signups
  from months m
 order by m.month desc;

-- What each instructor is owed and has been paid. The pool commitment says
-- instructors can audit this; so should we.
create or replace view public.instructor_ledger as
select i.id,
       p.display_name,
       p.email,
       i.state,
       i.reliability,
       coalesce(sum(ee.amount_cents) filter (where ee.type = 'review'), 0)  as review_cents,
       coalesce(sum(ee.amount_cents) filter (where ee.type::text like 'pool%'), 0) as pool_cents,
       coalesce(sum(ee.amount_cents), 0)                                    as accrued_cents,
       coalesce((
         select sum(pr.amount_cents) from payout_runs pr
          where pr.instructor_id = i.id and pr.state = 'paid'
       ), 0)                                                                as paid_cents,
       (select count(*) from courses c where c.instructor_id = i.id and c.state = 'published')
                                                                            as courses_live,
       (select count(*) from reviews r where r.reviewer_id = i.id)          as reviews_done,
       (select count(*) from reviews r where r.reviewer_id = i.id and not r.within_sla)
                                                                            as reviews_late
  from instructors i
  join profiles p on p.id = i.id
  left join earnings_entries ee on ee.instructor_id = i.id
 group by i.id, p.display_name, p.email, i.state, i.reliability;

-- Health of the thing the whole product rests on.
create or replace view public.review_health as
select count(*)                                                       as reviews_total,
       count(*) filter (where within_sla)                              as within_sla,
       round(100.0 * count(*) filter (where within_sla)
             / nullif(count(*), 0), 1)                                 as sla_pct,
       round(avg(extract(epoch from (r.completed_at - s.submitted_at)) / 3600)::numeric, 1)
                                                                       as avg_hours,
       count(*) filter (where r.outcome = 'pass')                      as passed,
       count(*) filter (where r.outcome = 'revise')                    as revised,
       (select count(*) from appeals)                                  as appeals,
       (select count(*) from appeals where outcome = 'pass')           as appeals_upheld
  from reviews r
  join submissions s on s.id = r.submission_id;

-- Catalogue health. A course nobody finishes is a content problem, not a
-- learner problem.
create or replace view public.course_health as
select c.slug,
       c.title,
       c.subject,
       c.state,
       c.is_free,
       p.display_name                                                as instructor,
       count(distinct e.id)                                          as enrolments,
       count(distinct e.id) filter (where e.state = 'certified')     as certified,
       round(100.0 * count(distinct e.id) filter (where e.state = 'certified')
             / nullif(count(distinct e.id), 0), 1)                    as completion_pct,
       (select count(*) from modules m join topics t on t.module_id = m.id
         where m.course_id = c.id)                                    as topics
  from courses c
  left join profiles p on p.id = c.instructor_id
  left join enrolments e on e.course_id = c.id
 group by c.slug, c.title, c.subject, c.state, c.is_free, p.display_name, c.id;

-- ---------------------------------------------------------------------
-- Support actions. Deliberately few: an owner console should be able to
-- unstick somebody, not reach into anything it likes.
-- ---------------------------------------------------------------------
create or replace function public.admin_set_role(
  p_user_id uuid, p_role user_role, p_actor uuid, p_actor_email text
)
returns boolean
language plpgsql security definer set search_path = public as $$
declare v_old user_role;
begin
  select role into v_old from profiles where id = p_user_id;
  if not found then return false; end if;

  update profiles set role = p_role where id = p_user_id;

  -- An operator needs an instructor row to hold a review queue.
  if p_role = 'instructor' and not exists (select 1 from instructors where id = p_user_id) then
    insert into instructors (id, state, onboarded_at) values (p_user_id, 'active', now());
  end if;

  insert into admin_audit (actor_id, actor_email, action, subject, detail)
  values (p_actor, p_actor_email, 'set_role', p_user_id::text,
          jsonb_build_object('from', v_old, 'to', p_role));
  return true;
end; $$;

create or replace function public.admin_grant_allowance(
  p_user_id uuid, p_extra int, p_reason text, p_actor uuid, p_actor_email text
)
returns boolean
language plpgsql security definer set search_path = public as $$
declare v_id uuid;
begin
  select id into v_id from cert_allowances
   where user_id = p_user_id and now() between period_start and period_end
   order by period_end desc limit 1;

  if v_id is null then
    insert into cert_allowances (user_id, period_start, period_end, included, purchased)
    values (p_user_id, now(), now() + interval '1 year', 0, p_extra);
  else
    update cert_allowances set purchased = purchased + p_extra where id = v_id;
  end if;

  insert into admin_audit (actor_id, actor_email, action, subject, detail)
  values (p_actor, p_actor_email, 'grant_allowance', p_user_id::text,
          jsonb_build_object('extra', p_extra, 'reason', p_reason));
  return true;
end; $$;

create or replace function public.admin_revoke_certificate(
  p_code text, p_reason text, p_actor uuid, p_actor_email text
)
returns boolean
language plpgsql security definer set search_path = public as $$
begin
  update certificates
     set revoked_at = now(), revoke_reason = p_reason
   where code = p_code and revoked_at is null;

  if not found then return false; end if;

  insert into admin_audit (actor_id, actor_email, action, subject, detail)
  values (p_actor, p_actor_email, 'revoke_certificate', p_code,
          jsonb_build_object('reason', p_reason));
  return true;
end; $$;

create or replace function public.admin_log(
  p_actor uuid, p_actor_email text, p_action text, p_subject text, p_detail jsonb
)
returns void
language sql security definer set search_path = public as $$
  insert into admin_audit (actor_id, actor_email, action, subject, detail)
  values (p_actor, p_actor_email, p_action, p_subject, p_detail);
$$;

revoke all on function public.admin_set_role(uuid, user_role, uuid, text) from public, anon, authenticated;
revoke all on function public.admin_grant_allowance(uuid, int, text, uuid, text) from public, anon, authenticated;
revoke all on function public.admin_revoke_certificate(text, text, uuid, text) from public, anon, authenticated;
revoke all on function public.admin_log(uuid, text, text, text, jsonb) from public, anon, authenticated;

-- ============ from 0018: instructor applications ============

do $ap$ begin
  if not exists (select 1 from pg_type where typname = 'application_state') then
    create type application_state as enum ('submitted','reviewing','approved','rejected','withdrawn');
  end if;
end $ap$;

create table if not exists instructor_applications (
  id                uuid primary key default gen_random_uuid(),
  full_name         text not null,
  email             text not null,
  country           text,
  -- Not "current_role": that is a reserved word in Postgres, and an
  -- unquoted column by that name is a syntax error — this whole migration
  -- failed on it, so the table has never existed.
  current_work      text not null,          -- what they do for a living now
  years_experience  int,
  linkedin_url      text,
  proposed_title    text not null,
  proposed_subject  text not null,
  proposed_segment  text not null,
  proposed_outline  text not null,
  sample_url        text,
  sample_note       text,
  review_capacity   int,                    -- projects they can assess per week
  accepts_sla       boolean not null default false,
  accepts_terms     boolean not null default false,
  state             application_state not null default 'submitted',
  reviewer_note     text,
  reviewed_by       uuid references profiles(id) on delete set null,
  reviewed_at       timestamptz,
  instructor_id     uuid references instructors(id) on delete set null,
  created_at        timestamptz not null default now()
);

create index if not exists instructor_applications_state on instructor_applications (state, created_at desc);
create unique index if not exists instructor_applications_open_email
  on instructor_applications (lower(email))
  where state in ('submitted','reviewing');

alter table instructor_applications enable row level security;
-- No public policies. Reads and writes happen through server code only.

-- ---------------------------------------------------------------------
-- Operator helpers
-- ---------------------------------------------------------------------
create or replace function public.is_operator(p_user uuid)
returns boolean
language sql
stable
security definer set search_path = public
as $$
  select exists (select 1 from profiles where id = p_user and role = 'operator');
$$;

comment on function public.is_operator is
  'Used by server code to gate the admin views. Grant the operator role in SQL, never through the UI.';
