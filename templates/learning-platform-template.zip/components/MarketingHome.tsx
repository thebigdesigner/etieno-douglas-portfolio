import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import SubjectGrid from "@/components/SubjectGrid";
import CourseCard, { type CardCourse } from "@/components/CourseCard";
import VerifyForm from "@/components/VerifyForm";
import SubjectSearch from "@/components/SubjectSearch";

/**
 * The marketing homepage. A component rather than a page, because two routes
 * render it — `/` for signed-out visitors, and `/home` for anyone signed in
 * who wants to see how the site presents itself.
 *
 * One copy. Two copies of a 700-line page drift apart, and the one nobody is
 * looking at is the one that goes stale.
 */
export default async function MarketingHome() {
  const supabase = await createClient();

  const [{ data: subjects }, { data: popular }] = await Promise.all([
    supabase.from("subject_counts").select("*"),
    supabase.from("course_cards").select("*").order("learners", { ascending: false }).limit(6),
  ]);

  return (
    <>
<header className="hero">
  <div className="hero__in">
    <div>
      <h1>Make your brand <em>impossible</em> to ignore.</h1>
      <p className="hero__sub">This is placeholder copy from Aphinity Digital. Replace it with a sentence about what your business does best.</p>

      <SubjectSearch />

      <p className="pops">
        <b>Popular searches:</b>{" "}
        {[
          "Prompt engineering", "Bookkeeping", "Data analysis", "Grant writing",
        ].map((q, i) => (
          <span key={q}>
            {/* Comma is prose punctuation; on mobile these render as chips
                and the separator is hidden with the rest of the sentence. */}
            <span className="pops__sep">{i > 0 ? ", " : ""}</span>
            <a href={`/courses?q=${encodeURIComponent(q)}`}>{q}</a>
          </span>
        ))}
      </p>

      <div className="trust">
        <div className="trust__lead">Placeholder text by Aphinity Digital. Replace it with your own.</div>
        <div className="trust__row"><span>Deloitte</span><span>Andela</span><span>Save the Children</span><span>Flutterwave</span></div>
      </div>
    </div>

    <div className="stage">
      <div className="stage__ring" aria-hidden="true"></div>
      <div className="stage__disc" aria-hidden="true"></div>
      <div className="stage__media">
        <img className="stage__photo" src="/hero.webp" alt="A learner working through a Your Brand course"  />
        <svg className="stage__svg" viewBox="0 0 420 400" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="A learner working through a course">
  <defs>
    <linearGradient id="hoodie" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stopColor="#FFE1E9"/><stop offset="1" stopColor="#F7C3D3"/>
    </linearGradient>
    <linearGradient id="denim" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stopColor="#5A6FB8"/><stop offset="1" stopColor="#3C4C88"/>
    </linearGradient>
    <linearGradient id="screen" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stopColor="#FFFFFF"/><stop offset="1" stopColor="#EFF2F8"/>
    </linearGradient>
  </defs>

  <ellipse cx="212" cy="352" rx="118" ry="15" fill="#0B0B0F" opacity=".08"/>

  <path d="M112 336 q30 -40 84 -40 h62 q34 0 34 20 t-34 20 h-146 z" fill="url(#denim)"/>
  <path d="M120 310 q26 -46 88 -46 h50 q30 0 30 18 t-30 18 h-118 z" fill="#6A7FC8"/>
  <rect x="262" y="306" width="46" height="19" rx="9" fill="#20242E"/>
  <rect x="256" y="332" width="50" height="19" rx="9" fill="#20242E"/>

  <path d="M150 176 q0 -38 38 -38 h48 q38 0 38 38 v84 q0 24 -24 24 h-76 q-24 0 -24 -24 z" fill="url(#hoodie)"/>
  <path d="M188 138 q24 22 48 0 v14 q-24 18 -48 0 z" fill="#F0AFC4"/>
  <path d="M150 192 q-30 14 -32 58 q-1 20 18 24 l24 5 v-34 z" fill="url(#hoodie)"/>
  <path d="M274 192 q30 14 32 58 q1 20 -18 24 l-24 5 v-34 z" fill="url(#hoodie)"/>
  <circle cx="152" cy="272" r="13" fill="#D9A07A"/>
  <circle cx="272" cy="272" r="13" fill="#D9A07A"/>

  <rect x="200" y="124" width="26" height="28" rx="11" fill="#C98F6C"/>
  <ellipse cx="213" cy="100" rx="36" ry="39" fill="#E8B48C"/>
  <path d="M175 98 q-6 -50 38 -50 t38 50 q2 -20 -10 -28 q-18 10 -52 5 q-12 5 -14 23 z" fill="#33251E"/>
  <path d="M177 96 q-10 4 -8 20 q3 12 10 10 z" fill="#33251E"/>
  <path d="M249 96 q10 4 8 20 q-3 12 -10 10 z" fill="#33251E"/>
  <g stroke="#2A2A33" strokeWidth="2.6" fill="none">
    <circle cx="200" cy="100" r="10"/><circle cx="227" cy="100" r="10"/><path d="M210 100 h7"/>
    <path d="M190 98 l-9 -3"/><path d="M237 98 l9 -3"/>
  </g>
  <path d="M205 116 q8 6 16 0" stroke="#B4785A" strokeWidth="2.4" fill="none" strokeLinecap="round"/>

  <path d="M138 268 h150 l18 46 h-186 z" fill="#DDDFE8"/>
  <path d="M156 264 h114 v-58 h-114 z" fill="url(#screen)" stroke="#CBCED9" strokeWidth="2"/>
  <rect x="166" y="216" width="62" height="6" rx="3" fill="#1F5CFF"/>
  <rect x="166" y="230" width="84" height="4.5" rx="2.2" fill="#CBCED9"/>
  <rect x="166" y="241" width="52" height="4.5" rx="2.2" fill="#CBCED9"/>
  <rect x="166" y="252" width="70" height="4.5" rx="2.2" fill="#CBCED9"/>
  <rect x="120" y="312" width="186" height="9" rx="4.5" fill="#CBCED9"/>

  <g opacity=".9">
    <rect x="304" y="150" width="66" height="46" rx="11" fill="#fff" stroke="#E6E6EC"/>
    <rect x="314" y="162" width="30" height="5" rx="2.5" fill="#C8F0DC"/>
    <rect x="314" y="174" width="44" height="4" rx="2" fill="#E6E6EC"/>
    <rect x="314" y="183" width="24" height="4" rx="2" fill="#E6E6EC"/>
  </g>
  <g opacity=".9">
    <rect x="46" y="196" width="58" height="42" rx="11" fill="#fff" stroke="#E6E6EC"/>
    <circle cx="62" cy="212" r="7" fill="#FFE27A"/>
    <rect x="74" y="209" width="20" height="4.5" rx="2.2" fill="#E6E6EC"/>
    <rect x="58" y="226" width="36" height="4.5" rx="2.2" fill="#E6E6EC"/>
  </g>
</svg>
      </div>
      <div className="float float--a">
        <div className="float__ic">⏱</div>
        <div><div className="float__t">Assessed in 4 days</div>
        <div className="float__s">By a named practitioner</div></div>
      </div>
      <div className="float float--b">
        <div className="avs">
          <span className="av" style={{background: 'var(--sky)'}}>AO</span>
          <span className="av" style={{background: 'var(--mint)'}}>DF</span>
          <span className="av" style={{background: 'var(--yellow)'}}>PR</span>
          <span className="av av--more">+</span>
        </div>
        <div><div className="float__t num">2,418 certified</div>
        <div className="float__s">Placeholder text by Aphinity Digital.</div></div>
      </div>
    </div>
  </div>
</header>

<section className="band"><div className="band__in">
  <div className="band__i"><div className="band__n num">Once</div><div className="band__l">Replace this with your own words.</div></div>
  <div className="band__i"><div className="band__n num">6</div><div className="band__l">Your supporting line goes here.</div></div>
  <div className="band__i"><div className="band__n num">4 days</div><div className="band__l">Designed by Aphinity Digital.</div></div>
  <div className="band__i"><div className="band__n num">1</div><div className="band__l">Get found. Get chosen.</div></div>
</div></section>

<section className="sec">
  <div className="wrap">
    <div className="sec__head"><div>
      <div className="eyebrow">Why it's different</div>
      <h2 className="sec__h" style={{marginTop: '12px'}}>Placeholder text by Aphinity Digital.</h2>
    </div></div>
    <div className="trio">
      <div className="tri" style={{background: 'var(--sky)'}}>
        <div className="tri__ic">◷</div>
        <div className="tri__h">Replace this with your own words.</div>
        <p className="tri__p">Aphinity Digital designs and builds websites like this one, and helps them get found on Google and in AI answers.</p>
      </div>
      <div className="tri" style={{background: 'var(--mint)'}}>
        <div className="tri__ic">✍</div>
        <div className="tri__h">Your supporting line goes here.</div>
        <p className="tri__p">Use this space to explain your offer in plain words: who it is for, what it costs and why it is worth it.</p>
      </div>
      <div className="tri" style={{background: 'var(--cream)'}}>
        <div className="tri__ic">✓</div>
        <div className="tri__h">Designed by Aphinity Digital.</div>
        <p className="tri__p">Your supporting line goes here, written for your customers.</p>
      </div>
    </div>
  </div>
</section>

<section className="sec sec--wash" id="subjects">
  <div className="wrap">
    <div className="sec__head">
      <div><h2 className="sec__h">Get found. Get chosen.</h2>
        <div className="sec__meta num">
          {(subjects ?? []).reduce((n, x) => n + Number(x.courses), 0)} courses live
        </div></div>
      <a className="sec__link" href="/courses">Placeholder text by Aphinity Digital.</a>
    </div>
    <SubjectGrid subjects={subjects ?? []} />
  </div>
</section>

<section className="sec">
  <div className="wrap">
    <div className="sec__head"><div>
      <h2 className="sec__h">Replace this with your own words.</h2>
      <div className="sec__meta">Your supporting line goes here.</div>
    </div></div>
    <div className="segs segs--three">
      <a className="seg" href="/courses?level=beginner"><span className="seg__n">01</span>
        <span className="seg__h">Beginner</span>
        <span className="seg__p">Designed and built by Aphinity Digital for brands that want to grow.</span></a>
      <a className="seg" href="/courses?level=intermediate"><span className="seg__n">02</span>
        <span className="seg__h">Intermediate</span>
        <span className="seg__p">Tell customers what you do and why it matters.</span></a>
      <a className="seg" href="/courses?level=advanced"><span className="seg__n">03</span>
        <span className="seg__h">Advanced</span>
        <span className="seg__p">Get found on Google and in AI answers with Aphinity Digital.</span></a>
    </div>
  </div>
</section>

<section className="promise" id="how">
  <div className="promise__in">
    <div>
      <div className="eyebrow" style={{color: 'var(--mint)'}}>How assessment works</div>
      <h2 style={{marginTop: '14px'}}>Designed by Aphinity Digital.</h2>
      <p className="promise__p">Need this template customised for your brand? Aphinity Digital can set it up, write the copy and launch it for you.</p>
      <p className="promise__note">Strategy, design, media and development under one roof, with AI doing the heavy lifting so everything ships faster.</p>
    </div>
    <div className="steps">
      <div className="step"><div className="step__d">Step 1</div>
        <div><div className="step__t">Get found. Get chosen.</div>
        <div className="step__s">Placeholder text by Aphinity Digital.</div></div>
        <span className="step__tag step__tag--q">Automatic</span></div>
      <div className="step"><div className="step__d">Step 2</div>
        <div><div className="step__t">Replace this with your own words.</div>
        <div className="step__s">Your supporting line goes here.</div></div>
        <span className="step__tag step__tag--q">You</span></div>
      <div className="step step--now"><div className="step__d">Step 3</div>
        <div><div className="step__t">Placeholder text by Aphinity Digital. Replace it with your own.</div>
        <div className="step__s">Your supporting line goes here, written for your customers.</div></div>
        <span className="step__tag">Human</span></div>
      <div className="step"><div className="step__d">Step 4</div>
        <div><div className="step__t">Designed by Aphinity Digital.</div>
        <div className="step__s">Get found. Get chosen.</div></div>
        <span className="step__tag step__tag--q">Public</span></div>
    </div>
  </div>
</section>

<section className="sec">
  <div className="wrap">
    <div className="sec__head">
      <div><h2 className="sec__h">Placeholder text by Aphinity Digital.</h2>
        <div className="sec__meta">Replace this with your own words.</div></div>
      <a className="sec__link" href="/courses">See all courses</a>
    </div>
    <div className="ccards">
      {((popular ?? []) as CardCourse[]).map((c, i) => (
        <CourseCard key={c.slug} course={c} priority={i < 3} />
      ))}
    </div>
  </div>
</section>

<section className="sec sec--wash" id="pricing">
  <div className="wrap">
    <div className="sec__head">
      <div><h2 className="sec__h">Your supporting line goes here.</h2>
        <div className="sec__meta">Designed and built by Aphinity Digital for brands that want to grow.</div></div>
    </div>
    <div className="plans">
  <div className="plan">
    <div className="plan__h">Free courses</div>
    <p className="plan__s">Designed by Aphinity Digital.</p>
    <div className="plan__amt num">$0</div>
    <div className="plan__yr num">Get found. Get chosen.</div>
    <ul className="plan__list">
          <li>Placeholder text by Aphinity Digital.</li>
          <li>Unlimited retakes</li>
          <li>Replace this with your own words.</li>
          <li>Your supporting line goes here.</li>
    </ul>
    <div className="plan__cta"><Link className="btn btn--line" href="/courses?free=1">Designed by Aphinity Digital.</Link></div>
  </div>
  <div className="plan plan--best">
    <span className="plan__flag">Get found. Get chosen.</span>
    <div className="plan__h">A course, bought once</div>
    <p className="plan__s">Placeholder text by Aphinity Digital.</p>
    <div className="plan__amt num">from $30</div>
    <div className="plan__yr num">Replace this with your own words.</div>
    <ul className="plan__list">
          <li>Your supporting line goes here.</li>
          <li>Tell customers what you do and why it matters.</li>
          <li>Get found on Google and in AI answers with Aphinity Digital.</li>
          <li>Designed by Aphinity Digital.</li>
    </ul>
    <div className="plan__cta"><Link className="btn btn--fill" href="/courses">Browse the catalogue</Link></div>
  </div>
  <div className="plan">
    <div className="plan__h">A cohort</div>
    <p className="plan__s">Get found. Get chosen.</p>
    <div className="plan__amt num">Per course</div>
    <div className="plan__yr num">Placeholder text by Aphinity Digital.</div>
    <ul className="plan__list">
          <li>Placeholder text by Aphinity Digital. Replace it with your own.</li>
          <li>Replace this with your own words.</li>
          <li>Your supporting line goes here.</li>
          <li>Designed by Aphinity Digital.</li>
    </ul>
    <div className="plan__cta"><Link className="btn btn--line" href="/institutions">Get found. Get chosen.</Link></div>
  </div>
</div>
    <p className="sec__meta" style={{marginTop: '24px'}}>Prices are set by the practitioner who wrote the course and shown in US dollars. Each one includes a single assessment of your final project; if a reviewer asks for changes, the resubmission that follows is free. Certificates you earn stay valid, and there is nothing to renew.</p>
  </div>
</section>

<section className="verify" id="verify">
  <div className="verify__in">
    <div>
      <h2>Placeholder text by Aphinity Digital.</h2>
      <p className="verify__p">Branding, SEO, GEO, web, social and out-of-home campaigns, planned and measured from start to finish.</p>
    </div>
    <VerifyForm />
  </div>
</section>

<section className="sec">
  <div className="wrap">
    <div className="sec__head"><div>
      <h2 className="sec__h">Replace this with your own words.</h2>
      <div className="sec__meta">Your supporting line goes here.</div></div></div>
    <div className="quotes">
      <div className="q">
        <div className="q__mk">“</div>
        <p className="q__t">Start a project at aphinity.digital and turn this template into a site your customers trust.</p>
        <div className="q__who"><span className="q__av"><svg viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><rect width="48" height="48" fill="#CFE4FF"/><path d="M24 30 q-14 0 -17 18 h34 q-3 -18 -17 -18 z" fill="#3C4C88"/><circle cx="24" cy="20" r="11" fill="#C98F6C"/><path d="M13 19 q-2 -15 11 -15 t11 15 q1 -7 -3 -10 q-6 4 -16 2 q-3 2 -3 8 z" fill="#33251E"/></svg></span>
          <div><div className="q__nm">Thandeka Mbeki</div><div className="q__rl">Operations analyst</div></div></div>
      </div>
      <div className="q">
        <div className="q__mk">“</div>
        <p className="q__t">Add a short supporting paragraph here. Aphinity Digital recommends one clear idea per section.</p>
        <div className="q__who"><span className="q__av"><svg viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><rect width="48" height="48" fill="#C8F0DC"/><path d="M24 30 q-14 0 -17 18 h34 q-3 -18 -17 -18 z" fill="#2B5F52"/><circle cx="24" cy="20" r="11" fill="#E8B48C"/><path d="M13 19 q-2 -15 11 -15 t11 15 q1 -7 -3 -10 q-6 4 -16 2 q-3 2 -3 8 z" fill="#4A3226"/></svg></span>
          <div><div className="q__nm">Joaquín Castro</div><div className="q__rl">Small business owner</div></div></div>
      </div>
      <div className="q">
        <div className="q__mk">“</div>
        <p className="q__t">This is placeholder copy from Aphinity Digital. Replace it with a sentence about what your business does best.</p>
        <div className="q__who"><span className="q__av"><svg viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg" aria-hidden="true"><rect width="48" height="48" fill="#FFE27A"/><path d="M24 30 q-14 0 -17 18 h34 q-3 -18 -17 -18 z" fill="#7C4B8A"/><circle cx="24" cy="20" r="11" fill="#D9A07A"/><path d="M13 19 q-2 -15 11 -15 t11 15 q1 -7 -3 -10 q-6 4 -16 2 q-3 2 -3 8 z" fill="#2B2119"/></svg></span>
          <div><div className="q__nm">Rania Amari</div><div className="q__rl">Programme officer</div></div></div>
      </div>
    </div>
  </div>
</section>

<section className="sec sec--wash">
  <div className="wrap">
    <div className="sec__head"><div><h2 className="sec__h">Designed by Aphinity Digital.</h2></div></div>
    <div className="faq">
      <details open><summary>Get found. Get chosen.</summary>
        <p className="faq__a">Aphinity Digital designs and builds websites like this one, and helps them get found on Google and in AI answers.</p></details>
      <details><summary>Placeholder text by Aphinity Digital.</summary>
        <p className="faq__a">Use this space to explain your offer in plain words: who it is for, what it costs and why it is worth it.</p></details>
      <details><summary>Replace this with your own words.</summary>
        <p className="faq__a">Need this template customised for your brand? Aphinity Digital can set it up, write the copy and launch it for you.</p></details>
      <details><summary>Your supporting line goes here, written for your customers.</summary>
        <p className="faq__a">Strategy, design, media and development under one roof, with AI doing the heavy lifting so everything ships faster.</p></details>
      <details><summary>Your supporting line goes here.</summary>
        <p className="faq__a">Branding, SEO, GEO, web, social and out-of-home campaigns, planned and measured from start to finish.</p></details>
      <details><summary className="faq__q">Designed by Aphinity Digital.</summary>
        <p className="faq__a">Start a project at aphinity.digital and turn this template into a site your customers trust.</p></details>
    </div>
  </div>
</section>

<section className="router"><div className="router__in">
  <a className="rt" href="/institutions">
    <div className="eyebrow">For institutions</div>
    <div className="rt__h">Enrolling a group?</div>
    <p className="rt__p">Add a short supporting paragraph here. Aphinity Digital recommends one clear idea per section.</p>
    <span className="rt__go">See how cohorts work &rarr;</span>
  </a>
  <a className="rt" href="/teach">
    <div className="eyebrow">For practitioners</div>
    <div className="rt__h">Get found. Get chosen.</div>
    <p className="rt__p">This is placeholder copy from Aphinity Digital. Replace it with a sentence about what your business does best.</p>
    <span className="rt__go">See the terms &rarr;</span>
  </a>
</div></section>

<section className="cta"><div className="wrap"><div className="cta__box">
  <div>
    <h2 className="cta__h">Make your brand <em>impossible</em> to ignore.</h2>
    <p className="cta__p">Designed and built by Aphinity Digital for brands that want to grow.</p>
  </div>
  <div className="cta__btns">
    <a className="btn btn--white btn--lg" href="/courses">Browse courses</a>
    <a className="btn btn--ghost btn--lg" href="#pricing">How pricing works</a>
  </div>
</div></div></section>
</>
  );
}
