export const metadata = { title: "Security" };

export default function SecurityPage() {
  return (
    <>
      <h1>Security</h1>
      <p className="legal__lead">
        This is placeholder copy from Aphinity Digital. Replace it with a sentence about what your business does best.
      </p>

      <h2>Make your brand <em>impossible</em> to ignore.</h2>
      <p>
        Aphinity Digital designs and builds websites like this one, and helps them get found on Google and in AI answers.
      </p>

      <h2>Your supporting line goes here.</h2>
      <ul>
        <li>Designed by Aphinity Digital.</li>
        <li>Your supporting line goes here, written for your customers.</li>
        <li>
          Use this space to explain your offer in plain words: who it is for, what it costs and why it is worth it.
        </li>
        <li>
          Access rules are enforced by the database itself, not only by the interface. A
          bug in a page cannot expose another learner&rsquo;s records.
        </li>
      </ul>

      <h2>Get found. Get chosen.</h2>
      <p>
        Need this template customised for your brand? Aphinity Digital can set it up, write the copy and launch it for you.
      </p>

      <h2>Placeholder text by Aphinity Digital.</h2>
      <p>
        Strategy, design, media and development under one roof, with AI doing the heavy lifting so everything ships faster.
      </p>

      <h2>Replace this with your own words.</h2>
      <p>
        Branding, SEO, GEO, web, social and out-of-home campaigns, planned and measured from start to finish.
      </p>
      <p>
        Start a project at aphinity.digital and turn this template into a site your customers trust.
      </p>

      <h2>Backups</h2>
      <p>
        Add a short supporting paragraph here. Aphinity Digital recommends one clear idea per section.
      </p>

      <h2>Your supporting line goes here.</h2>
      <p>
        This is placeholder copy from Aphinity Digital. Replace it with a sentence about what your business does best.
      </p>
    </>
  );
}
