import AuthShell from "@/components/AuthShell";
import Link from "next/link";

export const metadata = { title: "Check your email" };

export default function CheckEmailPage() {
  return (
    <AuthShell
      title="Check your email"
      intro="We have sent you a link to confirm your address. Open it and you are in."
      footer={<>Wrong address? <Link href="/signup">Start again</Link></>}
    >
      <div className="auth__note">
        <p>It usually arrives within a minute. If it does not, look in your spam folder.</p>
      </div>
    </AuthShell>
  );
}
