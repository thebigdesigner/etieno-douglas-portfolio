-- =====================================================================
-- Your Brand Academy — initial schema
-- Postgres / Supabase. Run with: supabase db push
-- =====================================================================

create extension if not exists "pgcrypto";

-- ---------------------------------------------------------------- enums
create type account_type   as enum ('adult','teen','child','institution_minor');
create type user_role       as enum ('learner','instructor','institution_admin','operator');
create type consent_state   as enum ('pending','confirmed','withdrawn','expired');
create type course_state    as enum ('draft','in_review','revision_requested','published','unpublished');
create type instructor_state as enum ('applied','rejected','approved','active','paused','suspended');
create type enrolment_source as enum ('individual','cohort');
create type enrolment_state as enum ('not_started','in_progress','topics_complete','submitted','certified','lapsed');
create type submission_state as enum ('submitted','assigned','in_review','revision_requested','passed','abandoned');
create type review_outcome  as enum ('pass','revise');
create type cohort_state    as enum ('draft','active','ended','archived');
create type invoice_state   as enum ('projected','issued','paid','overdue');
create type plan_tier       as enum ('starter','plus','complete');
create type revenue_source  as enum ('individual','institution');
create type earning_type    as enum ('review','pool_individual','pool_institution','referral','adjustment');
create type payout_state    as enum ('accrued','below_threshold','scheduled','paid','failed');

-- ---------------------------------------------------------------- people
-- Supabase manages auth.users. This extends it.
create table profiles (
  id              uuid primary key references auth.users(id) on delete cascade,
  role            user_role    not null default 'learner',
  display_name    text,
  date_of_birth   date,
  account_type    account_type not null default 'adult',
  segment         text,                       -- chosen audience segment
  guardian_email  text,                       -- teen / child only
  marketing_opt_in boolean not null default false,
  created_at      timestamptz not null default now()
);
comment on column profiles.display_name is 'Confirmed before certificate issuance, not at signup.';

-- Age gate outcome is persisted before the account exists, keyed by device.
create table age_checks (
  id            uuid primary key default gen_random_uuid(),
  device_token  text not null,
  date_of_birth date not null,
  derived_type  account_type not null,
  created_at    timestamptz not null default now()
);
create index on age_checks (device_token);

create table parental_consents (
  id              uuid primary key default gen_random_uuid(),
  learner_id      uuid not null references profiles(id) on delete cascade,
  guardian_email  text not null,
  token           text not null unique,
  consent_version text not null,              -- versioned, never a boolean
  state           consent_state not null default 'pending',
  requested_at    timestamptz not null default now(),
  confirmed_at    timestamptz,
  confirmed_ip    inet,
  withdrawn_at    timestamptz,
  expires_at      timestamptz not null default (now() + interval '14 days')
);
create index on parental_consents (learner_id);

create table instructors (
  id             uuid primary key references profiles(id) on delete cascade,
  state          instructor_state not null default 'applied',
  headline       text,
  bio            text,
  accepts_reviews boolean not null default true,
  available      boolean not null default true,
  concurrent_cap int,                          -- null = uncapped
  reliability    numeric(5,2),                  -- % of reviews inside SLA
  applied_at     timestamptz not null default now(),
  approved_at    timestamptz
);

-- ---------------------------------------------------------- institutions
create table institutions (
  id            uuid primary key default gen_random_uuid(),
  name          text not null,
  contact_email text not null,
  plan          plan_tier not null default 'plus',
  dpa_signed_at timestamptz,
  created_at    timestamptz not null default now()
);

create table institution_members (
  institution_id uuid references institutions(id) on delete cascade,
  user_id        uuid references profiles(id) on delete cascade,
  primary key (institution_id, user_id)
);

create table cohorts (
  id             uuid primary key default gen_random_uuid(),
  institution_id uuid not null references institutions(id) on delete cascade,
  name           text not null,
  class_code     text not null unique,
  plan           plan_tier not null,
  seat_ceiling   int not null check (seat_ceiling > 0),
  starts_on      date not null,
  ends_on        date not null,
  state          cohort_state not null default 'draft',
  created_at     timestamptz not null default now()
);

-- One row per seat. Only an issued username can join — this closes the
-- shared-code leak structurally rather than by policy.
create table cohort_seats (
  id         uuid primary key default gen_random_uuid(),
  cohort_id  uuid not null references cohorts(id) on delete cascade,
  username   text not null,
  pin_hash   text,
  user_id    uuid references profiles(id) on delete set null,
  claimed_at timestamptz,
  unique (cohort_id, username)
);

create table cohort_courses (
  cohort_id uuid references cohorts(id) on delete cascade,
  course_id uuid not null,
  primary key (cohort_id, course_id)
);

-- --------------------------------------------------------------- courses
create table courses (
  id            uuid primary key default gen_random_uuid(),
  instructor_id uuid references instructors(id) on delete restrict,
  slug          text not null unique,
  title         text not null,
  summary       text,
  subject       text not null,     -- AI, Entrepreneurship, Technology, Business Skills, Creative, Career
  segment       text not null,     -- High School, University, Digital Skills, Career Growth, Business Owners
  project_brief text,
  state         course_state not null default 'draft',
  published_at  timestamptz,
  created_at    timestamptz not null default now()
);
create index on courses (subject, segment) where state = 'published';

create table modules (
  id        uuid primary key default gen_random_uuid(),
  course_id uuid not null references courses(id) on delete cascade,
  position  int  not null,
  title     text not null,
  unique (course_id, position)
);

create table topics (
  id            uuid primary key default gen_random_uuid(),
  module_id     uuid not null references modules(id) on delete cascade,
  position      int  not null,
  title         text not null,
  body          text,
  video_uid     text,             -- provider asset id (Bunny / Mux / Stream)
  video_ready   boolean not null default false,
  duration_secs int,
  is_free       boolean not null default false,   -- first topic of a course
  unique (module_id, position)
);

create table quiz_items (
  id          uuid primary key default gen_random_uuid(),
  topic_id    uuid not null references topics(id) on delete cascade,
  prompt      text not null,
  options     jsonb not null,     -- [{id, text}]
  correct     jsonb not null,     -- [option ids]
  explanation text
);

create table rubric_criteria (
  id          uuid primary key default gen_random_uuid(),
  course_id   uuid not null references courses(id) on delete cascade,
  position    int  not null,
  title       text not null,
  descriptor  text not null,
  max_score   int  not null default 5,
  unique (course_id, position)
);

-- -------------------------------------------------------------- learning
create table enrolments (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references profiles(id) on delete cascade,
  course_id  uuid not null references courses(id) on delete cascade,
  source     enrolment_source not null default 'individual',
  cohort_id  uuid references cohorts(id) on delete set null,
  state      enrolment_state not null default 'not_started',
  created_at timestamptz not null default now(),
  unique (user_id, course_id)
);

-- The unit the royalty pool divides by. revenue_source is recorded at
-- completion time; reconstructing it later is not reliably possible.
create table topic_completions (
  id             uuid primary key default gen_random_uuid(),
  enrolment_id   uuid not null references enrolments(id) on delete cascade,
  topic_id       uuid not null references topics(id) on delete cascade,
  revenue_source revenue_source not null,
  completed_at   timestamptz not null default now(),
  unique (enrolment_id, topic_id)
);
create index on topic_completions (completed_at, revenue_source);

create table quiz_attempts (
  id           uuid primary key default gen_random_uuid(),
  enrolment_id uuid not null references enrolments(id) on delete cascade,
  topic_id     uuid not null references topics(id) on delete cascade,
  score_pct    numeric(5,2) not null,
  passed       boolean not null,
  answers      jsonb,
  attempted_at timestamptz not null default now()
);
create index on quiz_attempts (enrolment_id, topic_id);

-- ---------------------------------------------------------------- review
-- Working days are counted on one published calendar so the four-day
-- promise means the same thing in every country.
create table business_holidays (
  day    date primary key,
  label  text
);

create table submissions (
  id                  uuid primary key default gen_random_uuid(),
  enrolment_id        uuid not null references enrolments(id) on delete cascade,
  attempt_no          int  not null default 1,
  state               submission_state not null default 'submitted',
  body                text,
  file_paths          text[],
  assigned_reviewer_id uuid references instructors(id) on delete set null,
  submitted_at        timestamptz not null default now(),
  deadline_at         timestamptz not null,
  escalated_at        timestamptz,
  reassigned_at       timestamptz,
  consumed_allowance  boolean not null default true  -- free resubmission = false
);
create index on submissions (state, deadline_at);

create table reviews (
  id            uuid primary key default gen_random_uuid(),
  submission_id uuid not null references submissions(id) on delete cascade,
  reviewer_id   uuid not null references instructors(id) on delete restrict,
  outcome       review_outcome not null,
  feedback      text not null,
  scores        jsonb,             -- {criterion_id: score}
  within_sla    boolean not null,
  completed_at  timestamptz not null default now()
);

create table appeals (
  id             uuid primary key default gen_random_uuid(),
  submission_id  uuid not null references submissions(id) on delete cascade,
  grounds        text not null,
  second_reviewer_id uuid references instructors(id) on delete set null,
  outcome        review_outcome,
  resolved_at    timestamptz,
  created_at     timestamptz not null default now(),
  unique (submission_id)            -- one appeal per submission
);

create table certificates (
  id            uuid primary key default gen_random_uuid(),
  enrolment_id  uuid not null references enrolments(id) on delete cascade,
  code          text not null unique,
  reviewer_name text not null,
  show_name     boolean not null default true,   -- false for under-18s
  issued_at     timestamptz not null default now(),
  revoked_at    timestamptz,
  revoke_reason text
);

-- --------------------------------------------------------------- billing
create table subscriptions (
  id                   uuid primary key default gen_random_uuid(),
  user_id              uuid not null references profiles(id) on delete cascade,
  plan                 plan_tier not null,
  provider             text not null,          -- paddle | lemonsqueezy
  provider_ref         text not null,
  status               text not null,          -- active | past_due | cancelled
  current_period_start timestamptz not null,
  current_period_end   timestamptz not null,
  cancelled_at         timestamptz
);
create index on subscriptions (user_id, status);

-- Certification allowance: 1 / 3 / 5 per year, resets on renewal, no rollover.
create table cert_allowances (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null references profiles(id) on delete cascade,
  period_start timestamptz not null,
  period_end   timestamptz not null,
  included     int not null,
  used         int not null default 0,
  purchased    int not null default 0,     -- extras bought at $14 on Complete
  check (used >= 0)
);
create index on cert_allowances (user_id, period_end);

create table invoices (
  id             uuid primary key default gen_random_uuid(),
  institution_id uuid not null references institutions(id) on delete cascade,
  period_month   date not null,             -- first of month
  active_count   int  not null,
  seats_unused   int  not null,
  unit_cents     int  not null,
  amount_cents   int  not null,
  state          invoice_state not null default 'projected',
  issued_at      timestamptz,
  paid_at        timestamptz,
  unique (institution_id, period_month)
);

-- --------------------------------------------------------------- payouts
create table pool_periods (
  id              uuid primary key default gen_random_uuid(),
  period_month    date not null,
  source          revenue_source not null,
  revenue_cents   bigint not null,
  pool_rate       numeric(5,4) not null,     -- 0.35 individual, 0.30 institution
  pool_cents      bigint not null,
  completions     int    not null,
  rate_per_completion_cents numeric(12,4) not null,
  calculated_at   timestamptz not null default now(),
  unique (period_month, source)
);

create table earnings_entries (
  id            uuid primary key default gen_random_uuid(),
  instructor_id uuid not null references instructors(id) on delete cascade,
  type          earning_type not null,
  amount_cents  int not null,
  ref_id        uuid,                        -- review id, pool period id
  note          text,
  created_at    timestamptz not null default now()
);
create index on earnings_entries (instructor_id, created_at);

create table payout_runs (
  id            uuid primary key default gen_random_uuid(),
  week_start    date not null,
  instructor_id uuid not null references instructors(id) on delete cascade,
  amount_cents  int not null,
  state         payout_state not null default 'accrued',
  paid_at       timestamptz,
  unique (week_start, instructor_id)
);

-- --------------------------------------------------------------- tracking
create table events (
  id         bigserial primary key,
  user_id    uuid references profiles(id) on delete set null,
  name       text not null,
  props      jsonb,
  created_at timestamptz not null default now()
);
create index on events (name, created_at);

-- ------------------------------------------------------------------- RLS
-- Enable on everything; policies are added per feature as it is built.
alter table profiles            enable row level security;
alter table parental_consents   enable row level security;
alter table instructors         enable row level security;
alter table institutions        enable row level security;
alter table institution_members enable row level security;
alter table cohorts             enable row level security;
alter table cohort_seats        enable row level security;
alter table enrolments          enable row level security;
alter table topic_completions   enable row level security;
alter table quiz_attempts       enable row level security;
alter table submissions         enable row level security;
alter table reviews             enable row level security;
alter table appeals             enable row level security;
alter table certificates        enable row level security;
alter table subscriptions       enable row level security;
alter table cert_allowances     enable row level security;
alter table invoices            enable row level security;
alter table earnings_entries    enable row level security;
alter table payout_runs         enable row level security;

-- A learner reads and writes only their own rows.
create policy own_profile on profiles
  for all using (auth.uid() = id) with check (auth.uid() = id);

create policy own_enrolments on enrolments
  for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create policy own_subscriptions on subscriptions
  for select using (auth.uid() = user_id);

create policy own_allowances on cert_allowances
  for select using (auth.uid() = user_id);

-- Published course content is world-readable; drafts are not.
alter table courses enable row level security;
create policy public_courses on courses
  for select using (state = 'published');

-- Certificates are looked up by code on a public page, so reads are open.
-- The page itself decides whether to display the learner's name.
create policy public_certificate_lookup on certificates
  for select using (true);
