/**
 * Share the sign-in between yourbrand.com and marketplace.yourbrand.com.
 *
 * Supabase sets its auth cookie on the exact host by default, so someone
 * signed in on the Academy arrives at the marketplace signed out. Setting
 * NEXT_PUBLIC_COOKIE_DOMAIN=.yourbrand.com widens the cookie to every
 * subdomain. Left unset (localhost, previews) nothing changes.
 *
 * Sessions made before the change stay host-only; those people sign in
 * once more and the new cookie covers both sites from then on.
 */
export function cookieOptions(): { domain: string } | undefined {
  const d = process.env.NEXT_PUBLIC_COOKIE_DOMAIN;
  return d ? { domain: d } : undefined;
}
