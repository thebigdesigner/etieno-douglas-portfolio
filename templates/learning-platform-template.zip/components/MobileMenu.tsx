"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { NAV } from "@/lib/nav";

const SIGNUP_PATHS = [
  { href: "/signup", label: "Sign up to learn" },
  { href: "/signup?intent=instructor", label: "Sign up to teach" },
  { href: "/signup?intent=institution", label: "Set up an organisation" },
];

export default function MobileMenu() {
  const pathname = usePathname();

  // The relevant one first, rather than assuming everybody is a learner.
  const ordered = pathname.startsWith("/teach")
    ? [SIGNUP_PATHS[1], SIGNUP_PATHS[0], SIGNUP_PATHS[2]]
    : pathname.startsWith("/institutions")
      ? [SIGNUP_PATHS[2], SIGNUP_PATHS[0], SIGNUP_PATHS[1]]
      : SIGNUP_PATHS;

  return (
    <details className="navm">
      <summary aria-label="Menu"><span /><span /><span /></summary>
      <div className="navm__panel">
        {NAV.map((item) => (
          <Link key={item.href} href={item.href}>{item.label}</Link>
        ))}
        <div className="navm__sep" />
        {ordered.map((s) => (
          <Link key={s.href} href={s.href}>{s.label}</Link>
        ))}
        <div className="navm__sep" />
        <Link href="/login">Log in</Link>
        <Link href="/dashboard">Dashboard</Link>
      </div>
    </details>
  );
}
