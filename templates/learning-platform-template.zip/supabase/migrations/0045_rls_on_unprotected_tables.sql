-- =====================================================================
-- 0045 — eight tables were never given row level security
--
-- In Supabase, a table in the public schema without RLS is not private
-- by default — it is served through PostgREST to anyone holding the
-- anon key, which every visitor's browser is given. Enabling RLS with
-- no policy is what makes a table server-side only, and these eight
-- never had it:
--
--   assistant_threads   who was talking to the assistant, and when
--   assistant_turns     what they said — the full text of every turn
--   assistant_usage     per-user usage counters
--   age_checks          date of birth against a device token
--   events              the analytics stream, user_id included
--   cohort_courses      which courses a cohort is assigned
--   pool_periods        monthly revenue and pool figures
--   business_holidays   SLA working-day calendar
--
-- The first four are the ones that matter. assistant_turns holds
-- learners' own words; age_checks holds dates of birth and was also
-- writable, so the age gate could be satisfied by inserting a row
-- rather than passing it. Both are readable by an unauthenticated
-- request today.
--
-- Every one of these tables is touched exclusively by the service-role
-- client, which bypasses RLS — so enabling it with no policy at all
-- changes nothing about how the product works and closes the door to
-- everybody else. That is deliberate: a policy would be a claim that
-- somebody should read these from a browser, and nobody should.
--
-- pool_periods is read by two signed-in pages (admin payouts, studio
-- earnings) but both go through the service-role client too, so it
-- needs no policy either.
-- =====================================================================

alter table assistant_threads enable row level security;
alter table assistant_turns   enable row level security;
alter table assistant_usage   enable row level security;
alter table age_checks        enable row level security;
alter table events            enable row level security;
alter table cohort_courses    enable row level security;
alter table pool_periods      enable row level security;
alter table business_holidays enable row level security;

comment on table assistant_turns is
  'Learners'' own words. Service-role only: RLS is on with no policy, deliberately — see 0045.';
comment on table age_checks is
  'Date of birth against a device token. Service-role only: RLS on with no policy — a readable or writable age gate is not a gate. See 0045.';
