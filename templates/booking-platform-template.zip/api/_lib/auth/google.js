/**
 * Verifies a Google Sign-In credential and issues a session cookie.
 *
 * Flow: the page renders Google's button with GOOGLE_CLIENT_ID, Google returns a signed ID token
 * (JWT), the page POSTs it here, and this endpoint verifies it with Google before trusting anything.
 * The browser never decides who is signed in.
 *
 * Environment variables:
 *   GOOGLE_CLIENT_ID      — OAuth client ID (also used publicly by the page; see /api/auth/config)
 *   SESSION_SECRET        — long random string; signs the session cookie
 *
 * No database: the session cookie carries the profile (id, name, email, picture). That is enough to
 * greet the customer and prefill their details. Persisting bookings to an account needs the
 * Transport OS database — see the README.
 */
import { sign } from './session.js';

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST only' });
  const clientId = process.env.GOOGLE_CLIENT_ID, secret = process.env.SESSION_SECRET;
  if (!clientId || !secret) return res.status(503).json({ error: 'sign-in not configured' });

  const { credential } = req.body || {};
  if (typeof credential !== 'string' || credential.length > 4000) return res.status(400).json({ error: 'bad credential' });

  // Ask Google to validate its own token. Simple, dependency-free, and authoritative.
  let claims;
  try {
    const r = await fetch(`https://oauth2.googleapis.com/tokeninfo?id_token=${encodeURIComponent(credential)}`);
    if (!r.ok) throw new Error(`tokeninfo ${r.status}`);
    claims = await r.json();
  } catch (err) {
    console.error('google verify failed:', err.message);
    return res.status(401).json({ error: 'could not verify sign-in' });
  }

  const validIssuer = ['accounts.google.com', 'https://accounts.google.com'].includes(claims.iss);
  const validAudience = claims.aud === clientId;
  const notExpired = Number(claims.exp) > Math.floor(Date.now() / 1000);
  if (!validIssuer || !validAudience || !notExpired || claims.email_verified !== 'true') {
    return res.status(401).json({ error: 'sign-in rejected' });
  }

  const user = {
    kind: 'customer',
    sub: claims.sub,
    name: claims.name || claims.given_name || 'Traveller',
    email: claims.email,
    picture: claims.picture || '',
    exp: Math.floor(Date.now() / 1000) + 60 * 60 * 24 * 30   // 30 days
  };
  const cookie = [
    `atx_session=${sign(user, secret)}`,
    'Path=/', 'HttpOnly', 'Secure', 'SameSite=Lax', `Max-Age=${60 * 60 * 24 * 30}`
  ].join('; ');
  res.setHeader('Set-Cookie', cookie);
  return res.status(200).json({ user: { name: user.name, email: user.email, picture: user.picture } });
}
