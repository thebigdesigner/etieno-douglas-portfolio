/**
 * POST /api/payments/webhook — Paystack calls this. It is the ONLY thing that confirms a booking.
 *
 * Three rules, all enforced here:
 *   1. Verify the signature (HMAC-SHA512 of the raw body with the secret key) before reading anything.
 *   2. Be idempotent — Paystack retries, and a replayed event must not double-confirm or double-count.
 *   3. Re-verify the amount against the transaction we created. Never trust the payload alone.
 *
 * Add the URL in the Paystack dashboard: https://your-domain/api/payments/webhook
 */
import { opsAlert } from '../_lib/ops-alert.js';
const nairaOf = k => '₦' + Math.round(Number(k || 0) / 100).toLocaleString('en-NG');
import crypto from 'crypto';
import { configured, select, insert, update, rpc, tenant, audit, fail } from '../_lib/db.js';
import { sendTicketEmail } from '../_lib/ticket-email.js';

// Vercel must not parse the body: the signature is over the raw bytes.
export const config = { api: { bodyParser: false } };

const readRaw = (req) => new Promise((resolve, reject) => {
  const chunks = [];
  req.on('data', c => { chunks.push(c); if (chunks.reduce((n, b) => n + b.length, 0) > 1_000_000) reject(new Error('too large')); });
  req.on('end', () => resolve(Buffer.concat(chunks)));
  req.on('error', reject);
});

export function signatureValid(raw, signature, secret) {
  if (!signature || !secret) return false;
  const expected = crypto.createHmac('sha512', secret).update(raw).digest('hex');
  const a = Buffer.from(signature, 'utf8'), b = Buffer.from(expected, 'utf8');
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return fail(res, 405, 'method', 'POST only');
  const key = process.env.PAYSTACK_SECRET_KEY;
  if (!configured() || !key) return fail(res, 503, 'not_configured', 'Payments not configured');

  let raw;
  try { raw = await readRaw(req); } catch { return fail(res, 413, 'too_large', 'Payload too large'); }

  if (!signatureValid(raw, req.headers['x-paystack-signature'], key)) {
    console.warn('webhook rejected: bad signature');
    return fail(res, 401, 'bad_signature', 'Rejected');
  }

  let event;
  try { event = JSON.parse(raw.toString('utf8')); } catch { return fail(res, 400, 'bad_json', 'Rejected'); }

  const payRef = event?.data?.reference;
  const eventId = String(event?.id || `${event?.event}:${payRef}`);
  if (!payRef) return res.status(200).json({ ok: true });         // nothing to do, but acknowledge

  try {
    const t = await tenant();

    /* Rule 2, done properly. The row is written on arrival, but only processed_at makes an event
       "done". A delivery that crashed half-way is NOT a duplicate: when Paystack retries it, it
       runs again. Every step below is safe to repeat. (It used to answer "duplicate" to the
       retry, which left a paid booking unconfirmed for good.) */
    let eventRow;
    try {
      [eventRow] = await insert('webhook_events', [{ provider: 'paystack', event_id: eventId, payload: event }]);
    } catch (err) {
      if (!(err.status === 409 || String(err.message).includes('duplicate'))) throw err;
      const seen = await select('webhook_events',
        `provider=eq.paystack&event_id=eq.${encodeURIComponent(eventId)}&select=id,processed_at`);
      if (seen[0]?.processed_at) return res.status(200).json({ ok: true, duplicate: true });
      eventRow = seen[0];
    }
    const done = async () => {
      if (eventRow?.id) await update('webhook_events', `id=eq.${eventRow.id}`, { processed_at: new Date().toISOString() });
    };

    if (event.event !== 'charge.success') {
      if (event.event === 'charge.failed') {
        await update('payments', `tenant_id=eq.${t.id}&provider_ref=eq.${encodeURIComponent(payRef)}&status=neq.success`, { status: 'failed' });
      }
      await done();
      return res.status(200).json({ ok: true });
    }

    const rows = await select('payments', `tenant_id=eq.${t.id}&provider_ref=eq.${encodeURIComponent(payRef)}&select=id,booking_id,amount_kobo,status`);
    if (!rows.length) {
      console.warn('webhook for unknown payment reference', payRef);
      await done();
      return res.status(200).json({ ok: true });                   // acknowledge; nothing of ours
    }
    const payment = rows[0];

    // Rule 3: confirm the money with Paystack itself, and check the amount we expected.
    const v = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(payRef)}`, {
      headers: { Authorization: `Bearer ${key}` }
    });
    const verified = await v.json();
    const d = verified?.data;
    if (!v.ok || !verified.status) throw new Error(`paystack verify ${v.status}`);   // retry later
    if (d?.status !== 'success') {
      await update('payments', `id=eq.${payment.id}&status=neq.success`, { status: 'failed', raw: verified });
      await done();
      return res.status(200).json({ ok: true });
    }
    if (Number(d.amount) !== Number(payment.amount_kobo)) {
      await opsAlert(`payment:mismatch:${payRef}`, { severity: 'urgent', title: `Paystack amount did not match — ${payRef}`,
        detail: { expected: nairaOf(payment.amount_kobo), received: nairaOf(d.amount), what_to_do: 'Check the payment in Paystack and refund or rebook.' } });
      await update('payments', `id=eq.${payment.id}&status=neq.success`, { status: 'failed', raw: verified,
        needs_attention: `Paystack took ${d.amount} kobo against ${payment.amount_kobo} expected` });
      await audit({ tenant_id: t.id, actor_type: 'provider', action: 'payment.amount_mismatch', entity: 'payment', entity_id: payment.id,
        detail: { expected_kobo: payment.amount_kobo, received_kobo: d.amount, provider_ref: payRef } });
      await done();
      return res.status(200).json({ ok: true });
    }

    if (payment.status !== 'success') {
      await update('payments', `id=eq.${payment.id}`, {
        status: 'success', channel: d.channel || null, settled_at: new Date().toISOString(), raw: verified
      });
    }

    /* The money is real. Whether the seats still are is a separate question: a checkout can
       outlast its hold, and by then the seat may have gone to someone else. confirm_booking
       says which, and anything short of a seat is put in front of a person — never dropped. */
    const outcome = await rpc('confirm_booking', { p_booking: payment.booking_id });
    const booking = (await select('bookings', `id=eq.${payment.booking_id}&select=reference,status`))[0] || {};

    if (outcome === 'lost' || outcome === 'missing') {
      await update('payments', `id=eq.${payment.id}&needs_attention=is.null`, {
        needs_attention: booking.status === 'cancelled' || booking.status === 'refunded'
          ? `Paid after the booking was ${booking.status} — refund or rebook`
          : 'Paid after the seat hold lapsed and the seat was resold — refund or re-seat'
      });
      await audit({ tenant_id: t.id, actor_type: 'provider', action: 'payment.needs_refund', entity: 'booking', entity_id: payment.booking_id,
        detail: { provider_ref: payRef, amount_kobo: d.amount, channel: d.channel, outcome, booking_status: booking.status } });
      await opsAlert(`payment:stranded:${payRef}`, { severity: 'urgent', title: `Money taken with no seat — ${booking.reference || payRef}`,
        detail: { amount: nairaOf(d.amount), channel: d.channel, booking_status: booking.status,
          what_to_do: 'Re-seat the passenger or refund them in Paystack, then mark it dealt with on the dashboard.' } });
      await done();
      return res.status(200).json({ ok: true, attention: true });
    }

    if (outcome !== 'already') {
      await audit({ tenant_id: t.id, actor_type: 'provider', action: outcome === 'reseated' ? 'payment.confirmed_after_lapse' : 'payment.confirmed',
        entity: 'booking', entity_id: payment.booking_id, detail: { provider_ref: payRef, amount_kobo: d.amount, channel: d.channel } });

      // The ticket goes out from here — after the money is verified, never from the browser.
      try {
        const sent = await sendTicketEmail(booking.reference);
        await audit({ tenant_id: t.id, actor_type: 'system', action: 'ticket.emailed', entity: 'booking', entity_id: payment.booking_id, detail: sent });
      } catch (e) {
        if (e.code !== 'no_email' && e.code !== 'not_configured') {
          console.error('ticket email failed:', e.message);
          await opsAlert('email:ticket', { severity: 'warning', title: 'Tickets are not being emailed',
            detail: { last_booking: booking.reference, error: e.message, what_to_do: 'Check RESEND_API_KEY and the sending domain in Resend.' } });
        }
      }
    }
    // SMS is queued here too once the provider is wired in.
    await done();
    return res.status(200).json({ ok: true });
  } catch (err) {
    console.error('webhook failed:', err.message);
    await opsAlert('webhook:error', { severity: 'urgent', title: 'Payment confirmations are failing',
      detail: { error: err.message, note: 'Paystack will retry; if this repeats, customers are paying without getting tickets.' }, everyMin: 30 });
    // 500 tells Paystack to retry, which is what we want if our database was briefly unreachable.
    return fail(res, 500, 'server', 'Retry');
  }
}
