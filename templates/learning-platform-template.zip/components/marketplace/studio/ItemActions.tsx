"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { deleteDraft, retireItem, submitItem } from "@/app/actions/marketplace";
import type { ItemState } from "@/lib/marketplace/studio";

/** The state-changing buttons, which differ by where the item is in its life. */
export default function ItemActions({ id, state, missing = [], house = false }:
  { id: string; state: ItemState; missing?: string[]; house?: boolean }) {
  const [pending, start] = useTransition();
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null);
  const router = useRouter();
  const run = (fn: () => Promise<{ error?: string; message?: string }>) => start(async () => {
    const r = await fn();
    setMsg(r.error ? { ok: false, text: r.error } : r.message ? { ok: true, text: r.message } : null);
    router.refresh();
  });

  return (
    <div className="st-itemacts">
      {(state === "draft" || state === "retired") && (
        <>
          <button type="button" className="mk-btn mk-btn--fill mk-btn--wide" disabled={pending || missing.length > 0}
            onClick={() => run(() => submitItem(id))}>
            {house
              ? (state === "retired" ? "Put back on sale" : "Publish")
              : (state === "retired" ? "Submit again for review" : "Submit for review")}
          </button>
          {missing.length > 0 && <p className="st-field__hint st-center">Add the {missing.join(" and ").toLowerCase()} to {house ? "publish" : "submit"}.</p>}
        </>
      )}
      {state === "in_review" && (
        <button type="button" className="mk-btn mk-btn--line mk-btn--wide" disabled={pending} onClick={() => run(() => retireItem(id))}>
          Withdraw from review
        </button>
      )}
      {state === "published" && (
        <button type="button" className="mk-btn mk-btn--line mk-btn--wide" disabled={pending}
          onClick={() => { if (confirm("Take this item off sale? Past buyers keep their downloads.")) run(() => retireItem(id)); }}>
          Take off sale
        </button>
      )}
      {state === "draft" && (
        <button type="button" className="st-danger" disabled={pending}
          onClick={() => { if (confirm("Delete this draft and its uploads? This cannot be undone.")) run(() => deleteDraft(id)); }}>
          Delete draft
        </button>
      )}
      {msg && <p className={`st-msg ${msg.ok ? "st-msg--ok" : "st-msg--err"}`} role="status">{msg.text}</p>}
    </div>
  );
}
