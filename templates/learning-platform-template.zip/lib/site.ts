/**
 * The public origin of this deployment.
 *
 * Every caller used to write `process.env.NEXT_PUBLIC_SITE_URL ?? "http://localhost:3000"`
 * inline. That default is fine locally and dangerous in production: if the
 * variable is not set in Vercel, the payment callback_url sent to Paystack
 * becomes http://localhost:3000/dashboard/plans/complete, so a customer who
 * has just paid is bounced to their own machine, the return page never runs,
 * and — if the webhook is also misconfigured — nothing is ever unlocked.
 *
 * The same default silently breaks OAuth callbacks, review links and every
 * email URL, and the bare interpolations produced literal "undefined/review".
 *
 * Vercel always sets VERCEL_PROJECT_PRODUCTION_URL and VERCEL_URL, so the
 * fallback chain can reach a real origin without any configuration at all.
 * NEXT_PUBLIC_SITE_URL still wins when set, because it is the only one that
 * knows about a custom domain.
 */

function normalise(raw: string): string {
  const trimmed = raw.trim().replace(/\/+$/, "");
  if (!trimmed) return "";
  return /^https?:\/\//i.test(trimmed) ? trimmed : `https://${trimmed}`;
}

export function siteUrl(): string {
  const configured = normalise(process.env.NEXT_PUBLIC_SITE_URL ?? "");
  if (configured) return configured;

  // The stable production domain of this Vercel project.
  const production = normalise(process.env.VERCEL_PROJECT_PRODUCTION_URL ?? "");
  if (production) return production;

  // Preview deployments: the per-deployment URL is the only real origin.
  const deployment = normalise(process.env.VERCEL_URL ?? "");
  if (deployment) return deployment;

  return "http://localhost:3000";
}

/** Absolute URL for an in-app path. Accepts paths with or without a slash. */
export function siteUrlFor(path: string): string {
  return `${siteUrl()}${path.startsWith("/") ? path : `/${path}`}`;
}
