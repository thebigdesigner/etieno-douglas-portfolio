/**
 * Staff API — desk, manager, accountant and driver, in one serverless function.
 *
 * AUTHENTICATION
 * Staff sign in with Supabase Auth (email + password). This endpoint verifies the credentials
 * with Supabase, looks up the matching row in `staff`, and issues its own signed HttpOnly cookie
 * carrying the staff id, role and terminal. Every action then checks the role — permissions are
 * enforced here on the server, not by hiding buttons in the page.
 *
 * Actions:
 *   login | me | logout
 *   book | manifest | mark | lookup | takings | bookings-search   (desk roles, manager)
 *   refund                                           (cancel: any desk role; refund: manager, accountant)
 *   closeout                                         (terminal sees own till, manager/accountant see all)
 *   dashboard | schedule | trip-assign | trip-cancel | extend-schedule   (manager)
 *   fleet | route-save | vehicle-save | driver-save                      (manager)
 *   staff-list | staff-add | staff-archive | staff-restore | staff-activity  (manager)
 *   expenses | expense-add                                              (manager, accountant)
 *   feedback-list | feedback-handle                          (manager, terminal_manager)
 *   loyalty-settings | loyalty-save                                     (manager)
 *   finance                                          (manager, accountant)
 *   mytrips | trip-status                            (driver, manager)
 */
import { opsAlert } from '../_lib/ops-alert.js';
import { randomBytes, randomUUID } from 'node:crypto';
import { staffAssist } from '../_lib/staff-assistant.js';
import { providers as aiProviders } from '../_lib/ai.js';
import { configured, select, insert, update, rpc, tenant, clearTenantCache, audit, makeReference, tripContext, fail, lagosToday, WAT } from '../_lib/db.js';
import { signedView } from '../_lib/storage.js';
import { sendTicketEmail } from '../_lib/ticket-email.js';
import { sign, verify } from '../_lib/auth/session.js';

const COOKIE = 'atx_staff';
const PHONE = /^\+?\d[\d\s-]{8,}$/;
const DAY = /^\d{4}-\d{2}-\d{2}$/;
const UUID = /^[0-9a-f-]{36}$/i;
/* The business day is Lagos's, not UTC's. Between midnight and 01:00 Lagos time the UTC date is
   still yesterday, and every "today" screen showed the wrong day. */
const today = () => lagosToday();
/* Day boundaries for PostgREST filters on timestamptz columns, in Lagos time. The '+' must be
   percent-encoded or the query string turns it into a space. */
const DAY_START = d => `${d}T00:00:00%2B01:00`;
const DAY_END = d => `${d}T23:59:59.999%2B01:00`;
/* Temporary passwords come from the system's secure random source. Math.random is predictable
   enough that a password made with it can be reconstructed. Same readable shape as before —
   atx-xxxxxx-xxxx — so the set-password screen still recognises and refuses it. Alphabet has
   no 0/o/1/l so it survives being read over the phone. */
const TEMP_ALPHABET = 'abcdefghijkmnpqrstuvwxyz23456789';
function tempPassword() {
  const pick = n => Array.from(randomBytes(n), b => TEMP_ALPHABET[b % TEMP_ALPHABET.length]).join('');
  return `atx-${pick(6)}-${pick(4)}`;
}
const uuidOrNull = v => (UUID.test(String(v || '')) ? String(v) : null);
/* The same list the contact page offers. Kept in step with api/feedback.js by hand — a topic
   that exists in one and not the other would quietly drop messages out of the inbox filter. */
const FEEDBACK_TOPICS = ['booking', 'refund', 'lost property', 'hire a vehicle', 'complaint', 'something else'];

/**
 * Every list screen offers the same filters, so they are collected in one place.
 * A filter is only applied when it names something real — an unknown value is ignored
 * rather than silently returning an empty screen.
 */
function readFilters(body) {
  return {
    terminal: uuidOrNull(body.terminal),
    routeId: uuidOrNull(body.routeId),
    vehicleId: uuidOrNull(body.vehicleId),
    driverId: uuidOrNull(body.driverId),
    staffId: uuidOrNull(body.staffId),
    status: typeof body.status === 'string' && /^[a-z_]{3,20}$/.test(body.status) ? body.status : null,
    method: typeof body.method === 'string' && /^[a-z_]{3,20}$/.test(body.method) ? body.method : null,
    channel: typeof body.channel === 'string' && /^[a-z_]{3,20}$/.test(body.channel) ? body.channel : null,
    category: typeof body.category === 'string' && /^[a-z_]{3,20}$/.test(body.category) ? body.category : null
  };
}

/**
 * Email a staff member a single-use link confirming their address, after they set their own
 * password. Returns false rather than throwing when email is not configured — a terminal that
 * cannot send mail should still be able to put someone to work.
 */
async function sendCouponEmail({ email, coupon, coupon_value_kobo }) {
  const key = process.env.RESEND_API_KEY, from = process.env.TICKET_FROM;
  const site = (process.env.SITE_URL || '').replace(/\/$/, '');
  if (!key || !from || !email) return false;
  const value = '₦' + Number((coupon_value_kobo || 0) / 100).toLocaleString('en-NG');

  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      from, to: [email],
      subject: `You have earned a ${value} travel credit`,
      html: `<div style="font-family:system-ui,sans-serif;max-width:520px;margin:0 auto;padding:24px;color:#101828">
        <p style="font-size:16px">Thank you for travelling with us.</p>
        <p>Your Trail points have earned you a <b>${value}</b> credit towards your next trip.</p>
        <p style="margin:24px 0;text-align:center">
          <span style="display:inline-block;border:2px dashed #0E4D33;border-radius:12px;padding:16px 26px;
            font-family:ui-monospace,Menlo,monospace;font-size:22px;font-weight:800;letter-spacing:.08em;color:#0E4D33">${coupon}</span></p>
        <p style="font-size:13.5px;color:#667085">Quote this code at any of our terminals when you book.
        ${site ? `Your points and credits are in your account at <a href="${site}/account">${site.replace(/^https?:\/\//, '')}</a>.` : ''}</p>
      </div>`
    })
  });
  if (!res.ok) { console.error('coupon email rejected:', (await res.text()).slice(0, 200)); return false; }
  return true;
}

async function sendStaffVerification({ staffId, email, name, tenantId, secret }) {
  const key = process.env.RESEND_API_KEY, from = process.env.TICKET_FROM;
  const site = (process.env.SITE_URL || '').replace(/\/$/, '');
  if (!key || !from || !site || !email) return false;

  const jti = `sv_${randomUUID()}`;
  const expires = new Date(Date.now() + 24 * 60 * 60000).toISOString();
  await insert('login_tokens', [{ tenant_id: tenantId || null, jti, email, expires_at: expires }], 'return=minimal');

  const token = sign({ kind: 'staff-verify', jti, staffId, exp: Math.floor(Date.parse(expires) / 1000) }, secret);
  const link = `${site}/api/auth/staff-verify?t=${encodeURIComponent(token)}`;

  const res = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({
      from, to: [email],
      subject: 'Confirm your Your Brand staff account',
      html: `<div style="font-family:system-ui,sans-serif;max-width:520px;margin:0 auto;padding:24px;color:#101828">
        <p style="font-size:16px">Hello ${String(name || '').split(' ')[0] || 'there'},</p>
        <p>Your password has been changed and your staff account is now yours alone. Confirm this
        email address so your manager knows the account reached you.</p>
        <p style="margin:26px 0"><a href="${link}"
          style="background:#0E4D33;color:#fff;text-decoration:none;padding:13px 22px;border-radius:10px;font-weight:700">Confirm my email</a></p>
        <p style="font-size:13px;color:#667085">The link works once and expires in 24 hours.
        If you did not change your password, tell your manager straight away — someone else may have.</p>
      </div>`
    })
  });
  if (!res.ok) { console.error('verification email rejected:', (await res.text()).slice(0, 200)); return false; }
  return true;
}

function sessionOf(req) {
  const secret = process.env.SESSION_SECRET; if (!secret) return null;
  const raw = (req.headers.cookie || '').split(';').map(c => c.trim()).find(c => c.startsWith(`${COOKIE}=`));
  const claims = raw ? verify(raw.slice(COOKIE.length + 1), secret) : null;
  return claims && claims.kind === 'staff' ? claims : null;
}
const can = (staff, ...roles) => staff && roles.includes(staff.role);
/* A terminal_manager does everything a clerk does, so anywhere that admits 'terminal'
   should admit them too rather than listing both role names at every call site. */
const DESK = ['terminal', 'terminal_manager'];
const atDesk = staff => can(staff, ...DESK);

export default async function handler(req, res) {
  try { return await route(req, res); }
  catch (err) {
    const detail = [err && err.message, err && err.details && JSON.stringify(err.details)].filter(Boolean).join(' ');
    console.error('staff handler crashed:', detail, err && err.stack);
    await opsAlert('staff:error', { severity: 'warning', title: 'A dashboard screen is failing',
      detail: { action: req.body && req.body.action, error: detail.slice(0, 300) } });

    /* "Something went wrong" tells nobody anything. The two failures that actually happen
       here are a schema that has not been run yet and a missing environment variable, and
       both are fixable in a minute once they are named. */
    if (/column .* does not exist|42703|schema cache|PGRST20[0-9]/i.test(detail)) {
      return fail(res, 500, 'schema_behind',
        'The database is missing something this screen needs. Run db/schema.sql in Supabase, then try again.');
    }
    if (/relationship|foreign key|PGRST200/i.test(detail)) {
      return fail(res, 500, 'schema_behind',
        'The database is missing a link between two tables. Run db/schema.sql in Supabase, then try again.');
    }
    return fail(res, 500, 'server', 'Something went wrong. The details are in the Vercel logs for /api/staff.');
  }
}

/* ---------------------------------------------------------------- assistant
   A per-person limit: twelve questions a minute is more than anyone types, and each one may
   make several model calls. */
const ASSIST_LIMIT = new Map();
function assistTooMany(staffId) {
  const now = Date.now();
  const list = (ASSIST_LIMIT.get(staffId) || []).filter(t => now - t < 60000);
  list.push(now);
  ASSIST_LIMIT.set(staffId, list);
  if (ASSIST_LIMIT.size > 500) ASSIST_LIMIT.clear();
  return list.length > 12;
}

/* The models themselves live in ../_lib/ai.js and the assistant in ../_lib/staff-assistant.js. */


async function route(req, res) {
  if (req.method !== 'POST') return fail(res, 405, 'method', 'POST only');
  const { action } = req.body || {};

  if (action === 'ping') {
    return res.status(200).json({
      ok: true,
      has: {
        session_secret: Boolean(process.env.SESSION_SECRET),
        supabase_url: Boolean(process.env.SUPABASE_URL),
        service_key: Boolean(process.env.SUPABASE_SERVICE_ROLE_KEY),
        anon_key: Boolean(process.env.SUPABASE_ANON_KEY),
        tenant_slug: process.env.TENANT_SLUG || null
      }
    });
  }

  const secret = process.env.SESSION_SECRET;
  if (!configured() || !secret) return fail(res, 503, 'not_configured', 'Staff sign-in is not configured');

  /* ---------------------------------------------------------------- sign in */
  if (action === 'login') {
    const url = process.env.SUPABASE_URL, anon = process.env.SUPABASE_ANON_KEY;
    if (!url || !anon) return fail(res, 503, 'not_configured', 'Staff sign-in is not configured');
    const email = String(req.body.email || '').trim().toLowerCase();
    const password = String(req.body.password || '');
    if (!email || !password) return fail(res, 400, 'bad_credentials', 'Enter your email and password');

    /* The lock on the only door that had none. Counted in the database, not in memory: a
       serverless instance forgets everything when it goes cold and there are many of them, so an
       in-memory limit hands an attacker a fresh allowance every few seconds. */
    const ip = String(req.headers['x-forwarded-for'] || '').split(',')[0].trim() || null;
    let gateTenant = null;
    try {
      gateTenant = await tenant();
      const gate = await rpc('login_gate', { p_email: email, p_ip: ip });
      if (gate && gate.locked) {
        const mins = Math.max(1, Math.round((gate.retryAfter || 900) / 60));
        return fail(res, 429, 'locked_out',
          `Too many attempts. Try again in ${mins} minute${mins === 1 ? '' : 's'}, or ask a manager to reset your password.`);
      }
    } catch (err) {
      /* If the gate itself is broken, sign-in still works. A locked-out building is worse than
         an unlocked one when the lock is the thing that failed. */
      console.error('login gate unavailable:', err.message);
    }
    const noteAttempt = async ok => {
      try { await rpc('note_login', { p_tenant: gateTenant ? gateTenant.id : null, p_email: email, p_ip: ip, p_ok: ok }); }
      catch (err) { console.error('login attempt not recorded:', err.message); }
    };

    let authUser;
    try {
      const r = await fetch(`${url}/auth/v1/token?grant_type=password`, {
        method: 'POST',
        headers: { apikey: anon, 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      const data = await r.json();
      if (!r.ok || !data.user) {
        await noteAttempt(false);
        /* Deliberately the same words whether or not the account exists. */
        return fail(res, 401, 'bad_credentials', 'Email or password is not right');
      }
      authUser = data.user;
      await noteAttempt(true);
    } catch (err) {
      console.error('staff auth failed:', err.message);
      return fail(res, 502, 'auth_unavailable', 'Could not reach the sign-in service');
    }

    let t, rows;
    try {
      t = await tenant();
      rows = await select('staff',
        `tenant_id=eq.${t.id}&auth_user_id=eq.${authUser.id}&active=is.true&select=id,name,role,terminal_id,must_change_password,email_verified_at,email,terminal:terminals(code,city)`);
    } catch (err) {
      console.error('staff lookup failed:', err.message, err.details ? JSON.stringify(err.details).slice(0, 300) : '');
      return fail(res, 500, 'staff_lookup', 'Could not read your staff record');
    }
    if (!rows.length) return fail(res, 403, 'no_staff_record', 'That account is not set up for this company');

    const s = rows[0];

    /* A temporary password gets you exactly one thing: the screen that replaces it. The cookie
       issued here carries kind 'staff-pending', which every other action rejects. */
    if (s.must_change_password) {
      const pending = { kind: 'staff-pending', id: s.id, name: s.name, authId: authUser.id, email: s.email,
        exp: Math.floor(Date.now() / 1000) + 60 * 20 };
      res.setHeader('Set-Cookie', [`${COOKIE}=${sign(pending, secret)}`, 'Path=/', 'HttpOnly', 'Secure', 'SameSite=Lax', 'Max-Age=1200'].join('; '));
      return res.status(200).json({ mustChangePassword: true, name: s.name });
    }

    const claims = {
      kind: 'staff', id: s.id, name: s.name, role: s.role,
      terminal: s.terminal?.code || null, terminalId: s.terminal_id || null,
      exp: Math.floor(Date.now() / 1000) + 60 * 60 * 12
    };
    res.setHeader('Set-Cookie', [`${COOKIE}=${sign(claims, secret)}`, 'Path=/', 'HttpOnly', 'Secure', 'SameSite=Lax', `Max-Age=${60 * 60 * 12}`].join('; '));
    await audit({ tenant_id: t.id, actor_type: 'staff', actor_id: s.id, action: 'staff.signed_in', entity: 'staff', entity_id: s.id, detail: { role: s.role } });
    return res.status(200).json({ staff: { name: s.name, role: s.role, terminal: claims.terminal, city: s.terminal?.city || null,
      emailVerified: Boolean(s.email_verified_at) } });
  }

  if (action === 'logout') {
    res.setHeader('Set-Cookie', `${COOKIE}=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0`);
    return res.status(200).json({ ok: true });
  }

  /* Sits above the ordinary session check: whoever is here has no usable session yet. */
  if (action === 'set-password') {
    const raw = (req.headers.cookie || '').split(';').map(c => c.trim()).find(c => c.startsWith(`${COOKIE}=`));
    const pending = raw ? verify(raw.slice(COOKIE.length + 1), secret) : null;
    if (!pending || pending.kind !== 'staff-pending') return fail(res, 401, 'signed_out', 'Start again from the sign-in screen');

    const password = String(req.body.password || '');
    if (password.length < 8) return fail(res, 400, 'weak', 'Use at least 8 characters');
    if (/^atx-/.test(password)) return fail(res, 400, 'weak', 'Choose something other than the temporary password');
    if (String(req.body.confirm || '') !== password) return fail(res, 400, 'mismatch', 'The two passwords do not match');

    const url = process.env.SUPABASE_URL, key = process.env.SUPABASE_SERVICE_ROLE_KEY;
    if (!url || !key) return fail(res, 503, 'not_configured', 'Cannot change passwords right now');

    try {
      const r = await fetch(`${url}/auth/v1/admin/users/${pending.authId}`, {
        method: 'PUT',
        headers: { apikey: key, Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ password })
      });
      if (!r.ok) {
        const data = await r.json().catch(() => ({}));
        console.error('password change failed:', JSON.stringify(data).slice(0, 300));
        return fail(res, 502, 'auth_failed', data.msg || 'Could not save the new password');
      }
    } catch (err) {
      console.error('auth admin unreachable:', err.message);
      return fail(res, 502, 'auth_failed', 'Could not reach the sign-in service');
    }

    let t2;
    try { t2 = await tenant(); } catch { t2 = null; }
    await update('staff', `id=eq.${pending.id}`, { must_change_password: false, password_set_at: new Date().toISOString() });
    if (t2) await audit({ tenant_id: t2.id, actor_type: 'staff', actor_id: pending.id, action: 'staff.password_set', entity: 'staff', entity_id: pending.id, detail: {} });

    /* Confirm the address is real. Not a gate — a clerk without inbox access on their first
       morning still has to be able to work — but the manager can see who has not confirmed. */
    let emailed = false;
    try { emailed = await sendStaffVerification({ staffId: pending.id, email: pending.email, name: pending.name, tenantId: t2 && t2.id, secret }); }
    catch (err) { console.error('verification email failed:', err.message); }

    res.setHeader('Set-Cookie', `${COOKIE}=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0`);
    return res.status(200).json({ ok: true, emailed });
  }

  const staff = sessionOf(req);
  if (action === 'me') return res.status(200).json({ staff: staff ? { name: staff.name, role: staff.role, terminal: staff.terminal } : null });
  if (!staff) return fail(res, 401, 'signed_out', 'Sign in to continue');

  let t;
  try { t = await tenant(); }
  catch (err) { console.error('tenant lookup failed:', err.message); return fail(res, 500, 'tenant', 'Could not load the company record'); }

  /* The session cookie lasts 12 hours, so archiving someone would otherwise leave them
     working until it expired. One indexed lookup per request closes that window. */
  try {
    const live = await select('staff', `id=eq.${staff.id}&tenant_id=eq.${t.id}&active=is.true&select=id,role`);
    if (!live.length) {
      res.setHeader('Set-Cookie', `${COOKIE}=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0`);
      return fail(res, 401, 'signed_out', 'Your account is no longer active. Ask your manager.');
    }
    if (live[0].role !== staff.role) staff.role = live[0].role;   // role changed mid-session
  } catch (err) {
    console.error('staff status check failed:', err.message);
  }
  const money = kobo => Number(kobo || 0) / 100;

  try {
    /* ---------------------------------------------------------- terminal desk */
    if (action === 'book') {
      if (!can(staff, ...DESK, 'manager')) return fail(res, 403, 'forbidden', 'Your role cannot sell seats');
      const { tripId, seats, passengers = [], contact = {}, payment = {} } = req.body;
      if (!UUID.test(tripId || '')) return fail(res, 400, 'bad_trip', 'Unknown trip');
      if (!Array.isArray(seats) || !seats.length || seats.some(s => !Number.isInteger(s))) return fail(res, 400, 'bad_seats', 'Choose a seat');
      if (passengers.length !== seats.length) return fail(res, 400, 'bad_passengers', 'One passenger per seat');
      if (passengers.some(p => String(p?.name || '').trim().length < 3)) return fail(res, 400, 'bad_passengers', 'Every passenger needs a name');
      if (!PHONE.test(String(contact.phone || '').trim())) return fail(res, 400, 'bad_phone', 'Enter the passenger phone number');
      /* The desk asks for an email too: the ticket and its QR are emailed, and without one the
         passenger has nothing to show at the gate but a reference read out to them. */
      const deskEmail = String(contact.email || '').trim();
      if (!deskEmail) return fail(res, 400, 'no_email', 'Enter an email — the ticket is sent there');
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(deskEmail)) return fail(res, 400, 'bad_email', 'Check the email address');
      const method = ['cash', 'pos', 'transfer'].includes(payment.method) ? payment.method : null;
      if (!method) return fail(res, 400, 'bad_payment', 'Record how the passenger paid');

      let bookingId = null;
      try {
        const trips = await select('trips', `id=eq.${tripId}&tenant_id=eq.${t.id}&status=in.(scheduled,boarding)&select=id,fare_kobo,depart_date,depart_time`);
        if (!trips.length) return fail(res, 404, 'no_trip', 'That departure is no longer available');
        const trip = trips[0];
        const ratio = Number((t.settings || {}).child_fare_ratio ?? 0.75);
        const priced = passengers.map((p, i) => {
          const type = p.type === 'child' ? 'child' : p.type === 'infant' ? 'infant' : 'adult';
          return { name: String(p.name).trim().slice(0, 120), type, seat: seats[i],
                   fare: type === 'infant' ? 0 : Math.round(trip.fare_kobo * (type === 'child' ? ratio : 1)) };
        });
        const total = priced.reduce((a, p) => a + p.fare, 0);
        const reference = makeReference(t.prefix, await tripContext(t.id, tripId));
        const couponCode = String(payment.couponCode || '').trim();
        const [booking] = await insert('bookings', [{
          tenant_id: t.id, reference, channel: 'terminal', created_by: staff.id, status: 'pending',
          contact_name: String(contact.name || priced[0].name).slice(0, 120),
          contact_phone: String(contact.phone).trim().slice(0, 32),
          contact_email: deskEmail.slice(0, 160),
          total_kobo: total, hold_expires_at: new Date(Date.now() + 10 * 60000).toISOString()
        }]);
        bookingId = booking.id;
        await rpc('claim_seats', { p_trip_id: tripId, p_seats: seats, p_booking: booking.id, p_hold_mins: 10 });
        await insert('passengers', priced.map(p => ({ booking_id: booking.id, trip_id: tripId, seat_no: p.seat, full_name: p.name, pax_type: p.type, fare_kobo: p.fare })), 'return=minimal');
        /* A credit is spent inside the same try as the seats: if anything after it fails the
           booking is released, and the coupon row is the only thing that would be left claimed —
           so it is applied last, once the seats are certain. */
        let credit = 0;
        if (couponCode) {
          try {
            credit = await rpc('redeem_coupon', { p_tenant: t.id, p_code: couponCode, p_booking: booking.id, p_max_kobo: total });
          } catch (err) {
            const m = String(err.message || '');
            const why = m.includes('already_used') ? 'That credit has already been used'
              : m.includes('expired') ? 'That credit has expired'
              : m.includes('no_coupon') ? 'No credit with that code'
              : 'That credit could not be applied';
            await rpc('release_booking', { p_booking: booking.id, p_status: 'cancelled' }).catch(() => {});
            return fail(res, 409, 'bad_coupon', why);
          }
        }

        /* Two rows, not one discounted row: the money the desk actually holds, and the credit
           that covered the rest. Payments still sum to the fare, so the books balance and a
           manager can see what credits are costing by filtering on the method. */
        const rows = [];
        const cash = total - credit;
        if (cash > 0) rows.push({ tenant_id: t.id, booking_id: booking.id, provider: method === 'transfer' ? 'transfer' : method,
          amount_kobo: cash, status: 'success', channel: method, recorded_by: staff.id, settled_at: new Date().toISOString() });
        if (credit > 0) rows.push({ tenant_id: t.id, booking_id: booking.id, provider: 'other',
          amount_kobo: credit, status: 'success', channel: 'coupon', recorded_by: staff.id, settled_at: new Date().toISOString(),
          raw: { kind: 'coupon', code: couponCode.toUpperCase() } });
        await insert('payments', rows, 'return=minimal');
        await rpc('confirm_booking', { p_booking: booking.id });
        await audit({ tenant_id: t.id, actor_type: 'staff', actor_id: staff.id, action: 'booking.created_at_terminal', entity: 'booking', entity_id: booking.id,
          detail: { reference, by: staff.name, terminal: staff.terminal, seats, total_kobo: total, payment: method,
                    credit_kobo: credit || undefined, coupon: credit ? couponCode.toUpperCase() : undefined } });
        return res.status(201).json({ reference, total: money(total), seats, credit: money(credit), collected: money(total - credit),
          trip: { date: trip.depart_date, time: String(trip.depart_time).slice(0, 5) },
          passengers: priced.map(p => ({ name: p.name, seat: p.seat })) });
      } catch (err) {
        if (bookingId) { try { await rpc('release_booking', { p_booking: bookingId, p_status: 'cancelled' }); } catch {} }
        if (err.code === 'seat_taken') return fail(res, 409, 'seat_taken', 'That seat has just gone. Pick another.');
        throw err;
      }
    }

    if (action === 'coupon-check') {
      if (!can(staff, ...DESK, 'manager')) return fail(res, 403, 'forbidden', 'Your role cannot take bookings');
      const code = String(req.body.code || '').trim();
      if (code.length < 4) return fail(res, 400, 'bad_code', 'Type the code from the customer');
      const c = await rpc('check_coupon', { p_tenant: t.id, p_code: code });
      if (!c || !c.code) return fail(res, 404, 'no_coupon', 'No credit with that code');
      if (c.used) return fail(res, 409, 'already_used', 'That credit has already been used');
      if (c.expired) return fail(res, 409, 'expired', 'That credit has expired');
      return res.status(200).json({ code: c.code, value: money(c.value), email: c.email });
    }

    if (action === 'manifest') {
      if (!can(staff, 'manager', 'accountant', ...DESK, 'driver')) {
        return fail(res, 403, 'forbidden', 'Your role cannot open a manifest');
      }
      const { tripId } = req.body;
      if (!UUID.test(tripId || '')) return fail(res, 400, 'bad_trip', 'Unknown trip');

      /* The trip has to belong to this company. Selecting passengers straight off a trip id
         the caller supplied would hand any signed-in user another operator's manifest the
         moment there is a second operator. */
      const trips = await select('trips',
        `id=eq.${tripId}&tenant_id=eq.${t.id}&select=status,depart_date,depart_time,driver_id,driver:drivers(name,phone),vehicle:vehicles(label,plate)`);
      if (!trips.length) return fail(res, 404, 'not_found', 'No such departure');

      /* A driver gets the manifest for their own vehicle, not for every departure today. */
      if (can(staff, 'driver') && !can(staff, 'manager')) {
        const me = await select('drivers', `tenant_id=eq.${t.id}&staff_id=eq.${staff.id}&select=id`);
        if (!me.length || trips[0].driver_id !== me[0].id) {
          return fail(res, 403, 'forbidden', 'That departure is not yours');
        }
      }

      /* Scoped by construction: the trip above was fetched with tenant_id and 404s otherwise,
         so this trip_id is already proven to be ours. */
      const rows = await select('passengers',
        `trip_id=eq.${tripId}&select=id,full_name,seat_no,pax_type,status,booking:bookings(reference,contact_phone,status)&order=seat_no.asc`);
      return res.status(200).json({ manifest: rows, trip: trips[0] || null });
    }

    if (action === 'mark') {
      if (!can(staff, ...DESK, 'manager', 'driver')) return fail(res, 403, 'forbidden', 'Your role cannot check passengers in');
      const { passengerId, status } = req.body;
      if (!UUID.test(passengerId || '')) return fail(res, 400, 'bad_passenger', 'Unknown passenger');
      await rpc('mark_passenger', { p_passenger: passengerId, p_status: status, p_staff: staff.id });

      /* Points are earned by travelling, not by booking — otherwise a booking made and refunded
         the same afternoon would still pay out. Awarding here, once, at boarding. */
      let loyalty = null;
      if (status === 'boarded') {
        try {
          const r = await rpc('award_trip_points', { p_passenger: passengerId });
          if (r && r.awarded > 0) {
            loyalty = r;
            if (r.coupon) {
              await audit({ tenant_id: t.id, actor_type: 'system', actor_id: null, action: 'loyalty.coupon_issued', entity: 'booking', entity_id: null,
                detail: { email: r.email, code: r.coupon, value_kobo: r.coupon_value_kobo } });
              sendCouponEmail(r).catch(err => console.error('coupon email failed:', err.message));
            }
          }
        } catch (err) { console.error('points award failed:', err.message); }
      }
      return res.status(200).json({ ok: true, loyalty });
    }

    if (action === 'recent') {
      if (!can(staff, 'manager', 'terminal_manager', 'accountant', ...DESK)) {
        return fail(res, 403, 'forbidden', 'Your role cannot see recent bookings');
      }
      const limit = Math.min(Number(req.body.limit) || 8, 30);
      /* A clerk sees their terminal's bookings, the same scope as their takings. */
      let scope = '';
      if (can(staff, 'terminal')) {
        const mates = staff.terminalId
          ? await select('staff', `tenant_id=eq.${t.id}&terminal_id=eq.${staff.terminalId}&select=id`) : [];
        const ids = mates.map(x => x.id).filter(Boolean);
        scope = ids.length ? `created_by=in.(${ids.join(',')})&` : `created_by=eq.${staff.id}&`;
      }
      const rows = await select('bookings',
        `tenant_id=eq.${t.id}&${scope}select=reference,status,channel,total_kobo,contact_name,created_at,` +
        `passengers(seat_no,trip:trips(depart_date,depart_time,route:routes(from_terminal,to_terminal)))` +
        `&order=created_at.desc&limit=${limit}`);
      const terminals = await select('terminals', `tenant_id=eq.${t.id}&select=id,city`);
      const city = id => terminals.find(x => x.id === id)?.city || '';
      return res.status(200).json({ bookings: rows.map(b => {
        const trip = b.passengers[0]?.trip;
        return { reference: b.reference, status: b.status, channel: b.channel, total: money(b.total_kobo),
          name: b.contact_name, at: b.created_at, seats: b.passengers.length,
          route: trip ? `${city(trip.route?.from_terminal)} → ${city(trip.route?.to_terminal)}` : '',
          date: trip?.depart_date || null, time: trip ? String(trip.depart_time).slice(0,5) : null };
      }) });
    }

    if (action === 'network') {
      if (!can(staff, 'manager')) return fail(res, 403, 'forbidden', 'Managers only');
      const [routes, vehicles, drivers, terminals] = await Promise.all([
        select('routes', `tenant_id=eq.${t.id}&select=id,fare_kobo,duration_min,operating_days,departures,active,from_terminal,to_terminal`),
        select('vehicles', `tenant_id=eq.${t.id}&select=id,label,plate,capacity,status`),
        select('drivers', `tenant_id=eq.${t.id}&select=id,name,phone,active`),
        select('terminals', `tenant_id=eq.${t.id}&select=id,code,city,name,phone,active`)
      ]);
      const city = id => terminals.find(x => x.id === id)?.city || '';
      const DAYS = ['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
      return res.status(200).json({
        terminals,
        vehicles,
        drivers,
        routes: routes.map(r => ({ id: r.id, from: city(r.from_terminal), to: city(r.to_terminal),
          fare: money(r.fare_kobo), durationMin: r.duration_min, active: r.active,
          days: (r.operating_days || []).map(d => DAYS[d]).join(', '),
          departures: (r.departures || []).map(d => String(d).slice(0,5)).join(', ') }))
      });
    }

    if (action === 'lookup') {
      /* Opening a booking shows a passenger's name and phone number. The desk, the manager and
         the accountant need that; a driver has the manifest for their own trip instead. */
      if (!can(staff, 'manager', 'accountant', ...DESK)) {
        return fail(res, 403, 'forbidden', 'Your role cannot look up bookings');
      }
      const typed = String(req.body.reference || '').trim();
      const ref = typed.toUpperCase();
      const digits = typed.replace(/\D/g, '');

      /* A passenger who has lost their SMS still knows the number they booked with, and at a
         counter that is the fastest thing they can say. Phone numbers are stored as typed, so
         match on the last digits rather than the exact string. */
      if (!/^[A-Z]{2,5}-[A-Z0-9]{4,10}(-[A-Z0-9]{2,6})?$/.test(ref)) {
        if (digits.length < 7) return fail(res, 400, 'bad_reference', 'Enter a booking reference or the phone number it was booked with');

        const tail = digits.slice(-9);
        const matches = await select('bookings',
          `tenant_id=eq.${t.id}&contact_phone=ilike.*${tail}*&select=reference,status,contact_name,contact_phone,total_kobo,created_at,` +
          `passengers(seat_no,trip:trips(depart_date,depart_time,route:routes(from_terminal,to_terminal)))` +
          `&order=created_at.desc&limit=12`);
        if (!matches.length) return fail(res, 404, 'not_found', 'No booking with that phone number');

        if (matches.length > 1) {
          const terms = await select('terminals', `tenant_id=eq.${t.id}&select=id,city`);
          const cityName = id => terms.find(x => x.id === id)?.city || '';
          return res.status(200).json({ matches: matches.map(b => {
            const trip = b.passengers[0]?.trip;
            return { reference: b.reference, status: b.status, name: b.contact_name, phone: b.contact_phone,
              total: money(b.total_kobo),
              route: trip ? `${cityName(trip.route?.from_terminal)} → ${cityName(trip.route?.to_terminal)}` : null,
              date: trip?.depart_date || null, time: trip ? String(trip.depart_time).slice(0, 5) : null };
          }) });
        }
        req.body.reference = matches[0].reference;
        return route(req, res);   // one match: carry on as if they had typed the reference
      }

      const rows = await select('bookings',
        `tenant_id=eq.${t.id}&reference=eq.${ref}&select=reference,status,total_kobo,contact_name,contact_phone,channel,created_at,` +
        `passengers(id,full_name,seat_no,status,trip:trips(id,depart_date,depart_time,route:routes(from_terminal,to_terminal))),payments(status,channel,amount_kobo)`);
      if (!rows.length) return fail(res, 404, 'not_found', 'No booking with that reference');
      const terminals = await select('terminals', `tenant_id=eq.${t.id}&select=id,city`);
      const city = id => terminals.find(x => x.id === id)?.city || '';
      const b = rows[0], trip = b.passengers[0]?.trip;
      return res.status(200).json({ booking: {
        reference: b.reference, status: b.status, total: money(b.total_kobo), channel: b.channel,
        contact: { name: b.contact_name, phone: b.contact_phone },
        trip: trip ? { id: trip.id, date: trip.depart_date, time: String(trip.depart_time).slice(0, 5), from: city(trip.route?.from_terminal), to: city(trip.route?.to_terminal) } : null,
        passengers: b.passengers.map(p => ({ id: p.id, name: p.full_name, seat: p.seat_no, status: p.status })),
        paid: (b.payments || []).some(p => p.status === 'success')
      } });
    }

    /* --------------------------------------------------------- bookings list */
    if (action === 'bookings-search') {
      if (!can(staff, ...DESK, 'manager', 'accountant')) return fail(res, 403, 'forbidden', 'Your role cannot look up bookings');
      const f = readFilters(req.body);
      const raw = String(req.body.q || '').trim();
      const to = DAY.test(req.body.to || '') ? req.body.to : null;
      const from = DAY.test(req.body.from || '') ? req.body.from : null;
      const limit = Math.min(Number(req.body.limit) || 40, 100);

      /* PostgREST 'or' takes a comma-separated list, so a comma or bracket in the search box
         would otherwise change the shape of the query. Strip them rather than escaping. */
      const q = raw.replace(/[(),*]/g, ' ').replace(/\s+/g, ' ').trim();
      const digits = q.replace(/\D/g, '');

      let ids = null;
      if (q) {
        /* A passenger's name is on the passenger row, not the booking, so someone who booked
           for a friend is only findable this way. */
        /* passengers carries no tenant_id, so the scope has to come through the booking.
           !inner makes the embed a filter rather than a decoration — without it this returned
           every operator's passengers matching the name, and a clerk searching "Blessing"
           would have pulled back another company's booking ids. */
        const byPax = await select('passengers',
          `full_name=ilike.*${encodeURIComponent(q)}*&booking.tenant_id=eq.${t.id}` +
          `&select=booking_id,booking:bookings!inner(tenant_id)&limit=200`);
        ids = [...new Set(byPax.map(x => x.booking_id).filter(Boolean))];
      }

      const terms = [];
      if (q) {
        terms.push(`reference.ilike.*${q}*`);
        terms.push(`contact_name.ilike.*${q}*`);
        if (q.includes('@')) terms.push(`contact_email.ilike.*${q}*`);
        /* Phones are stored as typed — '0800 000 0000', '+2348000000000' — so match on the
           last digits the caller gives rather than the exact string. */
        if (digits.length >= 4) terms.push(`contact_phone.ilike.*${digits.slice(-7)}*`);
        if (ids && ids.length) terms.push(`id.in.(${ids.join(',')})`);
      }

      const parts = [`tenant_id=eq.${t.id}`];
      if (terms.length) parts.push(`or=(${terms.join(',')})`);
      if (f.status) parts.push(`status=eq.${f.status}`);
      if (f.channel) parts.push(`channel=eq.${f.channel}`);
      if (from) parts.push(`created_at=gte.${DAY_START(from)}`);
      if (to) parts.push(`created_at=lte.${DAY_END(to)}`);
      parts.push('select=id,reference,status,channel,total_kobo,contact_name,contact_phone,contact_email,created_at,' +
        'passengers(full_name,seat_no,status,trip:trips(depart_date,depart_time,route:routes(from_terminal,to_terminal))),' +
        'payments(status,amount_kobo)');
      parts.push('order=created_at.desc');
      parts.push(`limit=${limit}`);

      const rows = await select('bookings', parts.join('&'));
      const terminals = await select('terminals', `tenant_id=eq.${t.id}&select=id,city`);
      const city = id => terminals.find(x => x.id === id)?.city || '';

      const out = rows.map(b => {
        const trip = b.passengers[0]?.trip;
        const paid = (b.payments || []).filter(p => p.status === 'success').reduce((a, p) => a + p.amount_kobo, 0);
        return {
          reference: b.reference, status: b.status, channel: b.channel,
          name: b.contact_name, phone: b.contact_phone, email: b.contact_email,
          total: money(b.total_kobo), paid: money(paid),
          seats: b.passengers.map(x => x.seat_no).sort((x, y) => x - y),
          passengers: b.passengers.map(x => x.full_name),
          route: trip ? `${city(trip.route?.from_terminal)} → ${city(trip.route?.to_terminal)}` : null,
          fromTerminal: trip?.route?.from_terminal || null,
          date: trip?.depart_date || null, time: trip ? String(trip.depart_time).slice(0, 5) : null,
          created: b.created_at
        };
      }).filter(b => !f.terminal || b.fromTerminal === f.terminal);

      return res.status(200).json({
        query: raw, count: out.length, limited: rows.length >= limit,
        options: {
          statuses: ['pending', 'confirmed', 'cancelled', 'refunded', 'expired', 'no_show', 'completed'],
          channels: ['web', 'terminal', 'phone', 'whatsapp', 'api'],
          terminals: terminals.map(x => ({ id: x.id, label: x.city }))
        },
        bookings: out
      });
    }

    /* ------------------------------------------------------------- takings */
    if (action === 'ops-alert-resolve') {
      if (!can(staff, 'manager')) return fail(res, 403, 'forbidden', 'Managers only');
      const id = uuidOrNull(req.body.id); const note = String(req.body.note || '').trim().slice(0, 300);
      if (!id) return fail(res, 400, 'bad_request', 'Which alert?');
      const done = await update('ops_alerts', `id=eq.${id}&tenant_id=eq.${t.id}&resolved_at=is.null`,
        { resolved_at: new Date().toISOString(), resolved_by: `${staff.name}${note ? `: ${note}` : ''}` });
      if (!done?.length) return fail(res, 409, 'already', 'Already dealt with');
      await audit({ tenant_id: t.id, actor_type: 'staff', actor_id: staff.id, action: 'ops_alert.resolved', entity: 'ops_alert', entity_id: id, detail: { by: staff.name, note } });
      return res.status(200).json({ ok: true });
    }

    if (action === 'refund-request-done') {
      if (!can(staff, 'manager', 'accountant', 'terminal_manager'))
        return fail(res, 403, 'forbidden', 'A manager or the accountant has to record a refund');
      const id = uuidOrNull(req.body.id);
      const paid = req.body.decision === 'paid' ? true : req.body.decision === 'rejected' ? false : null;
      const note = String(req.body.note || '').trim().slice(0, 300);
      if (!id || paid === null) return fail(res, 400, 'bad_request', 'Which refund, and was it paid?');
      if (note.length < 3) return fail(res, 400, 'need_note', paid ? 'Say how the money was sent' : 'Say why it is being declined');
      const own = await select('refunds', `id=eq.${id}&tenant_id=eq.${t.id}&select=id,amount_kobo,booking_id`);
      if (!own.length) return fail(res, 404, 'not_found', 'No such refund');
      const outcome = await rpc('process_refund', { p_refund: id, p_staff: staff.id, p_paid: paid, p_note: note });
      if (outcome === 'already') return fail(res, 409, 'already', 'That refund has already been dealt with');
      await audit({ tenant_id: t.id, actor_type: 'staff', actor_id: staff.id, action: paid ? 'refund.paid' : 'refund.declined',
        entity: 'booking', entity_id: own[0].booking_id, detail: { by: staff.name, note, amount_kobo: own[0].amount_kobo } });
      return res.status(200).json({ ok: true, outcome });
    }

    if (action === 'payment-attention-done') {
      if (!can(staff, 'manager', 'accountant', 'terminal_manager'))
        return fail(res, 403, 'forbidden', 'A manager or the accountant has to close this');
      const id = uuidOrNull(req.body.id);
      const note = String(req.body.note || '').trim().slice(0, 300);
      if (!id) return fail(res, 400, 'bad_request', 'Which payment?');
      if (note.length < 3) return fail(res, 400, 'need_note', 'Say what was done — refunded, re-seated, or something else');
      const rows = await update('payments',
        `id=eq.${id}&tenant_id=eq.${t.id}&needs_attention=not.is.null&attention_handled_at=is.null`,
        { attention_handled_at: new Date().toISOString() });
      if (!rows.length) return fail(res, 404, 'not_found', 'That one has already been dealt with');
      await audit({ tenant_id: t.id, actor_type: 'staff', actor_id: staff.id, action: 'payment.attention_handled',
        entity: 'payment', entity_id: id, detail: { by: staff.name, note, amount_kobo: rows[0].amount_kobo } });
      return res.status(200).json({ ok: true });
    }

    if (action === 'takings') {
      /* Who sees whose money. Managers, terminal managers and the accountant see the whole
         company. A clerk sees their terminal — not just their own till, because a desk covers
         for itself and the drawer is counted per terminal. A driver sees only the trips they
         drove. Anyone else has no business here. */
      if (!can(staff, 'manager', 'terminal_manager', 'accountant', ...DESK, 'driver')) {
        return fail(res, 403, 'forbidden', 'Your role cannot see takings');
      }
      const date = DAY.test(req.body.date || '') ? req.body.date : today();
      const rows = await select('payments',
        `tenant_id=eq.${t.id}&status=eq.success&created_at=gte.${DAY_START(date)}&created_at=lte.${DAY_END(date)}` +
        `&select=amount_kobo,channel,recorded_by,booking:bookings(reference,channel,contact_name,` +
        `passengers(trip:trips(id,driver_id,route:routes(from_terminal))))&order=created_at.desc`);

      let mine = rows, scope = 'the whole company';
      if (can(staff, 'terminal')) {
        /* Taken by anyone at this terminal, or against a departure leaving from it. */
        const mates = staff.terminalId
          ? await select('staff', `tenant_id=eq.${t.id}&terminal_id=eq.${staff.terminalId}&select=id`) : [];
        const ids = new Set(mates.map(x => x.id));
        mine = rows.filter(r => ids.has(r.recorded_by) ||
          (r.booking?.passengers || []).some(p => p.trip?.route?.from_terminal === staff.terminalId));
        scope = 'this terminal';
      } else if (can(staff, 'driver')) {
        const me = await select('drivers', `tenant_id=eq.${t.id}&staff_id=eq.${staff.id}&select=id`);
        const dids = new Set(me.map(x => x.id));
        mine = dids.size ? rows.filter(r => (r.booking?.passengers || []).some(p => dids.has(p.trip?.driver_id))) : [];
        scope = 'your trips';
      }
      const byChannel = {};
      mine.forEach(r => { byChannel[r.channel || 'online'] = (byChannel[r.channel || 'online'] || 0) + r.amount_kobo; });
      return res.status(200).json({
        date, scope, count: mine.length, total: money(mine.reduce((a, r) => a + r.amount_kobo, 0)),
        byChannel: Object.fromEntries(Object.entries(byChannel).map(([k, v]) => [k, money(v)])),
        rows: mine.slice(0, 60).map(r => ({ amount: money(r.amount_kobo), channel: r.channel, reference: r.booking?.reference, name: r.booking?.contact_name }))
      });
    }

    /* ------------------------------------------------------- manager: today */
    if (action === 'dashboard') {
      if (!can(staff, 'manager')) return fail(res, 403, 'forbidden', 'Managers only');
      const date = DAY.test(req.body.date || '') ? req.body.date : today();
      const f = readFilters(req.body);
      const summary = await rpc('ops_summary', { p_tenant: t.id, p_date: date });
      let trips = await select('trips',
        `tenant_id=eq.${t.id}&depart_date=eq.${date}&select=id,depart_time,capacity,status,route:routes(id,from_terminal,to_terminal),` +
        `vehicle:vehicles(id,label,plate),driver:drivers(id,name),trip_seats(state),passengers(status)&order=depart_time.asc`);

      /* Filters narrow the departures and the numbers above them together — a terminal's
         seat count next to the whole company's revenue would be worse than no filter at all. */
      const filtered = trips.filter(tr =>
        (!f.terminal || tr.route?.from_terminal === f.terminal) &&
        (!f.routeId || tr.route?.id === f.routeId) &&
        (!f.vehicleId || tr.vehicle?.id === f.vehicleId) &&
        (!f.driverId || tr.driver?.id === f.driverId) &&
        (!f.status || tr.status === f.status));
      const narrowed = filtered.length !== trips.length;
      trips = filtered;
      const terminals = await select('terminals', `tenant_id=eq.${t.id}&select=id,city`);
      const city = id => terminals.find(x => x.id === id)?.city || '';
      /* The trail records actor_id but there is no foreign key to staff, so PostgREST cannot
         join it — resolve the names here instead. Without this the manager sees "staff signed
         in" with no idea who signed in. */
      const recentRaw = await select('audit_log',
        `tenant_id=eq.${t.id}&select=action,detail,created_at,actor_id,actor_type,entity,entity_id&order=created_at.desc&limit=40`);
      const people = await select('staff', `tenant_id=eq.${t.id}&select=id,name`);
      const nameOf = id => (people.find(x => x.id === id) || {}).name || null;
      /* The readable line is built here, where the terminal codes, the tenant and the kobo
         conversion all live. The browser was printing raw keys — "payment cash · terminal cal
         · total ₦36,000" — which is the audit row, not a sentence. */
      const terms = await select('terminals', `tenant_id=eq.${t.id}&select=code,city`);
      const cityOfCode = c => (terms.find(x => x.city && x.code === c) || {}).city || c;
      const naira = k => money(Number(k || 0));

      const summarise = (action, d) => {
        const seats = Array.isArray(d.seats) && d.seats.length
          ? `Seat${d.seats.length > 1 ? 's' : ''} ${d.seats.join(', ')}` : null;
        if (action.startsWith('passenger.'))
          return [d.seat != null ? `Seat ${d.seat}` : null, d.passenger].filter(Boolean).join(' · ');
        if (action === 'booking.created_at_terminal')
          return [seats, d.payment, d.total_kobo != null ? naira(d.total_kobo) : null,
                  d.coupon ? `credit ${d.coupon}` : null,
                  d.terminal ? `${cityOfCode(d.terminal)} desk` : null].filter(Boolean).join(' · ');
        if (action === 'booking.created')
          return [seats, d.channel, d.total_kobo != null ? naira(d.total_kobo) : null].filter(Boolean).join(' · ');
        if (action.startsWith('booking.refunded') || action.startsWith('booking.cancelled'))
          return [d.refund_kobo ? `refunded ${naira(d.refund_kobo)}` : 'no money returned', d.reason].filter(Boolean).join(' · ');
        if (action.startsWith('payment.')) return d.amount_kobo != null ? naira(d.amount_kobo) : '';
        if (action === 'staff.signed_in') return d.role || '';
        if (action === 'expense.recorded')
          return [d.category, d.payee, d.amount_kobo != null ? naira(d.amount_kobo) : null].filter(Boolean).join(' · ');
        if (action.startsWith('loyalty.'))
          return [d.code, d.value_kobo != null ? naira(d.value_kobo) : null, d.email].filter(Boolean).join(' · ');
        /* Anything without a rule: readable pairs, skipping what the row already shows. */
        return Object.entries(d)
          .filter(([k, v]) => !['by','reference','booking','seats'].includes(k)
            && v !== null && v !== undefined && v !== '' && typeof v !== 'object')
          .map(([k, v]) => /_kobo$/.test(k) ? `${k.replace(/_kobo$/, '').replace(/_/g, ' ')} ${naira(v)}`
                                            : `${k.replace(/_/g, ' ')} ${v}`)
          .join(' · ');
      };

      const recent = recentRaw.map(a => {
        const d = a.detail || {};
        return { action: a.action, created_at: a.created_at, detail: d,
          by: d.by || nameOf(a.actor_id) || (a.actor_type === 'system' ? 'System'
                : a.actor_type === 'provider' ? 'Paystack' : a.actor_type === 'customer' ? 'Customer' : null),
          reference: d.reference || d.booking || null,
          summary: summarise(a.action, d) };
      });
      let shown = summary;
      if (narrowed) {
        /* Recomputed from the departures actually on screen, revenue included, so nothing
           on this page is counting something the filter excluded. */
        const seats = trips.flatMap(tr => tr.trip_seats || []);
        const pax = trips.flatMap(tr => tr.passengers || []);
        let revenue = 0;
        if (trips.length) {
          const ids = trips.map(tr => tr.id).join(',');
          const paxRows = await select('passengers', `trip_id=in.(${ids})&select=booking_id`);
          const bookingIds = [...new Set(paxRows.map(p => p.booking_id).filter(Boolean))];
          if (bookingIds.length) {
            const pays = await select('payments',
              `tenant_id=eq.${t.id}&status=eq.success&booking_id=in.(${bookingIds.join(',')})&select=amount_kobo`);
            revenue = pays.reduce((a, p) => a + p.amount_kobo, 0);
          }
        }
        shown = {
          trips: trips.length,
          seats_total: trips.reduce((a, tr) => a + tr.capacity, 0),
          seats_sold: seats.filter(x => x.state === 'sold').length,
          seats_held: seats.filter(x => x.state === 'held').length,
          revenue_kobo: revenue,
          checked_in: pax.filter(x => ['checked_in', 'boarded'].includes(x.status)).length,
          no_shows: pax.filter(x => x.status === 'no_show').length,
          pending: summary.pending
        };
      }

      const routes = await select('routes', `tenant_id=eq.${t.id}&select=id,from_terminal,to_terminal`);
      const vehicles = await select('vehicles', `tenant_id=eq.${t.id}&select=id,label,plate&order=label.asc`);
      const drivers = await select('drivers', `tenant_id=eq.${t.id}&active=is.true&select=id,name&order=name.asc`);

      /* Feeds the Messages card on the launcher: an unanswered complaint should be visible
         from the front door, not only to whoever thinks to open the screen. Deliberately
         swallowed on failure — a dashboard is not worth losing over a badge. */
      let messagesOpen = null;
      try {
        const openMsgs = await select('feedback', `tenant_id=eq.${t.id}&handled_at=is.null&select=id&limit=100`);
        messagesOpen = openMsgs.length;
      } catch (err) { console.error('open message count failed:', err.message); }

      return res.status(200).json({
        summary: shown, date, narrowed, messagesOpen,
        options: {
          terminals: terminals.map(x => ({ id: x.id, label: x.city })),
          routes: routes.map(r => ({ id: r.id, label: `${city(r.from_terminal)} → ${city(r.to_terminal)}` })),
          vehicles: vehicles.map(v => ({ id: v.id, label: `${v.label}${v.plate ? ' · ' + v.plate : ''}` })),
          drivers: drivers.map(d => ({ id: d.id, label: d.name })),
          statuses: ['scheduled', 'boarding', 'departed', 'arrived', 'completed', 'cancelled']
        },
        trips: trips.map(tr => {
          const seats = tr.trip_seats || [];
          return { id: tr.id, time: String(tr.depart_time).slice(0, 5), status: tr.status,
            route: `${city(tr.route?.from_terminal)} → ${city(tr.route?.to_terminal)}`,
            vehicle: tr.vehicle ? `${tr.vehicle.label}${tr.vehicle.plate ? ' · ' + tr.vehicle.plate : ''}` : '', driver: tr.driver?.name || null,
            capacity: tr.capacity, sold: seats.filter(s => s.state === 'sold').length,
            held: seats.filter(s => s.state === 'held').length,
            checkedIn: (tr.passengers || []).filter(p => ['checked_in', 'boarded'].includes(p.status)).length };
        }),
        recent
      });
    }

    /* --------------------------------------------------- accountant: money */
    if (action === 'finance') {
      if (!can(staff, 'manager', 'accountant')) return fail(res, 403, 'forbidden', 'Finance is for managers and accountants');
      const from = DAY.test(req.body.from || '') ? req.body.from : today();
      const to = DAY.test(req.body.to || '') ? req.body.to : today();
      const pays = await select('payments',
        `tenant_id=eq.${t.id}&created_at=gte.${DAY_START(from)}&created_at=lte.${DAY_END(to)}&select=amount_kobo,status,provider,channel,created_at,booking:bookings(reference,channel)&order=created_at.desc`);
      const fF = readFilters(req.body);
      const ok = pays.filter(p => p.status === 'success'
        && (!fF.method || (p.channel || p.provider) === fF.method)
        && (!fF.channel || (p.booking?.channel || 'web') === fF.channel));
      const byMethod = {}, byChannel = {};
      ok.forEach(p => {
        byMethod[p.channel || p.provider] = (byMethod[p.channel || p.provider] || 0) + p.amount_kobo;
        const c = p.booking?.channel || 'web'; byChannel[c] = (byChannel[c] || 0) + p.amount_kobo;
      });
      const pending = await select('bookings', `tenant_id=eq.${t.id}&status=eq.pending&select=reference,total_kobo,contact_phone,created_at&order=created_at.desc&limit=40`);
      return res.status(200).json({
        from, to,
        options: {
          methods: [...new Set(pays.filter(p => p.status === 'success').map(p => p.channel || p.provider))].filter(Boolean).sort(),
          channels: [...new Set(pays.map(p => p.booking?.channel).filter(Boolean))].sort()
        },
        revenue: money(ok.reduce((a, p) => a + p.amount_kobo, 0)),
        count: ok.length,
        failed: pays.filter(p => p.status === 'failed').length,
        byMethod: Object.fromEntries(Object.entries(byMethod).map(([k, v]) => [k, money(v)])),
        byChannel: Object.fromEntries(Object.entries(byChannel).map(([k, v]) => [k, money(v)])),
        pending: pending.map(b => ({ reference: b.reference, amount: money(b.total_kobo), phone: b.contact_phone, created: b.created_at })),
        rows: ok.slice(0, 80).map(p => ({ amount: money(p.amount_kobo), method: p.channel || p.provider, reference: p.booking?.reference, channel: p.booking?.channel, at: p.created_at }))
      });
    }

    /* ------------------------------------------------ manager: loyalty scheme */
    if (action === 'loyalty-settings') {
      if (!can(staff, 'manager')) return fail(res, 403, 'forbidden', 'Managers only');
      const cfg = (t.settings || {}).loyalty || {};
      const s2 = {
        enabled: cfg.enabled !== false,
        pointsPerTrip: Number(cfg.points_per_trip ?? 10),
        pointsPerCoupon: Number(cfg.points_per_coupon ?? 100),
        couponValue: Number(cfg.coupon_value_kobo ?? 500000) / 100,
        expiryDays: Number(cfg.coupon_expiry_days ?? 180)
      };
      /* What the scheme has actually cost and owes, so it is not run blind. */
      const issued = await select('coupons', `tenant_id=eq.${t.id}&select=value_kobo,redeemed_at,expires_at`);
      const live = issued.filter(c => !c.redeemed_at && (!c.expires_at || Date.parse(c.expires_at) > Date.now()));
      const ledger = await select('loyalty_ledger', `tenant_id=eq.${t.id}&select=points,reason`);
      return res.status(200).json({
        settings: s2,
        stats: {
          couponsIssued: issued.length,
          couponsRedeemed: issued.filter(c => c.redeemed_at).length,
          outstanding: live.length,
          outstandingValue: money(live.reduce((a, c) => a + c.value_kobo, 0)),
          pointsLive: ledger.reduce((a, r) => a + r.points, 0),
          tripsAwarded: ledger.filter(r => r.reason === 'trip').length
        }
      });
    }

    if (action === 'loyalty-save') {
      if (!can(staff, 'manager')) return fail(res, 403, 'forbidden', 'Managers only');
      const { enabled, pointsPerTrip, pointsPerCoupon, couponValue, expiryDays } = req.body;
      const per = Number(pointsPerTrip), need = Number(pointsPerCoupon);
      const value = Math.round(Number(couponValue) * 100), days = Number(expiryDays);
      if (!Number.isInteger(per) || per < 0 || per > 1000) return fail(res, 400, 'bad_points', 'Points per trip must be 0 to 1000');
      if (!Number.isInteger(need) || need < 1 || need > 100000) return fail(res, 400, 'bad_threshold', 'Points per credit must be at least 1');
      if (!Number.isInteger(value) || value <= 0) return fail(res, 400, 'bad_value', 'Give the credit a value');
      if (!Number.isInteger(days) || days < 0 || days > 3650) return fail(res, 400, 'bad_expiry', 'Expiry must be 0 to 3650 days');

      /* A trip should never be worth more in credit than the fare itself — that is a scheme
         that pays people to travel, and it is easier to catch here than in the accounts. */
      const routes = await select('routes', `tenant_id=eq.${t.id}&active=is.true&select=fare_kobo`);
      const cheapest = Math.min(...routes.map(r => r.fare_kobo), Infinity);
      if (per > 0 && Number.isFinite(cheapest)) {
        const perTripValue = value * per / need;
        if (perTripValue > cheapest) {
          return fail(res, 400, 'too_generous',
            `That earns ${money(perTripValue)} of credit per trip on a ${money(cheapest)} fare. Lower the credit or raise the points needed.`);
        }
      }

      const settings = { ...(t.settings || {}), loyalty: {
        enabled: enabled !== false, points_per_trip: per, points_per_coupon: need,
        coupon_value_kobo: value, coupon_expiry_days: days
      } };
      await update('tenants', `id=eq.${t.id}`, { settings });
      await audit({ tenant_id: t.id, actor_type: 'staff', actor_id: staff.id, action: 'loyalty.settings_changed', entity: 'tenant', entity_id: t.id,
        detail: { by: staff.name, ...settings.loyalty } });
      return res.status(200).json({ ok: true });
    }

    /* --------------------------------------------------- manager: staff */
    if (action === 'staff-list') {
      if (!can(staff, 'manager')) return fail(res, 403, 'forbidden', 'Managers only');
      const archived = Boolean(req.body.archived);
      const rows = await select('staff',
        `tenant_id=eq.${t.id}&active=is.${archived ? 'false' : 'true'}` +
        `&select=id,name,email,phone,role,terminal_id,active,archived_at,created_at,must_change_password,password_set_at,email_verified_at,terminal:terminals(code,city)&order=name.asc`);
      const terminals = await select('terminals', `tenant_id=eq.${t.id}&select=id,code,city&order=city.asc`);
      return res.status(200).json({
        archived, terminals,
        staff: rows.map(r => ({ id: r.id, name: r.name, email: r.email, phone: r.phone, role: r.role,
          terminalId: r.terminal_id, terminal: r.terminal?.city || null,
          since: r.created_at, archivedAt: r.archived_at, isYou: r.id === staff.id,
          mustChange: r.must_change_password, passwordSet: r.password_set_at, emailVerified: Boolean(r.email_verified_at) }))
      });
    }

    if (action === 'staff-add') {
      if (!can(staff, 'manager')) return fail(res, 403, 'forbidden', 'Managers only');
      const url = process.env.SUPABASE_URL, key = process.env.SUPABASE_SERVICE_ROLE_KEY;
      if (!url || !key) return fail(res, 503, 'not_configured', 'Cannot create accounts right now');

      const name = String(req.body.name || '').trim();
      const email = String(req.body.email || '').trim().toLowerCase();
      const role = String(req.body.role || '');
      const phone = String(req.body.phone || '').trim();
      const terminalId = req.body.terminalId || null;

      if (name.length < 3) return fail(res, 400, 'bad_name', 'Give their full name');
      if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return fail(res, 400, 'bad_email', 'Check the email address');
      if (!['manager', 'terminal_manager', 'terminal', 'accountant', 'driver'].includes(role)) return fail(res, 400, 'bad_role', 'Pick a role');
      if (DESK.includes(role) && !UUID.test(terminalId || '')) return fail(res, 400, 'bad_terminal', 'Desk staff belong to a terminal');
      /* The drivers table needs a phone, and without one the staff account can never be tied to
         a driver record — which used to mean archiving the person left the driver on the rota. */
      if (role === 'driver' && !PHONE.test(phone)) return fail(res, 400, 'bad_phone', 'A driver needs a phone number so their driving record can be linked');

      const existing = await select('staff', `tenant_id=eq.${t.id}&email=eq.${encodeURIComponent(email)}&select=id,active`);
      if (existing.length) {
        return fail(res, 409, 'exists', existing[0].active
          ? 'Someone already works here with that email'
          : 'That email belongs to an archived account — restore it instead of adding a new one');
      }

      /* A readable one-off password. They sign in with it and it is shown to the manager once,
         because there is no email delivery for staff invitations yet. */
      const password = tempPassword();

      let authId;
      try {
        const r = await fetch(`${url}/auth/v1/admin/users`, {
          method: 'POST',
          headers: { apikey: key, Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
          body: JSON.stringify({ email, password, email_confirm: true })
        });
        const data = await r.json();
        if (!r.ok || !data.id) {
          console.error('auth user create failed:', JSON.stringify(data).slice(0, 300));
          return fail(res, 502, 'auth_failed', data.msg || data.message || 'Could not create the sign-in account');
        }
        authId = data.id;
      } catch (err) {
        console.error('auth admin unreachable:', err.message);
        return fail(res, 502, 'auth_failed', 'Could not reach the sign-in service');
      }

      let row;
      try {
        [row] = await insert('staff', [{ tenant_id: t.id, auth_user_id: authId, name: name.slice(0, 120),
          email, phone: phone ? phone.slice(0, 32) : null, role, must_change_password: true,
          terminal_id: DESK.includes(role) ? terminalId : (UUID.test(terminalId || '') ? terminalId : null), active: true }]);
      } catch (err) {
        /* Do not leave an orphan sign-in account behind if the staff row fails. */
        try {
          await fetch(`${url}/auth/v1/admin/users/${authId}`, { method: 'DELETE', headers: { apikey: key, Authorization: `Bearer ${key}` } });
        } catch {}
        throw err;
      }

      if (role === 'driver') {
        /* Match on phone first — it is unique per tenant, while two people can share a name. */
        const digits = phone.replace(/\D/g, '').slice(-9);
        const byPhone = digits ? await select('drivers', `tenant_id=eq.${t.id}&phone=ilike.*${digits}*&select=id,staff_id`) : [];
        const byName = byPhone.length ? [] : await select('drivers', `tenant_id=eq.${t.id}&staff_id=is.null&name=eq.${encodeURIComponent(name)}&select=id`);
        const match = byPhone[0] || byName[0];
        if (match) await update('drivers', `id=eq.${match.id}`, { staff_id: row.id, active: true });
        else await insert('drivers', [{ tenant_id: t.id, staff_id: row.id, name: name.slice(0, 120), phone: phone.slice(0, 32), active: true }], 'return=minimal');
      }

      await audit({ tenant_id: t.id, actor_type: 'staff', actor_id: staff.id, action: 'staff.added', entity: 'staff', entity_id: row.id,
        detail: { by: staff.name, name, email, role } });
      return res.status(201).json({ id: row.id, email, password, role });
    }

    if (action === 'staff-reset-password') {
      if (!can(staff, 'manager')) return fail(res, 403, 'forbidden', 'Managers only');
      const { staffId } = req.body;
      if (!UUID.test(staffId || '')) return fail(res, 400, 'bad_staff', 'Unknown staff member');
      const url = process.env.SUPABASE_URL, key = process.env.SUPABASE_SERVICE_ROLE_KEY;
      if (!url || !key) return fail(res, 503, 'not_configured', 'Cannot reset passwords right now');

      const rows = await select('staff', `id=eq.${staffId}&tenant_id=eq.${t.id}&select=id,name,auth_user_id,active`);
      if (!rows.length) return fail(res, 404, 'not_found', 'No such staff member');
      const person = rows[0];
      if (!person.auth_user_id) return fail(res, 409, 'no_account', 'That person has no sign-in account yet');

      const password = tempPassword();
      const r = await fetch(`${url}/auth/v1/admin/users/${person.auth_user_id}`, {
        method: 'PUT', headers: { apikey: key, Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({ password })
      });
      if (!r.ok) {
        const data = await r.json().catch(() => ({}));
        console.error('reset failed:', JSON.stringify(data).slice(0, 300));
        return fail(res, 502, 'auth_failed', 'Could not reset that password');
      }
      /* They must replace it on next sign-in, so this temporary one is never a working password
         for longer than one login. */
      await update('staff', `id=eq.${staffId}&tenant_id=eq.${t.id}`, { must_change_password: true });
      await audit({ tenant_id: t.id, actor_type: 'staff', actor_id: staff.id, action: 'staff.password_reset', entity: 'staff', entity_id: staffId,
        detail: { by: staff.name, name: person.name } });
      return res.status(200).json({ password, name: person.name });
    }

    if (action === 'staff-archive' || action === 'staff-restore') {
      if (!can(staff, 'manager')) return fail(res, 403, 'forbidden', 'Managers only');
      const { staffId } = req.body;
      if (!UUID.test(staffId || '')) return fail(res, 400, 'bad_staff', 'Unknown staff member');
      if (staffId === staff.id) return fail(res, 400, 'not_yourself', 'You cannot archive your own account');

      const rows = await select('staff', `id=eq.${staffId}&tenant_id=eq.${t.id}&select=id,name,role,phone,auth_user_id,active`);
      if (!rows.length) return fail(res, 404, 'not_found', 'No such staff member');
      const person = rows[0];
      const archiving = action === 'staff-archive';

      if (archiving) {
        /* Last manager standing: locking yourself out of your own company is not recoverable
           from inside the app. */
        const managers = await select('staff', `tenant_id=eq.${t.id}&role=eq.manager&active=is.true&select=id`);
        if (person.role === 'manager' && managers.length <= 1) return fail(res, 409, 'last_manager', 'That is the only manager left. Add another before archiving this one.');
      }

      await update('staff', `id=eq.${staffId}&tenant_id=eq.${t.id}`, archiving
        ? { active: false, archived_at: new Date().toISOString(), archived_by: staff.id }
        : { active: true, archived_at: null, archived_by: null });

      /* Their history stays attributed to them; only the ability to sign in changes. */
      const url = process.env.SUPABASE_URL, key = process.env.SUPABASE_SERVICE_ROLE_KEY;
      if (person.auth_user_id && url && key) {
        try {
          await fetch(`${url}/auth/v1/admin/users/${person.auth_user_id}`, {
            method: 'PUT', headers: { apikey: key, Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
            body: JSON.stringify({ ban_duration: archiving ? '876000h' : 'none' })
          });
        } catch (err) { console.error('could not change sign-in status:', err.message); }
      }
      /* Deactivating by staff_id alone missed anyone whose driver record was added separately
         on the Drivers screen, so an archived driver kept appearing on the rota. Fall back to
         the phone, then the name, and link the rows while we are here so it cannot recur. */
      if (person.role === 'driver') {
        let linked = await select('drivers', `tenant_id=eq.${t.id}&staff_id=eq.${staffId}&select=id`);
        if (!linked.length) {
          const digits = String(person.phone || '').replace(/\D/g, '').slice(-9);
          if (digits) linked = await select('drivers', `tenant_id=eq.${t.id}&phone=ilike.*${digits}*&select=id`);
          if (!linked.length && person.name) {
            linked = await select('drivers', `tenant_id=eq.${t.id}&name=eq.${encodeURIComponent(person.name)}&select=id`);
          }
        }
        for (const d of linked) {
          await update('drivers', `id=eq.${d.id}&tenant_id=eq.${t.id}`, { active: !archiving, staff_id: staffId });
        }
        if (!linked.length) {
          console.warn('archived driver has no driver record:', person.name);
        }
      }

      await audit({ tenant_id: t.id, actor_type: 'staff', actor_id: staff.id, action: archiving ? 'staff.archived' : 'staff.restored',
        entity: 'staff', entity_id: staffId, detail: { by: staff.name, name: person.name } });
      return res.status(200).json({ ok: true });
    }

    if (action === 'staff-activity') {
      if (!can(staff, 'manager')) return fail(res, 403, 'forbidden', 'Managers only');
      const { staffId } = req.body;
      if (!UUID.test(staffId || '')) return fail(res, 400, 'bad_staff', 'Unknown staff member');
      const to = DAY.test(req.body.to || '') ? req.body.to : today();
      const from = DAY.test(req.body.from || '') ? req.body.from : new Date(Date.now() - 29 * 864e5).toISOString().slice(0, 10);

      const rows = await select('staff', `id=eq.${staffId}&tenant_id=eq.${t.id}&select=id,name,email,phone,role,active,archived_at,created_at,terminal:terminals(city)`);
      if (!rows.length) return fail(res, 404, 'not_found', 'No such staff member');
      const person = rows[0];

      const summary = await rpc('staff_activity', { p_staff: staffId, p_from: from, p_to: to });
      const bookings = await select('bookings',
        `tenant_id=eq.${t.id}&created_by=eq.${staffId}&select=reference,status,total_kobo,contact_name,created_at&order=created_at.desc&limit=25`);
      const log = await select('audit_log',
        `tenant_id=eq.${t.id}&actor_id=eq.${staffId}&select=action,detail,created_at&order=created_at.desc&limit=40`);

      return res.status(200).json({
        from, to,
        person: { id: person.id, name: person.name, email: person.email, phone: person.phone, role: person.role,
          active: person.active, archivedAt: person.archived_at, since: person.created_at, terminal: person.terminal?.city || null },
        summary: { bookings: summary.bookings, sales: money(summary.sales_kobo), refunds: money(summary.refunds_kobo),
          checkIns: summary.check_ins, actions: summary.actions },
        bookings: bookings.map(b => ({ reference: b.reference, status: b.status, total: money(b.total_kobo), name: b.contact_name, at: b.created_at })),
        log: log.map(a => ({ action: a.action, detail: a.detail, at: a.created_at }))
      });
    }


    /* ------------------------------------------------------- notifications
       Two lists, deliberately kept apart.

       "Needs attention" is derived from current state on every call. Nothing is written, so
       nothing can contradict reality: an unpaid hold that gets paid stops appearing, without
       anybody marking it read. It also works on data that already exists, which a stored feed
       never would.

       "Notices" are rows somebody wrote — a manager telling the desks a departure is cancelled.
       Those have no state to derive from, so they are stored and carry real read state.

       Both are scoped by the same rules as the rest of the API: a driver sees their own trips,
       a clerk their terminal, a manager everything. */
    if (action === 'notifications') {
      const soon = new Date(Date.now() + 2 * 3600000).toISOString();
      const nowIso = new Date().toISOString();
      const alerts = [];
      const isManager = can(staff, 'manager', 'terminal_manager');
      const myTerminal = staff.terminalId || null;

      /* A driver is matched through their drivers row, exactly as takings does. */
      let driverId = null;
      if (can(staff, 'driver')) {
        const me = await select('drivers', `tenant_id=eq.${t.id}&staff_id=eq.${staff.id}&select=id`);
        driverId = me[0]?.id || null;
      }

      const dayTrips = await select('trips',
        `tenant_id=eq.${t.id}&depart_date=eq.${today()}&status=eq.scheduled` +
        `&select=id,depart_time,depart_date,capacity,vehicle_id,driver_id,route:routes(from_terminal,to_terminal)`);
      const terms = await select('terminals', `tenant_id=eq.${t.id}&select=id,city`);
      const cityOf = id => (terms.find(x => x.id === id) || {}).city || '';
      const whenOf = tr => `${String(tr.depart_time).slice(0, 5)} ${cityOf(tr.route?.from_terminal)} → ${cityOf(tr.route?.to_terminal)}`;

      const mineTrip = tr => can(staff, 'driver') && !isManager ? tr.driver_id === driverId
        : can(staff, 'terminal') ? tr.route?.from_terminal === myTerminal : true;

      /* A departure leaving within two hours with nobody to drive it. */
      for (const tr of dayTrips.filter(mineTrip)) {
        const departsAt = new Date(`${tr.depart_date}T${String(tr.depart_time).slice(0, 8)}${WAT}`).toISOString();
        if (departsAt > soon || departsAt < nowIso) continue;
        if (!tr.driver_id || !tr.vehicle_id) {
          alerts.push({ key: `unassigned:${tr.id}`, kind: 'urgent',
            title: `${whenOf(tr)} has no ${!tr.driver_id && !tr.vehicle_id ? 'vehicle or driver' : !tr.driver_id ? 'driver' : 'vehicle'}`,
            body: 'It departs within two hours.', view: 'schedule' });
        }
      }

      if (isManager || can(staff, ...DESK)) {
        /* Held seats whose hold lapses within the hour: money about to fall out of the day. */
        const holds = await select('bookings',
          `tenant_id=eq.${t.id}&status=eq.pending&hold_expires_at=not.is.null&hold_expires_at=lte.${new Date(Date.now() + 3600000).toISOString()}` +
          `&select=reference,hold_expires_at,total_kobo&order=hold_expires_at.asc&limit=20`);
        for (const h of holds) {
          alerts.push({ key: `hold:${h.reference}`, kind: 'warning',
            title: `${h.reference} is unpaid and about to lapse`,
            body: `${money(h.total_kobo)} held until ${String(h.hold_expires_at).slice(11, 16)}.`, view: 'bookings' });
        }
      }

      if (isManager) {
        const unread = await select('feedback', `tenant_id=eq.${t.id}&handled_at=is.null&select=id,name,topic&limit=20`);
        if (unread.length) {
          alerts.push({ key: 'feedback', kind: 'warning',
            title: `${unread.length} message${unread.length === 1 ? '' : 's'} waiting for a reply`,
            body: unread.slice(0, 3).map(f => `${f.name} — ${f.topic}`).join('; '), view: 'messages' });
        }
        const failed = await select('payments',
          `tenant_id=eq.${t.id}&status=eq.failed&created_at=gte.${DAY_START(today())}&select=amount_kobo,booking:bookings(reference)&limit=20`);
        if (failed.length) {
          alerts.push({ key: 'failed-payments', kind: 'warning',
            title: `${failed.length} payment${failed.length === 1 ? '' : 's'} failed today`,
            body: failed.slice(0, 3).map(f => f.booking?.reference).filter(Boolean).join(', '), view: 'finance' });
        }
        /* Money that arrived for a seat that could not be kept — a checkout that outlasted its
           hold, or a booking cancelled while the customer was paying. The customer has paid and
           has no ticket. Each one stays here, urgent, until somebody refunds or re-seats them
           and marks it done. */
        if (can(staff, 'manager', 'accountant', 'terminal_manager')) {
          const stranded = await select('payments',
            `tenant_id=eq.${t.id}&needs_attention=not.is.null&attention_handled_at=is.null` +
            `&select=id,amount_kobo,needs_attention,created_at,booking:bookings(reference,contact_name,contact_phone)` +
            `&order=created_at.asc&limit=20`);
          for (const p of stranded) {
            alerts.push({ key: `stranded:${p.id}`, kind: 'urgent', handle: p.id,
              actions: [{ label: 'Mark as dealt with', action: 'payment-attention-done',
                prompt: 'What was done? e.g. "Refunded in Paystack" or "Re-seated on the 14:00"' }],
              title: `Paid ₦${money(p.amount_kobo).toLocaleString('en-NG')} with no seat — ${p.booking?.reference || 'unknown booking'}`,
              body: `${p.needs_attention}. ${p.booking?.contact_name || ''} ${p.booking?.contact_phone || ''}`.trim(),
              view: 'finance' });
          }
        }
        /* Things going wrong in the system itself — the same alerts that are emailed. */
        if (can(staff, 'manager')) {
          const ops = await select('ops_alerts', `tenant_id=eq.${t.id}&resolved_at=is.null&select=id,key,severity,title,detail,count,last_at&order=last_at.desc&limit=15`).catch(() => []);
          for (const o of ops) {
            const d = o.detail || {};
            alerts.push({ key: `ops:${o.id}`, kind: o.severity === 'info' ? 'warning' : o.severity, handle: o.id,
              title: o.title, body: [d.what_to_do || d.why || d.error || '', o.count > 1 ? `(${o.count} times, last ${new Date(o.last_at).toLocaleString('en-GB', { timeZone: 'Africa/Lagos', hour: '2-digit', minute: '2-digit', day: 'numeric', month: 'short' })})` : ''].filter(Boolean).join(' '),
              actions: [{ label: 'Mark as dealt with', action: 'ops-alert-resolve', prompt: 'What was done about it? (goes on the record)' }] });
          }
        }
        /* Refunds owed to customers who cancelled online. The seats are already back on sale; the
           money still has to be sent — in Paystack for card payments, by transfer otherwise — and
           then marked here, which records it against the booking. */
        if (can(staff, 'manager', 'accountant', 'terminal_manager')) {
          const owed = await select('refunds',
            `tenant_id=eq.${t.id}&status=eq.pending&select=id,amount_kobo,reason,created_at,` +
            `booking:bookings(reference,contact_name,contact_phone,payments(status,channel,amount_kobo))&order=created_at.asc&limit=20`);
          for (const r of owed) {
            const via = ((r.booking?.payments || []).find(p => p.status === 'success' && p.amount_kobo > 0 && p.channel !== 'coupon') || {}).channel;
            alerts.push({ key: `refund:${r.id}`, kind: 'urgent', handle: r.id,
              title: `Refund ₦${money(r.amount_kobo).toLocaleString('en-NG')} owed — ${r.booking?.reference || ''}`,
              body: `${r.booking?.contact_name || ''} ${r.booking?.contact_phone || ''} cancelled online. Paid by ${via || 'unknown'}; send it back the same way.`.trim(),
              view: 'finance',
              actions: [
                { label: 'Mark refunded', action: 'refund-request-done', decision: 'paid',
                  prompt: 'How was it sent? e.g. "Refunded in Paystack" or "Transfer to GTB 0123…"' },
                { label: 'Decline', action: 'refund-request-done', decision: 'rejected', subtle: true,
                  prompt: 'Why is this refund being declined? The reason goes on the record.' }
              ] });
          }
        }
        /* The cron lays out departures 45 days ahead. If that stops, the site quietly runs out
           of days to sell and nobody notices until a customer says so. */
        const horizon = await select('trips',
          `tenant_id=eq.${t.id}&status=neq.cancelled&select=depart_date&order=depart_date.desc&limit=1`);
        const last = horizon[0]?.depart_date;
        const daysLeft = last ? Math.round((Date.parse(last) - Date.now()) / 864e5) : 0;
        if (daysLeft < 14) {
          alerts.push({ key: 'horizon', kind: daysLeft < 7 ? 'urgent' : 'warning',
            title: `Only ${daysLeft} day${daysLeft === 1 ? '' : 's'} of departures are on sale`,
            body: 'The nightly job may have stopped. Extend the schedule.', view: 'schedule' });
        }
      }

      /* Stored notices addressed to this person, their role, or everyone. */
      const audiences = [`audience_role.eq.all`, `audience_role.eq.${staff.role}`, `audience_staff.eq.${staff.id}`];
      const notices = await select('notifications',
        `tenant_id=eq.${t.id}&or=(${audiences.join(',')})&order=created_at.desc&limit=30` +
        `&select=id,kind,title,body,created_at,expires_at,by:staff!notifications_created_by_fkey(name)`);
      const live = notices.filter(n => !n.expires_at || n.expires_at > nowIso);
      const reads = live.length
        ? await select('notification_reads', `notification_id=in.(${live.map(n => n.id).join(',')})&reader=eq.${staff.id}&select=notification_id`)
        : [];
      const readSet = new Set(reads.map(r => r.notification_id));

      return res.status(200).json({
        alerts,
        notices: live.map(n => ({ id: n.id, kind: n.kind, title: n.title, body: n.body,
          at: n.created_at, by: n.by?.name || null, read: readSet.has(n.id) })),
        unread: alerts.length + live.filter(n => !readSet.has(n.id)).length
      });
    }

    if (action === 'notification-read') {
      const ids = Array.isArray(req.body.ids) ? req.body.ids.filter(x => UUID.test(x || '')) : [];
      if (!ids.length) return res.status(200).json({ ok: true, marked: 0 });
      /* Upsert semantics without an upsert: a repeated read is not an error. */
      await insert('notification_reads', ids.map(id => ({ notification_id: id, reader: staff.id })),
        'resolution=ignore-duplicates,return=minimal');
      return res.status(200).json({ ok: true, marked: ids.length });
    }

    if (action === 'notification-send') {
      if (!can(staff, 'manager')) return fail(res, 403, 'forbidden', 'Managers only');
      const title = String(req.body.title || '').trim();
      if (title.length < 3) return fail(res, 400, 'bad_title', 'Say what the notice is about');
      const body = String(req.body.body || '').trim().slice(0, 1000) || null;
      const kind = ['notice', 'warning', 'urgent'].includes(req.body.kind) ? req.body.kind : 'notice';
      const to = String(req.body.to || 'all');
      const ROLES = ['manager', 'terminal_manager', 'terminal', 'accountant', 'driver', 'all', 'customers'];
      const row = { tenant_id: t.id, kind, title: title.slice(0, 160), body, created_by: staff.id,
        expires_at: DAY.test(req.body.until || '') ? `${req.body.until}T23:59:59${WAT}` : null };
      if (UUID.test(to)) row.audience_staff = to;
      else if (ROLES.includes(to)) row.audience_role = to;
      else return fail(res, 400, 'bad_audience', 'Choose who this is for');

      const [saved] = await insert('notifications', [row]);
      await audit({ tenant_id: t.id, actor_type: 'staff', actor_id: staff.id, action: 'notification.sent',
        entity: 'notification', entity_id: saved.id, detail: { by: staff.name, to, title: row.title, kind } });
      return res.status(201).json({ ok: true, id: saved.id });
    }

    /* A cheap signature of everything a screen might be showing. The app polls this and only
       reloads when something actually moved — it is not a websocket, but on a terminal's
       connection it is steadier than one, and it costs one small query. */
    if (action === 'pulse') {
      /* Deliberately open to any signed-in member of staff — everyone's screen should refresh.
         The signature only carries what the caller is already allowed to see: the message count
         goes in for the roles that can open Messages, and nowhere else, so a driver cannot infer
         how many complaints are outstanding by watching the number move. */
      const seesMessages = can(staff, 'manager', 'terminal_manager');
      const [lastAudit, lastNotice, openFeedback] = await Promise.all([
        select('audit_log', `tenant_id=eq.${t.id}&select=created_at&order=created_at.desc&limit=1`),
        select('notifications', `tenant_id=eq.${t.id}&select=created_at&order=created_at.desc&limit=1`),
        seesMessages ? select('feedback', `tenant_id=eq.${t.id}&handled_at=is.null&select=id&limit=50`) : Promise.resolve([])
      ]);
      return res.status(200).json({
        at: new Date().toISOString(),
        signature: [lastAudit[0]?.created_at || '', lastNotice[0]?.created_at || '',
                    seesMessages ? openFeedback.length : ''].join('|')
      });
    }

    /* ------------------------------------------------------------ messages
       Contact-page messages, read where the work happens instead of in the Supabase table
       editor. A message is either waiting or handled; handling one records who did it and
       what was done, because the question that actually gets asked later is "did anyone
       ever call this woman back?" */
    if (action === 'feedback-list') {
      if (!can(staff, 'manager', 'terminal_manager')) return fail(res, 403, 'forbidden', 'Managers only');
      const to = DAY.test(req.body.to || '') ? req.body.to : today();
      const from = DAY.test(req.body.from || '') ? req.body.from : new Date(Date.now() - 89 * 864e5).toISOString().slice(0, 10);
      const fM = readFilters(req.body);
      const topic = FEEDBACK_TOPICS.includes(req.body.topic) ? req.body.topic : null;
      const stateOf = ['new', 'handled'].includes(fM.status) ? fM.status : null;

      const q = [
        topic ? `&topic=eq.${encodeURIComponent(topic)}` : '',
        stateOf === 'new' ? '&handled_at=is.null' : '',
        stateOf === 'handled' ? '&handled_at=not.is.null' : ''
      ].join('');

      const rows = await select('feedback',
        `tenant_id=eq.${t.id}&created_at=gte.${DAY_START(from)}&created_at=lte.${DAY_END(to)}${q}` +
        `&select=id,name,email,phone,reference,topic,message,handled_at,handled_note,created_at,` +
        `handler:staff!feedback_handled_by_fkey(name)` +
        `&order=created_at.desc&limit=200`);

      /* An unanswered message must never be hidden by a date range — that is the single
         failure this screen exists to prevent. Count the ones falling outside it so the
         page can say so and offer to widen. */
      const older = await select('feedback',
        `tenant_id=eq.${t.id}&handled_at=is.null&created_at=lt.${DAY_START(from)}&select=id,created_at&order=created_at.asc&limit=100`);

      const waiting = rows.filter(r => !r.handled_at);
      const byTopic = {};
      rows.forEach(r => { byTopic[r.topic] = (byTopic[r.topic] || 0) + 1; });

      return res.status(200).json({
        from, to,
        options: {
          topics: FEEDBACK_TOPICS.map(x => ({ id: x, label: x })),
          statuses: [{ id: 'new', label: 'Waiting' }, { id: 'handled', label: 'Handled' }]
        },
        count: rows.length,
        open: waiting.length,
        handled: rows.length - waiting.length,
        oldestOpen: waiting.length ? waiting[waiting.length - 1].created_at : null,
        openOutside: older.length,
        openOutsideFrom: older.length ? older[0].created_at.slice(0, 10) : null,
        byTopic,
        rows: rows.map(r => ({
          id: r.id, name: r.name, email: r.email, phone: r.phone, reference: r.reference,
          topic: r.topic, message: r.message, at: r.created_at,
          handledAt: r.handled_at, handledBy: r.handler?.name || null, note: r.handled_note || null
        }))
      });
    }

    if (action === 'feedback-handle') {
      if (!can(staff, 'manager', 'terminal_manager')) return fail(res, 403, 'forbidden', 'Managers only');
      const id = uuidOrNull(req.body.id);
      if (!id) return fail(res, 400, 'bad_message', 'Unknown message');
      const handled = req.body.handled !== false;
      const note = String(req.body.note || '').trim().slice(0, 500);
      if (handled && note.length < 3) return fail(res, 400, 'no_note', 'Say what was done about it — it goes on the record');

      const found = await select('feedback', `id=eq.${id}&tenant_id=eq.${t.id}&select=id,name,topic,handled_at`);
      if (!found.length) return fail(res, 404, 'not_found', 'No such message');

      await update('feedback', `id=eq.${id}&tenant_id=eq.${t.id}`, handled
        ? { handled_at: new Date().toISOString(), handled_by: staff.id, handled_note: note }
        : { handled_at: null, handled_by: null, handled_note: null });

      await audit({ tenant_id: t.id, actor_type: 'staff', actor_id: staff.id,
        action: handled ? 'feedback.handled' : 'feedback.reopened', entity: 'feedback', entity_id: id,
        detail: { by: staff.name, topic: found[0].topic, from: found[0].name, note: handled ? note : null } });
      return res.status(200).json({ ok: true, handled });
    }

    /* ------------------------------------------------------------ expenses */
    if (action === 'expenses') {
      if (!can(staff, 'manager', 'accountant')) return fail(res, 403, 'forbidden', 'Managers and accountants only');
      const to = DAY.test(req.body.to || '') ? req.body.to : today();
      const from = DAY.test(req.body.from || '') ? req.body.from : new Date(Date.now() - 29 * 864e5).toISOString().slice(0, 10);
      const fE = readFilters(req.body);
      const q = [fE.category ? `&category=eq.${fE.category}` : '',
                 fE.vehicleId ? `&vehicle_id=eq.${fE.vehicleId}` : '',
                 fE.driverId ? `&driver_id=eq.${fE.driverId}` : ''].join('');
      const rows = await select('expenses',
        `tenant_id=eq.${t.id}&incurred_on=gte.${from}&incurred_on=lte.${to}${q}` +
        `&select=id,category,amount_kobo,note,payee,method,incurred_on,created_at,vehicle:vehicles(label,plate),driver:drivers(name),by:staff!expenses_recorded_by_fkey(name)` +
        `&order=incurred_on.desc,created_at.desc&limit=200`);
      const byCategory = {};
      rows.forEach(r => { byCategory[r.category] = (byCategory[r.category] || 0) + r.amount_kobo; });
      const vehicles = await select('vehicles', `tenant_id=eq.${t.id}&select=id,label,plate&order=label.asc`);
      const drivers = await select('drivers', `tenant_id=eq.${t.id}&active=is.true&select=id,name&order=name.asc`);
      return res.status(200).json({
        from, to, vehicles, drivers,
        options: {
          categories: ['fuel', 'repair', 'salary', 'levy', 'rent', 'supplies', 'other'],
          vehicles: vehicles.map(v => ({ id: v.id, label: `${v.label}${v.plate ? ' · ' + v.plate : ''}` })),
          drivers: drivers.map(d => ({ id: d.id, label: d.name }))
        },
        total: money(rows.reduce((a, r) => a + r.amount_kobo, 0)),
        count: rows.length,
        byCategory: Object.fromEntries(Object.entries(byCategory).map(([k, v]) => [k, money(v)])),
        rows: rows.map(r => ({ id: r.id, category: r.category, amount: money(r.amount_kobo), note: r.note,
          payee: r.payee, method: r.method, date: r.incurred_on,
          vehicle: r.vehicle ? `${r.vehicle.label}${r.vehicle.plate ? ' · ' + r.vehicle.plate : ''}` : null,
          driver: r.driver?.name || null, by: r.by?.name || null }))
      });
    }

    if (action === 'expense-add') {
      if (!can(staff, 'manager', 'accountant')) return fail(res, 403, 'forbidden', 'Managers and accountants only');
      const { category, amount, payee, note, vehicleId, driverId, method, date } = req.body;
      const cat = String(category || '').trim().toLowerCase();
      if (!['fuel', 'repair', 'salary', 'levy', 'rent', 'supplies', 'other'].includes(cat)) return fail(res, 400, 'bad_category', 'Pick a category');
      const kobo = Math.round(Number(amount) * 100);
      if (!Number.isInteger(kobo) || kobo <= 0) return fail(res, 400, 'bad_amount', 'How much was paid?');
      const who = String(payee || '').trim();
      if (who.length < 2) return fail(res, 400, 'bad_payee', 'Who was paid?');

      const [row] = await insert('expenses', [{
        tenant_id: t.id, category: cat, amount_kobo: kobo, payee: who.slice(0, 120),
        note: String(note || '').trim().slice(0, 300) || null,
        vehicle_id: UUID.test(vehicleId || '') ? vehicleId : null,
        driver_id: UUID.test(driverId || '') ? driverId : null,
        method: ['cash', 'transfer', 'pos'].includes(method) ? method : null,
        incurred_on: DAY.test(date || '') ? date : today(),
        recorded_by: staff.id
      }]);
      await audit({ tenant_id: t.id, actor_type: 'staff', actor_id: staff.id, action: 'expense.recorded', entity: 'expense', entity_id: row.id,
        detail: { by: staff.name, category: cat, amount_kobo: kobo, payee: who } });
      return res.status(201).json({ ok: true, id: row.id });
    }






    /* ----------------------------------------------------------- tracking
       A driver's phone reports where the vehicle is while a trip is running. Three rules hold
       this together and each one exists because the obvious version is worse:

         * only the assigned driver may report for a trip, and only while it is boarding or
           departed — otherwise any signed-in phone could write a position for any vehicle;
         * every reader is told how old the position is, so nothing can draw a stale dot as if
           it were live;
         * customers are never given a position at all. */
    if (action === 'location-ping') {
      if (!can(staff, 'driver', 'manager')) return fail(res, 403, 'forbidden', 'Drivers only');
      const tripId = uuidOrNull(req.body.tripId);
      const lat = Number(req.body.lat), lng = Number(req.body.lng);
      if (!tripId) return fail(res, 400, 'bad_trip', 'Unknown departure');
      if (!Number.isFinite(lat) || !Number.isFinite(lng) || Math.abs(lat) > 90 || Math.abs(lng) > 180) {
        return fail(res, 400, 'bad_position', 'That is not a position');
      }
      const trips = await select('trips',
        `id=eq.${tripId}&tenant_id=eq.${t.id}&select=id,status,driver_id`);
      if (!trips.length) return fail(res, 404, 'not_found', 'No such departure');
      const trip = trips[0];
      if (!['boarding', 'departed'].includes(trip.status)) {
        /* Not an error the driver caused — the trip finished, or has not started. Tell the app
           to stop rather than have it keep pinging a journey nobody is on. */
        return res.status(200).json({ ok: true, sharing: false, reason: 'not_running' });
      }
      if (!can(staff, 'manager')) {
        const me = await select('drivers', `tenant_id=eq.${t.id}&staff_id=eq.${staff.id}&select=id`);
        if (!me.length || me[0].id !== trip.driver_id) return fail(res, 403, 'forbidden', 'That departure is not yours');
      }

      const round = (v, dp) => (Number.isFinite(Number(v)) ? Math.round(Number(v) * 10 ** dp) / 10 ** dp : null);
      await insert('trip_locations', [{
        tenant_id: t.id, trip_id: tripId, driver_id: trip.driver_id,
        /* Five decimal places is about a metre. More is false precision from a phone and more
           of somebody's movements than the job needs. */
        lat: round(lat, 5), lng: round(lng, 5),
        accuracy_m: Number.isFinite(Number(req.body.accuracy)) ? Math.round(Number(req.body.accuracy)) : null,
        speed_kph: Number.isFinite(Number(req.body.speed)) ? Math.max(0, Math.round(Number(req.body.speed))) : null,
        heading: Number.isFinite(Number(req.body.heading)) ? Math.round(Number(req.body.heading)) : null
      }], 'return=minimal');
      return res.status(200).json({ ok: true, sharing: true });
    }

    if (action === 'tracking') {
      if (!can(staff, 'manager', 'terminal_manager')) return fail(res, 403, 'forbidden', 'Managers only');
      const rows = await rpc('tracking_now', { p_tenant: t.id });
      /* The bands are named here so every screen says the same thing about the same age. A
         position older than a quarter of an hour is not a location, it is a memory. */
      const band = age => age == null ? 'never' : age < 150 ? 'live' : age < 900 ? 'recent' : 'stale';
      /* How far there is still to go, straight line. Called that on screen: road distance needs
         a routing provider, and a number that pretends to be one would be wrong by a third. */
      const crowKm = (a, b) => {
        if (a?.lat == null || b?.lat == null) return null;
        const R = 6371, rad = d => d * Math.PI / 180;
        const dLat = rad(b.lat - a.lat), dLng = rad(b.lng - a.lng);
        const x = Math.sin(dLat / 2) ** 2 + Math.cos(rad(a.lat)) * Math.cos(rad(b.lat)) * Math.sin(dLng / 2) ** 2;
        return Math.round(R * 2 * Math.atan2(Math.sqrt(x), Math.sqrt(1 - x)));
      };
      const trips = (rows || []).map(r => {
        const here = r.lat != null ? { lat: r.lat, lng: r.lng } : null;
        const dest = r.toLat != null ? { lat: r.toLat, lng: r.toLng } : null;
        const start = r.fromLat != null ? { lat: r.fromLat, lng: r.fromLng } : null;
        const remaining = crowKm(here, dest);
        const whole = crowKm(start, dest);
        return { ...r, freshness: band(r.ageSeconds), remainingKm: remaining,
          /* Rough, and only drawn when both ends are known. */
          progress: remaining != null && whole ? Math.min(100, Math.max(0, Math.round((1 - remaining / whole) * 100))) : null };
      });
      const count = f => trips.filter(x => x.freshness === f).length;
      return res.status(200).json({
        at: new Date().toISOString(),
        summary: { total: trips.length, reporting: count('live') + count('recent'),
          silent: count('stale') + count('never'),
          passengers: trips.reduce((a, x) => a + Number(x.passengers || 0), 0) },
        trips
      });
    }

    /* ----------------------------------------------------------- customers
       Who has travelled with us, and how it has gone. The identity is the phone number, set by
       a trigger on bookings, so a person who booked online in March and at the desk in June is
       one row rather than two strangers. */
    if (action === 'customers') {
      if (!can(staff, 'manager', 'terminal_manager', ...DESK)) {
        return fail(res, 403, 'forbidden', 'Your role cannot see customers');
      }
      const q = String(req.body.q || '').trim().slice(0, 60);
      const digits = q.replace(/\D/g, '');
      let filter = '';
      if (digits.length >= 4) filter = `&phone=ilike.*${encodeURIComponent(digits.slice(-10))}*`;
      else if (q) filter = `&or=(name.ilike.*${encodeURIComponent(q)}*,email.ilike.*${encodeURIComponent(q)}*)`;

      const rows = await select('customers',
        `tenant_id=eq.${t.id}${filter}&select=id,name,phone,email,created_at&order=created_at.desc&limit=60`);
      if (!rows.length) return res.status(200).json({ query: q, customers: [] });

      /* One pass over this page of customers' bookings, rather than a stats call each. */
      const ids = rows.map(c => c.id).join(',');
      const books = await select('bookings',
        `tenant_id=eq.${t.id}&customer_id=in.(${ids})&select=customer_id,status,total_kobo,created_at,` +
        `payments(status,amount_kobo),passengers(status)&limit=1000`);
      const agg = new Map();
      for (const b of books) {
        const a = agg.get(b.customer_id) || { bookings: 0, spend: 0, cancelled: 0, trips: 0, noShows: 0, last: null };
        a.bookings += 1;
        if (['cancelled', 'refunded'].includes(b.status)) a.cancelled += 1;
        a.spend += (b.payments || []).filter(p => p.status === 'success').reduce((x, p) => x + p.amount_kobo, 0);
        for (const p of b.passengers || []) {
          if (p.status === 'boarded') a.trips += 1;
          if (p.status === 'no_show') a.noShows += 1;
        }
        if (!a.last || b.created_at > a.last) a.last = b.created_at;
        agg.set(b.customer_id, a);
      }

      return res.status(200).json({
        query: q,
        customers: rows.map(c => {
          const a = agg.get(c.id) || { bookings: 0, spend: 0, cancelled: 0, trips: 0, noShows: 0, last: null };
          return { id: c.id, name: c.name || '—', phone: c.phone, email: c.email,
            bookings: a.bookings, trips: a.trips, spend: money(a.spend),
            cancelled: a.cancelled, noShows: a.noShows, lastSeen: a.last };
        }).sort((x, y) => (y.lastSeen || '').localeCompare(x.lastSeen || ''))
      });
    }

    if (action === 'customer') {
      if (!can(staff, 'manager', 'terminal_manager', ...DESK)) {
        return fail(res, 403, 'forbidden', 'Your role cannot see customers');
      }
      const id = uuidOrNull(req.body.id);
      if (!id) return fail(res, 400, 'bad_customer', 'Unknown customer');
      const rows = await select('customers', `id=eq.${id}&tenant_id=eq.${t.id}&select=id,name,phone,email,created_at`);
      if (!rows.length) return fail(res, 404, 'not_found', 'No such customer');

      const stats = await rpc('customer_stats', { p_tenant: t.id, p_customer: id });
      const books = await select('bookings',
        `tenant_id=eq.${t.id}&customer_id=eq.${id}&select=reference,status,total_kobo,created_at,` +
        `passengers(seat_no,status,trip:trips(depart_date,depart_time,route:routes(from_terminal,to_terminal)))` +
        `&order=created_at.desc&limit=50`);
      const terms = await select('terminals', `tenant_id=eq.${t.id}&select=id,city`);
      const city = x => (terms.find(y => y.id === x) || {}).city || '';

      return res.status(200).json({
        customer: { ...rows[0], since: rows[0].created_at },
        stats: {
          bookings: stats.bookings, trips: stats.trips, spend: money(stats.spend_kobo),
          cancelled: stats.cancelled, noShows: stats.no_shows,
          firstSeen: stats.first_seen, lastSeen: stats.last_seen, topRoute: stats.top_route
        },
        bookings: books.map(b => {
          const trip = b.passengers[0]?.trip;
          return { reference: b.reference, status: b.status, total: money(b.total_kobo), at: b.created_at,
            route: trip ? `${city(trip.route?.from_terminal)} → ${city(trip.route?.to_terminal)}` : null,
            date: trip?.depart_date || null, time: trip ? String(trip.depart_time).slice(0, 5) : null,
            seats: b.passengers.map(p => p.seat_no).sort((x, y) => x - y) };
        })
      });
    }


    /* ------------------------------------------------------------- assistant
       A staff member can ask for things in words. Three rules make this safe enough to put in
       front of an operations team:

       1. IT HAS NO PERMISSIONS OF ITS OWN. Every tool it runs goes back through route() with the
          caller's own cookie, so the same role gate that guards the screen guards the assistant.
          A clerk asking it for the finance report gets the same 403 they would get from the
          sidebar. There is no second permission system to drift out of step with the first.

       2. IT NEVER WRITES. Read-only tools run and their results are handed back to the model to
          answer from. Anything that changes something is returned as a *proposal* — the person
          presses a button and the browser calls the ordinary action directly. The model is never
          in the path of a write, so a prompt injected through a passenger name or a feedback
          message cannot cancel a trip.

       3. EVERY TOOL RUN IS AUDITED as done by that person through the assistant. "Who did what"
          has to stay answerable. */
    if (action === 'assist') {
      const question = String(req.body.question || '').trim();
      if (!question || question.length > 1000) return fail(res, 400, 'bad_question', 'Ask something shorter');
      if (assistTooMany(staff.id)) return fail(res, 429, 'too_many', 'Give it a moment before asking again.');

      /* Re-entering route() is the whole safety model: same cookie, same gates, same tenant. */
      const runAction = async (body) => {
        const sub = { method: 'POST', headers: req.headers, body };
        const out = { code: 200, data: null };
        const cap = {
          statusCode: 200, setHeader() {},
          status(c) { out.code = c; return this; },
          json(o) { out.data = o; return o; }
        };
        await route(sub, cap);
        return out;
      };
      try {
        const out = await staffAssist({ staff, t, question, history: req.body.history, runAction });
        return res.status(200).json({ reply: out.reply, used: out.used, proposals: out.proposals,
          propose: out.proposals[0] || null, via: out.via });
      } catch (err) {
        console.error('assistant failed:', err.diagnosis || err.message);
        await opsAlert('ai:down', { severity: 'warning', title: 'The dashboard assistant is not answering',
          detail: { why: err.diagnosis || err.message }, everyMin: 720 });
        /* A manager can fix configuration, so they get the reason; everyone else a plain line. */
        return fail(res, 503, 'assistant_down', staff.role === 'manager' && err.diagnosis
          ? `The assistant is not answering: ${err.diagnosis}` : 'The assistant is not answering right now. Try again in a minute.');
      }
    }


    /* A manager can ask what the assistant is actually configured with, without reading Vercel's
       env list or a log. Names only — never a key, not even partially. */
    if (action === 'assist-status') {
      if (!can(staff, 'manager')) return fail(res, 403, 'forbidden', 'Managers only');
      const chain = aiProviders();
      return res.status(200).json({
        configured: chain.length > 0,
        chain: chain.map((p, i) => ({ order: i + 1, via: p.name === 'gemini' ? 'Google Gemini (free tier)' : 'Groq (free tier)', model: p.model })),
        hint: chain.length ? null : 'Set GEMINI_API_KEY in Vercel (free from aistudio.google.com), then redeploy. GROQ_API_KEY works as a backup.'
      });
    }

    /* ------------------------------------------------------------- reports
       Finance, Takings and Close-out answer "what happened today". This answers "what is
       working" — the same journeys grouped by route, vehicle, driver or day, over a period.

       Revenue is attributed to the DEPARTURE, not to the day the money arrived. A seat paid for
       three weeks early belongs to the trip it was bought for, or every route's figures shift
       depending on when people happened to book. Takings already reports the other basis, which
       is the one that reconciles a drawer. */
    if (action === 'report') {
      if (!can(staff, 'manager', 'accountant', 'terminal_manager')) {
        return fail(res, 403, 'forbidden', 'Managers and the accountant only');
      }
      const to = DAY.test(req.body.to || '') ? req.body.to : today();
      const from = DAY.test(req.body.from || '') ? req.body.from : new Date(Date.now() - 29 * 864e5).toISOString().slice(0, 10);
      if (Date.parse(to) - Date.parse(from) > 92 * 864e5) {
        return fail(res, 400, 'too_wide', 'Choose a range of 92 days or less');
      }
      const by = ['route', 'vehicle', 'driver', 'day'].includes(req.body.by) ? req.body.by : 'route';

      const trips = await select('trips',
        `tenant_id=eq.${t.id}&depart_date=gte.${from}&depart_date=lte.${to}` +
        `&select=id,depart_date,depart_time,capacity,status,route:routes(from_terminal,to_terminal),` +
        `vehicle:vehicles(label,plate),driver:drivers(name),passengers(fare_kobo,status)` +
        `&order=depart_date.asc&limit=2000`);
      const terms = await select('terminals', `tenant_id=eq.${t.id}&select=id,city`);
      const city = id => (terms.find(x => x.id === id) || {}).city || '';

      const keyOf = tr => {
        if (by === 'route') return `${city(tr.route?.from_terminal)} → ${city(tr.route?.to_terminal)}`;
        if (by === 'vehicle') return tr.vehicle ? `${tr.vehicle.label}${tr.vehicle.plate ? ' · ' + tr.vehicle.plate : ''}` : 'No vehicle assigned';
        if (by === 'driver') return tr.driver?.name || 'No driver assigned';
        return tr.depart_date;
      };

      const groups = new Map();
      for (const tr of trips) {
        if (tr.status === 'cancelled') continue;
        const k = keyOf(tr);
        const g = groups.get(k) || { key: k, trips: 0, seats: 0, sold: 0, revenueKobo: 0,
          noShows: 0, cancelled: 0, boarded: 0 };
        g.trips += 1;
        g.seats += tr.capacity || 0;
        for (const p of tr.passengers || []) {
          if (p.status === 'cancelled') { g.cancelled += 1; continue; }
          /* A no-show paid and did not travel: the seat was sold and the money is earned. */
          g.sold += 1;
          g.revenueKobo += Number(p.fare_kobo || 0);
          if (p.status === 'no_show') g.noShows += 1;
          if (p.status === 'boarded') g.boarded += 1;
        }
        groups.set(k, g);
      }

      const rows = [...groups.values()].map(g => ({
        key: g.key, trips: g.trips, seats: g.seats, sold: g.sold,
        occupancy: g.seats ? Math.round((g.sold / g.seats) * 100) : 0,
        revenue: money(g.revenueKobo),
        revenueKobo: g.revenueKobo,
        perTrip: g.trips ? money(Math.round(g.revenueKobo / g.trips)) : money(0),
        noShows: g.noShows, cancelled: g.cancelled, boarded: g.boarded
      })).sort((a, b) => by === 'day' ? String(a.key).localeCompare(b.key) : b.revenueKobo - a.revenueKobo);

      const totalKobo = rows.reduce((a, r) => a + r.revenueKobo, 0);
      const seats = rows.reduce((a, r) => a + r.seats, 0);
      const sold = rows.reduce((a, r) => a + r.sold, 0);

      return res.status(200).json({
        from, to, by,
        totals: {
          trips: rows.reduce((a, r) => a + r.trips, 0),
          seats, sold, occupancy: seats ? Math.round((sold / seats) * 100) : 0,
          revenue: money(totalKobo),
          noShows: rows.reduce((a, r) => a + r.noShows, 0),
          cancelled: rows.reduce((a, r) => a + r.cancelled, 0)
        },
        rows
      });
    }

    /* ------------------------------------------------------ seat changes
       Moving somebody used to mean cancelling and re-selling: a new reference, a refund and a
       fresh sale in the ledger for one journey, and a window where the seat could be taken.
       move_passenger does it in one transaction; this adds the money. */
    if (action === 'move-options') {
      if (!can(staff, 'manager', ...DESK)) return fail(res, 403, 'forbidden', 'Your role cannot move passengers');
      const pid = uuidOrNull(req.body.passengerId);
      if (!pid) return fail(res, 400, 'bad_passenger', 'Unknown passenger');

      const rows = await select('passengers',
        `id=eq.${pid}&select=id,seat_no,status,trip_id,booking:bookings!inner(tenant_id,reference),` +
        `trip:trips(id,depart_date,depart_time,route_id,capacity)&booking.tenant_id=eq.${t.id}`);
      if (!rows.length) return fail(res, 404, 'not_found', 'No such passenger');
      const p = rows[0];

      /* Same route only: a different route is a different journey and a different price, which
         is a new booking, not a move. */
      const trips = await select('trips',
        `tenant_id=eq.${t.id}&route_id=eq.${p.trip.route_id}&status=eq.scheduled` +
        `&depart_date=gte.${today()}&select=id,depart_date,depart_time,capacity,fare_kobo,trip_seats(seat_no,state)` +
        `&order=depart_date.asc,depart_time.asc&limit=30`);

      return res.status(200).json({
        passenger: { id: p.id, seat: p.seat_no, status: p.status, tripId: p.trip_id, reference: p.booking.reference },
        departures: trips.map(tr => ({
          id: tr.id, date: tr.depart_date, time: String(tr.depart_time).slice(0, 5),
          fare: money(tr.fare_kobo), current: tr.id === p.trip_id,
          /* A seat is offerable if it is free, or if it is the one they are already in. */
          seats: (tr.trip_seats || []).sort((a, b) => a.seat_no - b.seat_no).map(s => ({
            no: s.seat_no,
            free: s.state === 'free' || (tr.id === p.trip_id && s.seat_no === p.seat_no)
          }))
        }))
      });
    }

    if (action === 'move-passenger') {
      if (!can(staff, 'manager', ...DESK)) return fail(res, 403, 'forbidden', 'Your role cannot move passengers');
      const pid = uuidOrNull(req.body.passengerId);
      const tripId = uuidOrNull(req.body.tripId);
      const seat = Number(req.body.seat);
      if (!pid || !tripId) return fail(res, 400, 'bad_request', 'Choose a departure and a seat');
      if (!Number.isInteger(seat) || seat < 1 || seat > 80) return fail(res, 400, 'bad_seat', 'Choose a seat');

      /* Confirm the passenger is ours before handing ids to the function. */
      const mine = await select('passengers',
        `id=eq.${pid}&select=id,booking_id,booking:bookings!inner(tenant_id,reference)&booking.tenant_id=eq.${t.id}`);
      if (!mine.length) return fail(res, 404, 'not_found', 'No such passenger');

      let result;
      try {
        result = await rpc('move_passenger', { p_passenger: pid, p_trip: tripId, p_seat: seat, p_staff: staff.id });
      } catch (err) {
        const m = (err.details?.message || err.message || '').toLowerCase();
        if (m.includes('seat_taken')) return fail(res, 409, 'seat_taken', 'Somebody else has taken that seat. Choose another.');
        if (m.includes('already_boarded')) return fail(res, 409, 'already_boarded', 'They have already boarded — they cannot be moved.');
        if (m.includes('seat_missing')) return fail(res, 400, 'seat_missing', 'That seat does not exist on this vehicle.');
        if (m.includes('not_live')) return fail(res, 409, 'not_live', 'That passenger is no longer travelling.');
        if (m.includes('no_trip')) return fail(res, 400, 'no_trip', 'That departure is not available.');
        if (m.includes('different_route')) return fail(res, 400, 'different_route', 'A different route needs a new booking, not a move.');
        throw err;
      }
      if (!result || result.moved === false) return res.status(200).json({ ok: true, moved: false, message: 'They are already in that seat.' });

      /* The fare can differ between departures. The ledger is append-only, so a difference is
         its own row — never an edit to what was already taken — and the booking total moves with
         it so close-out still reconciles. */
      const diff = Number(result.fare_change_kobo || 0);
      if (diff !== 0) {
        await insert('payments', [{
          tenant_id: t.id, booking_id: mine[0].booking_id, amount_kobo: diff,
          status: 'success', channel: 'terminal', recorded_by: staff.id,
          settled_at: new Date().toISOString(),
          raw: { kind: 'seat_change', by: staff.name, passenger: pid }
        }], 'return=minimal');
        const b = await select('bookings', `id=eq.${mine[0].booking_id}&tenant_id=eq.${t.id}&select=total_kobo`);
        if (b.length) await update('bookings', `id=eq.${mine[0].booking_id}&tenant_id=eq.${t.id}`,
          { total_kobo: Number(b[0].total_kobo) + diff });
      }

      return res.status(200).json({
        ok: true, moved: true, fromSeat: result.from_seat, toSeat: result.to_seat,
        sameTrip: result.same_trip, fareChange: money(diff),
        message: diff > 0 ? `Collect ${money(diff)} more.` : diff < 0 ? `Give back ${money(-diff)}.` : 'Same fare, nothing to settle.'
      });
    }


    /* ------------------------------------------------- transfer receipts (desk)
       Approving one is a money decision, so it sits with the roles that already handle money:
       the accountant, a manager, and the desk the passenger is travelling from. Approval runs
       the same confirm_booking() a card payment does — a transfer and a card end in exactly the
       same state, which is what keeps close-out and the reports honest. */
    if (action === 'proofs') {
      if (!can(staff, 'manager', 'accountant', ...DESK)) return fail(res, 403, 'forbidden', 'Your role cannot review receipts');
      const status = ['pending', 'approved', 'rejected'].includes(req.body.status) ? req.body.status : 'pending';
      const rows = await select('payment_proofs',
        `tenant_id=eq.${t.id}&status=eq.${status}&order=created_at.desc&limit=60` +
        `&select=id,storage_path,mime,sender_name,bank,amount_kobo,status,note,created_at,` +
        `booking:bookings(reference,contact_name,contact_phone,total_kobo,status,` +
        `passengers(seat_no,trip:trips(depart_date,depart_time,route:routes(from_terminal))))`);
      const terms = await select('terminals', `tenant_id=eq.${t.id}&select=id,city`);
      const city = id => (terms.find(x => x.id === id) || {}).city || '';

      /* A clerk sees the departures leaving their own terminal; managers and the accountant see
         everything. Same rule as takings. */
      const mine = can(staff, 'terminal') && staff.terminalId
        ? rows.filter(r => (r.booking?.passengers || []).some(p => p.trip?.route?.from_terminal === staff.terminalId))
        : rows;

      return res.status(200).json({
        status,
        proofs: mine.map(r => {
          const trip = r.booking?.passengers?.[0]?.trip;
          return {
            id: r.id, at: r.created_at, status: r.status, note: r.note,
            reference: r.booking?.reference, name: r.booking?.contact_name,
            phone: r.booking?.contact_phone,
            bookingStatus: r.booking?.status,
            expected: money(r.amount_kobo || r.booking?.total_kobo || 0),
            senderName: r.sender_name, bank: r.bank,
            from: city(trip?.route?.from_terminal),
            date: trip?.depart_date || null,
            time: trip ? String(trip.depart_time).slice(0, 5) : null,
            seats: (r.booking?.passengers || []).map(p => p.seat_no).sort((a, b) => a - b)
          };
        })
      });
    }

    if (action === 'proof-view') {
      if (!can(staff, 'manager', 'accountant', ...DESK)) return fail(res, 403, 'forbidden', 'Your role cannot review receipts');
      const id = uuidOrNull(req.body.id);
      if (!id) return fail(res, 400, 'bad_proof', 'Unknown receipt');
      const rows = await select('payment_proofs', `id=eq.${id}&tenant_id=eq.${t.id}&select=storage_path`);
      if (!rows.length) return fail(res, 404, 'not_found', 'No such receipt');
      try {
        /* Five minutes. Long enough to look at, short enough that a copied URL is worthless by
           the time it is pasted anywhere. */
        const url = await signedView(rows[0].storage_path, 300);
        await audit({ tenant_id: t.id, actor_type: 'staff', actor_id: staff.id, action: 'payment.proof_viewed',
          entity: 'proof', entity_id: id, detail: { by: staff.name } });
        return res.status(200).json({ url, expiresInSeconds: 300 });
      } catch (err) {
        console.error('receipt view failed:', err.message);
        return fail(res, 503, 'no_storage', 'Could not open that receipt');
      }
    }

    if (action === 'proof-decide') {
      /* Money in is a manager, the accountant, or the terminal manager. A clerk can look at a
         receipt and chase the passenger, but confirming a seat against money nobody has seen
         land is the decision that gets abused. */
      if (!can(staff, 'manager', 'accountant', 'terminal_manager')) {
        return fail(res, 403, 'needs_manager', 'A manager or the accountant has to approve a receipt');
      }
      const id = uuidOrNull(req.body.id);
      const decision = req.body.decision === 'approve' ? 'approved' : req.body.decision === 'reject' ? 'rejected' : null;
      if (!id || !decision) return fail(res, 400, 'bad_request', 'Approve or reject');
      const note = String(req.body.note || '').trim().slice(0, 300) || null;
      if (decision === 'rejected' && !note) return fail(res, 400, 'need_reason', 'Say why it is being rejected');

      const rows = await select('payment_proofs',
        `id=eq.${id}&tenant_id=eq.${t.id}&select=id,status,booking_id,amount_kobo,booking:bookings(reference,status,total_kobo)`);
      if (!rows.length) return fail(res, 404, 'not_found', 'No such receipt');
      const proof = rows[0];
      if (proof.status !== 'pending') return fail(res, 409, 'already_done', `That receipt was already ${proof.status}.`);

      await update('payment_proofs', `id=eq.${id}&tenant_id=eq.${t.id}`,
        { status: decision, note, reviewed_by: staff.id, reviewed_at: new Date().toISOString() });

      if (decision === 'approved') {
        /* The money is recorded as a payment like any other, then the ordinary confirmation
           runs. Nothing here writes to seats or booking status directly. */
        await insert('payments', [{
          tenant_id: t.id, booking_id: proof.booking_id,
          amount_kobo: proof.amount_kobo || proof.booking?.total_kobo || 0,
          status: 'success', channel: 'transfer', recorded_by: staff.id,
          settled_at: new Date().toISOString(),
          raw: { kind: 'transfer_receipt', proof: id, by: staff.name }
        }], 'return=minimal');
        await rpc('confirm_booking', { p_booking: proof.booking_id });
        sendTicketEmail(proof.booking?.reference).catch(err => console.error('ticket after transfer failed:', err.message));
      }

      await audit({ tenant_id: t.id, actor_type: 'staff', actor_id: staff.id,
        action: `payment.proof_${decision}`, entity: 'booking', entity_id: proof.booking_id,
        detail: { by: staff.name, reference: proof.booking?.reference, note } });

      return res.status(200).json({ ok: true, status: decision, reference: proof.booking?.reference });
    }

    /* ------------------------------------------------- terminals and settings
       The three addresses said "full address to be confirmed" for months because they lived in
       index.html and assets/pages.js. Anything a manager should be able to correct without a
       deploy belongs in the database; these two actions are how it gets there. */
    if (action === 'terminals') {
      if (!can(staff, 'manager', 'terminal_manager')) return fail(res, 403, 'forbidden', 'Managers only');
      const rows = await select('terminals',
        `tenant_id=eq.${t.id}&select=id,code,city,name,address,phone,whatsapp,opens_at,active,lat,lng&order=city.asc`);
      const s = t.settings || {};
      return res.status(200).json({
        terminals: rows.map(x => ({ id: x.id, code: x.code, city: x.city, name: x.name,
          address: x.address || '', phone: x.phone || '', whatsapp: x.whatsapp || '',
          opensAt: x.opens_at ? String(x.opens_at).slice(0, 5) : '', active: x.active !== false,
          lat: x.lat ?? '', lng: x.lng ?? '' })),
        settings: {
          tollFree: s.toll_free || '', contactEmail: s.contact_email || '',
          bankName: s.bank_name || '', bankAccountName: s.bank_account_name || '',
          bankAccountNumber: s.bank_account_number || '',
          holdMinutes: Number(s.hold_minutes ?? 15),
          childFareRatio: Number(s.child_fare_ratio ?? 0.75),
          arriveBeforeMin: Number(s.arrive_before_min ?? 30),
          checkInCloseMin: Number(s.check_in_close_min ?? 15),
          transferHoldMinutes: Number(s.transfer_hold_minutes ?? 60),
          cancelFreeHours: Number(s.cancel_free_hours ?? 24),
          cancelFeePct: Number(s.cancel_fee_pct ?? 25),
          noRefundHours: Number(s.no_refund_hours ?? 2)
        }
      });
    }

    if (action === 'terminal-save') {
      if (!can(staff, 'manager')) return fail(res, 403, 'forbidden', 'Managers only');
      const id = uuidOrNull(req.body.id);
      if (!id) return fail(res, 400, 'bad_terminal', 'Unknown terminal');
      const mine = await select('terminals', `id=eq.${id}&tenant_id=eq.${t.id}&select=id,city`);
      if (!mine.length) return fail(res, 404, 'not_found', 'No such terminal');

      const str = (v, n) => { const x = String(v ?? '').trim(); return x ? x.slice(0, n) : null; };
      const patch = {};
      if ('address' in req.body) patch.address = str(req.body.address, 300);
      if ('phone' in req.body) patch.phone = str(req.body.phone, 40);
      if ('whatsapp' in req.body) patch.whatsapp = str(req.body.whatsapp, 40);
      if ('name' in req.body) patch.name = str(req.body.name, 120) || mine[0].city;
      if ('opensAt' in req.body) {
        const v = String(req.body.opensAt || '').trim();
        if (v && !/^\d{2}:\d{2}$/.test(v)) return fail(res, 400, 'bad_time', 'Opening time must be HH:MM');
        patch.opens_at = v || null;
      }
      if ('active' in req.body) patch.active = req.body.active !== false;
      for (const [key, col, limit] of [['lat', 'lat', 90], ['lng', 'lng', 180]]) {
        if (!(key in req.body)) continue;
        const raw = String(req.body[key] ?? '').trim();
        if (!raw) { patch[col] = null; continue; }
        const v = Number(raw);
        if (!Number.isFinite(v) || Math.abs(v) > limit) return fail(res, 400, 'bad_position', 'Check the coordinates');
        patch[col] = v;
      }
      if (!Object.keys(patch).length) return fail(res, 400, 'nothing', 'Nothing to change');

      await update('terminals', `id=eq.${id}&tenant_id=eq.${t.id}`, patch);
      await audit({ tenant_id: t.id, actor_type: 'staff', actor_id: staff.id, action: 'terminal.updated',
        entity: 'terminal', entity_id: id, detail: { by: staff.name, terminal: mine[0].city, ...patch } });
      return res.status(200).json({ ok: true });
    }

    if (action === 'settings-save') {
      if (!can(staff, 'manager')) return fail(res, 403, 'forbidden', 'Managers only');
      const s = { ...(t.settings || {}) };
      const num = (v, lo, hi, dflt) => {
        const n = Number(v);
        return Number.isFinite(n) && n >= lo && n <= hi ? n : dflt;
      };
      if ('tollFree' in req.body) s.toll_free = String(req.body.tollFree || '').trim().slice(0, 40) || null;
      if ('contactEmail' in req.body) s.contact_email = String(req.body.contactEmail || '').trim().slice(0, 160) || null;
      /* The account a transfer should go to. Shown at checkout, so it has to be editable without
         a deploy — and it is the one field where a typo costs a customer real money. */
      if ('bankName' in req.body) s.bank_name = String(req.body.bankName || '').trim().slice(0, 80) || null;
      if ('bankAccountName' in req.body) s.bank_account_name = String(req.body.bankAccountName || '').trim().slice(0, 120) || null;
      if ('bankAccountNumber' in req.body) s.bank_account_number = String(req.body.bankAccountNumber || '').replace(/\s/g, '').slice(0, 20) || null;
      if ('arriveBeforeMin' in req.body) s.arrive_before_min = num(req.body.arriveBeforeMin, 0, 180, s.arrive_before_min ?? 30);
      if ('checkInCloseMin' in req.body) s.check_in_close_min = num(req.body.checkInCloseMin, 0, 120, s.check_in_close_min ?? 15);
      /* The refund rules drive the published policy page, so they are numbers a manager owns
         rather than prose somebody has to redeploy. */
      if ('transferHoldMinutes' in req.body) s.transfer_hold_minutes = num(req.body.transferHoldMinutes, 5, 720, s.transfer_hold_minutes ?? 60);
      if ('cancelFreeHours' in req.body) s.cancel_free_hours = num(req.body.cancelFreeHours, 0, 720, s.cancel_free_hours ?? 24);
      if ('cancelFeePct' in req.body) s.cancel_fee_pct = num(req.body.cancelFeePct, 0, 100, s.cancel_fee_pct ?? 25);
      if ('noRefundHours' in req.body) s.no_refund_hours = num(req.body.noRefundHours, 0, 168, s.no_refund_hours ?? 2);

      await update('tenants', `id=eq.${t.id}`, { settings: s });
      clearTenantCache();
      await audit({ tenant_id: t.id, actor_type: 'staff', actor_id: staff.id, action: 'settings.updated',
        entity: 'tenant', entity_id: t.id, detail: { by: staff.name } });
      return res.status(200).json({ ok: true, settings: s });
    }

    /* ------------------------------------------- manager: routes and fleet */
    if (action === 'fleet') {
      if (!can(staff, 'manager')) return fail(res, 403, 'forbidden', 'Managers only');
      const [routes, vehicles, drivers, terminals] = await Promise.all([
        select('routes', `tenant_id=eq.${t.id}&select=id,from_terminal,to_terminal,fare_kobo,duration_min,operating_days,departures,active`),
        select('vehicles', `tenant_id=eq.${t.id}&select=id,label,plate,capacity,status,driver_id,driver:drivers(name,phone)&order=label.asc`),
        select('drivers', `tenant_id=eq.${t.id}&select=id,name,phone,licence_no,active&order=name.asc`),
        select('terminals', `tenant_id=eq.${t.id}&select=id,city,name&order=city.asc`)
      ]);
      const city = id => terminals.find(x => x.id === id)?.city || '';
      /* Count future trips per route so the manager can see what a fare change would touch. */
      const future = await select('trips', `tenant_id=eq.${t.id}&depart_date=gte.${today()}&status=neq.cancelled&select=route_id,vehicle_id,driver_id`);
      return res.status(200).json({
        terminals,
        routes: routes.map(r => ({
          id: r.id, from: r.from_terminal, to: r.to_terminal, label: `${city(r.from_terminal)} → ${city(r.to_terminal)}`,
          fare: money(r.fare_kobo), durationMin: r.duration_min, days: r.operating_days,
          departures: (r.departures || []).map(x => String(x).slice(0, 5)), active: r.active,
          futureTrips: future.filter(f => f.route_id === r.id).length
        })),
        vehicles: vehicles.map(v => ({ ...v, inUse: future.filter(f => f.vehicle_id === v.id).length })),
        drivers: drivers.map(d => ({ ...d, inUse: future.filter(f => f.driver_id === d.id).length }))
      });
    }

    if (action === 'route-add') {
      if (!can(staff, 'manager')) return fail(res, 403, 'forbidden', 'Managers only');
      const { fromTerminal, toTerminal, fare, durationMin, days, departures, bothWays } = req.body;
      if (!UUID.test(fromTerminal || '') || !UUID.test(toTerminal || '')) return fail(res, 400, 'bad_terminal', 'Choose both terminals');
      if (fromTerminal === toTerminal) return fail(res, 400, 'same_terminal', 'A route has to go somewhere else');

      const kobo = Math.round(Number(fare) * 100);
      const mins = Number(durationMin);
      if (!Number.isInteger(kobo) || kobo <= 0) return fail(res, 400, 'bad_fare', 'Set the fare');
      if (!Number.isInteger(mins) || mins <= 0) return fail(res, 400, 'bad_duration', 'How long does the journey take?');
      if (!Array.isArray(days) || !days.length || days.some(d => !Number.isInteger(d) || d < 0 || d > 6)) return fail(res, 400, 'bad_days', 'Pick at least one operating day');
      if (!Array.isArray(departures) || !departures.length || departures.some(x => !/^\d{2}:\d{2}$/.test(String(x)))) return fail(res, 400, 'bad_times', 'Add departure times like 07:00');

      const existing = await select('routes', `tenant_id=eq.${t.id}&from_terminal=eq.${fromTerminal}&to_terminal=eq.${toTerminal}&select=id,active`);
      if (existing.length) return fail(res, 409, 'exists', 'That route already exists — edit it instead.');

      const rows = [{ tenant_id: t.id, from_terminal: fromTerminal, to_terminal: toTerminal, fare_kobo: kobo,
        duration_min: mins, operating_days: [...new Set(days)].sort(), departures: [...new Set(departures)].sort(), active: true }];

      /* A corridor almost always runs both ways, and a one-way route on a booking page looks
         like a mistake to a customer standing at the other end of it. */
      if (bothWays) {
        const back = await select('routes', `tenant_id=eq.${t.id}&from_terminal=eq.${toTerminal}&to_terminal=eq.${fromTerminal}&select=id`);
        if (!back.length) rows.push({ ...rows[0], from_terminal: toTerminal, to_terminal: fromTerminal });
      }

      const made = await insert('routes', rows);
      /* Departures only exist once they are generated, so fill the window now rather than
         leaving the route invisible until tonight's cron. */
      let created = 0;
      try { created = await rpc('generate_trips', { p_tenant_slug: process.env.TENANT_SLUG || 'ace-trail', p_days: 45 }); }
      catch (err) { console.error('could not generate trips for the new route:', err.message); }

      await audit({ tenant_id: t.id, actor_type: 'staff', actor_id: staff.id, action: 'route.added', entity: 'route', entity_id: made[0].id,
        detail: { by: staff.name, fare_kobo: kobo, both_ways: Boolean(bothWays) } });
      return res.status(201).json({ ok: true, routes: made.length, departuresCreated: created });
    }

    if (action === 'route-save') {
      if (!can(staff, 'manager')) return fail(res, 403, 'forbidden', 'Managers only');
      const { routeId, fare, durationMin, days, departures, active, applyFuture } = req.body;
      if (!UUID.test(routeId || '')) return fail(res, 400, 'bad_route', 'Unknown route');

      const patch = {};
      if (fare !== undefined) {
        const kobo = Math.round(Number(fare) * 100);
        if (!Number.isInteger(kobo) || kobo <= 0) return fail(res, 400, 'bad_fare', 'Fare must be more than zero');
        patch.fare_kobo = kobo;
      }
      if (durationMin !== undefined) {
        const mins = Number(durationMin);
        if (!Number.isInteger(mins) || mins <= 0) return fail(res, 400, 'bad_duration', 'Journey time must be more than zero');
        patch.duration_min = mins;
      }
      if (days !== undefined) {
        if (!Array.isArray(days) || days.some(d => !Number.isInteger(d) || d < 0 || d > 6)) return fail(res, 400, 'bad_days', 'Operating days are 0 (Sunday) to 6');
        if (!days.length) return fail(res, 400, 'bad_days', 'Pick at least one operating day');
        patch.operating_days = [...new Set(days)].sort();
      }
      if (departures !== undefined) {
        if (!Array.isArray(departures) || !departures.length) return fail(res, 400, 'bad_times', 'Add at least one departure time');
        if (departures.some(x => !/^\d{2}:\d{2}$/.test(String(x)))) return fail(res, 400, 'bad_times', 'Times look like 07:00');
        patch.departures = [...new Set(departures)].sort();
      }
      if (active !== undefined) patch.active = Boolean(active);
      if (!Object.keys(patch).length) return fail(res, 400, 'nothing', 'Nothing to change');

      await update('routes', `id=eq.${routeId}&tenant_id=eq.${t.id}`, patch);

      /* A trip copies its fare at creation, so changing the route does not move money that is
         already scheduled. Only the manager can say whether it should — and never for a
         departure someone has already paid for at the old price. */
      let repriced = 0;
      if (applyFuture && patch.fare_kobo) {
        const upcoming = await select('trips',
          `tenant_id=eq.${t.id}&route_id=eq.${routeId}&depart_date=gte.${today()}&status=neq.cancelled&select=id,trip_seats(state)`);
        const safe = upcoming.filter(tr => !(tr.trip_seats || []).some(x => x.state === 'sold'));
        for (const tr of safe) { await update('trips', `id=eq.${tr.id}`, { fare_kobo: patch.fare_kobo }); }
        repriced = safe.length;
      }
      await audit({ tenant_id: t.id, actor_type: 'staff', actor_id: staff.id, action: 'route.updated', entity: 'route', entity_id: routeId,
        detail: { by: staff.name, ...patch, repriced } });
      return res.status(200).json({ ok: true, repriced });
    }

    if (action === 'vehicle-save') {
      if (!can(staff, 'manager')) return fail(res, 403, 'forbidden', 'Managers only');
      const { vehicleId, label, plate, capacity, status, driverId, remove } = req.body;

      /* Removing a vehicle. Not a delete: departures, manifests and takings all point at it, and
         erasing it would leave holes in last month's figures. It is retired, which takes it off
         the list of vehicles a departure can be assigned to and leaves the history intact. A
         vehicle currently carrying passengers cannot be retired at all. */
      if (remove) {
        if (!UUID.test(vehicleId || '')) return fail(res, 400, 'bad_vehicle', 'Unknown vehicle');
        const live = await select('trips',
          `tenant_id=eq.${t.id}&vehicle_id=eq.${vehicleId}&status=in.(scheduled,boarding,departed)` +
          `&depart_date=gte.${today()}&select=id,depart_date,depart_time&order=depart_date.asc&limit=5`);
        if (live.length) {
          return fail(res, 409, 'vehicle_in_use',
            `That vehicle is on ${live.length} upcoming departure${live.length === 1 ? '' : 's'}, starting ${live[0].depart_date}. Reassign them first.`);
        }
        await update('vehicles', `id=eq.${vehicleId}&tenant_id=eq.${t.id}`, { status: 'retired', driver_id: null });
        await audit({ tenant_id: t.id, actor_type: 'staff', actor_id: staff.id, action: 'vehicle.retired',
          entity: 'vehicle', entity_id: vehicleId, detail: { by: staff.name } });
        return res.status(200).json({ ok: true, retired: true });
      }
      const cap = capacity === undefined ? undefined : Number(capacity);
      if (cap !== undefined && (!Number.isInteger(cap) || cap < 1 || cap > 80)) return fail(res, 400, 'bad_capacity', 'Capacity is 1 to 80');
      const name = String(label || '').trim();

      if (vehicleId) {
        if (!UUID.test(vehicleId)) return fail(res, 400, 'bad_vehicle', 'Unknown vehicle');
        const patch = {};
        if (name) patch.label = name.slice(0, 80);
        if (plate !== undefined) patch.plate = String(plate || '').trim().slice(0, 20) || null;
        if (driverId !== undefined) {
          /* The regular driver of this car. Blank unassigns. */
          if (driverId === null || driverId === '') patch.driver_id = null;
          else {
            if (!UUID.test(driverId)) return fail(res, 400, 'bad_driver', 'Unknown driver');
            const d = await select('drivers', `id=eq.${driverId}&tenant_id=eq.${t.id}&active=is.true&select=id`);
            if (!d.length) return fail(res, 404, 'not_found', 'No such driver');
            patch.driver_id = driverId;
          }
        }
        if (status !== undefined) {
          if (!['active', 'maintenance', 'retired'].includes(status)) return fail(res, 400, 'bad_status', 'Unknown status');
          patch.status = status;
        }
        /* Capacity is copied onto a trip when it is generated, and trip_seats rows already exist.
           Changing it here would not resize those, so it only affects future generation. */
        if (cap !== undefined) patch.capacity = cap;
        if (!Object.keys(patch).length) return fail(res, 400, 'nothing', 'Nothing to change');
        await update('vehicles', `id=eq.${vehicleId}&tenant_id=eq.${t.id}`, patch);
        await audit({ tenant_id: t.id, actor_type: 'staff', actor_id: staff.id, action: 'vehicle.updated', entity: 'vehicle', entity_id: vehicleId, detail: { by: staff.name, ...patch } });
        return res.status(200).json({ ok: true });
      }

      if (name.length < 2) return fail(res, 400, 'bad_label', 'Give the vehicle a name');
      if (!Number.isInteger(cap)) return fail(res, 400, 'bad_capacity', 'How many seats?');
      const seatMap = { rows: [[1], [2, 3], [4, 5]].slice(0, Math.ceil(cap / 2) + 1), seats: cap };
      const [v] = await insert('vehicles', [{ tenant_id: t.id, label: name.slice(0, 80),
        plate: String(plate || '').trim().slice(0, 20) || null, capacity: cap, seat_map: seatMap,
        status: ['active', 'maintenance', 'retired'].includes(status) ? status : 'active' }]);
      await audit({ tenant_id: t.id, actor_type: 'staff', actor_id: staff.id, action: 'vehicle.added', entity: 'vehicle', entity_id: v.id, detail: { by: staff.name, label: v.label, capacity: cap } });
      return res.status(201).json({ ok: true, id: v.id });
    }

    if (action === 'driver-save') {
      if (!can(staff, 'manager')) return fail(res, 403, 'forbidden', 'Managers only');
      const { driverId, name, phone, licence, active } = req.body;
      const nm = String(name || '').trim();
      const ph = String(phone || '').trim();

      if (driverId) {
        if (!UUID.test(driverId)) return fail(res, 400, 'bad_driver', 'Unknown driver');
        const patch = {};
        if (nm) patch.name = nm.slice(0, 120);
        if (ph) { if (!PHONE.test(ph)) return fail(res, 400, 'bad_phone', 'Check the phone number'); patch.phone = ph.slice(0, 32); }
        if (licence !== undefined) patch.licence_no = String(licence || '').trim().slice(0, 40) || null;
        if (active !== undefined) patch.active = Boolean(active);
        if (!Object.keys(patch).length) return fail(res, 400, 'nothing', 'Nothing to change');
        await update('drivers', `id=eq.${driverId}&tenant_id=eq.${t.id}`, patch);
        await audit({ tenant_id: t.id, actor_type: 'staff', actor_id: staff.id, action: 'driver.updated', entity: 'driver', entity_id: driverId, detail: { by: staff.name, ...patch } });
        return res.status(200).json({ ok: true });
      }

      if (nm.length < 3) return fail(res, 400, 'bad_name', 'Give the driver a full name');
      if (!PHONE.test(ph)) return fail(res, 400, 'bad_phone', 'Enter the driver phone number');
      const [d] = await insert('drivers', [{ tenant_id: t.id, name: nm.slice(0, 120), phone: ph.slice(0, 32),
        licence_no: String(licence || '').trim().slice(0, 40) || null, active: true }]);
      await audit({ tenant_id: t.id, actor_type: 'staff', actor_id: staff.id, action: 'driver.added', entity: 'driver', entity_id: d.id, detail: { by: staff.name, name: d.name } });
      return res.status(201).json({ ok: true, id: d.id });
    }

    /* --------------------------------------------- manager: trips & schedule */
    if (action === 'schedule') {
      if (!can(staff, 'manager')) return fail(res, 403, 'forbidden', 'Managers only');
      const from = DAY.test(req.body.from || '') ? req.body.from : today();
      const to = DAY.test(req.body.to || '') ? req.body.to : from;
      const f = readFilters(req.body);
      const trips = await select('trips',
        `tenant_id=eq.${t.id}&depart_date=gte.${from}&depart_date=lte.${to}` +
        `&select=id,depart_date,depart_time,capacity,fare_kobo,status,route:routes(id,from_terminal,to_terminal),` +
        `vehicle:vehicles(id,label,plate),driver:drivers(id,name),trip_seats(state)` +
        `&order=depart_date.asc,depart_time.asc&limit=400`);
      const terminals = await select('terminals', `tenant_id=eq.${t.id}&select=id,city`);
      const city = id => terminals.find(x => x.id === id)?.city || '';
      const vehicles = await select('vehicles', `tenant_id=eq.${t.id}&select=id,label,plate,capacity,status&order=label.asc`);
      const drivers = await select('drivers', `tenant_id=eq.${t.id}&active=is.true&select=id,name,phone&order=name.asc`);
      /* How far ahead anything is actually bookable — the number that silently decays
         when the schedule stops being generated. */
      const horizon = await select('trips', `tenant_id=eq.${t.id}&status=neq.cancelled&select=depart_date&order=depart_date.desc&limit=1`);
      const routes = await select('routes', `tenant_id=eq.${t.id}&select=id,from_terminal,to_terminal`);
      const shownTrips = trips.filter(tr =>
        (!f.terminal || tr.route?.from_terminal === f.terminal) &&
        (!f.routeId || tr.route?.id === f.routeId) &&
        (!f.vehicleId || tr.vehicle?.id === f.vehicleId) &&
        (!f.driverId || tr.driver?.id === f.driverId) &&
        (!f.status || tr.status === f.status));

      return res.status(200).json({
        from, to,
        lastDate: horizon[0]?.depart_date || null,
        vehicles, drivers,
        options: {
          terminals: terminals.map(x => ({ id: x.id, label: x.city })),
          routes: routes.map(r => ({ id: r.id, label: `${city(r.from_terminal)} → ${city(r.to_terminal)}` })),
          vehicles: vehicles.map(v => ({ id: v.id, label: `${v.label}${v.plate ? ' · ' + v.plate : ''}` })),
          drivers: drivers.map(d => ({ id: d.id, label: d.name })),
          statuses: ['scheduled', 'boarding', 'departed', 'arrived', 'completed', 'cancelled']
        },
        trips: shownTrips.map(tr => {
          const seats = tr.trip_seats || [];
          return { id: tr.id, date: tr.depart_date, time: String(tr.depart_time).slice(0, 5), status: tr.status,
            route: `${city(tr.route?.from_terminal)} → ${city(tr.route?.to_terminal)}`,
            fare: money(tr.fare_kobo), capacity: tr.capacity,
            vehicleId: tr.vehicle?.id || null, vehicle: tr.vehicle ? `${tr.vehicle.label}${tr.vehicle.plate ? ' · ' + tr.vehicle.plate : ''}` : null,
            driverId: tr.driver?.id || null, driver: tr.driver?.name || null,
            sold: seats.filter(x => x.state === 'sold').length,
            held: seats.filter(x => x.state === 'held').length };
        })
      });
    }

    if (action === 'trip-assign') {
      if (!can(staff, 'manager')) return fail(res, 403, 'forbidden', 'Managers only');
      const { tripId, vehicleId, driverId } = req.body;
      if (!UUID.test(tripId || '')) return fail(res, 400, 'bad_trip', 'Unknown trip');
      const patch = {};
      if (vehicleId !== undefined) patch.vehicle_id = UUID.test(vehicleId || '') ? vehicleId : null;
      if (driverId !== undefined) patch.driver_id = UUID.test(driverId || '') ? driverId : null;
      if (!Object.keys(patch).length) return fail(res, 400, 'nothing', 'Nothing to change');

      /* Nothing used to stop the same driver being put on two departures leaving at the same
         time in opposite directions. The clash is only visible if you happen to read the whole
         day's list, and by then a vehicle is at a terminal with passengers and no driver.
         A trip occupies its driver and vehicle until it is due to arrive. */
      const mine = await select('trips',
        `id=eq.${tripId}&tenant_id=eq.${t.id}&select=depart_date,depart_time,route:routes(duration_min)`);
      if (!mine.length) return fail(res, 404, 'no_trip', 'Unknown trip');
      const me = mine[0];
      const mins = x => { const [h, m] = String(x).split(':').map(Number); return h * 60 + m; };
      const myStart = mins(me.depart_time);
      const myEnd = myStart + Number(me.route?.duration_min || 0);

      const sameDay = await select('trips',
        `tenant_id=eq.${t.id}&depart_date=eq.${me.depart_date}&id=neq.${tripId}&status=neq.cancelled` +
        `&select=id,depart_time,driver_id,vehicle_id,route:routes(duration_min,from_terminal,to_terminal)`);
      const terms = await select('terminals', `tenant_id=eq.${t.id}&select=id,city`);
      const cityName = id => terms.find(x => x.id === id)?.city || '';

      for (const other of sameDay) {
        const oStart = mins(other.depart_time);
        const oEnd = oStart + Number(other.route?.duration_min || 0);
        if (myStart >= oEnd || oStart >= myEnd) continue;            // no overlap in time

        const clashDriver = patch.driver_id && other.driver_id === patch.driver_id;
        const clashVehicle = patch.vehicle_id && other.vehicle_id === patch.vehicle_id;
        if (!clashDriver && !clashVehicle) continue;

        const when = String(other.depart_time).slice(0, 5);
        const where = `${cityName(other.route?.from_terminal)} → ${cityName(other.route?.to_terminal)}`;
        return fail(res, 409, 'clash', clashDriver
          ? `That driver is already on the ${when} ${where}, which is still running at this departure time.`
          : `That vehicle is already on the ${when} ${where}, which is still running at this departure time.`);
      }

      await update('trips', `id=eq.${tripId}&tenant_id=eq.${t.id}`, patch);
      await audit({ tenant_id: t.id, actor_type: 'staff', actor_id: staff.id, action: 'trip.assigned', entity: 'trip', entity_id: tripId,
        detail: { by: staff.name, ...patch } });
      return res.status(200).json({ ok: true });
    }

    if (action === 'trip-cancel') {
      if (!can(staff, 'manager')) return fail(res, 403, 'forbidden', 'Managers only');
      const { tripId, reason } = req.body;
      if (!UUID.test(tripId || '')) return fail(res, 400, 'bad_trip', 'Unknown trip');
      const why = String(reason || '').trim();
      if (why.length < 3) return fail(res, 400, 'bad_reason', 'Say why the departure is cancelled');
      try {
        await rpc('cancel_trip', { p_trip: tripId, p_staff: staff.id, p_reason: why });
      } catch (err) {
        if (String(err.message || '').includes('has_passengers')) {
          return fail(res, 409, 'has_passengers', 'Passengers have paid for this departure. Refund them first, then cancel it.');
        }
        throw err;
      }
      await audit({ tenant_id: t.id, actor_type: 'staff', actor_id: staff.id, action: 'trip.cancelled', entity: 'trip', entity_id: tripId,
        detail: { by: staff.name, reason: why } });
      return res.status(200).json({ ok: true });
    }

    if (action === 'extend-schedule') {
      if (!can(staff, 'manager')) return fail(res, 403, 'forbidden', 'Managers only');
      const days = Math.min(Math.max(Number(req.body.days) || 45, 7), 120);
      const made = await rpc('generate_trips', { p_tenant_slug: process.env.TENANT_SLUG || 'ace-trail', p_days: days });
      await audit({ tenant_id: t.id, actor_type: 'staff', actor_id: staff.id, action: 'schedule.extended', entity: 'tenant', entity_id: t.id,
        detail: { by: staff.name, days, created: made } });
      return res.status(200).json({ created: made, days });
    }

    /* --------------------------------------------- refunds and cancellations */
    if (action === 'refund') {
      /* Money going out is a manager decision. A desk clerk can release an unpaid hold,
         but paying cash back over the counter needs a manager or the accountant. */
      const { reference, amount, reason } = req.body;
      const ref = String(reference || '').toUpperCase();
      if (!/^[A-Z]{2,5}-[A-Z0-9]{4,10}(-[A-Z0-9]{2,6})?$/.test(ref)) return fail(res, 400, 'bad_reference', 'Check the reference');
      const why = String(reason || '').trim();
      if (why.length < 3) return fail(res, 400, 'bad_reason', 'Say why this is being cancelled');

      const rows = await select('bookings',
        `tenant_id=eq.${t.id}&reference=eq.${ref}&select=id,status,total_kobo,created_by,payments(status,amount_kobo)`);
      if (!rows.length) return fail(res, 404, 'not_found', 'No booking with that reference');
      const b = rows[0];
      if (['cancelled', 'refunded', 'expired'].includes(b.status)) return fail(res, 409, 'already_closed', `That booking is already ${b.status}`);

      const paid = (b.payments || []).filter(p => p.status === 'success').reduce((a, p) => a + p.amount_kobo, 0);
      const asked = amount === undefined || amount === null ? paid : Math.round(Number(amount) * 100);
      if (!Number.isInteger(asked) || asked < 0 || asked > paid) return fail(res, 400, 'bad_amount', `You can refund at most ${money(paid)}`);

      if (asked > 0 && !can(staff, 'manager', 'accountant', 'terminal_manager')) {
        return fail(res, 403, 'needs_manager', 'A manager or the accountant has to authorise a refund');
      }
      if (asked === 0 && !can(staff, ...DESK, 'manager', 'accountant')) {
        return fail(res, 403, 'forbidden', 'Your role cannot cancel bookings');
      }

      const status = asked > 0 ? 'refunded' : 'cancelled';
      try {
        await rpc('cancel_booking', { p_booking: b.id, p_status: status, p_staff: staff.id, p_refund_kobo: asked, p_reason: why });
      } catch (err) {
        if (String(err.message || '').includes('already_closed')) return fail(res, 409, 'already_closed', 'That booking is already closed');
        throw err;
      }
      let pointsTaken = 0;
      try { pointsTaken = await rpc('reverse_trip_points', { p_booking: b.id }); }
      catch (err) { console.error('points reversal failed:', err.message); }

      await audit({ tenant_id: t.id, actor_type: 'staff', actor_id: staff.id, action: `booking.${status}`, entity: 'booking', entity_id: b.id,
        detail: { reference: ref, by: staff.name, refund_kobo: asked, paid_kobo: paid, reason: why, points_reversed: pointsTaken } });
      return res.status(200).json({ reference: ref, status, refunded: money(asked), seatsReleased: true, pointsReversed: pointsTaken });
    }

    /* ------------------------------------------------------- desk close-out */
    if (action === 'closeout') {
      if (!can(staff, ...DESK, 'manager', 'accountant')) return fail(res, 403, 'forbidden', 'Your role cannot run a close-out');
      const date = DAY.test(req.body.date || '') ? req.body.date : today();
      /* A clerk closes their own till; a manager or accountant sees the whole desk. */
      const fC = readFilters(req.body);
      const mine = can(staff, 'terminal');
      /* A clerk always closes their own till. A manager may narrow to one person or one desk. */
      const whoseTill = mine ? staff.id : fC.staffId;
      const args = { p_tenant: t.id, p_date: date, p_terminal: mine ? null : fC.terminal, p_staff: whoseTill || null };
      const summary = await rpc('closeout_summary', args);

      const pays = await select('payments',
        `tenant_id=eq.${t.id}&status=eq.success&created_at=gte.${DAY_START(date)}&created_at=lte.${DAY_END(date)}` +
        `&select=amount_kobo,channel,provider,recorded_by,created_at,raw,booking:bookings(reference,contact_name,channel)&order=created_at.asc`);
      const rows = pays.filter(p => !whoseTill || p.recorded_by === whoseTill);

      const staffRows = await select('staff', `tenant_id=eq.${t.id}&select=id,name`);
      const nameOf = id => staffRows.find(x => x.id === id)?.name || 'online';
      const byStaff = {};
      rows.forEach(p => { const k = nameOf(p.recorded_by); byStaff[k] = (byStaff[k] || 0) + p.amount_kobo; });

      const cash = rows.filter(p => (p.channel || p.provider) === 'cash').reduce((a, p) => a + p.amount_kobo, 0);
      const money2 = o => Object.fromEntries(Object.entries(o || {}).map(([k, v]) => [k, money(v)]));

      const everyone = await select('staff', `tenant_id=eq.${t.id}&active=is.true&select=id,name&order=name.asc`);
      const scopeName = whoseTill ? (staffRows.find(x => x.id === whoseTill)?.name || 'one person') : null;
      return res.status(200).json({
        date,
        options: mine ? null : {
          staff: everyone.map(x => ({ id: x.id, label: x.name })),
          terminals: (await select('terminals', `tenant_id=eq.${t.id}&select=id,city&order=city.asc`)).map(x => ({ id: x.id, label: x.city }))
        },
        scope: mine ? `${staff.name} · ${staff.terminal || 'desk'}` : (scopeName ? `${scopeName} only` : 'all desks and online'),
        gross: money(summary.gross_kobo), refunds: money(summary.refunds_kobo), net: money(summary.net_kobo),
        sales: summary.sales, refundCount: summary.refund_count,
        seatsSold: summary.seats_sold, cancelled: summary.cancelled,
        cashDue: money(cash),
        byMethod: money2(summary.by_method), bySource: money2(summary.by_source),
        byStaff: money2(byStaff),
        rows: rows.map(p => ({ amount: money(p.amount_kobo), method: p.channel || p.provider,
          reference: p.booking?.reference, name: p.booking?.contact_name, by: nameOf(p.recorded_by),
          at: String(p.created_at).slice(11, 16), refund: p.amount_kobo < 0, reason: p.raw?.reason || null }))
      });
    }

    /* ------------------------------------------------------------- driver */
    if (action === 'mytrips') {
      if (!can(staff, 'driver', 'manager')) return fail(res, 403, 'forbidden', 'Drivers only');
      const date = DAY.test(req.body.date || '') ? req.body.date : today();
      const drivers = await select('drivers', `tenant_id=eq.${t.id}&staff_id=eq.${staff.id}&select=id`);
      const driverId = drivers[0]?.id;
      const filter = driverId ? `driver_id=eq.${driverId}&` : (can(staff, 'manager') ? '' : 'id=eq.00000000-0000-0000-0000-000000000000&');
      const trips = await select('trips',
        `tenant_id=eq.${t.id}&${filter}depart_date=eq.${date}&select=id,depart_time,status,capacity,route:routes(from_terminal,to_terminal),vehicle:vehicles(label,plate),trip_seats(state)&order=depart_time.asc`);
      const terminals = await select('terminals', `tenant_id=eq.${t.id}&select=id,city,lat,lng`);
      const city = id => terminals.find(x => x.id === id)?.city || '';
      /* The driver's map needs to know where they are going, so each trip carries both ends. */
      const point = id => {
        const x = terminals.find(y => y.id === id);
        return x && x.lat != null && x.lng != null ? { city: x.city, lat: x.lat, lng: x.lng } : null;
      };
      return res.status(200).json({ date, trips: trips.map(tr => ({
        id: tr.id, time: String(tr.depart_time).slice(0, 5), status: tr.status,
        route: `${city(tr.route?.from_terminal)} → ${city(tr.route?.to_terminal)}`,
        vehicle: [tr.vehicle?.label, tr.vehicle?.plate].filter(Boolean).join(' · '),
        sold: (tr.trip_seats || []).filter(s => s.state === 'sold').length, capacity: tr.capacity,
        from: point(tr.route?.from_terminal), to: point(tr.route?.to_terminal)
      })) });
    }

    if (action === 'trip-status') {
      if (!can(staff, 'driver', 'manager')) return fail(res, 403, 'forbidden', 'Drivers and managers only');
      const { tripId, status } = req.body;
      if (!UUID.test(tripId || '')) return fail(res, 400, 'bad_trip', 'Unknown trip');
      await rpc('set_trip_status', { p_trip: tripId, p_status: status, p_staff: staff.id });

      /* A driver marking a departure arrived or departed is news the office needs without going
         looking for it. This writes a notice rather than leaving it to the derived alerts,
         because it is an event: it happened at a moment, and there is no state to work it out
         from ten minutes later.

         It goes to the manager and to the terminal manager. The desk clerks at the arriving
         terminal see it too — they are the ones who will be asked "has the North City car come in?" */
      if (['departed', 'arrived'].includes(status)) {
        const rows = await select('trips',
          `id=eq.${tripId}&tenant_id=eq.${t.id}&select=depart_date,depart_time,` +
          `vehicle:vehicles(label,plate),driver:drivers(name),route:routes(from_terminal,to_terminal)`);
        const tr = rows[0];
        if (tr) {
          const terms = await select('terminals', `tenant_id=eq.${t.id}&select=id,city`);
          const city = id => (terms.find(x => x.id === id) || {}).city || '';
          const when = String(tr.depart_time).slice(0, 5);
          const leg = `${city(tr.route?.from_terminal)} → ${city(tr.route?.to_terminal)}`;
          const who = [tr.vehicle?.label, tr.driver?.name].filter(Boolean).join(' · ');
          const title = status === 'arrived'
            ? `${when} ${leg} has arrived`
            : `${when} ${leg} has left`;
          const body = [who, status === 'arrived' ? `Marked arrived by ${staff.name}.` : `Marked away by ${staff.name}.`]
            .filter(Boolean).join(' · ');
          const base = { tenant_id: t.id, kind: 'notice', title: title.slice(0, 160), body,
            entity: 'trip', entity_id: tripId, created_by: staff.id,
            /* It stops being news the next day; without this the panel silts up. */
            expires_at: new Date(Date.now() + 24 * 3600000).toISOString() };
          try {
            await insert('notifications', [
              { ...base, audience_role: 'manager' },
              { ...base, audience_role: 'terminal_manager' },
              { ...base, audience_role: 'terminal' }
            ], 'return=minimal');
          } catch (err) { console.error('arrival notice failed:', err.message); }
        }
      }
      return res.status(200).json({ ok: true });
    }

    return fail(res, 400, 'bad_action', 'Unknown action');
  } catch (err) {
    console.error(`staff ${action} failed:`, err.message);
    return fail(res, 500, 'server', 'Something went wrong');
  }
}
