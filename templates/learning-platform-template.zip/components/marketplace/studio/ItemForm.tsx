"use client";

import { CCY_LABEL, CCY_SYMBOL, type Ccy } from "@/lib/money";
import { useActionState, useState } from "react";
import { saveItem } from "@/app/actions/marketplace";
import { CATEGORIES } from "@/lib/marketplace/categories";
import type { FormState } from "@/lib/forms";
import type { StudioItem } from "@/lib/marketplace/studio";
import StudioSubmit from "./StudioSubmit";
import ItemPreview, { type PreviewFields } from "./ItemPreview";

const dollars = (c: number | null | undefined) => (c == null ? "" : (c / 100).toFixed(c % 100 ? 2 : 0));

/**
 * The item's details. Category drives the rest: its types and file
 * formats are the only ones offered, the same lists the storefront
 * filters on, so a listing can never end up somewhere a buyer's filter
 * will not find it.
 */
/**
 * Naira is written whole — ₦25,000, never ₦25,000.00 — so it is entered
 * that way too. Dollars and pounds keep their decimals.
 */
function units(cents: number | null | undefined, ccy: Ccy): string {
  if (cents === null || cents === undefined) return "";
  const n = cents / 100;
  return ccy === "NGN" ? String(Math.round(n)) : String(n);
}

const lines = (v: FormDataEntryValue | null) =>
  String(v ?? "").split("\n").map((x) => x.trim()).filter(Boolean);
const commas = (v: FormDataEntryValue | null) =>
  String(v ?? "").split(",").map((x) => x.trim()).filter(Boolean);
const cents = (v: FormDataEntryValue | null) => {
  const n = Number(String(v ?? "").replace(/[$£₦,\s]/g, ""));
  return String(v ?? "").trim() === "" || Number.isNaN(n) ? null : Math.round(n * 100);
};

export default function ItemForm({ item, shopName }: { item?: StudioItem; shopName?: string }) {
  const [state, action] = useActionState<FormState, FormData>(saveItem, {});
  const [category, setCategory] = useState(item?.category ?? "");
  const [price, setPrice] = useState(dollars(item?.priceCents));
  const cat = CATEGORIES.find((c) => c.slug === category);
  const free = price !== "" && Number(price) === 0;

  /**
   * The preview is fed from the form itself rather than from a controlled
   * copy of every field: one read on each keystroke keeps the inputs
   * uncontrolled, which is what makes the form work without JavaScript.
   */
  const [preview, setPreview] = useState<PreviewFields | null>(null);
  const readForm = (form: HTMLFormElement) => {
    const fd = new FormData(form);
    setPreview({
      title: String(fd.get("title") ?? ""),
      category: String(fd.get("category") ?? ""),
      subcategory: String(fd.get("subcategory") ?? ""),
      summary: String(fd.get("summary") ?? ""),
      includes: lines(fd.get("includes")),
      tags: commas(fd.get("tags")),
      formats: fd.getAll("formats").map(String),
      priceCents: cents(fd.get("price")),
      commercialCents: cents(fd.get("commercial_price")),
    });
  };

  const body = (
    <form action={action} className="st-form"
      onInput={(e) => readForm(e.currentTarget)}
      onChange={(e) => readForm(e.currentTarget)}
      ref={(el) => { if (el && !preview) readForm(el); }}>
      {item && <input type="hidden" name="id" value={item.id} />}

      <label className="st-field">
        <span className="st-field__label">Title</span>
        <input name="title" required minLength={3} maxLength={90} defaultValue={item?.title}
          placeholder="Kobo — fintech app UI kit" />
      </label>

      <div className="st-row">
        <label className="st-field">
          <span className="st-field__label">Category</span>
          {/*
            Uncontrolled on purpose. The state is only here to work out
            which subcategories and formats to offer; binding value= as
            well means any render that throws or hydrates against a stale
            bundle snaps the field back to "Choose…", losing the choice
            the person just made. defaultValue leaves the DOM in charge
            of what is selected, so their pick survives either way.
          */}
          <select name="category" required defaultValue={item?.category ?? ""}
            onChange={(e) => setCategory(e.target.value)}>
            <option value="" disabled>Choose…</option>
            {CATEGORIES.map((c) => <option key={c.slug} value={c.slug}>{c.name}</option>)}
          </select>
        </label>
        <label className="st-field">
          <span className="st-field__label">Type</span>
          <select name="subcategory" required key={category} defaultValue={item?.category === category ? item?.subcategory : ""}
            disabled={!cat}>
            <option value="" disabled>{cat ? "Choose…" : "Pick a category first"}</option>
            {cat?.subcategories.map((s) => <option key={s.slug} value={s.slug}>{s.name}</option>)}
          </select>
        </label>
      </div>

      <label className="st-field">
        <span className="st-field__label">Description</span>
        <textarea name="summary" required minLength={20} maxLength={600} rows={4} defaultValue={item?.summary}
          placeholder="What it is, who it is for, and what makes it good. Buyers read the first sentence most." />
      </label>

      <fieldset className="st-field">
        <legend className="st-field__label">File formats</legend>
        {cat ? (
          <div className="st-checks">
            {cat.formats.map((f) => (
              <label key={f} className="st-check">
                <input type="checkbox" name="formats" value={f}
                  defaultChecked={item?.category === category && item?.formats.includes(f)} />
                <span>{f}</span>
              </label>
            ))}
          </div>
        ) : <span className="st-field__hint">Pick a category to see its formats.</span>}
      </fieldset>

      <label className="st-field">
        <span className="st-field__label">What is included <span className="st-opt">one per line</span></span>
        <textarea name="includes" rows={4} defaultValue={item?.includes.join("\n")}
          placeholder={"86 screens\nLight and dark mode\nAuto-layout components"} />
      </label>

      <label className="st-field">
        <span className="st-field__label">Tags <span className="st-opt">comma separated</span></span>
        <input name="tags" maxLength={200} defaultValue={item?.tags.join(", ")} placeholder="fintech, banking, mobile" />
      </label>

      <div className="st-row">
        <label className="st-field">
          <span className="st-field__label">Personal licence (USD)</span>
          <span className="st-money"><span>$</span>
            <input name="price" required inputMode="decimal" value={price} onChange={(e) => setPrice(e.target.value)} placeholder="19" />
          </span>
          <span className="st-field__hint">0 makes it free for any use.</span>
        </label>
        <label className="st-field">
          <span className="st-field__label">Commercial licence (USD) <span className="st-opt">optional</span></span>
          <span className="st-money"><span>$</span>
            <input name="commercial_price" inputMode="decimal" disabled={free}
              defaultValue={dollars(item?.commercialCents)} placeholder={free ? "—" : "57"} />
          </span>
          <span className="st-field__hint">For products that are resold or used in paid ads.</span>
        </label>
      </div>

      {!free && (
        <details className="st-local" open={Boolean(item?.prices?.GBP || item?.prices?.NGN)}>
          <summary className="st-local__sum">
            Prices in pounds and naira <span className="st-opt">optional</span>
          </summary>
          <p className="st-field__hint st-local__why">
            Set a figure that reads right in that market — £15, ₦25,000 — rather than converting the dollar
            price. Leave a currency blank and buyers there are charged in dollars. Earnings are paid to you
            in the currency each sale was taken in.
          </p>
          {(["GBP", "NGN"] as const).map((c) => (
            <div className="st-row" key={c}>
              <label className="st-field">
                <span className="st-field__label">Personal licence ({CCY_LABEL[c]})</span>
                <span className="st-money"><span>{CCY_SYMBOL[c]}</span>
                  <input name={`price_${c}`} inputMode="decimal"
                    defaultValue={units(item?.prices?.[c]?.priceCents, c)}
                    placeholder={c === "GBP" ? "15" : "25000"} />
                </span>
              </label>
              <label className="st-field">
                <span className="st-field__label">Commercial licence ({CCY_LABEL[c]}) <span className="st-opt">optional</span></span>
                <span className="st-money"><span>{CCY_SYMBOL[c]}</span>
                  <input name={`commercial_${c}`} inputMode="decimal"
                    defaultValue={units(item?.prices?.[c]?.commercialCents, c)}
                    placeholder={c === "GBP" ? "45" : "75000"} />
                </span>
              </label>
            </div>
          ))}
        </details>
      )}

      {state.error && <p className="st-msg st-msg--err" role="alert">{state.error}</p>}
      {state.ok && <p className="st-msg st-msg--ok" role="status">{state.message ?? "Saved."}</p>}
      <div className="st-actions">
        <StudioSubmit>{item ? "Save changes" : "Create draft"}</StudioSubmit>
        {!item && <span className="st-field__hint">You add the cover and the file on the next step.</span>}
      </div>
    </form>
  );

  // Without a shop name there is nobody to preview for — the edit screen
  // renders the form on its own, beside panels of its own.
  if (!shopName) return body;

  return (
    <div className="st-compose">
      {body}
      <ItemPreview f={preview ?? EMPTY_PREVIEW} shopName={shopName} />
    </div>
  );
}

const EMPTY_PREVIEW: PreviewFields = {
  title: "", category: "", subcategory: "", summary: "",
  includes: [], tags: [], formats: [], priceCents: null, commercialCents: null,
};
