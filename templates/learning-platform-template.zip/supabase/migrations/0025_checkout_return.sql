-- =====================================================================
-- Where to send someone back to after paying.
--
-- Somebody hits the paywall three topics into a course, pays, and is
-- currently dropped on the dashboard to find their place again. The lesson
-- they were on is known at the moment they click through to the plans, so
-- it is carried on the intent rather than guessed at afterwards.
--
-- Stored server-side on the intent, not passed through the payment
-- provider and back, because anything that makes a round trip through a
-- redirect is attacker-controlled by the time it returns.
-- =====================================================================

alter table checkout_intents add column return_to text;

comment on column checkout_intents.return_to is
  'In-app path to resume after payment. Relative paths only — validated on write.';
