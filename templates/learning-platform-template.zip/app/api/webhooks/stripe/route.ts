import { NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { verifyWebhook } from "@/lib/stripe";
import { fulfilPayment } from "@/lib/fulfil";

export const dynamic = "force-dynamic";

/**
 * Stripe webhook. Same shape as the Paystack one: check the signature
 * against the raw body, record the event (the unique key makes retries
 * harmless), then hand the reference to fulfilment, which re-verifies with
 * Stripe and checks the amount against the intent.
 */
export async function POST(request: Request) {
  if (!process.env.STRIPE_WEBHOOK_SECRET) {
    console.error("STRIPE_WEBHOOK_SECRET unset — refusing webhook");
    return NextResponse.json({ error: "not configured" }, { status: 503 });
  }

  const raw = await request.text();
  if (!verifyWebhook(raw, request.headers.get("stripe-signature"))) {
    return NextResponse.json({ error: "bad signature" }, { status: 401 });
  }

  let body: { id?: string; type?: string; data?: { object?: Record<string, unknown> } };
  try { body = JSON.parse(raw); } catch { return NextResponse.json({ error: "bad body" }, { status: 400 }); }

  const object = body.data?.object ?? {};
  const txRef = object.client_reference_id ? String(object.client_reference_id)
    : (object.metadata as Record<string, string> | undefined)?.tx_ref ?? null;
  const providerRef = body.id ?? (object.id ? String(object.id) : txRef);
  if (!providerRef) return NextResponse.json({ ok: true });

  const admin = createAdminClient();
  const { error: logErr } = await admin.from("payment_events").insert({
    provider: "stripe",
    event_type: String(body.type ?? ""),
    provider_ref: providerRef,
    tx_ref: txRef,
    payload: body as unknown as Record<string, unknown>,
  });
  if (logErr && logErr.code === "23505") return NextResponse.json({ ok: true, duplicate: true });

  if (body.type !== "checkout.session.completed" || !txRef) return NextResponse.json({ ok: true });

  const result = await fulfilPayment(txRef);
  if (!result.ok) {
    console.error("stripe webhook fulfil declined", txRef, result.reason);
    return NextResponse.json({ ok: true, ignored: result.reason });
  }

  await admin.from("payment_events").update({ handled_at: new Date().toISOString() })
    .eq("provider", "stripe").eq("provider_ref", providerRef).eq("event_type", body.type);

  return NextResponse.json({ ok: true });
}
