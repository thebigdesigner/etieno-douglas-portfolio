import { createAdminClient } from "@/lib/supabase/admin";

export { SUBJECTS } from "@/lib/subjects";

/**
 * Has this person bought anything at all?
 *
 * Not a permission — course_entitlement decides whether a particular course
 * opens, and it is the only thing that should. This answers the softer
 * question the dashboard and the account page ask: is this a learner who has
 * paid for something, or one who has only ever seen free material. It drives
 * copy, not access.
 *
 * Before 0063 this asked whether there was a live subscription, which was the
 * whole story when a plan was the only thing anyone could buy.
 *
 * Cohort learners count. Their institution paid on their behalf, and telling
 * somebody whose school bought their place that they have not bought anything
 * would be both wrong and impossible for them to act on.
 */
export async function hasAccess(userId: string): Promise<boolean> {
  const admin = createAdminClient();

  const { data: purchase, error } = await admin
    .from("course_purchases")
    .select("id")
    .eq("user_id", userId)
    .is("refunded_at", null)
    .limit(1)
    .maybeSingle();

  // Never swallow this. A failed lookup and a genuine no-purchase both
  // returned false silently, which is why "paid but locked out" stayed
  // invisible in the logs for as long as it did.
  if (error) {
    console.error("hasAccess purchase lookup failed", userId, error);
  }

  if (purchase) return true;

  const { data: cohort, error: cohortError } = await admin
    .from("enrolments")
    .select("id")
    .eq("user_id", userId)
    .eq("source", "cohort")
    .limit(1)
    .maybeSingle();

  if (cohortError) {
    console.error("hasAccess cohort lookup failed", userId, cohortError);
  }

  return !!cohort;
}

/**
 * Where the paywall sits: after module one, never at signup. A learner who has
 * felt one module of value converts far better than one asked to pay to look.
 */
export async function isBeyondFreeModule(
  courseId: string,
  topicId: string
): Promise<boolean> {
  const admin = createAdminClient();

  // A course marked free is open all the way through.
  const { data: course } = await admin
    .from("courses").select("is_free").eq("id", courseId).maybeSingle();
  if (course?.is_free) return false;

  const { data: firstModule } = await admin
    .from("modules")
    .select("id")
    .eq("course_id", courseId)
    .order("position")
    .limit(1)
    .maybeSingle();

  if (!firstModule) return false;

  const { data: topic } = await admin
    .from("topics")
    .select("module_id")
    .eq("id", topicId)
    .maybeSingle();

  return !!topic && topic.module_id !== firstModule.id;
}
