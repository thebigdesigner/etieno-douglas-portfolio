-- =====================================================================
-- Marketplace studio: where creators upload what they sell.
--
-- Two buckets, split by who may read them:
--   mk-covers  public.  Cover images are shown to everyone browsing.
--   mk-files   private. The product itself. Read only through a signed
--              URL minted server-side after the order check, never by
--              being signed in — same reasoning as the videos bucket.
--
-- Creators upload straight from the browser into a folder named after
-- their user id, so a 300MB UI kit never passes through a server action
-- (which caps request bodies at 5MB). The server then checks the path
-- belongs to them before attaching it to an item.
-- =====================================================================

insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('mk-covers', 'mk-covers', true, 10485760,
        array['image/png','image/jpeg','image/webp'])
on conflict (id) do nothing;

insert into storage.buckets (id, name, public, file_size_limit)
values ('mk-files', 'mk-files', false, 524288000)
on conflict (id) do nothing;

drop policy if exists "mk creators upload own covers" on storage.objects;
create policy "mk creators upload own covers" on storage.objects for insert to authenticated
  with check (bucket_id = 'mk-covers' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "mk creators replace own covers" on storage.objects;
create policy "mk creators replace own covers" on storage.objects for update to authenticated
  using (bucket_id = 'mk-covers' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "mk creators remove own covers" on storage.objects;
create policy "mk creators remove own covers" on storage.objects for delete to authenticated
  using (bucket_id = 'mk-covers' and (storage.foldername(name))[1] = auth.uid()::text);

drop policy if exists "mk creators upload own files" on storage.objects;
create policy "mk creators upload own files" on storage.objects for insert to authenticated
  with check (bucket_id = 'mk-files' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "mk creators replace own files" on storage.objects;
create policy "mk creators replace own files" on storage.objects for update to authenticated
  using (bucket_id = 'mk-files' and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists "mk creators remove own files" on storage.objects;
create policy "mk creators remove own files" on storage.objects for delete to authenticated
  using (bucket_id = 'mk-files' and (storage.foldername(name))[1] = auth.uid()::text);
-- No select policy on mk-files for anyone: downloads are signed server-side.

-- What the creator called the file, for the buyer's download button.
alter table mk_product_files add column if not exists name text;

-- Why an item was sent back, shown to its creator in the studio.
alter table mk_products add column if not exists review_note text;
alter table mk_products add column if not exists submitted_at timestamptz;

create index if not exists mk_products_review_idx on mk_products (state, submitted_at)
  where state = 'in_review';
