/** The "Hi, X" header. Time-aware, because a dashboard opened at 7am and one
 *  opened at 9pm are different moments. */
export default function Greeting({
  name, sub,
}: { name: string | null; sub?: string }) {
  const hour = new Date().getHours();
  const part = hour < 12 ? "Good morning" : hour < 18 ? "Good afternoon" : "Good evening";
  const first = name?.split(" ")[0];

  return (
    <div className="greet">
      <h1 className="greet__h">
        {part}{first ? `, ${first}` : ""}
      </h1>
      {sub && <p className="greet__s">{sub}</p>}
    </div>
  );
}
