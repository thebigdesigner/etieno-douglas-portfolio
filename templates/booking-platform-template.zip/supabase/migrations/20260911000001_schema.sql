-- ============================================================================
-- HISPREN TRANSPORT OS — core schema (Postgres / Supabase)
-- Run once in the Supabase SQL editor. Safe to re-run: every object uses IF NOT EXISTS
-- or CREATE OR REPLACE.
--
-- Design notes
--   * Every business table carries tenant_id. Your Brand is simply the first row in
--     tenants; a second operator is a second row, never a second deployment.
--   * Seats are rows, not a count. A seat can only be sold once because claiming it is a
--     single UPDATE guarded by its state — see claim_seats() at the bottom.
--   * Money is stored in kobo (integer). Never floats.
--   * Nothing is hard deleted; rows carry status and timestamps so the audit trail holds.
-- ============================================================================

create extension if not exists pgcrypto;

-- ---------------------------------------------------------------- tenants
create table if not exists tenants (
  id              uuid primary key default gen_random_uuid(),
  slug            text not null unique,
  name            text not null,
  prefix          text not null,                       -- booking reference prefix, e.g. ATX
  currency        text not null default 'NGN',
  settings        jsonb not null default '{}'::jsonb,  -- hold minutes, child ratio, check-in rules
  created_at      timestamptz not null default now()
);

-- ---------------------------------------------------------------- people
create table if not exists customers (
  id              uuid primary key default gen_random_uuid(),
  tenant_id       uuid not null references tenants(id) on delete cascade,
  google_sub      text,                                 -- set when they sign in with Google
  name            text,
  email           text,
  phone           text not null,
  created_at      timestamptz not null default now(),
  unique (tenant_id, phone)
);
create index if not exists customers_tenant_email_idx on customers (tenant_id, lower(email));
create unique index if not exists customers_google_idx on customers (tenant_id, google_sub) where google_sub is not null;

create table if not exists staff (
  id              uuid primary key default gen_random_uuid(),
  tenant_id       uuid not null references tenants(id) on delete cascade,
  auth_user_id    uuid unique,                          -- Supabase auth.users.id
  name            text not null,
  email           text not null,
  role            text not null check (role in ('manager','terminal','accountant','driver')),
  terminal_id     uuid,                                 -- terminal staff are scoped to one desk
  active          boolean not null default true,
  created_at      timestamptz not null default now(),
  unique (tenant_id, email)
);

-- ---------------------------------------------------------------- network
create table if not exists terminals (
  id              uuid primary key default gen_random_uuid(),
  tenant_id       uuid not null references tenants(id) on delete cascade,
  code            text not null,                        -- uyo, phc, cal
  city            text not null,
  name            text not null,
  address         text,
  phone           text,
  whatsapp        text,
  opens_at        time,
  active          boolean not null default true,
  unique (tenant_id, code)
);

create table if not exists vehicles (
  id              uuid primary key default gen_random_uuid(),
  tenant_id       uuid not null references tenants(id) on delete cascade,
  label           text not null,                        -- Toyota Sequoia
  plate           text,
  capacity        smallint not null check (capacity between 1 and 80),
  seat_map        jsonb not null,                       -- [["D",1],[2,3],[4,5]] plus seat labels
  status          text not null default 'active' check (status in ('active','maintenance','retired')),
  unique (tenant_id, plate)
);

create table if not exists drivers (
  id              uuid primary key default gen_random_uuid(),
  tenant_id       uuid not null references tenants(id) on delete cascade,
  staff_id        uuid references staff(id),
  name            text not null,
  phone           text not null,
  licence_no      text,
  active          boolean not null default true,
  unique (tenant_id, phone)
);

create table if not exists routes (
  id              uuid primary key default gen_random_uuid(),
  tenant_id       uuid not null references tenants(id) on delete cascade,
  from_terminal   uuid not null references terminals(id),
  to_terminal     uuid not null references terminals(id),
  fare_kobo       integer not null check (fare_kobo > 0),
  duration_min    integer not null check (duration_min > 0),
  operating_days  smallint[] not null,                  -- 0=Sunday … 6=Saturday
  departures      time[] not null,
  active          boolean not null default true,
  check (from_terminal <> to_terminal),
  unique (tenant_id, from_terminal, to_terminal)
);

-- ---------------------------------------------------------------- operations
create table if not exists trips (
  id              uuid primary key default gen_random_uuid(),
  tenant_id       uuid not null references tenants(id) on delete cascade,
  route_id        uuid not null references routes(id),
  vehicle_id      uuid references vehicles(id),
  driver_id       uuid references drivers(id),
  depart_date     date not null,
  depart_time     time not null,
  capacity        smallint not null,                    -- copied from the vehicle, overridable
  fare_kobo       integer not null,                     -- copied from the route at creation
  status          text not null default 'scheduled'
                  check (status in ('scheduled','boarding','departed','arrived','completed','cancelled')),
  departed_at     timestamptz,
  arrived_at      timestamptz,
  created_at      timestamptz not null default now(),
  unique (tenant_id, route_id, depart_date, depart_time)
);
create index if not exists trips_lookup_idx on trips (tenant_id, depart_date, route_id) where status <> 'cancelled';

create table if not exists bookings (
  id              uuid primary key default gen_random_uuid(),
  tenant_id       uuid not null references tenants(id) on delete cascade,
  reference       text not null,
  customer_id     uuid references customers(id),
  channel         text not null default 'web' check (channel in ('web','terminal','phone','whatsapp','api')),
  created_by      uuid references staff(id),            -- terminal staff, when not self-service
  status          text not null default 'pending'
                  check (status in ('pending','confirmed','cancelled','expired','refunded','no_show','completed')),
  contact_name    text,
  contact_phone   text not null,
  contact_email   text,
  kin_name        text,
  kin_phone       text,
  total_kobo      integer not null default 0,
  hold_expires_at timestamptz,                          -- while unpaid; null once settled
  confirmed_at    timestamptz,
  cancelled_at    timestamptz,
  created_at      timestamptz not null default now(),
  unique (tenant_id, reference)
);
create index if not exists bookings_phone_idx on bookings (tenant_id, contact_phone);
create index if not exists bookings_expiry_idx on bookings (hold_expires_at) where status = 'pending';

-- One row per physical seat on a trip. This table is why a seat cannot be sold twice.
create table if not exists trip_seats (
  trip_id         uuid not null references trips(id) on delete cascade,
  seat_no         smallint not null,
  state           text not null default 'free' check (state in ('free','held','sold','blocked')),
  booking_id      uuid references bookings(id) on delete set null,
  held_until      timestamptz,
  updated_at      timestamptz not null default now(),
  primary key (trip_id, seat_no)
);
create index if not exists trip_seats_state_idx on trip_seats (trip_id, state);
create index if not exists trip_seats_expiry_idx on trip_seats (held_until) where state = 'held';

create table if not exists passengers (
  id              uuid primary key default gen_random_uuid(),
  booking_id      uuid not null references bookings(id) on delete cascade,
  trip_id         uuid not null references trips(id),
  seat_no         smallint not null,
  full_name       text not null,
  pax_type        text not null default 'adult' check (pax_type in ('adult','child','infant')),
  fare_kobo       integer not null,
  status          text not null default 'reserved'
                  check (status in ('reserved','confirmed','checked_in','boarded','no_show','cancelled')),
  checked_in_at   timestamptz,
  boarded_at      timestamptz,
  unique (trip_id, seat_no)
);

-- ---------------------------------------------------------------- money
create table if not exists payments (
  id              uuid primary key default gen_random_uuid(),
  tenant_id       uuid not null references tenants(id) on delete cascade,
  booking_id      uuid not null references bookings(id),
  provider        text not null default 'paystack' check (provider in ('paystack','cash','pos','transfer','other')),
  provider_ref    text,                                 -- Paystack reference; unique per tenant
  amount_kobo     integer not null,
  status          text not null default 'initialised'
                  check (status in ('initialised','pending','success','failed','abandoned','reversed')),
  channel         text,                                 -- card, bank_transfer, ussd …
  recorded_by     uuid references staff(id),            -- who took the cash, when offline
  raw             jsonb,                                -- verified provider payload
  created_at      timestamptz not null default now(),
  settled_at      timestamptz
);
create unique index if not exists payments_provider_ref_idx on payments (tenant_id, provider_ref) where provider_ref is not null;
create index if not exists payments_booking_idx on payments (booking_id);

-- Webhook deliveries, so a replayed Paystack event can never be applied twice.
create table if not exists webhook_events (
  id              uuid primary key default gen_random_uuid(),
  provider        text not null,
  event_id        text not null,
  received_at     timestamptz not null default now(),
  payload         jsonb,
  unique (provider, event_id)
);

create table if not exists refunds (
  id              uuid primary key default gen_random_uuid(),
  tenant_id       uuid not null references tenants(id) on delete cascade,
  booking_id      uuid not null references bookings(id),
  amount_kobo     integer not null,
  reason          text,
  approved_by     uuid references staff(id),
  status          text not null default 'pending' check (status in ('pending','processed','rejected')),
  created_at      timestamptz not null default now()
);

create table if not exists expenses (
  id              uuid primary key default gen_random_uuid(),
  tenant_id       uuid not null references tenants(id) on delete cascade,
  trip_id         uuid references trips(id),
  vehicle_id      uuid references vehicles(id),
  category        text not null,
  amount_kobo     integer not null,
  note            text,
  recorded_by     uuid references staff(id),
  incurred_on     date not null default current_date,
  created_at      timestamptz not null default now()
);

-- ---------------------------------------------------------------- audit
create table if not exists audit_log (
  id              bigserial primary key,
  tenant_id       uuid references tenants(id) on delete cascade,
  actor_type      text not null check (actor_type in ('customer','staff','system','provider')),
  actor_id        uuid,
  action          text not null,                        -- booking.created, payment.confirmed …
  entity          text not null,
  entity_id       uuid,
  detail          jsonb,
  created_at      timestamptz not null default now()
);
create index if not exists audit_tenant_time_idx on audit_log (tenant_id, created_at desc);

-- ============================================================================
-- SEAT CLAIM
-- The only supported way to take seats. Runs in one transaction: it locks just the seats
-- asked for, releases any hold that has expired, and fails loudly if another booking got
-- there first. Two people tapping the last seat at the same moment: one succeeds, one gets
-- 'seat_taken'.
-- ============================================================================
create or replace function claim_seats(
  p_trip_id   uuid,
  p_seats     smallint[],
  p_booking   uuid,
  p_hold_mins integer
) returns void
language plpgsql
as $$
declare
  v_locked  integer;
  v_claimed integer;
begin
  -- Lock the requested seats in a deterministic order so concurrent callers cannot deadlock.
  select count(*) into v_locked
  from (
    select seat_no from trip_seats
    where trip_id = p_trip_id and seat_no = any(p_seats)
    order by seat_no
    for update
  ) locked;

  if v_locked <> array_length(p_seats, 1) then
    raise exception 'seat_missing' using hint = 'A requested seat does not exist on this trip.';
  end if;

  -- A hold that has run out is free again.
  update trip_seats
     set state = 'free', booking_id = null, held_until = null, updated_at = now()
   where trip_id = p_trip_id
     and seat_no = any(p_seats)
     and state = 'held'
     and held_until < now();

  update trip_seats
     set state      = 'held',
         booking_id = p_booking,
         held_until = now() + make_interval(mins => p_hold_mins),
         updated_at = now()
   where trip_id = p_trip_id
     and seat_no = any(p_seats)
     and state = 'free';

  get diagnostics v_claimed = row_count;

  if v_claimed <> array_length(p_seats, 1) then
    raise exception 'seat_taken' using hint = 'Someone else took one of those seats.';
  end if;
end;
$$;

-- Settle a booking once payment is verified: seats become sold, passengers confirmed.
create or replace function confirm_booking(p_booking uuid)
returns void
language plpgsql
as $$
begin
  update trip_seats
     set state = 'sold', held_until = null, updated_at = now()
   where booking_id = p_booking and state in ('held', 'sold');

  update passengers set status = 'confirmed'
   where booking_id = p_booking and status = 'reserved';

  update bookings
     set status = 'confirmed', confirmed_at = coalesce(confirmed_at, now()), hold_expires_at = null
   where id = p_booking and status in ('pending', 'confirmed');
end;
$$;

-- Release everything a booking is holding (expiry, cancellation).
create or replace function release_booking(p_booking uuid, p_status text)
returns void
language plpgsql
as $$
begin
  update trip_seats
     set state = 'free', booking_id = null, held_until = null, updated_at = now()
   where booking_id = p_booking and state = 'held';

  update passengers set status = 'cancelled'
   where booking_id = p_booking and status in ('reserved', 'confirmed');

  update bookings
     set status = p_status, cancelled_at = now(), hold_expires_at = null
   where id = p_booking;
end;
$$;

-- Sweep expired holds. Call from a scheduled job (pg_cron or a Vercel cron hitting an endpoint).
create or replace function expire_holds()
returns integer
language plpgsql
as $$
declare v_count integer;
begin
  with dead as (
    select id from bookings
     where status = 'pending' and hold_expires_at is not null and hold_expires_at < now()
     for update skip locked
  )
  select count(*) into v_count from dead;

  update trip_seats ts
     set state = 'free', booking_id = null, held_until = null, updated_at = now()
    from bookings b
   where ts.booking_id = b.id and ts.state = 'held'
     and b.status = 'pending' and b.hold_expires_at < now();

  update bookings
     set status = 'expired', hold_expires_at = null
   where status = 'pending' and hold_expires_at is not null and hold_expires_at < now();

  return coalesce(v_count, 0);
end;
$$;

-- ============================================================================
-- ROW LEVEL SECURITY
-- The API uses the service role and scopes every query by tenant itself. RLS is the second
-- line: even a leaked anon key cannot read another operator's data, or any customer data.
-- ============================================================================
alter table tenants      enable row level security;
alter table customers    enable row level security;
alter table staff        enable row level security;
alter table terminals    enable row level security;
alter table vehicles     enable row level security;
alter table drivers      enable row level security;
alter table routes       enable row level security;
alter table trips        enable row level security;
alter table bookings     enable row level security;
alter table trip_seats   enable row level security;
alter table passengers   enable row level security;
alter table payments     enable row level security;
alter table refunds      enable row level security;
alter table expenses     enable row level security;
alter table audit_log    enable row level security;
alter table webhook_events enable row level security;

-- Staff may read their own tenant's operational data.
create policy staff_reads_own_tenant on trips for select
  using (tenant_id in (select tenant_id from staff where auth_user_id = auth.uid() and active));

create policy staff_reads_bookings on bookings for select
  using (tenant_id in (select tenant_id from staff where auth_user_id = auth.uid() and active));

-- Money is for managers and accountants only.
create policy finance_reads_payments on payments for select
  using (tenant_id in (
    select tenant_id from staff
     where auth_user_id = auth.uid() and active and role in ('manager','accountant')
  ));

-- No anon policies anywhere: the public site reaches data only through the API.

-- ============================================================================
-- SCHEDULED HOLD EXPIRY (runs inside Postgres, no external cron needed)
-- Supabase: Database → Extensions → enable "pg_cron", then run this block once.
-- Vercel's Hobby plan only allows daily crons, so the sweep lives here instead.
-- ============================================================================
-- create extension if not exists pg_cron;
-- select cron.schedule('expire-holds', '*/2 * * * *', $$select expire_holds();$$);
--
-- Keep the departure calendar rolling (run once a day at 02:00):
-- select cron.schedule('generate-trips', '0 2 * * *', $$select generate_trips('ace-trail', 30);$$);
--
-- To inspect or remove:
-- select * from cron.job;
-- select cron.unschedule('expire-holds');
