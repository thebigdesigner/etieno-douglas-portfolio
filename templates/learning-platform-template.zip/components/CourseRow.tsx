import Link from "next/link";
import CourseThumb from "@/components/CourseThumb";

export type RowCourse = {
  // Both are returned by the learner_courses view and used as keys / RPC
  // arguments on the dashboard; they were missing here, which broke the build.
  enrolment_id: string;
  course_id: string;
  slug: string;
  title: string;
  subject: string;
  thumbnail_path: string | null;
  pct: number | null;
  topics_done: number | null;
  topics_total: number | null;
  hours_high: number | null;
  last_active: string | null;
  state: string;
  submission_state: string | null;
  certificate_code: string | null;
  nextTopicId?: string | null;
};

/** "over 30 days ago" rather than a date — the point is how stale it is. */
function lastActiveLabel(iso: string | null): string {
  if (!iso) return "Not started";
  const days = Math.floor((Date.now() - new Date(iso).getTime()) / 86400_000);
  if (days === 0) return "Active today";
  if (days === 1) return "Active yesterday";
  if (days < 30) return `Last active ${days} days ago`;
  return "Last active over 30 days ago";
}

/** Remaining hours from the instructor's estimate and how far through they are. */
function timeLeft(hoursHigh: number | null, pct: number | null): string | null {
  if (!hoursHigh) return null;
  const remaining = hoursHigh * (1 - (pct ?? 0) / 100);
  if (remaining <= 0) return null;
  const hrs = Math.floor(remaining);
  const mins = Math.round((remaining - hrs) * 60);
  if (hrs === 0) return `${mins} mins left`;
  return `${hrs} hr${hrs === 1 ? "" : "s"} ${mins} mins left`;
}

export default function CourseRow({ course }: { course: RowCourse }) {
  const pct = Number(course.pct ?? 0);
  const done = pct >= 100;
  const awaiting = ["submitted", "assigned", "in_review"].includes(
    course.submission_state ?? ""
  );

  const href = course.certificate_code
    ? "/dashboard/certificates"
    : awaiting
      ? "/dashboard/submissions"
      : done
        ? `/courses/${course.slug}/submit`
        : course.nextTopicId
          ? `/learn/${course.slug}/${course.nextTopicId}`
          : `/courses/${course.slug}`;

  const cta = course.certificate_code
    ? "See certificate"
    : awaiting
      ? "Being assessed"
      : done
        ? "Submit project"
        : pct > 0
          ? "Continue learning"
          : "Start learning";

  const left = timeLeft(course.hours_high, pct);

  return (
    <article className="crow">
      <Link className="crow__thumb" href={`/courses/${course.slug}`}>
        <CourseThumb
          path={course.thumbnail_path}
          title={course.title}
          subject={course.subject}
        />
      </Link>

      <div className="crow__body">
        <Link className="crow__h" href={`/courses/${course.slug}`}>{course.title}</Link>

        <div className="crow__meta">
          <span className={`crow__last${
            course.last_active &&
            Date.now() - new Date(course.last_active).getTime() > 30 * 86400_000
              ? " is-stale" : ""}`}>
            {lastActiveLabel(course.last_active)}
          </span>
          {course.topics_total ? (
            <span className="crow__topics num">
              {course.topics_done ?? 0} of {course.topics_total} topics
            </span>
          ) : null}
        </div>

        <div className="crow__prog">
          <div className="crow__bar">
            <span
              className={pct >= 100 ? "is-done" : pct >= 40 ? "is-mid" : ""}
              style={{ width: `${Math.max(pct, 2)}%` }}
            />
          </div>
          <span className="crow__pct num">{pct}%</span>
        </div>
      </div>

      <div className="crow__act">
        <Link className={`crow__cta${awaiting ? " is-waiting" : ""}`} href={href}>
          {cta}
          {left && !done && <span className="crow__left">{left}</span>}
        </Link>
      </div>
    </article>
  );
}
