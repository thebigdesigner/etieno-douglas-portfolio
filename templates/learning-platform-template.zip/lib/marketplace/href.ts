/**
 * Link builder, split from url.ts so client components can use it without
 * pulling next/headers into the browser bundle.
 */
/** Joins the base and a path, and never returns an empty string. */
export function mk(base: string, path = "/"): string {
  const p = path.startsWith("/") ? path : `/${path}`;
  const joined = `${base}${p === "/" && base ? "" : p}`;
  return joined || "/";
}

/** marketplace.yourbrand.com, or whatever MARKETPLACE_HOST names. Edge-safe. */
export function isMarketplaceHost(host: string | null | undefined): boolean {
  if (!host) return false;
  const bare = host.split(":")[0].toLowerCase();
  const configured = process.env.MARKETPLACE_HOST?.toLowerCase();
  return bare === configured || bare.startsWith("marketplace.");
}

