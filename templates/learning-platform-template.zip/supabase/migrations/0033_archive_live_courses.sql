-- =====================================================================
-- 0033 — archive, for courses that are already live
--
-- 0032 refuses deletes on a published course. That is the right rule and
-- it leaves a gap: an instructor who publishes a topic they should not
-- have has no way to withdraw it.
--
-- Archiving is the answer. An archived topic disappears for anyone who
-- has not already started it, and stays exactly where it was for anyone
-- who has — their completion, their notes and their progress are
-- untouched, and the royalty pool still counts the topics they finished.
--
-- Nothing is deleted, so nothing cascades. That is the whole point.
-- =====================================================================

alter table modules add column if not exists archived_at timestamptz;
alter table topics  add column if not exists archived_at timestamptz;

comment on column topics.archived_at is
  'Withdrawn from a live course. Hidden from learners who never completed it; still present for those who did.';

create index if not exists topics_live on topics (module_id) where archived_at is null;

-- ---------------------------------------------------------------------
-- The outline, respecting archives.
--
-- A learner who completed an archived topic still sees it, so their
-- progress does not silently jump and a finished course does not become
-- unfinished. Everyone else sees the course without it.
-- ---------------------------------------------------------------------
create or replace function public.course_outline(p_course_id uuid, p_user_id uuid)
returns table (
  topic_id     uuid,
  module_title text,
  topic_title  text,
  pos          int,
  is_free      boolean,
  has_quiz     boolean,
  completed    boolean,
  unlocked     boolean
)
language sql
stable
security definer set search_path = public
as $$
  with done as (
    select tc.topic_id
      from topic_completions tc
      join enrolments e on e.id = tc.enrolment_id
     where e.user_id = p_user_id and e.course_id = p_course_id
  ),
  ordered as (
    select t.id,
           m.title as module_title,
           t.title as topic_title,
           row_number() over (order by m.position, t.position)::int as pos,
           t.is_free,
           exists (select 1 from quiz_items q where q.topic_id = t.id) as has_quiz
      from topics t
      join modules m on m.id = t.module_id
     where m.course_id = p_course_id
       and m.archived_at is null
       -- Archived topics survive for the people who already did them.
       and (t.archived_at is null or t.id in (select topic_id from done))
  )
  select o.id,
         o.module_title,
         o.topic_title,
         o.pos,
         o.is_free,
         o.has_quiz,
         (o.id in (select topic_id from done)) as completed,
         (
           o.pos = 1
           or o.is_free
           or (select count(*) from ordered o2
                where o2.pos < o.pos
                  and o2.id not in (select topic_id from done)) = 0
         ) as unlocked
    from ordered o
   order by o.pos;
$$;

-- ---------------------------------------------------------------------
-- Archiving is allowed on a live course. It is the one structural change
-- that is, which is why it gets functions of its own rather than being a
-- column an update could set from anywhere.
-- ---------------------------------------------------------------------
create or replace function public.archive_topic(p_topic_id uuid, p_instructor_id uuid)
returns table (ok boolean, reason text)
language plpgsql
security definer set search_path = public
as $$
declare v_course courses%rowtype;
begin
  select c.* into v_course
    from topics t join modules m on m.id = t.module_id join courses c on c.id = m.course_id
   where t.id = p_topic_id;

  if not found then return query select false, 'no_topic'; return; end if;
  if v_course.instructor_id <> p_instructor_id then
    return query select false, 'not_yours'; return;
  end if;

  update topics set archived_at = now() where id = p_topic_id and archived_at is null;
  return query select true, null::text;
end;
$$;

create or replace function public.archive_module(p_module_id uuid, p_instructor_id uuid)
returns table (ok boolean, reason text)
language plpgsql
security definer set search_path = public
as $$
declare v_course courses%rowtype;
begin
  select c.* into v_course
    from modules m join courses c on c.id = m.course_id where m.id = p_module_id;

  if not found then return query select false, 'no_module'; return; end if;
  if v_course.instructor_id <> p_instructor_id then
    return query select false, 'not_yours'; return;
  end if;

  update modules set archived_at = now() where id = p_module_id and archived_at is null;
  -- The topics go with it, so a half-archived module cannot exist.
  update topics set archived_at = now()
   where module_id = p_module_id and archived_at is null;

  return query select true, null::text;
end;
$$;

-- ---------------------------------------------------------------------
-- Publishing counts live topics only. Without this an instructor could
-- archive their way below the three-topic minimum and stay published.
-- ---------------------------------------------------------------------
create or replace function public.live_topic_count(p_course_id uuid)
returns int language sql stable security definer set search_path = public as $$
  select count(*)::int
    from topics t join modules m on m.id = t.module_id
   where m.course_id = p_course_id
     and m.archived_at is null and t.archived_at is null;
$$;
