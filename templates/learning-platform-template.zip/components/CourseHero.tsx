"use client";

import Link from "next/link";
import { useState } from "react";
import { dismissSuggestion } from "@/app/actions/account";
import NavIcon from "@/components/NavIcon";

export type HeroCourse = {
  slug: string;
  title: string;
  summary: string | null;
  subject: string | null;
  thumbnailPath: string | null;
  thumbnailAlt: string | null;
  hoursLow: number | null;
  hoursHigh: number | null;
  /** Present for a course already under way. */
  courseId?: string;
  pct?: number;
  topicsDone?: number;
  topicsTotal?: number;
  nextTopicId?: string | null;
  learners?: number;
};

function thumbUrl(path: string | null) {
  if (!path) return null;
  if (path.startsWith("http")) return path;
  const base = process.env.NEXT_PUBLIC_SUPABASE_URL;
  return base ? `${base}/storage/v1/object/public/thumbnails/${path}` : null;
}

/**
 * The first thing on the dashboard: what to press play on.
 *
 * Styled as a player rather than being one — the thumbnail with a play
 * control over it, which opens the lesson where the real player lives.
 * Embedding the provider iframe here would load a video nobody asked to
 * watch on every dashboard visit.
 */
export default function CourseHero({
  course, mode, firstName,
}: {
  course: HeroCourse;
  mode: "continue" | "suggestion";
  firstName?: string | null;
}) {
  const [gone, setGone] = useState(false);
  if (gone) return null;

  const img = thumbUrl(course.thumbnailPath);
  const href = mode === "continue" && course.nextTopicId
    ? `/learn/${course.slug}/${course.nextTopicId}`
    : `/courses/${course.slug}`;

  const hours = course.hoursLow && course.hoursHigh
    ? `${course.hoursLow}–${course.hoursHigh} hours`
    : null;

  return (
    <section className="dhero">
      <Link className="dhero__screen" href={href} aria-label={`Open ${course.title}`}>
        {img ? (
          <img className="dhero__img" src={img} alt={course.thumbnailAlt ?? ""} />
        ) : (
          <span className="dhero__img dhero__img--none" aria-hidden="true" />
        )}
        <span className="dhero__shade" aria-hidden="true" />
        <span className="dhero__play" aria-hidden="true">
          <NavIcon name="play" size={26} />
        </span>
        {mode === "continue" && (
          <span className="dhero__bar" aria-hidden="true">
            <span className="dhero__barfill" style={{ width: `${course.pct ?? 0}%` }} />
          </span>
        )}
      </Link>

      <div className="dhero__body">
        <div className="dhero__top">
          <span className="tag tag--cool">
            {mode === "continue" ? "Continue where you left off" : "Suggested for you"}
          </span>
          {mode === "suggestion" && (
            <button
              className="dhero__x"
              aria-label="Not interested in this course"
              onClick={() => { setGone(true); void dismissSuggestion(course.slug); }}
            >
              ✕
            </button>
          )}
        </div>

        <h2 className="dhero__h">{course.title}</h2>

        {course.summary && <p className="dhero__p">{course.summary}</p>}

        <div className="dhero__meta">
          {course.subject && <span className="tag">{course.subject}</span>}
          {hours && <span className="tag">{hours}</span>}
          {mode === "continue" && course.topicsTotal ? (
            <span className="tag tag--wait num">
              {course.topicsDone ?? 0} of {course.topicsTotal} topics
            </span>
          ) : null}
          {mode === "suggestion" && (course.learners ?? 0) > 0 && (
            <span className="tag num">{course.learners} learning it</span>
          )}
        </div>

        <div className="dhero__acts">
          <Link className="btn btn--fill" href={href}>
            {mode === "continue" ? "Resume" : "Start the free first topic"}
          </Link>
          {mode === "suggestion" && (
            <Link className="btn btn--line" href="/courses">Browse the catalogue</Link>
          )}
        </div>

        {mode === "suggestion" && (
          <p className="dhero__hint">
            {firstName ? `Picked for you, ${firstName}` : "Picked for you"} — the first
            topic is free, so you can look before deciding.
          </p>
        )}
      </div>
    </section>
  );
}
