"use client";
import { useActionState } from "react";
import { login } from "@/app/actions/auth";
import type { FormState } from "@/lib/forms";
import SubmitButton from "@/components/SubmitButton";
import Alert from "@/components/Alert";

const initial: FormState = {};

export default function LoginForm({ next }: { next?: string }) {
  const [state, action] = useActionState(login, initial);

  return (
    <form action={action} className="auth__form">
      {next && <input type="hidden" name="next" value={next} />}
      <label className="field">
        <span className="field__label">Email</span>
        <input name="email" type="email" autoComplete="email" required />
      </label>
      <label className="field">
        <span className="field__label">Password</span>
        <input name="password" type="password" autoComplete="current-password" required />
      </label>

      {state.error && <Alert kind="error">{state.error}</Alert>}

      <SubmitButton>Log in</SubmitButton>
    </form>
  );
}
