-- =====================================================================
-- Showing who bought something, without telling on them.
--
-- An item page can show the initials of recent buyers. That is a
-- disclosure the buyer never asked for: "AY" beside a product about debt,
-- fertility, immigration or job-hunting is a fact about a person, and on
-- a small marketplace two letters plus a niche product can be enough to
-- identify someone.
--
-- So it is an opt-out they can find, initials only — no names, no links,
-- nothing clickable — and it never appears on an item with too few buyers
-- to hide in. A creator's own sales figures are unaffected: they still see
-- every sale in the studio, which is a record of their business rather
-- than a public billboard.
-- =====================================================================

alter table profiles add column if not exists show_purchases boolean not null default true;

comment on column profiles.show_purchases is
  'When false, this person is never shown among the recent buyers of an item.';

-- Recent buyers of a published item, for the item page.
--
-- security definer because mk_orders is not readable by other buyers, and
-- must not become so: this returns initials and nothing else, for people
-- who have not opted out, and only once MIN_BUYERS distinct people have
-- bought. Below that threshold it returns nothing at all.
create or replace function mk_recent_buyers(p_product uuid, p_limit integer default 4, p_min integer default 3)
returns table (initials text)
language plpgsql stable security definer set search_path = public as $$
declare v_total integer;
begin
  select count(distinct o.user_id) into v_total
    from mk_orders o where o.product_id = p_product and o.status = 'paid';
  if v_total < p_min then return; end if;

  return query
    select upper(left(regexp_replace(coalesce(pr.display_name, 'S'), '[^a-zA-Z ]', '', 'g'), 1)
           || coalesce(substring(split_part(regexp_replace(coalesce(pr.display_name, ''), '[^a-zA-Z ]', '', 'g'), ' ', 2) from 1 for 1), ''))
      from (
        select distinct on (o.user_id) o.user_id, o.paid_at
          from mk_orders o
         where o.product_id = p_product and o.status = 'paid'
         order by o.user_id, o.paid_at desc
      ) b
      join profiles pr on pr.id = b.user_id
     where pr.show_purchases
     order by b.paid_at desc
     limit greatest(p_limit, 0);
end;
$$;
