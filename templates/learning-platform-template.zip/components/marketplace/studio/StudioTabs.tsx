import Link from "next/link";
import { mk } from "@/lib/marketplace/href";

/** Items, earnings: the two halves of running a shop. */
export default function StudioTabs({ base, on }: { base: string; on: "items" | "earnings" }) {
  const tabs = [
    { id: "items", label: "Items", href: mk(base, "/studio") },
    { id: "earnings", label: "Earnings", href: mk(base, "/studio/earnings") },
  ] as const;
  return (
    <nav className="st-tabs" aria-label="Studio">
      {tabs.map((t) => (
        <Link key={t.id} href={t.href} className={`st-tabs__t${t.id === on ? " is-on" : ""}`}
          aria-current={t.id === on ? "page" : undefined}>{t.label}</Link>
      ))}
    </nav>
  );
}
