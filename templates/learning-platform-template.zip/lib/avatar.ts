/**
 * Resolving a stored avatar to something an <img> can use.
 *
 * avatar_path holds one of two things: a path inside the public avatars
 * bucket (what an upload writes), or a full https URL (what Google and
 * LinkedIn hand us at signup). Callers should not have to care which, so
 * this decides.
 */
export function avatarUrl(path: string | null | undefined): string | null {
  if (!path) return null;
  if (path.startsWith("http://") || path.startsWith("https://")) return path;

  const base = process.env.NEXT_PUBLIC_SUPABASE_URL;
  if (!base) return null;
  return `${base}/storage/v1/object/public/avatars/${path}`;
}

/** Fallback when there is no picture. Two letters, never more. */
export function initials(name: string | null | undefined): string {
  const parts = (name ?? "").trim().split(/\s+/).filter(Boolean);
  if (parts.length === 0) return "?";
  return parts.map((w) => w[0]).join("").slice(0, 2).toUpperCase();
}
