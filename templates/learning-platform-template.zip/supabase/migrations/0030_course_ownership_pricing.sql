-- =====================================================================
-- 0030 — who owns a course, and what it costs
--
-- Your Brand stops being one economy and becomes two:
--
--   splari      · written in-house. Covered by the subscription.
--   institution · written by an organisation for its own cohorts.
--                 Covered by their seat billing.
--   instructor  · written by a practitioner. Bought once, and the price
--                 includes the assessment of that course's project.
--
-- Only instructor courses carry a price. The other two are null, and a
-- null price is what "covered by a plan" means — there is no separate
-- flag to fall out of step with the number.
--
-- This migration adds the columns and nothing else. Access is still
-- decided by hasAccess(), so behaviour does not change until the
-- purchase path exists: every course today becomes an instructor course
-- with no price, which reads as "not for sale yet" rather than "free".
-- =====================================================================

do $$ begin
  if not exists (select 1 from pg_type where typname = 'course_owner_kind') then
    create type course_owner_kind as enum ('splari','instructor','institution');
  end if;
  if not exists (select 1 from pg_type where typname = 'price_state') then
    -- An instructor sets the price; it is looked at before the course goes
    -- live, alongside the course itself.
    create type price_state as enum ('unset','proposed','approved');
  end if;
end $$;

alter table courses
  add column if not exists owner_kind      course_owner_kind not null default 'instructor',
  add column if not exists institution_id  uuid references institutions(id) on delete set null,
  add column if not exists price_cents     int,
  add column if not exists price_state     price_state not null default 'unset',
  add column if not exists price_note      text;

comment on column courses.price_cents is
  'Instructor courses only. Includes one assessment of the final project, so it can never be less than the review fee it has to cover.';

-- A price belongs to an instructor course and nothing else, and an
-- institution course belongs to an institution. Enforced here rather than
-- in the application: these are the two ways the two economies could get
-- crossed, and a constraint cannot be forgotten in a code path.
do $$ begin
  if not exists (select 1 from pg_constraint where conname = 'courses_price_only_instructor') then
    alter table courses add constraint courses_price_only_instructor
      check (price_cents is null or owner_kind = 'instructor');
  end if;
  if not exists (select 1 from pg_constraint where conname = 'courses_institution_owner') then
    alter table courses add constraint courses_institution_owner
      check ((owner_kind = 'institution') = (institution_id is not null));
  end if;
end $$;

-- ---------------------------------------------------------------------
-- What a learner gets, and what they will be able to do. Both are short
-- lists shown on the course page, and both are arrays rather than tables
-- because nothing ever queries an individual line of them.
-- ---------------------------------------------------------------------
alter table courses
  add column if not exists outcomes text[] not null default '{}',
  add column if not exists includes text[] not null default '{}';

comment on column courses.outcomes is 'What a learner will be able to do afterwards. Shown on the course page.';
comment on column courses.includes is 'What comes with the course — certificate, files, templates.';

-- ---------------------------------------------------------------------
-- The floor. A sale has to cover the assessment it promises, or the
-- product loses money on every certificate it issues.
-- ---------------------------------------------------------------------
create or replace function public.min_course_price_cents()
returns int language sql immutable as $$ select 3000 $$;

comment on function public.min_course_price_cents is
  'Minimum price for an instructor course: $30. The assessment inside it costs $18.85 to pay for, before payment fees or anything else.';
