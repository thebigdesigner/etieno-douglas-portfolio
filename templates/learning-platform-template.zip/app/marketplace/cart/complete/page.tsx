import type { Metadata } from "next";
import Link from "next/link";
import { fulfilPayment } from "@/lib/fulfil";
import { marketBase, mk } from "@/lib/marketplace/url";
import MkIcon from "@/components/marketplace/MkIcon";
import CartDone from "@/components/marketplace/CartDone";

export const metadata: Metadata = { title: "Purchase complete", robots: { index: false } };
export const dynamic = "force-dynamic";

type Props = { searchParams: Promise<{ reference?: string; trxref?: string; status?: string }> };

/**
 * Where the payment provider sends a buyer back to.
 *
 * Fulfils from here as well as from the webhook: whichever arrives first
 * grants the download. fulfilPayment verifies with the provider and is
 * idempotent, so calling it twice is safe by design.
 */
export default async function MarketplaceComplete({ searchParams }: Props) {
  const [sp, base] = await Promise.all([searchParams, marketBase()]);
  const txRef = sp.reference ?? sp.trxref;
  const cancelled = sp.status === "cancelled";
  const result = !cancelled && txRef ? await fulfilPayment(txRef) : null;
  const ok = result?.ok === true;

  return (
    <section className="mk-done">
      {ok && <CartDone />}
      <span className={`mk-done__ico${ok ? " is-ok" : ""}`}>
        <MkIcon name={ok ? "check" : cancelled ? "cart" : "clock"} size={28} />
      </span>
      <h1 className="mk-done__h">
        {ok ? "That's yours now" : cancelled ? "Payment cancelled" : "We could not confirm that payment"}
      </h1>
      <p className="mk-done__p">
        {ok
          ? "Your files are in your library, and they stay there. Download them as often as you need, on any device."
          : cancelled
            ? "Nothing was charged and your cart is still here, so you can pick up where you left off."
            : "If money left your account, nothing is lost: the payment is recorded and this page will confirm it once the provider does. Give it a minute and reload."}
      </p>
      {!ok && !cancelled && txRef && <p className="mk-done__ref">Reference <strong>{txRef}</strong></p>}
      <div className="mk-done__acts">
        {ok ? (
          <>
            <Link href={mk(base, "/library")} className="mk-btn mk-btn--fill">Go to my library</Link>
            <Link href={mk(base, "/all")} className="mk-btn mk-btn--line">Keep browsing</Link>
          </>
        ) : (
          <>
            <Link href={mk(base, "/cart")} className="mk-btn mk-btn--fill">Back to cart</Link>
            <a href="https://yourbrand.com/contact" className="mk-btn mk-btn--line">Contact support</a>
          </>
        )}
      </div>
    </section>
  );
}
