"use client";
import { completeCreatorCourse } from "@/app/actions/studio";
import { useFormStatus } from "react-dom";

function Btn() {
  const { pending } = useFormStatus();
  return (
    <button className="btn btn--fill btn--lg" disabled={pending}>
      {pending ? "Saving…" : "Read it — stop reminding me"}
    </button>
  );
}

export default function DoneButton() {
  return <form action={completeCreatorCourse}><Btn /></form>;
}
