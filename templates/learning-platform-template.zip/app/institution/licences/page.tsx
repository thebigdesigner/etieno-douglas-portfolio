import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { buyLicences } from "@/app/actions/licences";
import PayChoice from "@/components/PayChoice";
import { availableProviders } from "@/lib/payments";
import NavIcon from "@/components/NavIcon";

export const metadata = { title: "Course licences" };
export const dynamic = "force-dynamic";

type Params = Promise<{ error?: string }>;

const ERRORS: Record<string, string> = {
  none: "Nothing was selected, or those courses are already licensed.",
  checkout: "The payment page would not open. Nothing has been charged.",
};

function money(cents: number) {
  return `$${(cents / 100).toFixed(2)}`;
}

export default async function LicencesPage({ searchParams }: { searchParams: Params }) {
  const { error } = await searchParams;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login?next=/institution/licences");

  const admin = createAdminClient();
  const { data: member } = await admin
    .from("institution_members").select("institution_id")
    .eq("user_id", user.id).maybeSingle();
  if (!member) redirect("/institution");

  const { data: rows } = await admin
    .rpc("institution_catalogue", { p_institution_id: member.institution_id });

  const catalogue = (rows ?? []) as {
    course_id: string; slug: string; title: string; subject: string;
    price_cents: number; licensed: boolean;
  }[];

  const held = catalogue.filter((c) => c.licensed);
  const available = catalogue.filter((c) => !c.licensed);

  return (
    <>
      <div className="dash__bar">
        <div>
          <div className="eyebrow">Admin</div>
          <h1 className="dash__title">Course licences</h1>
        </div>
      </div>

      {error && ERRORS[error] && (
        <div className="insight insight--warn" style={{ marginBottom: 18 }}>
          <span className="insight__ico" aria-hidden="true">!</span>
          <span className="insight__body">{ERRORS[error]}</span>
        </div>
      )}

      <div className="card">
        <p className="card__meta" style={{ maxWidth: "62ch" }}>
          Courses written by Your Brand are covered by your seats. Courses written by
          practitioners are bought once, and a licence opens the course for every
          cohort you run — the price includes each learner&rsquo;s project assessment.
        </p>
      </div>

      {available.length > 0 ? (
        <form action={buyLicences} className="card" style={{ marginTop: 18 }}>
          <div className="card__h">Available to license</div>

          <div className="licgrid">
            {available.map((c) => (
              <label key={c.course_id} className="lic">
                <input type="checkbox" name="course" value={c.course_id} />
                <span className="lic__body">
                  <span className="lic__title">{c.title}</span>
                  <span className="lic__meta">{c.subject}</span>
                </span>
                <span className="lic__price num">{money(c.price_cents)}</span>
              </label>
            ))}
          </div>

          <PayChoice options={availableProviders()} className="pay--inline" />

          <button className="btn btn--fill btn--lg" style={{ marginTop: 20 }}>
            Buy selected licences
          </button>
        </form>
      ) : (
        <div className="card" style={{ marginTop: 18 }}>
          <p className="card__meta">
            Nothing to license right now — every practitioner course in the catalogue
            is already open to your cohorts.
          </p>
        </div>
      )}

      {held.length > 0 && (
        <div className="card" style={{ marginTop: 18 }}>
          <div className="card__h">Licensed</div>
          <div className="licgrid" style={{ marginTop: 12 }}>
            {held.map((c) => (
              <div key={c.course_id} className="lic is-held">
                <span className="lic__tick" aria-hidden="true">
                  <NavIcon name="award" size={15} />
                </span>
                <span className="lic__body">
                  <Link className="lic__title" href={`/courses/${c.slug}`}>{c.title}</Link>
                  <span className="lic__meta">Open to every cohort</span>
                </span>
              </div>
            ))}
          </div>
        </div>
      )}
    </>
  );
}
