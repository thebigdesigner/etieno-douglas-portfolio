// Run specific migration files against the Supabase database.
//
//   node scripts/run-sql.mjs --status
//   node scripts/run-sql.mjs supabase/migrations/0065_marketplace.sql supabase/migrations/0066_marketplace_studio.sql
//
// Needs SUPABASE_DB_URL: the Session pooler connection string from
// Supabase → Connect (it works over IPv4; the direct one is IPv6-only).
//
// Each file runs inside its own transaction: if any statement fails, that
// whole file is rolled back and the script stops, so nothing is ever left
// half-applied. Files after a failure are not attempted.
import { readFileSync } from "node:fs";
import postgres from "postgres";

const url = process.env.SUPABASE_DB_URL;
if (!url) {
  console.error("SUPABASE_DB_URL is not set. See the comment at the top of this file.");
  process.exit(1);
}

const sql = postgres(url, { ssl: "require", max: 1, onnotice: () => {}, prepare: false });

async function status() {
  const [r] = await sql`
    select
      to_regclass('public.mk_products') is not null as marketplace_0065,
      exists (select 1 from information_schema.columns
              where table_name = 'mk_products' and column_name = 'review_note') as studio_0066,
      exists (select 1 from storage.buckets where id = 'mk-files') as studio_buckets`;
  console.log(`0065 marketplace tables : ${r.marketplace_0065 ? "applied" : "NOT applied"}`);
  console.log(`0066 studio columns     : ${r.studio_0066 ? "applied" : "NOT applied"}`);
  console.log(`0066 storage buckets    : ${r.studio_buckets ? "present" : "missing"}`);
}

try {
  const args = process.argv.slice(2);
  if (args.length === 0 || args[0] === "--status") {
    await status();
  } else {
    for (const file of args) {
      const text = readFileSync(file, "utf8");
      process.stdout.write(`Running ${file} ... `);
      try {
        await sql.begin((tx) => tx.unsafe(text));
        console.log("done");
      } catch (err) {
        console.log("FAILED, rolled back");
        console.error(`  ${err.message}`);
        if (err.position) console.error(`  near character ${err.position} of the file`);
        process.exitCode = 1;
        break;
      }
    }
    if (!process.exitCode) { console.log(""); await status(); }
  }
} catch (err) {
  console.error(err.message.includes("password") || err.message.includes("auth")
    ? "Could not sign in to the database. Check the password in SUPABASE_DB_URL."
    : `Could not connect: ${err.message}`);
  process.exitCode = 1;
} finally {
  await sql.end({ timeout: 5 });
}
