import type { Ccy } from "@/lib/money";
/**
 * Marketplace shapes.
 *
 * Kept apart from the course types on purpose. A course is something you
 * work through and get assessed on; a marketplace item is a file you buy
 * and use. They share an author pool and a payment rail, not a model.
 */

/** How an item is drawn when it has no uploaded cover. One per category. */
export type PreviewKind =
  | "ui" | "slides" | "graphic" | "icons" | "font"
  | "audio" | "video" | "3d" | "book" | "code";

export type Category = {
  slug: string;
  name: string;
  /** Singular noun, for counts: "12 fonts", "1 font". */
  noun: [string, string];
  blurb: string;
  icon: MkIconName;
  preview: PreviewKind;
  subcategories: { slug: string; name: string }[];
  formats: string[];
  /** Flags the rail item with the orange "Hot" pill. */
  hot?: boolean;
};

export type Author = {
  handle: string;
  name: string;
  /** The person behind a studio name, shown under it. */
  person?: string;
  location: string;
  bio: string;
  joined: string;          // ISO date
  followers: number;
  hue: number;             // avatar tint, 0-5 — maps to the theme's six tile colours
  socials: { kind: "instagram" | "x" | "behance" | "dribbble" | "youtube"; url: string }[];
};

export type Product = {
  id: string;
  slug: string;
  title: string;
  category: string;
  subcategory: string;
  author: string;          // Author.handle
  /** Personal licence, in cents. 0 is free. */
  /** In `currency`, which is what the visitor is being priced in. */
  priceCents: number;
  /** Commercial licence, in cents. Null when the item is free for any use. */
  commercialCents: number | null;
  /** The currency the two figures above are in. */
  currency: Ccy;
  rating: number;          // 0-5, one decimal
  ratings: number;
  downloads: number;
  publishedAt: string;     // ISO
  updatedAt: string;       // ISO
  formats: string[];
  tags: string[];
  summary: string;
  includes: string[];
  /** Audio and video only: "02:14". */
  duration?: string;
  fileSize: string;
  coverUrl?: string | null;
  trending?: boolean;
  featured?: boolean;
};

export type Sort = "popular" | "newest" | "price-asc" | "price-desc" | "rating";

export type ProductQuery = {
  category?: string;
  subcategory?: string;
  q?: string;
  price?: "free" | "paid";
  formats?: string[];
  minRating?: number;
  sort?: Sort;
  page?: number;
  perPage?: number;
  author?: string;
};

export type ProductPage = {
  items: Product[];
  total: number;
  page: number;
  pages: number;
};

export type MkIconName =
  | "layout" | "browser" | "slides" | "palette" | "shapes" | "type"
  | "music" | "wave" | "film" | "cube" | "book" | "code"
  | "home" | "compass" | "search" | "heart" | "star" | "download"
  | "chevron" | "chevron-left" | "help" | "academy" | "menu" | "close"
  | "check" | "tag" | "clock" | "users" | "sliders" | "store" | "more"
  | "file" | "sparkle" | "arrow-up" | "play" | "bag"
  | "apps" | "arrow-left" | "arrow-right" | "more-circle" | "chevron-right" | "gift" | "cart" | "trash";
