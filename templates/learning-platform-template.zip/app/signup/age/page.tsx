import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import Link from "next/link";
import AuthShell from "@/components/AuthShell";
import StepProgress from "@/components/StepProgress";
import AdultForm from "./AdultForm";

export const metadata = { title: "Confirm your age" };
export const dynamic = "force-dynamic";

const COPY: Record<string, string> = {
  learner: "Your Brand is built for adults deciding what to learn next, so everything here assumes you are one.",
  instructor: "You will be assessing other people's work and being paid for it.",
  institution: "You will be responsible for the learners you enrol.",
};

export default async function AgePage() {
  const intent = (await cookies()).get("splari_intent")?.value;
  if (!intent || !COPY[intent]) redirect("/signup");

  return (
    <AuthShell
      progress={<StepProgress step={2} total={3} labels={["You", "Details", "Done"]} />}
      title="One thing before we start"
      intro={COPY[intent]}
      footer={<Link href="/signup">Back a step</Link>}
    >
      <AdultForm />
    </AuthShell>
  );
}
