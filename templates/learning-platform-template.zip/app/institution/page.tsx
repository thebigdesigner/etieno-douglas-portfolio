import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import NewCohortForm from "./NewCohortForm";
import NavIcon from "@/components/NavIcon";

export const metadata = { title: "Cohorts" };
export const dynamic = "force-dynamic";

export default async function InstitutionPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  const admin = createAdminClient();
  const { data: member } = await admin
    .from("institution_members").select("institution_id").eq("user_id", user!.id).maybeSingle();

  if (!member) {
    return (
      <>
          <div className="empty" style={{ marginTop: 40 }}>
            <p className="empty__h">Not linked to an institution yet</p>
            <p className="empty__p">
              We set institution accounts up by hand after a call. Get in touch and we
              will connect yours.
            </p>
          </div>
        </>
    );
  }

  const { data: institution } = await admin
    .from("institutions").select("name, plan, verification").eq("id", member.institution_id).maybeSingle();

  const verified = institution?.verification === "verified";

  const { data: cohorts } = await admin
    .from("cohorts")
    .select("id, name, class_code, seat_ceiling, starts_on, ends_on, state")
    .eq("institution_id", member.institution_id)
    .order("starts_on", { ascending: false });

  const { data: courses } = await admin
    .from("courses").select("id, title, subject").eq("state", "published").order("title");

  const counts: Record<string, { claimed: number; active: number }> = {};
  for (const c of cohorts ?? []) {
    const { data: rows } = await admin
      .from("cohort_progress").select("user_id, topics_done").eq("cohort_id", c.id);
    counts[c.id] = {
      claimed: (rows ?? []).filter((r) => r.user_id).length,
      active: (rows ?? []).filter((r) => Number(r.topics_done) > 0).length,
    };
  }

  const unitPrice = institution?.plan === "starter" ? 11 : institution?.plan === "plus" ? 13 : 15;

  const totalActive = Object.values(counts).reduce((n, c) => n + c.active, 0);
  const totalJoined = Object.values(counts).reduce((n, c) => n + c.claimed, 0);
  const running = (cohorts ?? []).filter((c) => c.state === "active").length;

  return (
    <>
      <div className="dash__bar">
        <div>
          <div className="eyebrow">Institution</div>
          <h1 className="dash__title">{institution?.name}</h1>
        </div>
      </div>

      <div className="pan">
        <div className="pan__col">
          <div className="hero__panel">
            <div className="hero__eyebrow">This month</div>
            <h2 className="hero__title">
              {totalActive} active learner{totalActive === 1 ? "" : "s"}
            </h2>
            <p className="hero__sub">
              On {institution?.plan} — ${unitPrice} per active learner per month, billed at
              month end. Learners who never start are not charged.
            </p>
            <div className="hero__acts">
              <Link className="btn btn--white btn--lg" href="/institution/invoices">
                See invoices
              </Link>
              <Link className="btn btn--ghost btn--lg" href="/courses">Course catalogue</Link>
            </div>
          </div>

          <div className="stats3">
            <div className="stat3">
              <div className="eyebrow">Cohorts</div>
              <div className="stat3__v num">{running}</div>
              <div className="stat3__n">Currently running</div>
            </div>
            <div className="stat3">
              <div className="eyebrow">Joined</div>
              <div className="stat3__v num">{totalJoined}</div>
              <div className="stat3__n">Seats claimed</div>
            </div>
            <div className="stat3">
              <div className="eyebrow">Billable</div>
              <div className="stat3__v num">{totalActive}</div>
              <div className="stat3__n">Started at least one topic</div>
            </div>
          </div>

          {!verified && (
            <div className="notice">
              <div>
                <p className="notice__h">
                  {institution?.verification === "pending"
                    ? "Verification is with us"
                    : "One step before you can enrol anyone"}
                </p>
                <p className="notice__p">
                  {institution?.verification === "pending"
                    ? "We usually come back within two working days, and will email you either way."
                    : "Send us a registration document or a letter on your headed paper. Your learners' data — some of it belonging to children — is why we check."}
                </p>
              </div>
              {institution?.verification !== "pending" && (
                <Link className="btn btn--fill" href="/institution/verify">Verify now</Link>
              )}
            </div>
          )}

          <div className="card">
            <div className="card__head">
              <div className="card__h">Cohorts</div>
            </div>
            {(!cohorts || cohorts.length === 0) ? (
              <p className="empty2">No cohorts yet. Create one below — it takes about a minute.</p>
            ) : (
              <div className="rq">
                {cohorts.map((c) => (
                  <Link key={c.id} className="rq__row" href={`/institution/cohorts/${c.id}`}>
                    <div>
                      <div className="rq__course">{c.name}</div>
                      <div className="rq__learner">
                        {new Date(c.starts_on).toLocaleDateString()} –{" "}
                        {new Date(c.ends_on).toLocaleDateString()}
                      </div>
                    </div>
                    <div className="rq__meta">
                      <span className="rq__sub num">
                        {counts[c.id]?.active ?? 0} active of {counts[c.id]?.claimed ?? 0} joined
                      </span>
                      <span className={`pill${c.state === "active" ? " pill--free" : ""}`}>{c.state}</span>
                    </div>
                    <span className="rq__go">Open &rarr;</span>
                  </Link>
                ))}
              </div>
            )}
          </div>

          {verified && (
            <div className="card">
              <div className="card__head"><div className="card__h">New cohort</div></div>
              <NewCohortForm courses={courses ?? []} />
            </div>
          )}
        </div>

        <div className="pan__col">
          <div className="card">
            <div className="card__head"><div className="card__h">Status</div></div>
            <div className="prow2">
              <span className="prow2__ico" aria-hidden="true"><NavIcon name="shield" size={17} /></span>
              <span><span className="prow2__t">Verification</span>
                <span className="prow2__s">Required before enrolling</span></span>
              <span className={`tag${verified ? " tag--go" : " tag--wait"}`}>
                {verified ? "Verified" : institution?.verification === "pending" ? "With us" : "Needed"}
              </span>
            </div>
            <div className="prow2">
              <span className="prow2__ico" aria-hidden="true"><NavIcon name="receipt" size={17} /></span>
              <span><span className="prow2__t">Plan</span>
                <span className="prow2__s">${unitPrice} per active learner</span></span>
              <span className="tag tag--cool">{institution?.plan}</span>
            </div>
          </div>

          <div className="card card--tint">
            <div className="card__h">How billing works</div>
            <p className="card__meta" style={{ marginTop: 8, lineHeight: 1.6 }}>
              You are billed on learners who complete at least one topic, not on seats
              issued. A learner who never starts costs nothing, so over-provisioning a
              cohort is safe.
            </p>
          </div>
        </div>
      </div>
    </>
  );
}
