import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { SUBJECTS, LEVELS, LEVEL_LABEL } from "@/lib/subjects";

export const dynamic = "force-dynamic";

export type Suggestion = {
  kind: string;
  label: string;
  meta: string;
  href: string;
  thumb?: string | null;
  free?: boolean;
};

/**
 * Typeahead for the search bars.
 *
 * It used to search the public catalogue no matter who was looking, which
 * made it close to useless anywhere but the learner surface: an instructor
 * searching their own draft found nothing, because a draft is not in the
 * catalogue, and an administrator searching a pupil got six unrelated
 * courses. It searches what the person works with now.
 *
 * The role is read from the profile, never taken from the request —
 * otherwise anybody could ask for the operator's index.
 *
 * Still not search_courses(). That RPC runs plainto_tsquery, which matches
 * whole words and returns nothing for "t" or "des" — exactly the state the
 * box is in while somebody types. Full-text ranking belongs on the results
 * page, where the query is finished.
 */
export async function GET(request: Request) {
  const q = (new URL(request.url).searchParams.get("q") ?? "").trim();
  if (q.length < 1) return NextResponse.json({ suggestions: [] });

  // % and _ are wildcards in ilike. Unescaped, a stray "%" matches everything.
  const safe = q.replace(/[\\%_]/g, (c) => `\\${c}`);
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  let role = "learner";
  if (user) {
    const admin = createAdminClient();
    const { data: profile } = await admin
      .from("profiles").select("role").eq("id", user.id).maybeSingle();
    role = (profile?.role as string) ?? "learner";
  }

  try {
    if (user && role === "instructor") {
      return NextResponse.json({ suggestions: await instructorSearch(safe, user.id) });
    }
    if (user && role === "institution_admin") {
      return NextResponse.json({ suggestions: await institutionSearch(safe, user.id) });
    }
    if (user && role === "operator") {
      return NextResponse.json({ suggestions: await operatorSearch(safe, q) });
    }
    return NextResponse.json({ suggestions: await learnerSearch(safe, q, supabase) });
  } catch (e) {
    // A failed lookup must not break typing. The results page still works,
    // so this degrades to "no suggestions".
    console.error("suggest lookup failed", q, role, e);
    return NextResponse.json({ suggestions: [] });
  }
}

/* ---------- learner: the catalogue, and how it is filed ---------- */
async function learnerSearch(
  safe: string, q: string, supabase: Awaited<ReturnType<typeof createClient>>
): Promise<Suggestion[]> {
  // course_cards is published-only and world-readable, so this runs on the
  // caller's own client rather than the service role.
  const { data } = await supabase
    .from("course_cards")
    .select("slug, title, subject, level, is_free, thumbnail_path")
    .or(`title.ilike.%${safe}%,summary.ilike.%${safe}%,subject.ilike.%${safe}%`)
    .order("learners", { ascending: false })
    .limit(6);

  const needle = q.toLowerCase();

  const courses: Suggestion[] = (data ?? []).map((c) => ({
    kind: "course",
    label: c.title as string,
    meta: [c.subject, LEVEL_LABEL[c.level as string] ?? c.level].filter(Boolean).join(" · "),
    href: `/courses/${c.slug}`,
    thumb: (c.thumbnail_path as string) ?? null,
    free: !!c.is_free,
  }));

  // Word-prefix, not substring. On "t", a plain includes() matched Artificial
  // Intelligence, Entrepreneurship and Creative — none of which anybody
  // typing "t" was reaching for.
  const subjects: Suggestion[] = SUBJECTS
    .filter((s) => s.toLowerCase().split(/\s+/).some((w) => w.startsWith(needle)))
    .map((s) => ({
      kind: "subject", label: s, meta: "Subject",
      href: `/courses?subject=${encodeURIComponent(s)}`,
    }));

  const levels: Suggestion[] = LEVELS
    .filter((l) => LEVEL_LABEL[l].toLowerCase().startsWith(needle))
    .map((l) => ({
      kind: "level", label: LEVEL_LABEL[l], meta: "Level",
      href: `/courses?level=${l}`,
    }));

  return [...subjects, ...levels, ...courses].slice(0, 8);
}

/* ---------- instructor: their own courses, and their queue ---------- */
const COURSE_STATE: Record<string, string> = {
  draft: "Draft", in_review: "In review", published: "Live",
  revision_requested: "Changes asked for", unpublished: "Retired",
};

async function instructorSearch(safe: string, userId: string): Promise<Suggestion[]> {
  const admin = createAdminClient();

  // Any state, drafts included. A draft is what an instructor most often
  // wants and the one thing the catalogue could never return.
  const { data: mine } = await admin
    .from("courses")
    .select("slug, title, subject, state")
    .eq("instructor_id", userId)
    .ilike("title", `%${safe}%`)
    .limit(6);

  const courses: Suggestion[] = (mine ?? []).map((c) => ({
    kind: "mycourse",
    label: c.title as string,
    meta: `${COURSE_STATE[c.state as string] ?? c.state} · ${c.subject}`,
    href: `/studio/${c.slug}`,
  }));

  // Work waiting on them, searched by course — which is what they remember,
  // not the learner's name, which they may never see.
  const { data: queue } = await admin
    .from("review_queue_status")
    .select("submission_id, course_title, deadline_at")
    .eq("assigned_reviewer_id", userId)
    .ilike("course_title", `%${safe}%`)
    .limit(4);

  const submissions: Suggestion[] = (queue ?? []).map((s) => ({
    kind: "submission",
    label: s.course_title as string,
    meta: s.deadline_at
      ? `To assess by ${new Date(s.deadline_at as string).toLocaleDateString("en-GB", { day: "numeric", month: "short" })}`
      : "To assess",
    href: `/review/${s.submission_id}`,
  }));

  return [...courses, ...submissions].slice(0, 8);
}

/* ---------- institution: their cohorts and the learners in them ---------- */
async function institutionSearch(safe: string, userId: string): Promise<Suggestion[]> {
  const admin = createAdminClient();

  const { data: member } = await admin
    .from("institution_members").select("institution_id").eq("user_id", userId).maybeSingle();
  if (!member) return [];

  const institutionId = member.institution_id as string;

  // Every cohort they own, so learner results can be scoped to them. An
  // administrator searching a name must never reach somebody else's pupil.
  const { data: owned } = await admin
    .from("cohorts").select("id, name, class_code")
    .eq("institution_id", institutionId);

  const scope = (owned ?? []).map((c) => c.id as string);
  const nameOf = new Map((owned ?? []).map((c) => [c.id as string, c.name as string]));

  const needle = safe.toLowerCase();
  const cohortRows: Suggestion[] = (owned ?? [])
    .filter((c) =>
      (c.name as string).toLowerCase().includes(needle) ||
      (c.class_code as string).toLowerCase().includes(needle))
    .slice(0, 5)
    .map((c) => ({
      kind: "cohort",
      label: c.name as string,
      meta: `Cohort · ${c.class_code}`,
      href: `/institution/cohorts/${c.id}`,
    }));

  const { data: seats } = scope.length
    ? await admin
        .from("cohort_seats")
        .select("username, cohort_id")
        .in("cohort_id", scope)
        .ilike("username", `%${safe}%`)
        .limit(5)
    : { data: [] };

  const learners: Suggestion[] = (seats ?? []).map((s) => ({
    kind: "learner",
    label: s.username as string,
    meta: `Learner · ${nameOf.get(s.cohort_id as string) ?? "cohort"}`,
    href: `/institution/cohorts/${s.cohort_id}`,
  }));

  return [...cohortRows, ...learners].slice(0, 8);
}

/* ---------- operator: people, and certificates by code ---------- */
async function operatorSearch(safe: string, q: string): Promise<Suggestion[]> {
  const admin = createAdminClient();

  const { data: people } = await admin
    .from("profiles")
    .select("id, display_name, email, role")
    .or(`display_name.ilike.%${safe}%,email.ilike.%${safe}%`)
    .limit(5);

  const rows: Suggestion[] = (people ?? []).map((p) => ({
    kind: "person",
    label: (p.display_name as string) ?? (p.email as string) ?? "Account",
    meta: `${p.role} · ${p.email ?? "no email"}`,
    href: `/console/people?q=${encodeURIComponent((p.email as string) ?? "")}`,
  }));

  // A certificate code is the one thing support is handed verbatim, so it is
  // worth matching from the first few characters.
  const { data: certs } = q.toUpperCase().startsWith("SPL")
    ? await admin
        .from("certificates")
        .select("code, kind, revoked_at")
        .ilike("code", `%${safe}%`)
        .limit(3)
    : { data: [] };

  const certRows: Suggestion[] = (certs ?? []).map((c) => ({
    kind: "certificate",
    label: c.code as string,
    meta: c.revoked_at ? "Certificate · withdrawn" : `Certificate · ${c.kind}`,
    href: `/verify/${c.code}`,
  }));

  return [...certRows, ...rows].slice(0, 8);
}
