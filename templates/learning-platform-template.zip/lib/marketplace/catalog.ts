import { cache } from "react";
import { createAdminClient } from "@/lib/supabase/admin";
import { DEFAULT_CCY, readCurrency, type Ccy } from "@/lib/currency";
import { createClient } from "@/lib/supabase/server";
import { AUTHORS, PRODUCTS } from "./seed";
import type { Author, Product, ProductPage, ProductQuery } from "./types";

/**
 * Every read the storefront makes goes through here.
 *
 * Two sources behind one interface: the mk_* tables from 0065, and the demo
 * catalogue in seed.ts. The demo is a review aid, so it is only reachable
 * outside production unless MARKETPLACE_DEMO=1 is set on purpose. In
 * production with the tables unreachable the shop is empty rather than
 * full of things nobody can buy — an empty shelf is a bug report, a fake
 * one is a refund.
 */

const PER_PAGE = 24;

function demoAllowed(): boolean {
  return process.env.MARKETPLACE_DEMO === "1" || process.env.NODE_ENV !== "production";
}

function dbConfigured(): boolean {
  return Boolean(process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY);
}

type Source = "db" | "demo" | "none";

/**
 * Decided once per request. A probe rather than a flag, because "the keys
 * are set" and "the migration has run" are different facts and only the
 * second one means the shop works.
 */
const source = cache(async (): Promise<Source> => {
  if (process.env.MARKETPLACE_DEMO === "1") return "demo";
  if (dbConfigured()) {
    try {
      const supabase = await createClient();
      const { error } = await supabase.from("mk_products").select("id", { head: true, count: "exact" }).limit(1);
      if (!error) return "db";
      console.error("marketplace: mk_products unreachable", error.message);
    } catch (err) {
      console.error("marketplace: catalogue probe failed", err);
    }
  }
  return demoAllowed() ? "demo" : "none";
});

export async function isDemo(): Promise<boolean> {
  return (await source()) === "demo";
}

// ------------------------------------------------------------------ rows
export type ProductRow = {
  id: string; slug: string; title: string; category: string; subcategory: string;
  price_cents: number; commercial_price_cents: number | null;
  rating: number | null; ratings_count: number; downloads: number;
  published_at: string; updated_at: string; formats: string[] | null; tags: string[] | null;
  summary: string; includes: string[] | null; duration: string | null; file_size: string | null;
  cover_url: string | null; trending: boolean; featured: boolean;
  mk_creators: { handle: string } | { handle: string }[] | null;
  mk_product_prices?: { currency: string; price_cents: number; commercial_cents: number | null }[] | null;
};

export const PRODUCT_COLS =
  "id, slug, title, category, subcategory, price_cents, commercial_price_cents, rating, ratings_count, " +
  "downloads, published_at, updated_at, formats, tags, summary, includes, duration, file_size, cover_url, " +
  "trending, featured, mk_creators!inner(handle), mk_product_prices(currency, price_cents, commercial_cents)";

/** Exported for the buyer library, which selects the same columns. */
export function fromRow(r: ProductRow, ccy: Ccy = DEFAULT_CCY): Product {
  const creator = Array.isArray(r.mk_creators) ? r.mk_creators[0] : r.mk_creators;
  // The dollar price is the one every product has; another currency is
  // shown only where its creator has actually set one, never converted.
  const row = ccy === DEFAULT_CCY ? null : r.mk_product_prices?.find((p) => p.currency === ccy);
  const priced = row
    ? { currency: ccy, priceCents: row.price_cents, commercialCents: row.commercial_cents }
    : { currency: DEFAULT_CCY, priceCents: r.price_cents, commercialCents: r.commercial_price_cents };
  return {
    ...priced,
    id: r.id, slug: r.slug, title: r.title, category: r.category, subcategory: r.subcategory,
    author: creator?.handle ?? "",
    rating: Number(r.rating ?? 0), ratings: r.ratings_count, downloads: r.downloads,
    publishedAt: r.published_at, updatedAt: r.updated_at,
    formats: r.formats ?? [], tags: r.tags ?? [], summary: r.summary, includes: r.includes ?? [],
    duration: r.duration ?? undefined, fileSize: r.file_size ?? "",
    coverUrl: r.cover_url, trending: r.trending, featured: r.featured,
  };
}

type CreatorRow = {
  handle: string; display_name: string; person_name: string | null; location: string | null;
  bio: string | null; created_at: string; followers: number; hue: number; socials: Author["socials"] | null;
};

function authorFromRow(r: CreatorRow): Author {
  return {
    handle: r.handle, name: r.display_name, person: r.person_name ?? undefined,
    location: r.location ?? "", bio: r.bio ?? "", joined: r.created_at,
    followers: r.followers, hue: r.hue, socials: r.socials ?? [],
  };
}

// ------------------------------------------------------------ in-memory
function sortProducts(list: Product[], sort: ProductQuery["sort"]): Product[] {
  const out = [...list];
  switch (sort) {
    case "newest": return out.sort((a, b) => b.publishedAt.localeCompare(a.publishedAt));
    case "price-asc": return out.sort((a, b) => a.priceCents - b.priceCents);
    case "price-desc": return out.sort((a, b) => b.priceCents - a.priceCents);
    case "rating": return out.sort((a, b) => b.rating - a.rating || b.ratings - a.ratings);
    default: return out.sort((a, b) => b.downloads - a.downloads);
  }
}

function matches(p: Product, q: ProductQuery): boolean {
  if (q.category && p.category !== q.category) return false;
  if (q.subcategory && p.subcategory !== q.subcategory) return false;
  if (q.author && p.author !== q.author) return false;
  if (q.price === "free" && p.priceCents > 0) return false;
  if (q.price === "paid" && p.priceCents === 0) return false;
  if (q.minRating && p.rating < q.minRating) return false;
  if (q.formats?.length && !q.formats.some((f) => p.formats.includes(f))) return false;
  if (q.q) {
    const words = q.q.toLowerCase().split(/\s+/).filter(Boolean);
    const hay = `${p.title} ${p.summary} ${p.tags.join(" ")} ${p.category}`.toLowerCase();
    if (!words.every((w) => hay.includes(w))) return false;
  }
  return true;
}

function paginate(list: Product[], page: number, perPage: number): ProductPage {
  const pages = Math.max(1, Math.ceil(list.length / perPage));
  const p = Math.min(Math.max(1, page), pages);
  return { items: list.slice((p - 1) * perPage, p * perPage), total: list.length, page: p, pages };
}

// ---------------------------------------------------------------- reads
export async function listProducts(query: ProductQuery = {}): Promise<ProductPage> {
  const perPage = query.perPage ?? PER_PAGE;
  const page = query.page ?? 1;
  const src = await source();

  if (src === "demo") {
    return paginate(sortProducts(PRODUCTS.filter((p) => matches(p, query)), query.sort), page, perPage);
  }
  if (src === "none") return { items: [], total: 0, page: 1, pages: 1 };

  const supabase = await createClient();
  let req = supabase.from("mk_products").select(PRODUCT_COLS, { count: "exact" }).eq("state", "published");
  if (query.category) req = req.eq("category", query.category);
  if (query.subcategory) req = req.eq("subcategory", query.subcategory);
  if (query.author) req = req.eq("mk_creators.handle", query.author);
  if (query.price === "free") req = req.eq("price_cents", 0);
  if (query.price === "paid") req = req.gt("price_cents", 0);
  if (query.minRating) req = req.gte("rating", query.minRating);
  if (query.formats?.length) req = req.overlaps("formats", query.formats);
  if (query.q) req = req.textSearch("search", query.q, { type: "websearch", config: "english" });

  const order: Record<string, [string, boolean]> = {
    newest: ["published_at", false], "price-asc": ["price_cents", true],
    "price-desc": ["price_cents", false], rating: ["rating", false], popular: ["downloads", false],
  };
  const [col, asc] = order[query.sort ?? "popular"] ?? order.popular;
  const from = (page - 1) * perPage;
  const { data, count, error } = await req.order(col, { ascending: asc }).range(from, from + perPage - 1);
  if (error) {
    console.error("marketplace: listProducts", error.message);
    return { items: [], total: 0, page: 1, pages: 1 };
  }
  const total = count ?? 0;
  const ccy = await readCurrency();
  return {
    items: ((data ?? []) as unknown as ProductRow[]).map((r) => fromRow(r, ccy)),
    total, page, pages: Math.max(1, Math.ceil(total / perPage)),
  };
}

export const getProduct = cache(async (slug: string): Promise<Product | null> => {
  const src = await source();
  if (src === "demo") return PRODUCTS.find((p) => p.slug === slug) ?? null;
  if (src === "none") return null;
  const supabase = await createClient();
  const { data } = await supabase.from("mk_products").select(PRODUCT_COLS)
    .eq("slug", slug).eq("state", "published").maybeSingle();
  return data ? fromRow(data as unknown as ProductRow, await readCurrency()) : null;
});

export const getAuthor = cache(async (handle: string): Promise<Author | null> => {
  const src = await source();
  if (src === "demo") return AUTHORS.find((a) => a.handle === handle) ?? null;
  if (src === "none") return null;
  const supabase = await createClient();
  const { data } = await supabase.from("mk_creators")
    .select("handle, display_name, person_name, location, bio, created_at, followers, hue, socials")
    .eq("handle", handle).maybeSingle();
  return data ? authorFromRow(data as CreatorRow) : null;
});

export async function getAuthors(handles: string[]): Promise<Map<string, Author>> {
  const unique = [...new Set(handles)].filter(Boolean);
  const found = await Promise.all(unique.map((h) => getAuthor(h)));
  return new Map(found.filter((a): a is Author => Boolean(a)).map((a) => [a.handle, a]));
}

/** Items, lifetime downloads and a ratings-weighted average, for the author page. */
export async function authorStats(handle: string) {
  const { items } = await listProducts({ author: handle, perPage: 500 });
  const downloads = items.reduce((n, p) => n + p.downloads, 0);
  const ratings = items.reduce((n, p) => n + p.ratings, 0);
  const rating = ratings ? items.reduce((n, p) => n + p.rating * p.ratings, 0) / ratings : 0;
  return { items, count: items.length, downloads, ratings, rating };
}

/** For the rail. One query for all twelve, not twelve. */
export const categoryCounts = cache(async (): Promise<Record<string, number>> => {
  const src = await source();
  const counts: Record<string, number> = {};
  if (src === "demo") {
    for (const p of PRODUCTS) counts[p.category] = (counts[p.category] ?? 0) + 1;
    return counts;
  }
  if (src === "none") return counts;
  const supabase = await createClient();
  const { data } = await supabase.from("mk_category_counts").select("category, items");
  for (const r of (data ?? []) as { category: string; items: number }[]) counts[r.category] = r.items;
  return counts;
});

export async function homeSections() {
  const [trending, newest, popular] = await Promise.all([
    listProducts({ sort: "popular", perPage: 200 }),
    listProducts({ sort: "newest", perPage: 8 }),
    listProducts({ sort: "popular", perPage: 5 }),
  ]);
  const hot = trending.items.filter((p) => p.trending).slice(0, 8);
  const featuredHandles = [...new Set(trending.items.filter((p) => p.featured).map((p) => p.author))].slice(0, 4);
  return {
    trending: hot.length >= 4 ? hot : trending.items.slice(0, 8),
    newest: newest.items,
    mostDownloaded: popular.items,
    featuredAuthors: featuredHandles,
    total: trending.total,
  };
}

/** Same category, overlapping tags first. Excludes the item itself. */
export async function similarProducts(p: Product, limit = 4): Promise<Product[]> {
  const { items } = await listProducts({ category: p.category, perPage: 40 });
  return items
    .filter((x) => x.slug !== p.slug)
    .map((x) => ({ x, score: x.tags.filter((t) => p.tags.includes(t)).length + (x.subcategory === p.subcategory ? 1 : 0) }))
    .sort((a, b) => b.score - a.score || b.x.downloads - a.x.downloads)
    .slice(0, limit)
    .map((s) => s.x);
}

/**
 * Initials of people who recently bought an item, for the downloads panel.
 *
 * Empty unless at least three different people have bought it: below that,
 * two letters beside a niche product can identify someone. Anyone who has
 * turned off "show my purchases" is never included, and nothing here is a
 * name or a link.
 */
export async function recentBuyers(productId: string, limit = 4): Promise<string[]> {
  if ((await source()) !== "db") return [];
  const { data, error } = await createAdminClient()
    .rpc("mk_recent_buyers", { p_product: productId, p_limit: limit });
  if (error) { console.error("marketplace: recentBuyers", error.message); return []; }
  return ((data ?? []) as { initials: string }[]).map((r) => r.initials).filter(Boolean);
}
