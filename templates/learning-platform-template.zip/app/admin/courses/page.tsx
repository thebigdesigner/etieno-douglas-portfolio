import Link from "next/link";
import { createAdminClient } from "@/lib/supabase/admin";
import CourseDecision from "./CourseDecision";

export const metadata = { title: "Courses awaiting review" };
export const dynamic = "force-dynamic";

export default async function AdminCoursesPage() {
  const admin = createAdminClient();

  const { data: courses } = await admin
    .from("courses")
    .select("id, slug, title, subject, level, project_brief, instructor_id, profiles:instructor_id(display_name)")
    .eq("state", "in_review");

  const rows = courses ?? [];

  return (
    <>
        <h1 className="sec__h" style={{ fontSize: 30, marginTop: 34 }}>
          {rows.length} course{rows.length === 1 ? "" : "s"} awaiting review
        </h1>
        <p className="sec__meta">
          The rubric gate: would two different reviewers reach the same verdict from it?
          That is the only question that matters here.
        </p>

        {rows.length === 0 ? (
          <div className="empty" style={{ marginTop: 28 }}>
            <p className="empty__h">Nothing waiting</p>
            <p className="empty__p">Courses appear here when an instructor submits them.</p>
          </div>
        ) : (
          <div className="apps">
            {rows.map((c) => {
              const p = c.profiles as unknown as { display_name: string } | null;
              return (
                <article key={c.id} className="app">
                  <div className="app__head">
                    <div>
                      <div className="app__name">{c.title}</div>
                      <div className="app__hl">
                        {p?.display_name ?? "Instructor"} · {c.subject} · {c.level}
                      </div>
                    </div>
                    <Link className="sec__link" href={`/admin/courses/${c.slug}`}>Open</Link>
                  </div>
                  <div className="app__field">
                    <div className="eyebrow">Project brief</div>
                    <p>{c.project_brief}</p>
                  </div>
                  <CourseDecision courseId={c.id} />
                </article>
              );
            })}
          </div>
        )}
      </>
  );
}
