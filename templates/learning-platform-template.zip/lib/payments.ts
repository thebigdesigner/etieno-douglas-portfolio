import * as paystack from "@/lib/paystack";
import * as stripe from "@/lib/stripe";

/**
 * Paying Your Brand.
 *
 * Everything is priced and charged in US dollars — one number per item, the
 * same for everyone, everywhere (see SALE_CURRENCY). What differs is *how*
 * a buyer pays, and that is their choice rather than ours:
 *
 *   Paystack — Nigerian and other African cards, bank transfer, USSD.
 *   Stripe   — cards worldwide, Apple Pay, Google Pay, Link.
 *
 * Routing by country would guess wrong constantly: Nigerians hold dollar
 * cards, and people abroad hold Nigerian ones. Asking is one radio button
 * and it is always right.
 *
 * Whichever providers are configured are the ones offered. With none
 * configured, checkout says so instead of failing at the payment page.
 */

export type Provider = "paystack" | "stripe";

export type ProviderChoice = {
  id: Provider;
  label: string;
  note: string;
  available: boolean;
  /** Why it cannot be used, for the logs — never shown to a buyer. */
  reason?: string;
};

/**
 * Which providers can settle a given currency.
 *
 *   NGN — Paystack only. Stripe does not settle naira.
 *   GBP — Stripe only.
 *   USD — either, once Paystack has approved dollars on the account.
 *
 * A currency nothing can settle returns nothing, and checkout says so
 * rather than sending someone to a payment page that will refuse them.
 */
export function providerChoices(currency = "USD"): ProviderChoice[] {
  const c = currency.toUpperCase();
  const paystackKey = Boolean(process.env.PAYSTACK_SECRET_KEY);
  // A Nigerian Paystack account must be approved for USD before it can
  // take dollars; naira needs no such approval.
  const paystackUsd = process.env.PAYSTACK_USD_ENABLED === "1";
  const paystackTakes = c === "NGN" ? paystackKey : c === "USD" ? paystackKey && paystackUsd : false;
  const stripeTakes = (c === "USD" || c === "GBP") && stripe.isConfigured();

  return [
    {
      id: "paystack",
      label: "Paystack",
      note: c === "NGN" ? "Card, bank transfer or USSD." : "Card, bank transfer or USSD. Best for African cards.",
      available: paystackTakes,
      reason: !paystackKey ? "no key"
        : c === "USD" && !paystackUsd ? "USD not enabled on the account"
        : c === "GBP" ? "Paystack does not settle pounds" : undefined,
    },
    {
      id: "stripe",
      label: "Stripe",
      note: "Card, Apple Pay or Google Pay. Best outside Africa.",
      available: stripeTakes,
      reason: !stripe.isConfigured() ? "no key" : c === "NGN" ? "Stripe does not settle naira" : undefined,
    },
  ];
}

export function availableProviders(currency = "USD"): ProviderChoice[] {
  return providerChoices(currency).filter((p) => p.available);
}

/** Narrows whatever arrived from a form to a provider that can take it. */
export function resolveProvider(wanted?: string | null, currency = "USD"): Provider | null {
  const open = availableProviders(currency).map((p) => p.id);
  if (wanted && open.includes(wanted as Provider)) return wanted as Provider;
  return open[0] ?? null;
}

export type StartArgs = {
  txRef: string; amount: number; currency: string; email: string;
  name?: string | null; description: string; redirectUrl: string;
  provider?: string | null; meta?: Record<string, string>;
};

export type Started = { url: string; provider: Provider; session: string | null };

export async function startCheckout(a: StartArgs): Promise<Started> {
  const provider = resolveProvider(a.provider, a.currency);
  if (!provider) {
    console.error(`nothing can settle ${a.currency}`,
      providerChoices(a.currency).map((p) => `${p.id}: ${p.reason}`));
    throw new Error(`No payment provider can take ${a.currency}`);
  }

  if (provider === "stripe") {
    const s = await stripe.createCheckout(a);
    return { url: s.url, provider, session: s.sessionId };
  }
  const url = await paystack.createCheckout({
    txRef: a.txRef, amount: a.amount, currency: a.currency, email: a.email,
    name: a.name, redirectUrl: a.redirectUrl, meta: a.meta,
  });
  return { url, provider, session: null };
}

export type Verified = {
  ok: boolean; txRef: string; amount: number; currency: string;
  providerRef: string; email: string | null;
};

/**
 * Confirms a payment with whichever provider took it. Stripe is looked up
 * by the session id recorded on the intent, Paystack by our own reference.
 */
export async function verifyPayment(
  provider: Provider | string | null, txRef: string, session?: string | null
): Promise<Verified | null> {
  if (provider === "stripe") return session ? stripe.verifyBySession(session) : null;
  return paystack.verifyByReference(txRef);
}

export { newReference } from "@/lib/paystack";
