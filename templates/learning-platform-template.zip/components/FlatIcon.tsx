/**
 * The filled set.
 *
 * NavIcon is a stroked, monochrome set built for the rail, where thirty-six
 * glyphs have to stay legible at 18px and look like siblings. That style is
 * right there and wrong on a 44px tinted chip, where a hairline outline
 * reads as faint rather than quiet.
 *
 * So there are two sets, split by job rather than by taste: stroked for
 * navigation, filled for content — stat tiles, the certificate shelf, what a
 * course includes. Solid shapes with a lighter accent, which is the concept
 * these were drawn from.
 *
 * Deliberately small. Every glyph here is one somebody asked for; the
 * temptation to fill in the other thirty is how a design system ends up with
 * two complete sets and no rule about which to use.
 */
export type FlatName =
  | "award" | "book" | "inbox" | "sparkle" | "clock" | "shield" | "user" | "play";

export default function FlatIcon({
  name, size = 22, className,
}: {
  name: FlatName;
  size?: number;
  className?: string;
}) {
  return (
    <svg
      width={size} height={size} viewBox="0 0 24 24"
      className={className} aria-hidden="true"
      /* currentColor for the solid mass, and a lightened copy of it for the
         detail — so one colour on the chip drives both and the icons tint
         with whatever surrounds them. */
      style={{ display: "block" }}
    >
      {GLYPHS[name]}
    </svg>
  );
}

/** Two tones of one colour, never white.
 *
 * The first draft cut details out in white, which vanished the moment the
 * icon itself was white on a saturated chip — an award that read as a plain
 * disc. Detail is now a translucent copy of the same colour, so a glyph
 * holds its shape on any background the chip happens to have. */
const soft = { fill: "currentColor", opacity: 0.42 } as const;
const solid = { fill: "currentColor" } as const;

const GLYPHS: Record<FlatName, React.ReactNode> = {
  /* A rosette. The centre is a real hole cut with evenodd rather than a
     lighter circle on top — opacity cannot lighten white on white, so on a
     saturated chip the first version read as a plain disc. A hole shows the
     chip through it and works on any background. */
  award: (
    <>
      <path {...soft} d="M8.7 15.1 6.1 21.6l3.2-1.2 1.6 2.6 2-5.2zM15.3 15.1l2.6 6.5-3.2-1.2-1.6 2.6-2-5.2z" />
      <path
        {...solid} fillRule="evenodd" clipRule="evenodd"
        d="M12 1.9a7.1 7.1 0 1 1 0 14.2 7.1 7.1 0 0 1 0-14.2zm0 3.6a3.5 3.5 0 1 0 0 7 3.5 3.5 0 0 0 0-7z"
      />
    </>
  ),

  // An open book: one solid leaf, one lighter.
  book: (
    <>
      <path {...solid} d="M3.1 5.1c2.6-.9 5.2-.9 7.8 0a1 1 0 0 1 .6 1v11.4a.6.6 0 0 1-.8.5c-2.4-.8-4.7-.8-7.1 0a.6.6 0 0 1-.8-.5V6.1a1 1 0 0 1 .3-1z" />
      <path {...soft} d="M20.9 5.1c-2.6-.9-5.2-.9-7.8 0a1 1 0 0 0-.6 1v11.4a.6.6 0 0 0 .8.5c2.4-.8 4.7-.8 7.1 0a.6.6 0 0 0 .8-.5V6.1a1 1 0 0 0-.3-1z" />
    </>
  ),

  // A tray, with the lighter lid above it.
  inbox: (
    <>
      <path {...soft} d="M5.9 4.4h12.2a1.6 1.6 0 0 1 1.5 1.1l1.8 5.6H2.6l1.8-5.6a1.6 1.6 0 0 1 1.5-1.1z" />
      <path {...solid} d="M2.4 12.6h5.5a.9.9 0 0 1 .87.66 3.4 3.4 0 0 0 6.46 0 .9.9 0 0 1 .87-.66h5.5v4.8a2.2 2.2 0 0 1-2.2 2.2H4.6a2.2 2.2 0 0 1-2.2-2.2z" />
    </>
  ),

  sparkle: (
    <>
      <path {...solid} d="M11.4 2.2c.55 4.1 1.9 6.2 5.9 6.9-4 .7-5.35 2.8-5.9 6.9-.55-4.1-1.9-6.2-5.9-6.9 4-.7 5.35-2.8 5.9-6.9z" />
      <path {...soft} d="M18 14.3c.3 2.1.95 3.15 2.95 3.55-2 .4-2.65 1.45-2.95 3.55-.3-2.1-.95-3.15-2.95-3.55 2-.4 2.65-1.45 2.95-3.55z" />
    </>
  ),

  // Hands cut out of the disc, same reason as the rosette above.
  clock: (
    <path
      {...solid} fillRule="evenodd" clipRule="evenodd"
      d="M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18zm-.9 3.6v6.05l4.6 2.7.9-1.55-3.7-2.2V6.6z"
    />
  ),

  shield: (
    <path
      {...solid} fillRule="evenodd" clipRule="evenodd"
      d="M12 2.2 20.1 5.2v6.3c0 4.7-3.25 8.75-8.1 10.35C7.15 20.25 3.9 16.2 3.9 11.5V5.2zm-1.15 12.4 5-5-1.35-1.35-3.65 3.65-1.35-1.35-1.35 1.35z"
    />
  ),

  user: (
    <>
      <circle {...solid} cx="12" cy="7.9" r="4.3" />
      <path {...soft} d="M3.7 20.5c0-4 3.75-6.5 8.3-6.5s8.3 2.5 8.3 6.5a1.2 1.2 0 0 1-1.2 1.2H4.9a1.2 1.2 0 0 1-1.2-1.2z" />
    </>
  ),

  play: (
    <path
      {...solid} fillRule="evenodd" clipRule="evenodd"
      d="M12 2.8a9.2 9.2 0 1 1 0 18.4 9.2 9.2 0 0 1 0-18.4zM9.9 7.9v8.2L16.4 12z"
    />
  ),
};
