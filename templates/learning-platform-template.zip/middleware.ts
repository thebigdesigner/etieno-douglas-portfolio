import { createServerClient } from "@supabase/ssr";
import { cookieOptions } from "@/lib/supabase/cookie-domain";
import { NextResponse, type NextRequest } from "next/server";
import { ARRIVAL_COOKIE } from "@/lib/arrival";
import { isMarketplaceHost } from "@/lib/marketplace/href";

/**
 * Paths on the marketplace host that are shared with the main app rather
 * than being marketplace pages: framework internals, API routes, the auth
 * callback, and the static files in /public.
 */
const SHARED = /^\/(api|auth|_next)(\/|$)|\.[a-z0-9]+$/i;

/**
 * marketplace.yourbrand.com is this same deployment. Its paths map onto
 * app/marketplace, so /fonts on the subdomain renders app/marketplace/fonts.
 * A rewrite, not a redirect: the visitor keeps the short URL.
 *
 * A stray /marketplace/... link arriving on the subdomain is redirected to
 * the short form instead of being rewritten again, which would render
 * /marketplace/marketplace and 404.
 */
function marketplaceTarget(request: NextRequest): URL | "redirect" | null {
  const host = request.headers.get("x-forwarded-host") ?? request.headers.get("host");
  if (!isMarketplaceHost(host)) return null;
  const { pathname } = request.nextUrl;
  if (SHARED.test(pathname)) return null;
  if (pathname === "/marketplace" || pathname.startsWith("/marketplace/")) return "redirect";
  const url = request.nextUrl.clone();
  url.pathname = `/marketplace${pathname === "/" ? "" : pathname}`;
  return url;
}

/**
 * The marketplace has one public address. Without this, yourbrand.com/fonts
 * would 404 but yourbrand.com/marketplace/fonts would render the whole shop a
 * second time — two URLs for every page, and search engines picking one.
 *
 * Only on the production domain: localhost and preview deployments keep
 * /marketplace so the shop can be worked on without the subdomain.
 */
const MARKETPLACE_ORIGIN = process.env.MARKETPLACE_URL ?? "https://marketplace.yourbrand.com";

function toMarketplaceHost(request: NextRequest): URL | null {
  const host = (request.headers.get("x-forwarded-host") ?? request.headers.get("host") ?? "").split(":")[0].toLowerCase();
  if (isMarketplaceHost(host) || !(host === "yourbrand.com" || host.endsWith(".yourbrand.com"))) return null;
  const { pathname, search } = request.nextUrl;
  if (pathname !== "/marketplace" && !pathname.startsWith("/marketplace/")) return null;
  const rest = pathname.replace(/^\/marketplace/, "") || "/";
  return new URL(`${rest}${search}`, MARKETPLACE_ORIGIN);
}

export async function middleware(request: NextRequest) {
  const away = toMarketplaceHost(request);
  if (away) return NextResponse.redirect(away, 308);

  const target = marketplaceTarget(request);
  if (target === "redirect") {
    const url = request.nextUrl.clone();
    url.pathname = url.pathname.replace(/^\/marketplace/, "") || "/";
    return NextResponse.redirect(url, 308);
  }
  // Every response this function builds has to carry the rewrite, including
  // the ones Supabase asks for when it refreshes the session below.
  const pass = () => (target ? NextResponse.rewrite(target, { request }) : NextResponse.next({ request }));
  let response = pass();

  const url = process.env.NEXT_PUBLIC_SUPABASE_URL;
  const key = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY;
  if (!url || !key) return response; // not configured yet — stay out of the way

  try {
  const supabase = createServerClient(url, key, {
    cookieOptions: cookieOptions(),
    cookies: {
      getAll() {
        return request.cookies.getAll();
      },
      // eslint-disable-next-line @typescript-eslint/no-explicit-any
      setAll(cookiesToSet: { name: string; value: string; options?: any }[]) {
        cookiesToSet.forEach(({ name, value }) => request.cookies.set(name, value));
        response = pass();
        cookiesToSet.forEach(({ name, value, options }) =>
          response.cookies.set(name, value, options)
        );
      },
    },
  });

  // Refreshes the auth token if it has expired.
  await supabase.auth.getUser();
  } catch (err) {
    /* Refreshing a token is not worth the whole site.
     *
     * This runs on every request, including prerendered static pages, so
     * anything thrown here 500s the entire domain — the marketing pages,
     * the legal pages, everything — for a reason no visitor could act on.
     * A paused Supabase project or a malformed URL took down /teach, which
     * is static HTML that needs no database at all.
     *
     * Swallowed deliberately: the cost is that an expired token is not
     * refreshed on this request, so the page renders signed-out and the
     * next request tries again. The alternative is a blank 500 for
     * everybody. */
    console.error("middleware: session refresh failed", err);
  }

  // Burn the arrival marker. The page still reads it on this request — the
  // request cookies are untouched — but it is gone from the browser
  // afterwards, so the next hop to /dashboard is navigation, not a login.
  // Deleted here rather than in the page because a server component cannot
  // write cookies. Last thing before the return: `response` is reassigned
  // above whenever Supabase refreshes the session.
  if (
    request.nextUrl.pathname === "/dashboard" &&
    request.cookies.get(ARRIVAL_COOKIE)
  ) {
    // Not response.cookies.delete(). Next reflects mutations made through
    // that API back into the request it forwards, so deleting here removed
    // the cookie from under the page before it could read it — the greeting
    // came out as "Hey" on a fresh login. Writing the expiry header directly
    // leaves the request alone and still clears the browser's copy.
    response.headers.append(
      "set-cookie",
      `${ARRIVAL_COOKIE}=; Path=/; Max-Age=0; HttpOnly; SameSite=Lax`
    );
  }

  return response;
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp)$).*)"],
};
