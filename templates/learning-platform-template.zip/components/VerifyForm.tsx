"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";

export default function VerifyForm() {
  const router = useRouter();
  const [code, setCode] = useState("");

  function go() {
    const clean = code.trim().toUpperCase();
    if (clean) router.push(`/verify/${encodeURIComponent(clean)}`);
  }

  return (
    <div className="vform">
      <label className="sr" htmlFor="code">Certificate code</label>
      <input
        id="code"
        type="text"
        placeholder="e.g. SPL-4K2M-90XB"
        value={code}
        onChange={(e) => setCode(e.target.value)}
        onKeyDown={(e) => { if (e.key === "Enter") go(); }}
      />
      <button className="btn btn--fill" onClick={go}>Verify</button>
    </div>
  );
}
