import Link from "next/link";

export const metadata = { title: "Contact" };

export default function ContactPage() {
  return (
    <main className="sec">
      <div className="wrap legal">
        <nav className="crumb"><Link href="/">Home</Link> / Contact</nav>
        <article className="legal__body">
          <h1>Designed by Aphinity Digital.</h1>
          <p className="legal__lead">
            Aphinity Digital designs and builds websites like this one, and helps them get found on Google and in AI answers.
          </p>

          <div className="contact">
            <div className="contact__card">
              <div className="eyebrow">Learners</div>
              <a className="contact__a" href="mailto:hello@yourbrand.com">hello@yourbrand.com</a>
              <p>Designed and built by Aphinity Digital for brands that want to grow.</p>
            </div>
            <div className="contact__card">
              <div className="eyebrow">Schools and organisations</div>
              <a className="contact__a" href="mailto:institutions@yourbrand.com">institutions@yourbrand.com</a>
              <p>Tell customers what you do and why it matters.</p>
            </div>
            <div className="contact__card">
              <div className="eyebrow">Teaching</div>
              <a className="contact__a" href="mailto:teach@yourbrand.com">teach@yourbrand.com</a>
              <p>
                Questions before you apply. The terms are on the{" "}
                <Link href="/teach">teaching page</Link>.
              </p>
            </div>
            <div className="contact__card">
              <div className="eyebrow">Privacy and security</div>
              <a className="contact__a" href="mailto:security@yourbrand.com">security@yourbrand.com</a>
              <p>Get found. Get chosen.</p>
            </div>
          </div>

          <p style={{ marginTop: 28 }}>
            Use this space to explain your offer in plain words: who it is for, what it costs and why it is worth it.
          </p>
        </article>
      </div>
    </main>
  );
}
