"use client";

import { useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { createClient } from "@/lib/supabase/client";
import { attachUpload } from "@/app/actions/marketplace";
import MkIcon from "@/components/marketplace/MkIcon";

const LIMITS = {
  cover: { bytes: 10 * 1024 * 1024, accept: "image/png,image/jpeg,image/webp", label: "PNG, JPG or WebP, up to 10 MB. 1600×1200 works best." },
  file: { bytes: 500 * 1024 * 1024, accept: ".zip,.rar,.7z,.pdf,.fig,.sketch,.xd,.otf,.ttf,.woff2,.mp3,.wav,.mp4,.mov,.blend,.glb,.fbx,.obj,.pptx,.key,.epub",
    label: "A .zip of everything the buyer gets, up to 500 MB." },
};

/**
 * Uploads go from the browser straight to storage, into a folder named
 * after the user and the item. The server then confirms the object
 * exists and belongs to them before attaching it. Large files never touch
 * a server action, which caps bodies at 5 MB.
 */
export default function Uploader({ itemId, userId, kind, current }: {
  itemId: string; userId: string; kind: "cover" | "file";
  current: { url?: string | null; name?: string | null; size?: string | null } | null;
}) {
  const input = useRef<HTMLInputElement>(null);
  const router = useRouter();
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const lim = LIMITS[kind];

  async function onPick(f: File | undefined) {
    if (!f) return;
    setError(null);
    if (f.size > lim.bytes) { setError(`That file is ${(f.size / 1024 / 1024).toFixed(0)} MB; the limit is ${lim.bytes / 1024 / 1024} MB.`); return; }
    setBusy(true);
    try {
      const clean = f.name.toLowerCase().replace(/[^a-z0-9._-]+/g, "-").slice(-80);
      const path = `${userId}/${itemId}/${Date.now().toString(36)}-${clean}`;
      const bucket = kind === "cover" ? "mk-covers" : "mk-files";
      const { error: upErr } = await createClient().storage.from(bucket)
        .upload(path, f, { contentType: f.type || "application/octet-stream", upsert: false });
      if (upErr) { setError(upErr.message.includes("mime") ? "That file type is not allowed here." : "Upload failed. Check your connection and try again."); return; }
      const res = await attachUpload({ id: itemId, kind, path, name: f.name, bytes: f.size });
      if (res.error) { setError(res.error); return; }
      router.refresh();
    } finally {
      setBusy(false);
      if (input.current) input.current.value = "";
    }
  }

  const has = kind === "cover" ? Boolean(current?.url) : Boolean(current?.name);
  return (
    <div className={`st-up${has ? " is-set" : ""}`}>
      {kind === "cover" && current?.url
        ? <img src={current.url} alt="Current cover" className="st-up__img" />
        : <span className="st-up__ico"><MkIcon name={kind === "cover" ? "palette" : "file"} size={24} /></span>}
      <div className="st-up__txt">
        <span className="st-up__h">
          {kind === "cover" ? (has ? "Cover image" : "Add a cover image") : (has ? current?.name : "Add the file buyers download")}
        </span>
        <span className="st-up__p">{kind === "file" && current?.size ? `${current.size} · ` : ""}{lim.label}</span>
        {error && <span className="st-msg st-msg--err" role="alert">{error}</span>}
      </div>
      <input ref={input} type="file" accept={lim.accept} hidden onChange={(e) => onPick(e.target.files?.[0])} />
      <button type="button" className="mk-btn mk-btn--line" disabled={busy} onClick={() => input.current?.click()}>
        {busy ? "Uploading…" : has ? "Replace" : "Upload"}
      </button>
    </div>
  );
}
