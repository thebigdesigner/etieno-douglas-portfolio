import Link from "next/link";
import AuthShell from "@/components/AuthShell";

export const metadata = { title: "Forgotten your PIN" };

export default function ForgotPinPage() {
  return (
    <AuthShell
      eyebrow="For learners in a class"
      title="Ask your teacher to reset it"
      intro="Class accounts do not use an email address, so we cannot send you a reset link. Whoever set up your class can clear your PIN in a few seconds."
      footer={<>Remembered it? <Link href="/join">Back to joining your class</Link></>}
    >
      <div className="auth__note">
        <p><strong>Tell them:</strong> your name, your username, and the name of your class.</p>
        <p style={{ marginTop: 12 }}>
          Once they have cleared it, come back to the join page and set a new 6-digit
          PIN. Nothing you have already done is lost.
        </p>
      </div>
    </AuthShell>
  );
}
