"use client";
import { useActionState } from "react";
import { reassignToReserve } from "@/app/actions/institution";
import type { FormState } from "@/lib/forms";
import { useFormStatus } from "react-dom";

const initial: FormState = {};

function Btn() {
  const { pending } = useFormStatus();
  return <button className="studio__add" disabled={pending}>{pending ? "…" : "Reassign"}</button>;
}

export default function ReassignForm({
  submissionId, reserves,
}: { submissionId: string; reserves: { id: string; name: string }[] }) {
  const [state, action] = useActionState(reassignToReserve.bind(null, submissionId), initial);

  if (state.ok) return <span className="rq__go">{state.message}</span>;

  return (
    <form action={action} className="reassign">
      <select name="reserve_id" defaultValue="" required>
        <option value="" disabled>Reserve…</option>
        {reserves.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
      </select>
      <Btn />
      {state.error && <span className="reassign__err">{state.error}</span>}
    </form>
  );
}
