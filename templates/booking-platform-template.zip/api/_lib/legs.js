/**
 * A booking stores one passenger row per person per leg. Everything that shows a booking —
 * the ticket email, the account page, Find my booking — needs it the other way round: the legs
 * in order, each with its seats, and each person once.
 */
export function legsOf(passengers, cityOf) {
  const byTrip = new Map();
  for (const p of passengers || []) {
    const t = p.trip; if (!t) continue;
    const key = `${t.depart_date}T${t.depart_time}`;
    if (!byTrip.has(key)) byTrip.set(key, { date: t.depart_date, time: String(t.depart_time).slice(0, 5),
      from: cityOf(t.route?.from_terminal), to: cityOf(t.route?.to_terminal), status: t.status, seats: [], names: [] });
    const leg = byTrip.get(key); leg.seats.push(p.seat_no); leg.names.push(p.full_name);
  }
  const legs = [...byTrip.entries()].sort(([a], [b]) => a.localeCompare(b)).map(([, l], i) =>
    ({ ...l, dir: i === 0 ? 'Outbound' : 'Return', seats: l.seats.sort((a, b) => a - b) }));
  return { legs, people: legs[0]?.names || [] };
}
