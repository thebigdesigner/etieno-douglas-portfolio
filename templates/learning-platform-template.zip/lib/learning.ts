/**
 * Shared constants and types for the learning engine.
 *
 * These live outside the "use server" file because a server-actions module
 * may only export async functions — exporting a constant from it breaks the
 * entire module for every importer.
 */

export const PASS_MARK = 80;

/** The final exam uses the same bar as a topic quiz. Two different pass
 *  marks would be a second rule to explain for no gain. */
export const EXAM_PASS_MARK = 80;

export type QuizResult = {
  error?: string;
  scorePct?: number;
  passed?: boolean;
  cooldownUntil?: string;
  /** Per-item feedback, only returned after grading. */
  review?: { itemId: string; correct: boolean; explanation: string | null }[];
};

/** Same shape as QuizResult. Kept separate so the exam can grow fields —
 *  a certificate code, a project handoff — without widening the quiz type
 *  that eleven topic screens depend on. */
export type ExamResult = {
  error?: string;
  scorePct?: number;
  passed?: boolean;
  cooldownUntil?: string;
  review?: { itemId: string; correct: boolean; explanation: string | null }[];
  /** Where a pass sends them: the project, or a freshly issued certificate. */
  next?: { kind: "project" | "certificate"; href: string; code?: string };
};
