"use client";
import { useFormStatus } from "react-dom";

/**
 * The label stays put while a spinner ring slides in beside it. A button
 * that swaps its label for "Just a moment…" changes width and reads as a
 * different control; one that keeps its words and shows work being done
 * reads as the same control, busy.
 */
export default function SubmitButton({ children }: { children: React.ReactNode }) {
  const { pending } = useFormStatus();
  return (
    <button
      className={`btn btn--fill btn--lg auth__submit${pending ? " is-busy" : ""}`}
      disabled={pending}
      aria-busy={pending}
    >
      <span className="btn__spin" aria-hidden="true" />
      <span className="btn__label">{children}</span>
      <span className="sr" role="status">{pending ? "Working…" : ""}</span>
    </button>
  );
}
