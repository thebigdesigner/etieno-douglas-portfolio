-- =====================================================================
-- Your Brand moves payments from Flutterwave to Paystack.
--
-- payment_events.provider defaulted to 'flutterwave'. The Paystack webhook
-- always names its provider explicitly, so this default is belt and
-- braces: anything that forgets to set it is recorded as Paystack, the
-- provider actually in use, rather than silently mislabelled.
--
-- Existing rows keep 'flutterwave'. They are the true record of what that
-- provider sent and are what a dispute would be settled from.
-- =====================================================================

alter table payment_events alter column provider set default 'paystack';
