import Link from "next/link";
import CourseThumb from "@/components/CourseThumb";
import { subjectTint } from "@/lib/media";
import { LEVEL_LABEL, hoursLabel } from "@/lib/subjects";

export type CardCourse = {
  slug: string;
  title: string;
  summary?: string | null;
  subject: string;
  level?: string | null;
  hours_low?: number | null;
  hours_high?: number | null;
  is_free?: boolean | null;
  thumbnail_path?: string | null;
  learners?: number | null;
  instructor?: string | null;
};

/**
 * One card, used everywhere a course appears. The metadata line is what a
 * learner actually decides on: how hard, how long, how many others have done
 * it. The summary is secondary.
 */
export default function CourseCard({
  course, priority = false,
}: { course: CardCourse; priority?: boolean }) {
  const hours = hoursLabel(course.hours_low ?? null, course.hours_high ?? null);
  const learners = Number(course.learners ?? 0);

  return (
    <Link className={`ccard tone-${subjectTint(course.subject)}`} href={`/courses/${course.slug}`}>
      <div className="ccard__top">
        <CourseThumb
          path={course.thumbnail_path}
          title={course.title}
          subject={course.subject}
          priority={priority}
        />
        {course.level && (
          <span className={`ccard__level ccard__level--${course.level}`}>
            {LEVEL_LABEL[course.level] ?? course.level}
          </span>
        )}
        {course.is_free && <span className="ccard__free">Free</span>}
      </div>

      <div className="ccard__body">
        <span className="ccard__subject">{course.subject}</span>
        <h3 className="ccard__h">{course.title}</h3>
        {course.instructor && (
          <p className="ccard__by">with {course.instructor}</p>
        )}

        <div className="ccard__meta">
          {hours && <span>{hours}</span>}
          {learners > 0 && (
            <span className="num">
              {learners.toLocaleString()} learner{learners === 1 ? "" : "s"}
            </span>
          )}
        </div>
      </div>

      <div className="ccard__foot">
        <span className="ccard__cert">Certificate included</span>
        <span className="ccard__go">Start learning</span>
      </div>
    </Link>
  );
}
