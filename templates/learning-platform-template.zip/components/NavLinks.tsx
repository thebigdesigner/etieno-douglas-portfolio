"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import { NAV, NAV_SIGNED_IN } from "@/lib/nav";

/**
 * Client component so the layout can stay static — usePathname does not
 * opt a route out of prerendering the way reading headers() would.
 */
export default function NavLinks({ className = "nav__links" }: { className?: string }) {
  const pathname = usePathname();
  const [signedIn, setSignedIn] = useState(false);

  useEffect(() => {
    const supabase = createClient();
    let cancelled = false;
    supabase.auth.getUser().then(({ data }) => {
      if (!cancelled) setSignedIn(!!data.user);
    });
    return () => { cancelled = true; };
  }, []);

  const items = signedIn ? NAV_SIGNED_IN : NAV;

  return (
    <div className={className}>
      {items.map((item) => {
        const base = item.href.split("#")[0] || "/";
        const current = base === "/" ? pathname === "/" : pathname.startsWith(base);
        return (
          <Link key={item.href} href={item.href} aria-current={current ? "page" : undefined}>
            {item.label}
          </Link>
        );
      })}
    </div>
  );
}
