import { createAdminClient } from "@/lib/supabase/admin";
import { requireOwner } from "@/lib/owner";
import FilterBar from "@/components/FilterBar";

export const metadata = { title: "Audit" };
export const dynamic = "force-dynamic";

const LABELS: Record<string, string> = {
  set_role: "Changed a role",
  grant_allowance: "Granted certifications",
  revoke_certificate: "Revoked a certificate",
  suspend_account: "Suspended an account",
  restore_account: "Restored an account",
};

type SearchParams = Promise<{ action?: string; since?: string }>;

export default async function AuditPage(
  { searchParams }: { searchParams: SearchParams }
) {
  await requireOwner();
  const { action, since } = await searchParams;
  const admin = createAdminClient();

  let query = admin.from("admin_audit").select("*");
  if (action) query = query.eq("action", action);

  // An audit trail is read backwards from a date — "what happened before the
  // complaint came in" — so the window matters more than any other filter.
  const DAYS: Record<string, number> = { "1": 1, "7": 7, "30": 30, "90": 90 };
  if (since && DAYS[since]) {
    const from = new Date(Date.now() - DAYS[since] * 864e5).toISOString();
    query = query.gte("created_at", from);
  }

  const [{ data: entries }, { count: total }] = await Promise.all([
    query.order("created_at", { ascending: false }).limit(200),
    admin.from("admin_audit").select("id", { count: "exact", head: true }),
  ]);

  const rows = entries ?? [];

  return (
    <>
      <FilterBar
        selects={[
          {
            name: "action", label: "Any action", value: action,
            options: Object.entries(LABELS).map(([value, label]) => ({ value, label })),
          },
          {
            name: "since", label: "All time", value: since,
            options: [
              { value: "1", label: "Last 24 hours" },
              { value: "7", label: "Last 7 days" },
              { value: "30", label: "Last 30 days" },
              { value: "90", label: "Last 90 days" },
            ],
          },
        ]}
        total={total ?? rows.length}
        showing={rows.length}
        clearHref="/console/audit"
      />

      <div className="con__head">
        <div>
          <h1 className="con__h">Audit</h1>
          <p className="con__sub">
            Every action taken on somebody else&rsquo;s account, by whom and when. It
            cannot be edited from here, and that is the point — a log you can quietly
            amend is not a log.
          </p>
        </div>
      </div>

      {rows.length === 0 ? (
        <div className="empty" style={{ marginTop: 26 }}>
          <p className="empty__h">Nothing recorded yet</p>
          <p className="empty__p">
            Role changes, allowances, suspensions and revocations all appear here.
          </p>
        </div>
      ) : (
        <table className="tbl" style={{ marginTop: 26 }}>
          <thead>
            <tr><th>When</th><th>Who</th><th>What</th><th>Subject</th><th>Detail</th></tr>
          </thead>
          <tbody>
            {rows.map((e) => (
              <tr key={e.id}>
                <td className="num">
                  {new Date(e.created_at).toLocaleString(undefined, {
                    day: "numeric", month: "short", hour: "2-digit", minute: "2-digit",
                  })}
                </td>
                <td>{e.actor_email}</td>
                <td>{LABELS[e.action] ?? e.action}</td>
                <td className="num" style={{ fontSize: 12 }}>
                  {String(e.subject ?? "").slice(0, 14)}
                </td>
                <td style={{ fontSize: 13, color: "var(--ink-70)" }}>
                  {e.detail ? Object.entries(e.detail as Record<string, unknown>)
                    .map(([k, v]) => `${k}: ${v}`).join(" · ") : "—"}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </>
  );
}
