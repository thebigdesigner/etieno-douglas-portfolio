-- =====================================================================
-- 0040 — Your Brand can author, and somebody named still assesses
--
-- createCourse hardcoded owner_kind = 'instructor' and set the creator as
-- the instructor, so there was no way to author a course Your Brand owns: an
-- operator making one produced an instructor course owned by their own
-- account, which then demanded a price and paid them royalties.
--
-- An operator can now create a course Your Brand owns and name its assessor —
-- any active instructor, or a member of staff. Either way it is a person,
-- because a certificate carries the name of whoever assessed it and
-- "assessed by Your Brand" would be the one claim the credential cannot make.
--
-- That forces a correction to the pool. 0037 excluded priced courses, on
-- the reasoning that a sold course is paid for directly. A Your Brand course
-- has no price, so it slipped back in — and would have paid its assessor
-- a subscription royalty for content they did not write. The pool is for
-- authorship; assessment is paid by the review fee.
-- =====================================================================

-- courses.instructor_id already holds whoever assesses; owner_kind says who
-- owns it. Naming the column would be clearer, but renaming one referenced
-- by nine functions and a dozen queries is a bigger risk than a comment.
comment on column courses.instructor_id is
  'Who assesses this course''s projects, and — on an instructor-owned course — who wrote it. Your Brand-owned courses carry an assessor here too, and are excluded from the royalty pool by owner_kind.';

create or replace function public.calculate_pool(p_month date, p_source revenue_source, p_revenue_cents bigint)
returns uuid
language plpgsql security definer set search_path = public as $$
declare
  v_start date := date_trunc('month', p_month)::date;
  v_end   date := (date_trunc('month', p_month) + interval '1 month')::date;
  v_rate  numeric(5,4) := case p_source when 'individual' then 0.35 else 0.30 end;
  v_pool  bigint := floor(p_revenue_cents * v_rate);
  v_completions int;
  v_per    numeric(12,4);
  v_id     uuid;
begin
  -- Only courses a practitioner wrote and gave away: not sold ones, which
  -- are paid for directly, and not Your Brand's own, whose named assessor did
  -- not author them.
  select count(*) into v_completions
    from topic_completions tc
    join enrolments e on e.id = tc.enrolment_id
    join courses    c on c.id = e.course_id
   where tc.revenue_source = p_source
     and tc.completed_at >= v_start and tc.completed_at < v_end
     and c.price_cents is null
     and c.owner_kind = 'instructor';

  if v_completions = 0 then return null; end if;
  v_per := v_pool::numeric / v_completions;

  insert into pool_periods (period_month, source, revenue_cents, pool_rate,
                            pool_cents, completions, rate_per_completion_cents)
  values (v_start, p_source, p_revenue_cents, v_rate, v_pool, v_completions, v_per)
  on conflict (period_month, source) do update
     set revenue_cents = excluded.revenue_cents, pool_cents = excluded.pool_cents,
         completions = excluded.completions,
         rate_per_completion_cents = excluded.rate_per_completion_cents,
         calculated_at = now()
  returning id into v_id;

  insert into earnings_entries (instructor_id, type, amount_cents, ref_id, note)
  select c.instructor_id,
         (case p_source when 'individual' then 'pool_individual'
                        else 'pool_institution' end)::earning_type,
         floor(count(*) * v_per)::int,
         v_id,
         to_char(v_start, 'Mon YYYY') || ' pool, ' || count(*) || ' completions'
    from topic_completions tc
    join enrolments e on e.id = tc.enrolment_id
    join courses    c on c.id = e.course_id
   where tc.revenue_source = p_source
     and tc.completed_at >= v_start and tc.completed_at < v_end
     and c.instructor_id is not null
     and c.price_cents is null
     and c.owner_kind = 'instructor'
   group by c.instructor_id
  having floor(count(*) * v_per) > 0;

  return v_id;
end; $$;

-- ---------------------------------------------------------------------
-- Who an operator may name as the assessor.
--
-- Active instructors, and staff. Both are people with a name to put on a
-- certificate, which is the only requirement that matters.
-- ---------------------------------------------------------------------
create or replace function public.eligible_assessors()
returns table (id uuid, name text, kind text)
language sql
stable
security definer set search_path = public
as $$
  select p.id, coalesce(p.display_name, p.email), 'Practitioner'
    from instructors i join profiles p on p.id = i.id
   where i.state = 'active'
  union all
  select p.id, coalesce(p.display_name, p.email), 'Your Brand'
    from profiles p
   where p.role = 'operator'
   order by 3 desc, 2;
$$;

revoke all on function public.eligible_assessors() from public, anon;
grant execute on function public.eligible_assessors() to authenticated, service_role;
