"use client";
import { useActionState, useState } from "react";
import { addSeats, raiseCeiling, regenerateCode, endCohort } from "@/app/actions/institution";
import type { FormState } from "@/lib/forms";
import SubmitButton from "@/components/SubmitButton";
import Alert from "@/components/Alert";

const initial: FormState = {};

export default function CohortTools({
  cohortId, classCode, ceiling, state,
}: { cohortId: string; classCode: string; ceiling: number; state: string }) {
  const [seatState, addAction] = useActionState(addSeats.bind(null, cohortId), initial);
  const [ceilState, ceilAction] = useActionState(raiseCeiling.bind(null, cohortId), initial);
  const [copied, setCopied] = useState(false);

  return (
    <div className="ctools">
      <div className="ctools__code">
        <div className="eyebrow">Class code</div>
        <div className="ctools__codev num">{classCode}</div>
        <div className="ctools__codeb">
          <button
            className="btn btn--line"
            onClick={() => {
              navigator.clipboard.writeText(classCode);
              setCopied(true);
              setTimeout(() => setCopied(false), 1800);
            }}
          >
            {copied ? "Copied" : "Copy"}
          </button>
          <form action={regenerateCode.bind(null, cohortId)}>
            <button className="btn btn--line">Regenerate</button>
          </form>
        </div>
        <p className="studio__hint" style={{ marginTop: 10 }}>
          Regenerating invalidates the old code. Learners already in are unaffected.
        </p>
      </div>

      <div className="ctools__forms">
        <form action={addAction} className="ctools__inline">
          <label className="field">
            <span className="field__label">Issue more usernames</span>
            <input name="count" type="number" min={1} max={500} defaultValue={10} />
          </label>
          <SubmitButton>Add</SubmitButton>
        </form>
        {seatState.error && <Alert kind="error">{seatState.error}</Alert>}
        {seatState.ok && <Alert kind="success">{seatState.message}</Alert>}

        <form action={ceilAction} className="ctools__inline">
          <label className="field">
            <span className="field__label">Seat ceiling</span>
            <input name="seat_ceiling" type="number" min={1} max={2000} defaultValue={ceiling} />
          </label>
          <SubmitButton>Update</SubmitButton>
        </form>
        {ceilState.error && <Alert kind="error">{ceilState.error}</Alert>}
        {ceilState.ok && <Alert kind="success">{ceilState.message}</Alert>}

        {state === "active" && (
          <form action={endCohort.bind(null, cohortId)} style={{ marginTop: 8 }}>
            <button className="btn btn--line">End this cohort</button>
          </form>
        )}
      </div>
    </div>
  );
}
