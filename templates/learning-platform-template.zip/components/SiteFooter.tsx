import Link from "next/link";

const COLS = [
  {
    heading: "Learn",
    links: [
      { label: "All courses", href: "/courses" },
      { label: "How pricing works", href: "/#pricing" },
      { label: "How assessment works", href: "/#how" },
      { label: "Verify a certificate", href: "/#verify" },
    ],
  },
  {
    heading: "Teach",
    links: [
      { label: "Teach on Your Brand", href: "/teach" },
      { label: "Start teaching", href: "/signup?intent=instructor" },
      { label: "What you earn", href: "/teach#rates" },
      { label: "Our commitments", href: "/teach#terms" },
      { label: "How review works", href: "/teach#commit" },
    ],
  },
  {
    heading: "Institutions",
    links: [
      { label: "Cohorts", href: "/institutions#how" },
      { label: "Set up an organisation", href: "/signup?intent=institution" },
      { label: "Billing", href: "/institutions#billing" },
      { label: "Verification", href: "/institutions#call" },
      { label: "Data processing", href: "/institutions#data" },
    ],
  },
  {
    heading: "Company",
    links: [
      { label: "Contact", href: "/contact" },
      { label: "Privacy", href: "/legal/privacy" },
      { label: "Terms", href: "/legal/terms" },
      { label: "Security", href: "/legal/security" },
    ],
  },
];

export default function SiteFooter() {
  const email = "hello@yourbrand.com";
  return (
    <footer className="foot">
      <div className="foot__in">
        <div>
          <div className="foot__logo">Your Brand<span>.</span></div>
          <p className="foot__blurb">
            Skills assessed by people who do the work. Learn anywhere, certify with
            someone&rsquo;s name on it.
          </p>
          <div className="foot__ct">
            <a href={`mailto:${email}`}>{email}</a>
            <span>Mon–Fri, 9:00–18:00</span>
          </div>
        </div>

        {COLS.map((col) => (
          <div key={col.heading} className="foot__col">
            <div className="foot__h">{col.heading}</div>
            <ul>
              {col.links.map((l) => (
                <li key={l.label}><Link href={l.href}>{l.label}</Link></li>
              ))}
            </ul>
          </div>
        ))}
      </div>

      <div className="foot__bar">
        <div className="foot__bar__in">
          <span>© {new Date().getFullYear()} Your Brand</span>
          <span>Your supporting line goes here, written for your customers.</span>
        </div>
      </div>
    </footer>
  );
}
