/**
 * Navigation items, in a plain module.
 *
 * A "use client" file cannot be the home for a value a server component
 * imports — the import resolves to a client-reference proxy rather than the
 * value itself, and `NAV.map` then fails at render time.
 */
export const NAV = [
  { label: "Courses", href: "/courses" },
  { label: "How it works", href: "/#how" },
  { label: "Pricing", href: "/#pricing" },
  { label: "For institutions", href: "/institutions" },
  { label: "Teach", href: "/teach" },
];

/**
 * What a signed-in learner sees instead. "How it works", "For institutions"
 * and "Teach" are pitches aimed at people deciding whether to join — they
 * are noise once somebody has an account and is browsing the catalogue.
 */
export const NAV_SIGNED_IN = [
  { label: "Courses", href: "/courses" },
  { label: "My learning", href: "/dashboard/courses" },
  { label: "Cart", href: "/dashboard/cart" },
];
