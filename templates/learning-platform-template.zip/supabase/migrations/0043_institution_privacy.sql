-- =====================================================================
-- 0043 — institution courses are private everywhere, not just the
--        catalogue view
--
-- 0041 took institution courses out of course_cards and taught
-- course_entitlement to guard the lesson page. Two other public doors
-- were left open:
--
--   · search_courses filtered only on state = 'published', so a
--     school's private course appeared in everybody's search results —
--     title, summary, and every topic title indexed and served.
--
--   · The public course page queried courses directly rather than
--     through course_cards, so a published institution course had a
--     working public URL. (Fixed in the app; noted here because the
--     two doors were opened by the same assumption — that course_cards
--     is the only way in.)
--
-- course_health also gains owner_kind, appended last because create or
-- replace view cannot reorder columns. The console catalogue reads this
-- view, and without the column it cannot keep an organisation's private
-- material out of Your Brand's own catalogue management.
-- =====================================================================

create or replace function public.search_courses(p_query text)
returns table (
  slug text, title text, summary text, subject text, level course_level,
  hours_low int, hours_high int, is_free boolean, thumbnail_path text,
  learners bigint, rank real
)
language sql stable
security definer set search_path = public
as $$
  select c.slug, c.title, c.summary, c.subject, c.level,
         c.hours_low, c.hours_high, c.is_free, c.thumbnail_path,
         (select count(*) from enrolments e where e.course_id = c.id) as learners,
         ts_rank(
           to_tsvector('english',
             c.title || ' ' || coalesce(c.summary,'') || ' ' || c.subject || ' ' ||
             coalesce((select string_agg(t.title, ' ')
                         from modules m join topics t on t.module_id = m.id
                        where m.course_id = c.id), '')),
           plainto_tsquery('english', p_query)
         ) as rank
    from courses c
   where c.state = 'published'
     -- An organisation's private material is not in anybody's search.
     and c.owner_kind <> 'institution'::course_owner_kind
     and to_tsvector('english',
           c.title || ' ' || coalesce(c.summary,'') || ' ' || c.subject || ' ' ||
           coalesce((select string_agg(t.title, ' ')
                       from modules m join topics t on t.module_id = m.id
                      where m.course_id = c.id), ''))
         @@ plainto_tsquery('english', p_query)
   order by rank desc
   limit 40;
$$;

-- Existing column order preserved exactly; owner_kind appended.
create or replace view public.course_health as
 SELECT c.slug,
    c.title,
    c.subject,
    c.state,
    c.is_free,
    p.display_name AS instructor,
    count(DISTINCT e.id) AS enrolments,
    count(DISTINCT e.id) FILTER (WHERE (e.state = 'certified'::enrolment_state)) AS certified,
    round(((100.0 * (count(DISTINCT e.id) FILTER (WHERE (e.state = 'certified'::enrolment_state)))::numeric) / (NULLIF(count(DISTINCT e.id), 0))::numeric), 1) AS completion_pct,
    ( SELECT count(*) AS count
           FROM (modules m
             JOIN topics t ON ((t.module_id = m.id)))
          WHERE (m.course_id = c.id)) AS topics,
    c.owner_kind
   FROM ((courses c
     LEFT JOIN profiles p ON ((p.id = c.instructor_id)))
     LEFT JOIN enrolments e ON ((e.course_id = c.id)))
  GROUP BY c.slug, c.title, c.subject, c.state, c.is_free, p.display_name, c.id;
