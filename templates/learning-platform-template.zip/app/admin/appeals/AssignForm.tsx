"use client";
import { useActionState } from "react";
import { assignAppeal } from "@/app/actions/review";
import type { FormState } from "@/lib/forms";
import SubmitButton from "@/components/SubmitButton";
import Alert from "@/components/Alert";

const initial: FormState = {};

export default function AssignForm({
  appealId, reviewers,
}: { appealId: string; reviewers: { id: string; name: string }[] }) {
  const [state, action] = useActionState(assignAppeal.bind(null, appealId), initial);

  if (state.ok) return <Alert kind="success">{state.message}</Alert>;

  return (
    <form action={action} className="ctools__inline" style={{ marginTop: 18 }}>
      <label className="field">
        <span className="field__label">Second reviewer</span>
        <select name="reviewer_id" defaultValue="" required>
          <option value="" disabled>Choose someone</option>
          {reviewers.map((r) => <option key={r.id} value={r.id}>{r.name}</option>)}
        </select>
      </label>
      <SubmitButton>Assign</SubmitButton>
      {state.error && <Alert kind="error">{state.error}</Alert>}
    </form>
  );
}
