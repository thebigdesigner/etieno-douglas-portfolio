import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { authorStats, getAuthor, isDemo } from "@/lib/marketplace/catalog";
import { compact, shortDate } from "@/lib/marketplace/format";
import { marketBase } from "@/lib/marketplace/url";
import MkIcon from "@/components/marketplace/MkIcon";
import { Avatar, DemoNote, ProductGrid, SectionHead } from "@/components/marketplace/bits";
import type { Author, MkIconName } from "@/lib/marketplace/types";

type Props = { params: Promise<{ handle: string }> };

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const a = await getAuthor((await params).handle);
  return a ? { title: a.name, description: a.bio } : {};
}

/** Brand marks for the social row. Simplified to read at 18px. */
const SOCIAL: Record<Author["socials"][number]["kind"], { label: string; d: string }> = {
  instagram: { label: "Instagram", d: "M7 3.5h10A3.5 3.5 0 0 1 20.5 7v10a3.5 3.5 0 0 1-3.5 3.5H7A3.5 3.5 0 0 1 3.5 17V7A3.5 3.5 0 0 1 7 3.5ZM12 8.2a3.8 3.8 0 1 1 0 7.6 3.8 3.8 0 0 1 0-7.6ZM17 6.8h.01" },
  x:         { label: "X", d: "M4.5 4h4.2l10.8 16h-4.2zM19.5 4l-6.2 7M10.7 13l-6.2 7" },
  behance:   { label: "Behance", d: "M3.5 6.5h5a2.5 2.5 0 0 1 0 5h-5zM3.5 11.5h5.5a2.7 2.7 0 0 1 0 5.5H3.5zM14.5 13.5h6a3 3 0 1 0-.6 2.2M15 7.5h5" },
  dribbble:  { label: "Dribbble", d: "M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18ZM5 7.5c4.5 1.5 9 1 13.5-1.5M3.2 13c5.5-1.8 11-1 15.5 4M8.5 3.8C12 8 14.5 13.5 15.5 20.2" },
  youtube:   { label: "YouTube", d: "M3.5 8.5c0-2 1-3 3-3.2 3.7-.3 7.3-.3 11 0 2 .2 3 1.2 3 3.2v7c0 2-1 3-3 3.2-3.7.3-7.3.3-11 0-2-.2-3-1.2-3-3.2zM10 9.2v5.6l4.8-2.8z" },
};

export default async function AuthorPage({ params }: Props) {
  const [{ handle }, base] = await Promise.all([params, marketBase()]);
  const author = await getAuthor(handle);
  if (!author) notFound();
  const [stats, demo] = await Promise.all([authorStats(handle), isDemo()]);
  const authors = new Map([[author.handle, author]]);

  const tiles: { icon: MkIconName; label: string; value: string }[] = [
    { icon: "file", label: "Items", value: String(stats.count) },
    { icon: "download", label: "Downloads", value: compact(stats.downloads) },
    { icon: "users", label: "Followers", value: compact(author.followers) },
    { icon: "star", label: "Average rating", value: stats.rating ? stats.rating.toFixed(1) : "–" },
  ];

  return (
    <>
      {demo && <DemoNote />}

      {/* The reference's channel banner: wide image, socials riding its edge. */}
      <section className="mk-cover">
        <div className="mk-cover__band" aria-hidden="true" />
        <div className="mk-cover__who">
          <Avatar name={author.name} hue={author.hue} size={84} />
          <div>
            <h1 className="mk-cover__h">{author.name}</h1>
            <p className="mk-cover__sub">
              {author.person && <>{author.person}, </>}{author.location}
            </p>
          </div>
        </div>
        {author.socials.length > 0 && (
          <ul className="mk-cover__socials">
            {author.socials.map((s) => (
              <li key={s.kind}>
                <a href={s.url} target="_blank" rel="noopener noreferrer" className="mk-social" data-kind={s.kind}>
                  <svg viewBox="0 0 24 24" width="18" height="18" fill="none" stroke="currentColor" strokeWidth="1.8"
                    strokeLinecap="round" strokeLinejoin="round" aria-hidden="true"><path d={SOCIAL[s.kind].d} /></svg>
                  <span className="sr">{author.name} on {SOCIAL[s.kind].label}</span>
                </a>
              </li>
            ))}
          </ul>
        )}
      </section>

      <div className="mk-profile">
        <section className="mk-panel mk-bio">
          <h2 className="mk-bio__h">About</h2>
          <p>{author.bio}</p>
          <p className="mk-bio__since"><MkIcon name="clock" size={15} />Selling since {shortDate(author.joined)}</p>
        </section>
        <ul className="mk-stats">
          {tiles.map((t) => (
            <li key={t.label} className="mk-stat">
              <span className="mk-stat__ico"><MkIcon name={t.icon} size={17} /></span>
              <span className="mk-stat__l">{t.label}</span>
              <span className="mk-stat__v num">{t.value}</span>
            </li>
          ))}
        </ul>
      </div>

      <section className="mk-sec">
        <SectionHead title={`Items by ${author.name}`} />
        {stats.items.length > 0
          ? <ProductGrid items={stats.items} base={base} authors={authors} />
          : <p className="mk-quiet">Nothing listed yet.</p>}
      </section>
    </>
  );
}
