-- =====================================================================
-- OAuth signup: pick up the name the provider gives us.
--
-- handle_new_user() only ever read 'display_name', which is a key this
-- app sets itself on the email signup path. Google and LinkedIn set
-- 'full_name' and/or 'name' instead, so an OAuth account previously
-- landed with a null display_name — which surfaces as a blank greeting,
-- a blank certificate, and "Learner" in every reviewer-facing view.
--
-- Order matters: our own key wins where it exists, so the email flow is
-- unchanged. Everything else about the function is left alone.
-- =====================================================================

create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (
    id, email, display_name, date_of_birth, account_type,
    segment, guardian_email, status, minor_protections, consent_required, intent
  )
  values (
    new.id,
    new.email,
    coalesce(
      nullif(new.raw_user_meta_data->>'display_name', ''),   -- email signup
      nullif(new.raw_user_meta_data->>'full_name', ''),      -- Google, LinkedIn
      nullif(new.raw_user_meta_data->>'name', '')            -- fallback
    ),
    nullif(new.raw_user_meta_data->>'date_of_birth', '')::date,
    coalesce((new.raw_user_meta_data->>'account_type')::account_type, 'adult'),
    nullif(new.raw_user_meta_data->>'segment', ''),
    nullif(new.raw_user_meta_data->>'guardian_email', ''),
    case when (new.raw_user_meta_data->>'consent_required')::boolean
         then 'pending_consent'::profile_status
         else 'active'::profile_status end,
    coalesce((new.raw_user_meta_data->>'minor_protections')::boolean, false),
    coalesce((new.raw_user_meta_data->>'consent_required')::boolean, false),
    coalesce((new.raw_user_meta_data->>'intent')::signup_intent, 'learner')
  );
  return new;
end;
$$;
