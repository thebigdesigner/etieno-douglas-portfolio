/**
 * GET /api/bookings/ATX-XXXXXX?phone=0803… — retrieve a ticket.
 * The phone number is required so a reference alone cannot expose someone's booking.
 */
import { configured, select, tenant, fail, lookupBlocked, lookupMissed } from '../_lib/db.js';
import { cancellationQuote } from '../_lib/cancel-policy.js';

const last7 = s => String(s || '').replace(/\D/g, '').slice(-7);

export default async function handler(req, res) {
  if (req.method !== 'GET') return fail(res, 405, 'method', 'GET only');
  if (!configured()) return fail(res, 503, 'not_configured', 'Database not configured');

  const ref = String(req.query.ref || '').toUpperCase();
  const phone = String(req.query.phone || '');
  if (!/^[A-Z]{2,5}-[A-Z0-9]{4,10}(-[A-Z0-9]{2,6})?$/.test(ref)) return fail(res, 400, 'bad_reference', 'Check the reference');
  if (last7(phone).length < 7) return fail(res, 400, 'bad_phone', 'Enter the phone number used to book');
  /* Reference + phone unlocks names and, during a trip, where the vehicle is. Guessing it is
     limited per connection and per phone number (shared with ticket resend and receipts). */
  if (await lookupBlocked(req, phone)) return fail(res, 429, 'too_many', 'Too many attempts. Please wait a few minutes and try again.');

  try {
    const t = await tenant();
    const rows = await select('bookings',
      `tenant_id=eq.${t.id}&reference=eq.${ref}&select=reference,status,total_kobo,contact_phone,contact_email,created_at,` +
      `passengers(full_name,seat_no,pax_type,status,trip:trips(id,status,depart_date,depart_time,` +
      `vehicle:vehicles(label,plate),driver:drivers(name),route:routes(from_terminal,to_terminal))),` +
      `payments(status,channel,settled_at,amount_kobo),refunds(status,amount_kobo,created_at)`);

    // Same answer whether the reference is wrong or the phone does not match: no fishing.
    if (!rows.length || last7(rows[0].contact_phone) !== last7(phone)) {
      await lookupMissed(req, phone);
      return fail(res, 404, 'not_found', 'No booking found for that reference and phone number');
    }

    const b = rows[0];
    const terminals = await select('terminals', `tenant_id=eq.${t.id}&select=id,code,city,lat,lng`);
    const cityOf = id => terminals.find(x => x.id === id)?.city || '';
    const codeOf = id => terminals.find(x => x.id === id)?.code || '';
    /* A booking can hold two legs (a round trip). Passengers are stored once per leg, so group
       them by departure; the earliest leg is "the trip" for older pages that expect one. */
    const byTrip = new Map();
    for (const p of b.passengers) {
      if (!p.trip) continue;
      if (!byTrip.has(p.trip.id)) byTrip.set(p.trip.id, { trip: p.trip, pax: [] });
      byTrip.get(p.trip.id).pax.push(p);
    }
    const legsRaw = [...byTrip.values()].sort((x, y) =>
      `${x.trip.depart_date}T${x.trip.depart_time}`.localeCompare(`${y.trip.depart_date}T${y.trip.depart_time}`));
    /* Live position follows whichever leg is actually on the road. */
    const first = (legsRaw.find(l => ['boarding', 'departed'].includes(l.trip.status)) || legsRaw[0] || {}).trip;
    const paid = (b.payments || []).find(p => p.status === 'success' && p.channel !== 'coupon') || (b.payments || []).find(p => p.status === 'success');

    /* ---- where the vehicle is, for this passenger only ----
       This is the one place a customer is given a driver's position, and it is fenced in:

         * they have already proved the booking is theirs — reference plus the phone number it
           was made with, checked above;
         * only while the trip is actually running. Before boarding there is nothing to watch,
           and after arrival it becomes a record of where a driver went, which is not the
           passenger's business;
         * only if the position is fresh. A stale one is withheld entirely rather than shown
           with a caveat, because a customer standing at a terminal will read any dot on a map
           as "it is there now";
         * the driver's name and the vehicle go out, their phone number does not. */
    let live = null;
    if (first && ['boarding', 'departed'].includes(first.status)) {
      const dest = terminals.find(x => x.id === first.route?.to_terminal);
      const pos = await select('trip_locations',
        `trip_id=eq.${first.id}&tenant_id=eq.${t.id}&select=lat,lng,recorded_at&order=recorded_at.desc&limit=1`);
      const at = pos[0]?.recorded_at ? Date.parse(pos[0].recorded_at) : null;
      const ageSeconds = at ? Math.round((Date.now() - at) / 1000) : null;
      const fresh = ageSeconds != null && ageSeconds < 900;
      live = {
        status: first.status,
        vehicle: [first.vehicle?.label, first.vehicle?.plate].filter(Boolean).join(' · ') || null,
        driver: first.driver?.name || null,
        destination: dest && dest.lat != null ? { city: dest.city, lat: dest.lat, lng: dest.lng } : null,
        position: fresh ? { lat: pos[0].lat, lng: pos[0].lng } : null,
        ageSeconds: fresh ? ageSeconds : null,
        sharing: fresh
      };
    }

    const legs = legsRaw.map(({ trip, pax }) => ({
      date: trip.depart_date, time: String(trip.depart_time).slice(0, 5), status: trip.status,
      from: cityOf(trip.route?.from_terminal), to: cityOf(trip.route?.to_terminal),
      fromCode: codeOf(trip.route?.from_terminal), toCode: codeOf(trip.route?.to_terminal),
      seats: pax.map(p => p.seat_no).sort((a, c) => a - c)
    }));
    const quote = cancellationQuote({ status: b.status, legs, passengers: b.passengers, payments: b.payments, settings: t.settings });
    const creditKobo = (b.payments || []).filter(p => p.status === 'success' && p.channel === 'coupon').reduce((a, p) => a + p.amount_kobo, 0);
    const paidKobo = (b.payments || []).filter(p => p.status === 'success').reduce((a, p) => a + p.amount_kobo, 0);
    const pendingRefund = (b.refunds || []).find(r => r.status === 'pending');
    const maskEmail = e => { const [u, d] = String(e || '').split('@'); return d ? `${u.slice(0, 1)}${'•'.repeat(Math.max(2, Math.min(6, u.length - 1)))}@${d}` : null; };

    res.setHeader('Cache-Control', 'no-store');
    return res.status(200).json({
      reference: b.reference,
      status: b.status,
      total: b.total_kobo / 100,
      paidBy: paid?.channel || null,
      trip: legs[0] ? { date: legs[0].date, time: legs[0].time, from: legs[0].from, to: legs[0].to } : null,
      /* One entry per person, with their seat on the first leg; each leg lists its own seats. */
      passengers: (legsRaw[0]?.pax || b.passengers).map(p => ({ name: p.full_name, seat: p.seat_no, type: p.pax_type, status: p.status })),
      legs,
      paidTotal: paidKobo / 100, creditUsed: creditKobo / 100, balance: Math.max(0, b.total_kobo - paidKobo) / 100,
      email: maskEmail(b.contact_email),
      refund: pendingRefund ? { amount: pendingRefund.amount_kobo / 100, status: 'pending', since: pendingRefund.created_at } : null,
      cancellation: quote.allowed
        ? { allowed: true, band: quote.band, refund: quote.refundKobo / 100, cashPaid: quote.cashPaidKobo / 100, feePct: quote.feePct }
        : { allowed: false, reason: quote.reason },
      live
    });
  } catch (err) {
    console.error('lookup failed:', err.message);
    return fail(res, 500, 'server', 'Could not load the booking');
  }
}
