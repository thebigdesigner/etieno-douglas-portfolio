/**
 * POST /api/feedback — a message from the contact page.
 *
 * Saved to the database first, then emailed. That order is deliberate: DMARC for the sending
 * domain is still pending, so an email can fail silently. A complaint that vanished because a
 * mail server was fussy is worse than one sitting in a table waiting to be read.
 */
import { configured, insert, tenant, fail, limited, clientIp } from './_lib/db.js';

const TOPICS = ['booking', 'refund', 'lost property', 'hire a vehicle', 'complaint', 'something else'];

export default async function handler(req, res) {
  if (req.method !== 'POST') return fail(res, 405, 'method', 'POST only');
  if (!configured()) return fail(res, 503, 'not_configured', 'Cannot take messages right now');

  const b = req.body || {};

  /* A hidden field no person can see and no person fills in. Bots fill everything. */
  if (String(b.company || '').trim()) return res.status(200).json({ ok: true });

  const name = String(b.name || '').trim();
  const email = String(b.email || '').trim();
  const phone = String(b.phone || '').trim();
  const reference = String(b.reference || '').trim().toUpperCase();
  const topic = TOPICS.includes(b.topic) ? b.topic : 'something else';
  const message = String(b.message || '').trim();

  if (name.length < 2) return fail(res, 400, 'bad_name', 'Tell us your name');
  if (message.length < 10) return fail(res, 400, 'bad_message', 'Tell us a little more so we can help');
  if (message.length > 4000) return fail(res, 400, 'too_long', 'That is longer than we can take — please summarise');
  /* Every message lands in the office's inbox. Five an hour from one connection is plenty for a
     person and nothing to a spammer. */
  if (await limited(`feedback:ip:${clientIp(req)}`, 5, 3600))
    return fail(res, 429, 'too_many', 'We have your messages — please give us a little time to reply.');
  if (!email && !phone) return fail(res, 400, 'no_contact', 'Leave a phone number or an email so we can reply');
  if (email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return fail(res, 400, 'bad_email', 'Check the email address');

  let t;
  try { t = await tenant(); }
  catch (err) { console.error('tenant lookup failed:', err.message); return fail(res, 500, 'server', 'Could not send your message'); }

  try {
    await insert('feedback', [{
      tenant_id: t.id, name: name.slice(0, 120), email: email.slice(0, 160) || null,
      phone: phone.slice(0, 32) || null, reference: reference.slice(0, 24) || null,
      topic, message: message.slice(0, 4000)
    }], 'return=minimal');
  } catch (err) {
    console.error('feedback save failed:', err.message);
    return fail(res, 500, 'server', 'Could not send your message. Please call a terminal.');
  }

  /* Email is a convenience on top of the saved record, so a failure here is not the
     customer's problem — their message is already safe. */
  const key = process.env.RESEND_API_KEY, from = process.env.TICKET_FROM;
  const to = process.env.FEEDBACK_TO || 'hello@yourbrand.com';
  if (key && from) {
    try {
      await fetch('https://api.resend.com/emails', {
        method: 'POST',
        headers: { Authorization: `Bearer ${key}`, 'Content-Type': 'application/json' },
        body: JSON.stringify({
          from, to: [to], reply_to: email || undefined,
          subject: `${topic} — message from ${name}`,
          html: `<div style="font-family:system-ui,sans-serif;max-width:560px;color:#101828">
            <p style="font-size:13px;color:#667085;margin:0 0 14px">From the contact page</p>
            <p><b>${escapeHtml(name)}</b><br>
              ${email ? escapeHtml(email) + '<br>' : ''}${phone ? escapeHtml(phone) + '<br>' : ''}
              ${reference ? 'Booking ' + escapeHtml(reference) + '<br>' : ''}
              About: ${escapeHtml(topic)}</p>
            <p style="white-space:pre-wrap;border-left:3px solid #E6E8EE;padding-left:14px;color:#344054">${escapeHtml(message)}</p>
          </div>`
        })
      });
    } catch (err) { console.error('feedback email failed:', err.message); }
  }

  return res.status(200).json({ ok: true });
}

const escapeHtml = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
