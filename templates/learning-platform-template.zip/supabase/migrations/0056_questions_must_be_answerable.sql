-- =====================================================================
-- 0056 — a question has to be answerable, not just present
--
-- The publish gate counts questions: three quiz items, five exam items.
-- It never looks inside one. So a course can pass every check and go
-- live with questions nobody can answer, and the failure is invisible
-- until a learner sits the exam.
--
-- Found by seeding two courses and getting the shape wrong. The
-- renderer expects:
--
--   options  [{"id":"a","text":"..."}, {"id":"b","text":"..."}]
--   correct  ["a"]                     -- option ids, not the answer text
--
-- and the seed wrote plain strings with the answer text. Both courses
-- passed the gate, and every option would have rendered blank with an
-- undefined value, with no answer ever marked correct. The page casts
-- the column to the expected type without checking it, so nothing
-- anywhere would have said a word.
--
-- Three things are checked now, on publish, where they are cheap:
--
--   · every option is an object with a non-empty id and text
--   · option ids are unique within a question
--   · every id in `correct` exists among the options, and there is at
--     least one
--
-- The last is the one that matters most: a question whose answer is not
-- among its options is unpassable, and an exam is 80% to pass. One
-- broken question in five makes the certificate unreachable, and the
-- learner would have no idea why.
-- =====================================================================

create or replace function public.questions_are_answerable(p_course_id uuid)
returns table (ok boolean, reason text)
language plpgsql stable security definer set search_path = public as $$
declare
  v_bad int;
begin
  -- Options must be objects carrying an id and some text.
  select count(*) into v_bad
    from (
      select x.id, x.options from exam_items x where x.course_id = p_course_id
      union all
      select q.id, q.options from quiz_items q
        join topics t on t.id = q.topic_id
        join modules m on m.id = t.module_id
       where m.course_id = p_course_id
    ) items
   where jsonb_typeof(items.options) <> 'array'
      or jsonb_array_length(items.options) < 2
      or exists (
        select 1 from jsonb_array_elements(items.options) o
         where jsonb_typeof(o) <> 'object'
            or coalesce(o->>'id', '') = ''
            or coalesce(o->>'text', '') = ''
      );

  if v_bad > 0 then
    return query select false, 'malformed_options'; return;
  end if;

  -- Option ids unique inside a question, or `correct` is ambiguous.
  select count(*) into v_bad
    from (
      select x.id, x.options from exam_items x where x.course_id = p_course_id
      union all
      select q.id, q.options from quiz_items q
        join topics t on t.id = q.topic_id
        join modules m on m.id = t.module_id
       where m.course_id = p_course_id
    ) items
   where (select count(distinct o->>'id') from jsonb_array_elements(items.options) o)
       <> jsonb_array_length(items.options);

  if v_bad > 0 then
    return query select false, 'duplicate_option_ids'; return;
  end if;

  -- The answer has to be one of the options.
  select count(*) into v_bad
    from (
      select x.id, x.options, x.correct from exam_items x where x.course_id = p_course_id
      union all
      select q.id, q.options, q.correct from quiz_items q
        join topics t on t.id = q.topic_id
        join modules m on m.id = t.module_id
       where m.course_id = p_course_id
    ) items
   where jsonb_typeof(items.correct) <> 'array'
      or jsonb_array_length(items.correct) = 0
      or exists (
        select 1 from jsonb_array_elements_text(items.correct) k
         where not exists (
           select 1 from jsonb_array_elements(items.options) o where o->>'id' = k
         )
      );

  if v_bad > 0 then
    return query select false, 'answer_not_in_options'; return;
  end if;

  return query select true, null::text;
end; $$;

grant execute on function public.questions_are_answerable(uuid) to service_role;

-- ---------------------------------------------------------------------
-- Wired into the gate, immediately before it lets the course through.
--
-- The rest of this function is 0039's, unchanged and reproduced in full
-- rather than wrapped: create or replace needs the whole body, and a
-- wrapper around "the previous version" would leave two definitions of
-- the same rule to drift apart.
-- ---------------------------------------------------------------------
create or replace function public.submit_course_for_review(
  p_course_id uuid, p_instructor_id uuid
) returns table (ok boolean, reason text)
language plpgsql security definer set search_path = public as $BODY$
declare
  v_answerable record;
  v_course courses%rowtype;
  v_topics int; v_criteria int; v_quiz int; v_empty int; v_exam int;
begin
  select * into v_course from courses where id = p_course_id and instructor_id = p_instructor_id;
  if not found then
    return query select false, 'not_yours'; return;
  end if;

  if v_course.state not in ('draft','revision_requested') then
    return query select false, 'wrong_state'; return;
  end if;

  if v_course.thumbnail_path is null then
    return query select false, 'no_thumbnail'; return;
  end if;
  if v_course.hours_low is null or v_course.hours_high is null then
    return query select false, 'no_hours'; return;
  end if;

  if v_course.owner_kind = 'instructor'
     and not v_course.is_free
     and v_course.price_cents is null then
    return query select false, 'no_price'; return;
  end if;

  v_topics := live_topic_count(p_course_id);
  if v_topics < 3 then return query select false, 'too_few_topics'; return; end if;

  select count(*) into v_empty
    from topics t join modules m on m.id = t.module_id
   where m.course_id = p_course_id
     and m.archived_at is null and t.archived_at is null
     and coalesce(length(trim(t.body)), 0) < 40
     and not exists (select 1 from topic_materials tm where tm.topic_id = t.id);
  if v_empty > 0 then return query select false, 'empty_topics'; return; end if;

  select count(*) into v_quiz
    from quiz_items q join topics t on t.id = q.topic_id
    join modules m on m.id = t.module_id
   where m.course_id = p_course_id
     and m.archived_at is null and t.archived_at is null;
  if v_quiz < 3 then return query select false, 'too_few_questions'; return; end if;

  select count(*) into v_exam from exam_items where course_id = p_course_id;
  if v_exam < 5 then return query select false, 'too_few_exam_questions'; return; end if;

  if v_course.requires_project then
    if coalesce(length(trim(v_course.project_brief)), 0) < 120 then
      return query select false, 'brief_too_short'; return;
    end if;

    select count(*) into v_criteria from rubric_criteria where course_id = p_course_id;
    if v_criteria < 2 then return query select false, 'rubric_too_thin'; return; end if;
  end if;

  -- Every question has to be answerable, not merely present. See 0056:
  -- the counts above were satisfied by items whose options rendered blank
  -- and whose answer matched nothing, and nothing said so.
  select * into v_answerable from questions_are_answerable(p_course_id);
  if not v_answerable.ok then
    return query select false, v_answerable.reason; return;
  end if;

  update courses set state = 'in_review' where id = p_course_id;
  return query select true, null::text;
end; 
$BODY$;
