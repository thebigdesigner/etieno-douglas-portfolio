"use client";

import { useActionState, useState } from "react";
import { createShop } from "@/app/actions/marketplace";
import type { FormState } from "@/lib/forms";
import StudioSubmit from "./StudioSubmit";

function toHandle(s: string) {
  return s.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 40);
}

/** Opening a shop: the four things a buyer sees on the author page. */
export default function ShopForm({ suggestedName }: { suggestedName: string }) {
  const [state, action] = useActionState<FormState, FormData>(createShop, {});
  const [name, setName] = useState(suggestedName);
  const [handle, setHandle] = useState(toHandle(suggestedName));
  const [touched, setTouched] = useState(false);

  return (
    <form action={action} className="st-form">
      <label className="st-field">
        <span className="st-field__label">Shop name</span>
        <input name="display_name" required minLength={2} maxLength={60} value={name}
          onChange={(e) => { setName(e.target.value); if (!touched) setHandle(toHandle(e.target.value)); }} />
        <span className="st-field__hint">A studio name or your own. Shown on every item you sell.</span>
      </label>
      <label className="st-field">
        <span className="st-field__label">Shop address</span>
        <span className="st-prefix">
          <span className="st-prefix__fixed">marketplace.yourbrand.com/author/</span>
          <input name="handle" required pattern="[a-z0-9][a-z0-9\-]{2,39}" value={handle}
            onChange={(e) => { setTouched(true); setHandle(toHandle(e.target.value)); }} />
        </span>
        <span className="st-field__hint">Lowercase letters, numbers and hyphens. You cannot change it later.</span>
      </label>
      <label className="st-field">
        <span className="st-field__label">Location <span className="st-opt">optional</span></span>
        <input name="location" maxLength={80} placeholder="Lagos, Nigeria" />
      </label>
      <label className="st-field">
        <span className="st-field__label">About the shop <span className="st-opt">optional</span></span>
        <textarea name="bio" rows={3} maxLength={600} placeholder="What you make, and who it is for." />
      </label>
      {state.error && <p className="st-msg st-msg--err" role="alert">{state.error}</p>}
      <StudioSubmit>Open my shop</StudioSubmit>
    </form>
  );
}
