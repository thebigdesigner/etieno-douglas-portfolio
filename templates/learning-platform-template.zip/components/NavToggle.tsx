"use client";

import { useEffect, useState } from "react";
import NavIcon from "@/components/NavIcon";

/**
 * The hamburger, in the top bar where a phone user looks for it.
 *
 * The sheet itself lives in AppSidebar, which is off-screen on mobile — so a
 * toggle inside it could never open it. Rather than lifting nav state into a
 * provider for one boolean, this flips a class on the sidebar element and
 * listens for the events it dispatches back. Two components, one source of
 * truth, no context.
 */
export default function NavToggle() {
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const nv = document.querySelector(".nv");
    if (!nv) return;
    nv.classList.toggle("is-open", open);
    document.body.style.overflow = open ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [open]);

  useEffect(() => {
    const close = () => setOpen(false);
    const esc = (e: KeyboardEvent) => { if (e.key === "Escape") setOpen(false); };
    window.addEventListener("splari:nav-close", close);
    document.addEventListener("keydown", esc);
    return () => {
      window.removeEventListener("splari:nav-close", close);
      document.removeEventListener("keydown", esc);
    };
  }, []);

  return (
    <button
      type="button"
      className="topbar__burger"
      aria-expanded={open}
      aria-label={open ? "Close navigation" : "Open navigation"}
      onClick={() => setOpen((o) => !o)}
    >
      <NavIcon name={open ? "close" : "menu"} size={19} />
    </button>
  );
}
