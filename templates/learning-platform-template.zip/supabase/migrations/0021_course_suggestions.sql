-- =====================================================================
-- Course suggestions on the dashboard.
--
-- A dismissal is a real preference — "not this one" — so it is stored per
-- course rather than as a single "hide suggestions" flag. That way the
-- next suggestion is a different course instead of nothing at all.
-- =====================================================================

create table dismissed_suggestions (
  user_id      uuid not null references profiles(id) on delete cascade,
  course_id    uuid not null references courses(id) on delete cascade,
  dismissed_at timestamptz not null default now(),
  primary key (user_id, course_id)
);

alter table dismissed_suggestions enable row level security;

create policy "own dismissals"
  on dismissed_suggestions for all to authenticated
  using (user_id = auth.uid())
  with check (user_id = auth.uid());

-- One course to put in front of somebody who has not started anything.
--
-- Ranked by how well it fits rather than by what is newest: the segment
-- the learner picked at signup first, then a free course (so the first
-- click costs nothing), then how many people are actually taking it.
create or replace function suggested_course(p_user_id uuid)
returns table (
  id            uuid,
  slug          text,
  title         text,
  summary       text,
  subject       text,
  thumbnail_path text,
  thumbnail_alt  text,
  hours_low     int,
  hours_high    int,
  learners      bigint
)
language sql
stable
security definer
set search_path = public
as $$
  with me as (
    select segment from profiles where id = p_user_id
  )
  select
    c.id, c.slug, c.title, c.summary, c.subject,
    c.thumbnail_path, c.thumbnail_alt,
    c.hours_low, c.hours_high,
    count(e.id) as learners
  from courses c
  left join enrolments e on e.course_id = c.id
  where c.state = 'published'
    and not exists (
      select 1 from enrolments x where x.course_id = c.id and x.user_id = p_user_id
    )
    and not exists (
      select 1 from dismissed_suggestions d
      where d.course_id = c.id and d.user_id = p_user_id
    )
  group by c.id
  order by
    (c.segment = (select segment from me)) desc nulls last,
    c.is_free desc,
    count(e.id) desc,
    c.published_at desc nulls last
  limit 1;
$$;

revoke all on function suggested_course(uuid) from public, anon;
grant execute on function suggested_course(uuid) to authenticated, service_role;
