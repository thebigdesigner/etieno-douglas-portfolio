"use client";

import { useEffect, useRef, useState } from "react";
import { savePosition } from "@/app/actions/student";

/**
 * Wraps the provider iframe and keeps a resume position.
 *
 * Third-party players do not expose currentTime across origins, so this
 * counts elapsed wall-clock time while the tab is visible and the learner has
 * not navigated away. It is approximate, and approximate is enough to put
 * somebody back near where they stopped.
 */
export default function Player({
  src, title, topicId, startAt = 0, kind = "iframe",
}: {
  src: string; title: string; topicId: string; startAt?: number;
  kind?: "iframe" | "file";
}) {
  const [resumed, setResumed] = useState(startAt < 20);
  const elapsed = useRef(startAt);
  const saved = useRef(startAt);
  const videoEl = useRef<HTMLVideoElement>(null);

  // A self-hosted file is a same-origin media element, so its real
  // currentTime is readable — no wall-clock guessing, and pausing
  // genuinely pauses progress.
  useEffect(() => {
    if (kind !== "file") return;
    const el = videoEl.current;
    if (!el) return;

    const onTime = () => {
      elapsed.current = Math.floor(el.currentTime);
      if (elapsed.current - saved.current >= 25) {
        saved.current = elapsed.current;
        savePosition(topicId, elapsed.current, Math.floor(el.duration || 0));
      }
    };
    const onLeave = () => {
      if (elapsed.current > saved.current) {
        savePosition(topicId, elapsed.current, Math.floor(el.duration || 0));
      }
    };
    el.addEventListener("timeupdate", onTime);
    window.addEventListener("pagehide", onLeave);
    return () => {
      el.removeEventListener("timeupdate", onTime);
      window.removeEventListener("pagehide", onLeave);
      onLeave();
    };
  }, [kind, topicId]);

  useEffect(() => {
    if (kind === "file") return;
    const tick = setInterval(() => {
      if (document.visibilityState !== "visible") return;
      elapsed.current += 5;
    }, 5000);

    // Persist every half minute rather than every tick.
    const flush = setInterval(() => {
      if (elapsed.current - saved.current < 25) return;
      saved.current = elapsed.current;
      savePosition(topicId, elapsed.current, 0);
    }, 30000);

    const onLeave = () => {
      if (elapsed.current > saved.current) {
        savePosition(topicId, elapsed.current, 0);
      }
    };
    window.addEventListener("pagehide", onLeave);

    return () => {
      clearInterval(tick);
      clearInterval(flush);
      window.removeEventListener("pagehide", onLeave);
      onLeave();
    };
  }, [kind, topicId]);

  const mins = Math.floor(startAt / 60);
  const secs = startAt % 60;

  return (
    <div className="player">
      {!resumed && (
        <div className="player__resume">
          <span>
            You were about {mins}:{String(secs).padStart(2, "0")} in last time.
          </span>
          <button onClick={() => setResumed(true)}>Start from the beginning</button>
        </div>
      )}

      <div className="learn__video">
        {kind === "file" ? (
          <video
            ref={videoEl}
            src={src}
            controls
            playsInline
            preload="metadata"
            controlsList="nodownload"
            onLoadedMetadata={(e) => {
              if (!resumed && startAt > 0) e.currentTarget.currentTime = startAt;
            }}
            title={title}
          />
        ) : (
          <iframe
            src={resumed ? src : `${src}${src.includes("?") ? "&" : "?"}t=${startAt}`}
            loading="lazy"
            allow="accelerometer; gyroscope; autoplay; encrypted-media; picture-in-picture; fullscreen"
            allowFullScreen
            title={title}
          />
        )}
      </div>
    </div>
  );
}
