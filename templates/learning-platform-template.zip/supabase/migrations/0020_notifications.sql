-- =====================================================================
-- In-app notifications.
--
-- No events table. Everything a learner needs to be told about already
-- exists with a timestamp — a verdict was returned, a certificate was
-- issued, a project is with a reviewer. A separate notifications table
-- would be a second copy of that truth, and the two would drift.
--
-- So this is a read-side function over what is already there, plus one
-- column recording when the person last opened the panel.
-- =====================================================================

alter table profiles add column notifications_seen_at timestamptz;

comment on column profiles.notifications_seen_at is
  'When the notification panel was last opened. Anything newer is unread.';

create or replace function learner_notifications(p_user_id uuid)
returns table (
  kind  text,
  title text,
  body  text,
  at    timestamptz,
  href  text
)
language sql
stable
security definer
set search_path = public
as $$
  -- A practitioner returned a verdict.
  select
    'review'::text,
    c.title,
    case when r.outcome = 'pass'
         then 'Passed — your certificate is ready'
         else 'Changes asked for, with written feedback' end,
    r.completed_at,
    '/dashboard/submissions'
  from reviews r
  join submissions s on s.id = r.submission_id
  join enrolments e  on e.id = s.enrolment_id
  join courses c     on c.id = e.course_id
  where e.user_id = p_user_id

  union all

  -- A certificate was issued.
  select
    'certificate'::text,
    c.title,
    'Certificate issued · ' || cert.code,
    cert.issued_at,
    '/dashboard/certificates'
  from certificates cert
  join enrolments e on e.id = cert.enrolment_id
  join courses c    on c.id = e.course_id
  where e.user_id = p_user_id
    and cert.revoked_at is null

  union all

  -- Still with a reviewer, so the wait is visible rather than silent.
  select
    'pending'::text,
    c.title,
    'With a practitioner · four working days',
    s.submitted_at,
    '/dashboard/submissions'
  from submissions s
  join enrolments e on e.id = s.enrolment_id
  join courses c    on c.id = e.course_id
  where e.user_id = p_user_id
    and s.state in ('submitted', 'assigned', 'in_review')

  order by 4 desc
  limit 10;
$$;

revoke all on function learner_notifications(uuid) from public, anon;
grant execute on function learner_notifications(uuid) to authenticated, service_role;
