"use client";
import { resetPin } from "@/app/actions/institution";

type Row = {
  seat_id: string; username: string; user_id: string | null;
  display_name: string | null; claimed_at: string | null;
  topics_done: number; last_active: string | null;
  projects_passed: number; projects_pending: number;
};

export default function SeatTable({ cohortId, rows }: { cohortId: string; rows: Row[] }) {
  function exportCsv() {
    const header = ["username", "name", "joined", "topics_done", "last_active", "passed", "pending"];
    const body = rows.map((r) => [
      r.username,
      r.display_name ?? "",
      r.claimed_at ? new Date(r.claimed_at).toISOString().slice(0, 10) : "",
      String(r.topics_done ?? 0),
      r.last_active ? new Date(r.last_active).toISOString().slice(0, 10) : "",
      String(r.projects_passed ?? 0),
      String(r.projects_pending ?? 0),
    ]);
    const csv = [header, ...body].map((cells) =>
      cells.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(",")
    ).join("\n");

    const url = URL.createObjectURL(new Blob([csv], { type: "text/csv" }));
    const a = document.createElement("a");
    a.href = url;
    a.download = `cohort-${cohortId}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  if (rows.length === 0) {
    return <p className="studio__hint" style={{ marginTop: 16 }}>No usernames issued yet.</p>;
  }

  return (
    <>
      <p style={{ marginTop: 16 }}>
        <button className="btn btn--line" onClick={exportCsv}>Export CSV</button>
      </p>

      <table className="tbl" style={{ marginTop: 18 }}>
        <thead>
          <tr><th>Username</th><th>Name</th><th>Topics</th><th>Last active</th><th></th></tr>
        </thead>
        <tbody>
          {rows.map((r) => (
            <tr key={r.seat_id}>
              <td className="num">{r.username}</td>
              <td>{r.display_name ?? <span style={{ color: "var(--ink-45)" }}>not joined</span>}</td>
              <td className="num">{r.topics_done ?? 0}</td>
              <td>{r.last_active ? new Date(r.last_active).toLocaleDateString() : "—"}</td>
              <td>
                {r.user_id && (
                  <form action={resetPin.bind(null, r.seat_id, cohortId)}>
                    <button className="studio__add">Reset PIN</button>
                  </form>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </>
  );
}
