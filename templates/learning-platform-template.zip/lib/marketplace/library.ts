// Server only: uses the service-role client.
import { createAdminClient } from "@/lib/supabase/admin";
import type { Product } from "@/lib/marketplace/types";
import { fromRow, PRODUCT_COLS, type ProductRow } from "@/lib/marketplace/catalog";

/**
 * What a buyer owns: items they paid for, and free items they claimed.
 * Both stay theirs — a creator raising a price or taking an item off sale
 * does not take it back from anyone who already has it.
 */
export type Owned = {
  product: Product;
  licence: "personal" | "commercial" | "free";
  boughtAt: string | null;
  hasFile: boolean;
};

// The catalogue's own columns, plus whether a file has been uploaded.
const COLS = `${PRODUCT_COLS}, mk_product_files(path)`;

export async function library(userId: string): Promise<Owned[]> {
  const admin = createAdminClient();

  const [{ data: orders }, { data: claims }] = await Promise.all([
    admin.from("mk_orders").select(`licence, paid_at, mk_products(${COLS})`)
      .eq("user_id", userId).eq("status", "paid").order("paid_at", { ascending: false }),
    admin.from("mk_downloads").select(`at, mk_products(${COLS})`)
      .eq("user_id", userId).is("order_id", null).order("at", { ascending: false }),
  ]);

  const out = new Map<string, Owned>();

  const add = (raw: unknown, licence: Owned["licence"], at: string | null) => {
    const row = (Array.isArray(raw) ? raw[0] : raw) as Record<string, unknown> | null;
    if (!row) return;
    const product = fromRow(row as unknown as ProductRow);
    const files = row.mk_product_files as { path?: string } | { path?: string }[] | null;
    const hasFile = Boolean(Array.isArray(files) ? files[0]?.path : files?.path);
    const existing = out.get(product.id);
    // A paid licence outranks a free claim of the same item.
    if (existing && existing.licence !== "free") return;
    out.set(product.id, { product, licence, boughtAt: at, hasFile });
  };

  for (const o of orders ?? []) add(o.mk_products, (o.licence as Owned["licence"]) ?? "personal", o.paid_at);
  for (const c of claims ?? []) add(c.mk_products, "free", c.at);

  return [...out.values()];
}
