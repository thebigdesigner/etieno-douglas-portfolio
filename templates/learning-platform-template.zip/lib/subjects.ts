/** The six subjects. The only axis a learner filters on. */
export const SUBJECTS = [
  "Artificial Intelligence",
  "Entrepreneurship",
  "Technology",
  "Business Skills",
  "Creative",
  "Career",
] as const;

export const LEVELS = ["beginner", "intermediate", "advanced"] as const;

export const LEVEL_LABEL: Record<string, string> = {
  beginner: "Beginner",
  intermediate: "Intermediate",
  advanced: "Advanced",
};

/** "6-10 hours" rather than "8 hours" — a single number reads as a promise. */
export function hoursLabel(low: number | null, high: number | null): string | null {
  if (!low && !high) return null;
  if (low && high && low !== high) return `${low}-${high} hours`;
  return `${high ?? low} hours`;
}

export function subjectBlurb(subject: string): string {
  const map: Record<string, string> = {
    "Artificial Intelligence": "Build with it, or work alongside it",
    "Entrepreneurship": "Starting, running and growing something",
    "Technology": "The tools the work actually runs on",
    "Business Skills": "Finance, operations, and reading a room",
    "Creative": "Writing, design, and making things people want",
    "Career": "Getting hired, getting promoted, getting paid",
  };
  return map[subject] ?? "";
}
