import { createHmac, timingSafeEqual } from "crypto";

/**
 * Stripe Checkout, for buyers Paystack cannot serve.
 *
 * Paystack settles African currencies and takes African cards well;
 * Stripe covers the rest of the world. Which one a checkout uses is
 * decided in lib/payments.ts by currency, not here.
 *
 * Called over plain fetch rather than the SDK: two endpoints and a
 * signature check do not justify a dependency, and the form encoding
 * Stripe expects is handled by toForm() below.
 *
 * Not configured until STRIPE_SECRET_KEY is set. isConfigured() lets the
 * rest of the app hide non-African currencies until then, instead of
 * offering a checkout that would fail.
 */

const API = "https://api.stripe.com/v1";

export function isConfigured(): boolean {
  return Boolean(process.env.STRIPE_SECRET_KEY);
}

function secret(): string {
  const k = process.env.STRIPE_SECRET_KEY;
  if (!k) throw new Error("STRIPE_SECRET_KEY is not set");
  return k;
}

/** Stripe takes form-encoded bodies, with nested keys as a[b][c]. */
function toForm(obj: Record<string, unknown>, prefix = "", out = new URLSearchParams()): URLSearchParams {
  for (const [k, v] of Object.entries(obj)) {
    if (v === undefined || v === null) continue;
    const key = prefix ? `${prefix}[${k}]` : k;
    if (typeof v === "object" && !Array.isArray(v)) toForm(v as Record<string, unknown>, key, out);
    else if (Array.isArray(v)) v.forEach((item, i) => toForm({ [i]: item }, key, out));
    else out.append(key, String(v));
  }
  return out;
}

async function call(path: string, body?: Record<string, unknown>) {
  const res = await fetch(`${API}${path}`, {
    method: body ? "POST" : "GET",
    headers: {
      Authorization: `Bearer ${secret()}`,
      ...(body ? { "Content-Type": "application/x-www-form-urlencoded" } : {}),
    },
    body: body ? toForm(body).toString() : undefined,
    cache: "no-store",
  });
  const data = await res.json().catch(() => null);
  if (!res.ok) {
    console.error("stripe error", path, res.status, data?.error?.message ?? data);
    return null;
  }
  return data;
}

export type StripeCheckout = { url: string; sessionId: string };

/**
 * Amounts are in the currency's smallest unit, like Paystack — except for
 * zero-decimal currencies (JPY and friends), which Stripe wants whole.
 * Your Brand charges none of those today; the guard is here so adding one
 * later fails loudly rather than by a factor of a hundred.
 */
const ZERO_DECIMAL = new Set(["BIF", "CLP", "DJF", "GNF", "JPY", "KMF", "KRW", "MGA", "PYG", "RWF", "UGX", "VND", "VUV", "XAF", "XOF", "XPF"]);

export async function createCheckout(a: {
  txRef: string; amount: number; currency: string; email: string;
  description: string; redirectUrl: string; cancelUrl?: string; meta?: Record<string, string>;
}): Promise<StripeCheckout> {
  const ccy = a.currency.toLowerCase();
  const unit = ZERO_DECIMAL.has(a.currency.toUpperCase()) ? Math.round(a.amount) : Math.round(a.amount * 100);

  const data = await call("/checkout/sessions", {
    mode: "payment",
    client_reference_id: a.txRef,
    customer_email: a.email,
    // Stripe puts the session id in the URL so the return page can verify
    // even if the webhook is late.
    success_url: `${a.redirectUrl}${a.redirectUrl.includes("?") ? "&" : "?"}reference=${encodeURIComponent(a.txRef)}&session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: a.cancelUrl ?? `${a.redirectUrl}${a.redirectUrl.includes("?") ? "&" : "?"}status=cancelled`,
    line_items: [{ quantity: 1, price_data: { currency: ccy, unit_amount: unit, product_data: { name: a.description } } }],
    payment_intent_data: { metadata: { tx_ref: a.txRef, ...a.meta } },
    metadata: { tx_ref: a.txRef, ...a.meta },
  });

  if (!data?.url || !data?.id) throw new Error("Could not start checkout");
  return { url: data.url as string, sessionId: data.id as string };
}

export type Verified = {
  ok: boolean; txRef: string; amount: number; currency: string;
  providerRef: string; email: string | null;
};

/** Confirms with Stripe itself. Takes the session id stored on the intent. */
export async function verifyBySession(sessionId: string): Promise<Verified | null> {
  const s = await call(`/checkout/sessions/${encodeURIComponent(sessionId)}`);
  if (!s) return null;
  const ccy = String(s.currency ?? "").toUpperCase();
  const paid = Number(s.amount_total ?? 0);
  return {
    ok: s.payment_status === "paid",
    txRef: String(s.client_reference_id ?? s.metadata?.tx_ref ?? ""),
    amount: ZERO_DECIMAL.has(ccy) ? paid : paid / 100,
    currency: ccy,
    providerRef: String(s.payment_intent ?? s.id),
    email: s.customer_details?.email ?? s.customer_email ?? null,
  };
}

/**
 * Stripe signs webhooks as "t=<timestamp>,v1=<hmac>" over
 * "<timestamp>.<raw body>". The timestamp is checked too, so a captured
 * request cannot be replayed days later.
 */
export function verifyWebhook(rawBody: string, header: string | null, toleranceSeconds = 300): boolean {
  const key = process.env.STRIPE_WEBHOOK_SECRET;
  if (!key || !header) return false;

  const parts = Object.fromEntries(header.split(",").map((p) => p.split("=", 2) as [string, string]));
  const t = Number(parts.t);
  if (!t || Math.abs(Date.now() / 1000 - t) > toleranceSeconds) return false;

  const expected = createHmac("sha256", key).update(`${t}.${rawBody}`).digest("hex");
  const a = Buffer.from(String(parts.v1 ?? ""), "utf8");
  const b = Buffer.from(expected, "utf8");
  return a.length === b.length && timingSafeEqual(a, b);
}
