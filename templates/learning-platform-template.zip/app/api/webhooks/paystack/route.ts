import { NextResponse } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { verifyWebhook } from "@/lib/paystack";
import { fulfilPayment } from "@/lib/fulfil";

export const dynamic = "force-dynamic";

/**
 * Paystack webhook.
 *
 * Three defences, in order, because this endpoint grants paid access to
 * anyone who can convince it:
 *
 *   1. x-paystack-signature must be the HMAC-SHA512 of the exact body,
 *      keyed with our secret key. Unlike a shared password, this proves the
 *      body itself was not altered.
 *   2. fulfilPayment re-verifies the transaction with Paystack's API.
 *   3. It also checks the amount and currency against the checkout intent
 *      recorded before the buyer left, so a cheap real payment cannot be
 *      replayed against an expensive order.
 *
 * Paystack retries until it gets a 200, so duplicates are certain; the
 * unique key on payment_events and the idempotent fulfilment make them
 * harmless.
 */
export async function POST(request: Request) {
  if (!process.env.PAYSTACK_SECRET_KEY) {
    console.error("PAYSTACK_SECRET_KEY unset — refusing webhook");
    return NextResponse.json({ error: "not configured" }, { status: 503 });
  }

  // The signature covers the raw bytes, so read text first and parse after.
  const raw = await request.text();
  if (!verifyWebhook(raw, request.headers.get("x-paystack-signature"))) {
    return NextResponse.json({ error: "bad signature" }, { status: 401 });
  }

  let body: { event?: string; data?: Record<string, unknown> };
  try { body = JSON.parse(raw); } catch { return NextResponse.json({ error: "bad body" }, { status: 400 }); }

  const event = String(body.event ?? "");
  const data = body.data ?? {};
  const txRef = data.reference ? String(data.reference) : null;
  const providerRef = data.id ? String(data.id) : txRef;
  if (!providerRef) return NextResponse.json({ ok: true });

  const admin = createAdminClient();

  // Record first. The unique constraint is what makes a retry harmless.
  const { error: logErr } = await admin.from("payment_events").insert({
    provider: "paystack",
    event_type: event,
    provider_ref: providerRef,
    tx_ref: txRef,
    payload: body as unknown as Record<string, unknown>,
  });
  if (logErr && logErr.code === "23505") return NextResponse.json({ ok: true, duplicate: true });

  if (event !== "charge.success" || !txRef) return NextResponse.json({ ok: true });

  const result = await fulfilPayment(txRef);
  if (!result.ok) {
    console.error("paystack webhook fulfil declined", txRef, result.reason);
    return NextResponse.json({ ok: true, ignored: result.reason });
  }

  await admin.from("payment_events")
    .update({ handled_at: new Date().toISOString() })
    .eq("provider", "paystack").eq("provider_ref", providerRef).eq("event_type", event);

  return NextResponse.json({ ok: true });
}
