-- =====================================================================
-- 0065 — the marketplace (marketplace.yourbrand.com)
--
-- Digital products sold by creators: templates, fonts, audio, video
-- templates, 3D, guides and code. Kept in its own mk_* tables rather than
-- stretched across courses: a course is worked through and assessed, an
-- item is a file you buy a licence to use. They share people (profiles)
-- and a currency, not a lifecycle.
--
-- What this migration covers: the catalogue the storefront reads, the
-- orders a checkout will write, and saved items. What it does not: the
-- checkout itself and file delivery. Those need their own kind in
-- checkout_intents and a fulfilment path in lib/fulfil.ts, and they are
-- the next piece of work — mk_orders is shaped for them now so that step
-- adds code, not a second migration to rename things.
--
-- Money follows 0063: one currency, USD, refused otherwise.
-- =====================================================================

-- ------------------------------------------------------------ creators
-- A seller's public face. One per person. The handle is the URL
-- (/author/<handle>), so it is lower-case, short and permanent-ish.
create table if not exists mk_creators (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null unique references profiles(id) on delete cascade,
  handle        text not null unique check (handle ~ '^[a-z0-9][a-z0-9-]{2,39}$'),
  display_name  text not null check (length(display_name) between 2 and 60),
  person_name   text,
  location      text,
  bio           text check (bio is null or length(bio) <= 600),
  hue           smallint not null default 0 check (hue between 0 and 5),
  socials       jsonb not null default '[]'::jsonb,
  followers     integer not null default 0 check (followers >= 0),
  created_at    timestamptz not null default now()
);

-- ------------------------------------------------------------ products
do $$ begin
  create type mk_product_state as enum ('draft', 'in_review', 'published', 'retired');
exception when duplicate_object then null; end $$;

-- array_to_string is only STABLE in general (it calls element output
-- functions), which a generated column refuses. For text[] the output is
-- the text itself, so this wrapper is honestly immutable.
create or replace function mk_join_tags(t text[]) returns text
language sql immutable parallel safe as $$ select coalesce(array_to_string(t, ' '), '') $$;

create table if not exists mk_products (
  id                      uuid primary key default gen_random_uuid(),
  creator_id              uuid not null references mk_creators(id) on delete restrict,
  slug                    text not null unique check (slug ~ '^[a-z0-9][a-z0-9-]{2,79}$'),
  title                   text not null check (length(title) between 3 and 90),
  -- Mirrors lib/marketplace/categories.ts. A category the code does not
  -- know has no icon, no preview and no rail entry, so it is refused here.
  category                text not null check (category in (
                            'ui-kits','web-templates','presentations','graphics','icons','fonts',
                            'music','sound-effects','video-templates','3d','ebooks','code')),
  subcategory             text not null,
  summary                 text not null check (length(summary) between 20 and 600),
  includes                text[] not null default '{}',
  tags                    text[] not null default '{}',
  formats                 text[] not null default '{}',
  -- Personal licence. 0 is free.
  price_cents             integer not null check (price_cents >= 0),
  -- Commercial licence. A free item is free for every use, so it has none;
  -- a paid one can never make the wider licence the cheaper of the two.
  commercial_price_cents  integer,
  currency                text not null default 'USD' check (currency = 'USD'),
  rating                  numeric(2,1) check (rating between 0 and 5),
  ratings_count           integer not null default 0 check (ratings_count >= 0),
  downloads               integer not null default 0 check (downloads >= 0),
  duration                text,
  file_size               text,
  cover_url               text,
  trending                boolean not null default false,
  featured                boolean not null default false,
  state                   mk_product_state not null default 'draft',
  published_at            timestamptz,
  created_at              timestamptz not null default now(),
  updated_at              timestamptz not null default now(),
  search                  tsvector generated always as (
                            setweight(to_tsvector('english', title), 'A') ||
                            setweight(to_tsvector('english', mk_join_tags(tags)), 'B') ||
                            setweight(to_tsvector('english', summary), 'C')
                          ) stored,
  constraint mk_commercial_price check (
    (price_cents = 0 and commercial_price_cents is null) or
    (price_cents > 0 and (commercial_price_cents is null or commercial_price_cents >= price_cents))
  ),
  constraint mk_published_has_date check (state <> 'published' or published_at is not null)
);

create index if not exists mk_products_search_idx on mk_products using gin (search);
create index if not exists mk_products_browse_idx on mk_products (state, category, downloads desc);
create index if not exists mk_products_newest_idx on mk_products (state, published_at desc);
create index if not exists mk_products_creator_idx on mk_products (creator_id);

-- The deliverable lives apart from the listing. RLS is on with no policy
-- at all, so only the service role — fulfilment, after a paid order —
-- can read a path. A column on mk_products would be one careless
-- select('*') away from publishing every paid file.
create table if not exists mk_product_files (
  product_id  uuid primary key references mk_products(id) on delete cascade,
  path        text not null,
  bytes       bigint check (bytes is null or bytes >= 0),
  updated_at  timestamptz not null default now()
);

create or replace function mk_touch_updated_at() returns trigger
language plpgsql as $$ begin new.updated_at := now(); return new; end $$;

drop trigger if exists mk_products_touch on mk_products;
create trigger mk_products_touch before update on mk_products
  for each row execute function mk_touch_updated_at();

-- The rail's per-category counts, in one query. security_invoker so the
-- view sees exactly what the caller's RLS lets them see: published only.
create or replace view mk_category_counts with (security_invoker = true) as
  select category, count(*)::int as items
  from mk_products where state = 'published'
  group by category;

-- -------------------------------------------------------------- orders
-- One row per licence bought. Written by checkout with the service role
-- before the redirect to Flutterwave, settled by the webhook — the same
-- intent-first pattern as checkout_intents, so a payment can always be
-- matched to what it was for. The price is copied in at order time;
-- fulfilment settles against it, not against a price the creator may
-- have changed while the buyer was on the card form.
create table if not exists mk_orders (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null references profiles(id) on delete cascade,
  product_id    uuid not null references mk_products(id) on delete restrict,
  licence       text not null check (licence in ('personal', 'commercial')),
  amount_cents  integer not null check (amount_cents >= 0),
  currency      text not null default 'USD' check (currency = 'USD'),
  tx_ref        text unique,
  status        text not null default 'pending' check (status in ('pending', 'paid', 'refunded', 'failed')),
  created_at    timestamptz not null default now(),
  paid_at       timestamptz,
  refunded_at   timestamptz
);
create index if not exists mk_orders_user_idx on mk_orders (user_id, created_at desc);
-- A buyer holds one live licence of each kind per item. Buying twice is a
-- support ticket, not a sale.
create unique index if not exists mk_orders_one_licence
  on mk_orders (user_id, product_id, licence) where status = 'paid';

create table if not exists mk_downloads (
  id          bigint generated always as identity primary key,
  order_id    uuid references mk_orders(id) on delete cascade,
  product_id  uuid not null references mk_products(id) on delete cascade,
  user_id     uuid not null references profiles(id) on delete cascade,
  at          timestamptz not null default now()
);
create index if not exists mk_downloads_product_idx on mk_downloads (product_id, at desc);

-- --------------------------------------------------------------- saves
create table if not exists mk_saves (
  user_id     uuid not null references profiles(id) on delete cascade,
  product_id  uuid not null references mk_products(id) on delete cascade,
  created_at  timestamptz not null default now(),
  primary key (user_id, product_id)
);

-- ----------------------------------------------------------------- RLS
alter table mk_creators  enable row level security;
alter table mk_products  enable row level security;
alter table mk_orders    enable row level security;
alter table mk_downloads enable row level security;
alter table mk_saves     enable row level security;

-- Creator pages are public. Editing goes through the studio with the
-- service role, so there is no write policy for anyone.
drop policy if exists mk_creators_read on mk_creators;
create policy mk_creators_read on mk_creators for select using (true);

-- The shop sees published items. A creator also sees their own drafts.
drop policy if exists mk_products_read on mk_products;
create policy mk_products_read on mk_products for select using (
  state = 'published'
  or creator_id in (select id from mk_creators where user_id = auth.uid())
);

-- No policy on purpose: see the table's comment.
alter table mk_product_files enable row level security;

drop policy if exists mk_orders_own on mk_orders;
create policy mk_orders_own on mk_orders for select using (user_id = auth.uid());

drop policy if exists mk_downloads_own on mk_downloads;
create policy mk_downloads_own on mk_downloads for select using (user_id = auth.uid());

drop policy if exists mk_saves_own on mk_saves;
create policy mk_saves_own on mk_saves for all
  using (user_id = auth.uid()) with check (user_id = auth.uid());
