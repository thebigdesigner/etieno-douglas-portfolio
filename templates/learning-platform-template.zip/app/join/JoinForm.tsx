"use client";
import { useActionState } from "react";
import { joinCohort } from "@/app/actions/auth";
import type { FormState } from "@/lib/forms";
import SubmitButton from "@/components/SubmitButton";
import Alert from "@/components/Alert";

const initial: FormState = {};

export default function JoinForm() {
  const [state, action] = useActionState(joinCohort, initial);

  return (
    <form action={action} className="auth__form">
      <label className="field">
        <span className="field__label">Class code</span>
        <input name="class_code" autoCapitalize="characters" placeholder="SPL-7K42" required />
      </label>
      <label className="field">
        <span className="field__label">Username</span>
        <input name="username" autoCapitalize="none" autoCorrect="off" required />
      </label>
      <label className="field">
        <span className="field__label">PIN</span>
        <input name="pin" inputMode="numeric" maxLength={6} placeholder="6 digits" required />
        <span className="field__hint">
          First time here? Pick a 6-digit PIN and remember it — that is how you log in.
        </span>
      </label>

      {state.error && <Alert kind="error">{state.error}</Alert>}

      <SubmitButton>Start learning</SubmitButton>
    </form>
  );
}
