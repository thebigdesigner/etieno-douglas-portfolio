import { createAdminClient } from "@/lib/supabase/admin";
import { requireProfile } from "@/lib/guard";
import { operationsNav } from "@/lib/app-nav";
import AppShell from "@/components/AppShell";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const { user, profile } = await requireProfile(["operator"], { next: "/admin" });

  const admin = createAdminClient();
  const [{ data: queue }, { count: verifications }, { count: applications }, { count: courses }, { count: appeals }] =
    await Promise.all([
      admin.from("review_queue_status").select("breached"),
      admin.from("institutions").select("id", { count: "exact", head: true }).eq("verification", "pending"),
      admin.from("instructors").select("id", { count: "exact", head: true }).eq("state", "applied"),
      admin.from("courses").select("id", { count: "exact", head: true }).eq("state", "in_review"),
      admin.from("appeals").select("id", { count: "exact", head: true }).is("resolved_at", null),
    ]);


  /* The bell was mounted on the learner dashboard and nowhere else, so
     everything waiting on a person here was invisible unless somebody
     opened the right page — including the two promises with clocks on
     them, the four-day assessment and the thirty-day erasure. */
  const { data: notifications } = await createAdminClient()
    .rpc("operator_notifications", { p_user_id: user.id });
  const seenAt = profile?.notifications_seen_at
    ? new Date(profile.notifications_seen_at).getTime() : 0;
  const unread = (notifications ?? [])
    .filter((n: { at: string }) => new Date(n.at).getTime() > seenAt).length;

  return (
    <AppShell
      notifications={notifications ?? []}
      unread={unread}
      brand="Admin"
      name={profile.display_name}
      profile={{ name: profile.display_name ?? "Operator", id: user.id, avatarPath: profile.avatar_path }}
      email={profile.email}
      homeHref="/admin/sla"
      groups={operationsNav({
        breached: (queue ?? []).filter((q) => q.breached).length,
        verifications: verifications ?? 0,
        courses: courses ?? 0,
        applications: applications ?? 0,
        appeals: appeals ?? 0,
      })}
    >
      {children}
    </AppShell>
  );
}
