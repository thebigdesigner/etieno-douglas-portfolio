-- =====================================================================
-- 0032 — a published course cannot lose its parts
--
-- Modules, topics, quiz questions, exam questions and rubric criteria can
-- be removed while a course is a draft. Once it is in review or live, the
-- structure is fixed: somebody has bought it, or is part-way through it,
-- and everything hanging off a topic cascades — quiz_items,
-- topic_materials, topic_notes, and, worse, topic_completions,
-- topic_progress and quiz_attempts.
--
-- Deleting a topic on a live course would therefore erase a learner's
-- completions and their notes, move their progress percentage, and —
-- because the royalty pool divides by completed topics — quietly rewrite
-- what every instructor earned that month.
--
-- The application already refuses this. This is the same rule one level
-- down, because a guard that only the button enforces is a guard that a
-- future code path forgets.
-- =====================================================================

create or replace function public.refuse_locked_course_delete()
returns trigger
language plpgsql
as $$
declare
  v_state course_state;
  v_course uuid;
begin
  -- Each table reaches the course differently; resolve it, then apply the
  -- one rule.
  if tg_table_name = 'modules' then
    v_course := old.course_id;
  elsif tg_table_name = 'topics' then
    select m.course_id into v_course from modules m where m.id = old.module_id;
  elsif tg_table_name = 'quiz_items' then
    select m.course_id into v_course
      from topics t join modules m on m.id = t.module_id where t.id = old.topic_id;
  elsif tg_table_name in ('exam_items','rubric_criteria') then
    v_course := old.course_id;
  else
    return old;
  end if;

  -- The course itself going means everything under it goes with it; that is
  -- a course delete, not a structure edit, and it has its own rule.
  if v_course is null then return old; end if;
  select state into v_state from courses where id = v_course;
  if v_state is null then return old; end if;

  if v_state not in ('draft','revision_requested') then
    raise exception 'course_locked'
      using hint = 'This course is in review or published. Its structure cannot change.';
  end if;

  return old;
end;
$$;

do $$
declare t text;
begin
  foreach t in array array['modules','topics','quiz_items','exam_items','rubric_criteria'] loop
    execute format('drop trigger if exists refuse_locked_delete on %I', t);
    execute format(
      'create trigger refuse_locked_delete before delete on %I
         for each row execute function refuse_locked_course_delete()', t);
  end loop;
end $$;
