"use client";
import Link from "next/link";
import { useActionState } from "react";
import { useFormStatus } from "react-dom";
import { submitQuiz } from "@/app/actions/learning";
import { PASS_MARK, type QuizResult } from "@/lib/learning";
import Alert from "@/components/Alert";

type Question = { id: string; prompt: string; options: { id: string; text: string }[] };

function Submit({ label }: { label: string }) {
  const { pending } = useFormStatus();
  return (
    <button className="btn btn--fill btn--lg" disabled={pending}>
      {pending ? "Marking…" : label}
    </button>
  );
}

export default function Quiz({
  slug, topicId, questions, alreadyPassed, nextHref, nextLabel,
}: {
  slug: string; topicId: string; questions: Question[];
  alreadyPassed: boolean; nextHref: string; nextLabel: string;
}) {
  const bound = submitQuiz.bind(null, slug, topicId);
  const [state, action] = useActionState<QuizResult, FormData>(bound, {});

  const cooling = state.cooldownUntil && new Date(state.cooldownUntil) > new Date();

  if (cooling) {
    const mins = Math.max(
      1, Math.ceil((new Date(state.cooldownUntil!).getTime() - Date.now()) / 60000)
    );
    return (
      <div className="quiz">
        <div className="quiz__cool">
          <p className="quiz__coolh">Take a short break</p>
          <p className="quiz__coolp">
            Two attempts in a row did not reach {PASS_MARK}%. Retakes open again in
            about {mins} minute{mins === 1 ? "" : "s"}. Reread the topic — the answers
            are all in there.
          </p>
        </div>
      </div>
    );
  }

  if (state.passed) {
    return (
      <div className="quiz">
        <div className="quiz__pass">
          <p className="quiz__passh">Passed — {state.scorePct}%</p>
          <p className="quiz__passp">That topic is done. Your progress is saved.</p>
          <Link className="btn btn--fill btn--lg" href={nextHref}>{nextLabel}</Link>
        </div>
      </div>
    );
  }

  return (
    <div className="quiz">
      <div className="quiz__head">
        <h2 className="quiz__h">Check what you took in</h2>
        <p className="quiz__sub">
          {PASS_MARK}% to move on. Retake as often as you need — after two misses in a
          row there is a short pause.
        </p>
      </div>

      {alreadyPassed && (
        <p className="quiz__already">You have already passed this one. Retaking will not lose it.</p>
      )}

      {state.scorePct !== undefined && !state.passed && (
        <div className="quiz__fail" role="alert">
          <p className="quiz__failh">{state.scorePct}% — not quite</p>
          <p className="quiz__failp">You need {PASS_MARK}%. The explanations below show where it went wrong.</p>
        </div>
      )}

      <form action={action} className="quiz__form">
        {questions.map((q, qi) => {
          const marked = state.review?.find((r) => r.itemId === q.id);
          return (
            <fieldset key={q.id} className={`q${marked ? (marked.correct ? " is-right" : " is-wrong") : ""}`}>
              <legend className="q__legend">
                <span className="q__n num">{qi + 1}</span>
                <span>{q.prompt}</span>
              </legend>
              <div className="q__opts">
                {q.options.map((o) => (
                  <label key={o.id} className="q__opt">
                    <input type="radio" name={`q_${q.id}`} value={o.id} required />
                    <span>{o.text}</span>
                  </label>
                ))}
              </div>
              {marked && marked.explanation && (
                <p className="q__exp">
                  <strong>{marked.correct ? "Correct." : "Not this one."}</strong> {marked.explanation}
                </p>
              )}
            </fieldset>
          );
        })}

        {state.error && <Alert kind="error">{state.error}</Alert>}

        <Submit label={state.scorePct !== undefined ? "Try again" : "Submit answers"} />
      </form>
    </div>
  );
}
