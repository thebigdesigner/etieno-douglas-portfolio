/**
 * Styled dropdowns for the customer site. Shares its behaviour with the staff app: the real
 * <select> stays in the DOM and remains the source of truth, so the booking form's existing
 * handlers and .value reads are untouched.
 */
(() => {
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
function enhanceSelect(sel) {
  if (sel.dataset.selx || sel.multiple) return;
  sel.dataset.selx = '1';

  const wrap = document.createElement('div');
  wrap.className = 'selx';
  sel.parentNode.insertBefore(wrap, sel);
  wrap.appendChild(sel);

  const btn = document.createElement('button');
  btn.type = 'button';
  btn.className = 'selx-btn';
  btn.setAttribute('aria-haspopup', 'listbox');
  btn.setAttribute('aria-expanded', 'false');
  btn.innerHTML = `<span></span><svg viewBox="0 0 12 8" fill="none" aria-hidden="true"><path d="M1 1.5 6 6.5l5-5" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>`;

  const menu = document.createElement('div');
  menu.className = 'selx-menu';
  menu.setAttribute('role', 'listbox');

  wrap.append(btn, menu);
  if (sel.style.minWidth) btn.style.minWidth = sel.style.minWidth;
  if (sel.disabled) btn.disabled = true;

  const paint = () => {
    const chosen = sel.options[sel.selectedIndex];
    btn.querySelector('span').textContent = chosen ? chosen.textContent : '';
    btn.classList.toggle('on', sel.classList.contains('on'));
    menu.innerHTML = [...sel.options].map((o, i) => `
      <button type="button" class="selx-opt" role="option" data-i="${i}" aria-selected="${i === sel.selectedIndex}">
        <svg class="tick" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12.5 4.5 4.5L19 7"/></svg>
        ${esc(o.textContent)}</button>`).join('');
  };
  paint();

  const close = () => { menu.classList.remove('open'); btn.setAttribute('aria-expanded', 'false'); };
  const open = () => {
    document.querySelectorAll('.selx-menu.open').forEach(m => {
      m.classList.remove('open');
      m.parentNode.querySelector('.selx-btn')?.setAttribute('aria-expanded', 'false');
    });
    paint(); menu.classList.add('open'); btn.setAttribute('aria-expanded', 'true');
    menu.querySelector('[aria-selected=true]')?.scrollIntoView({ block: 'nearest' });
  };

  btn.addEventListener('click', e => {
    e.stopPropagation();
    menu.classList.contains('open') ? close() : open();
  });

  menu.addEventListener('click', e => {
    const opt = e.target.closest('.selx-opt'); if (!opt) return;
    sel.selectedIndex = Number(opt.dataset.i);
    sel.dispatchEvent(new Event('change', { bubbles: true }));
    paint(); close(); btn.focus();
  });

  /* Keyboard: the control is a button, so arrows and Escape have to be wired by hand. */
  btn.addEventListener('keydown', e => {
    if (['ArrowDown', 'ArrowUp', 'Enter', ' '].includes(e.key)) { e.preventDefault(); open();
      menu.querySelector('[aria-selected=true], .selx-opt')?.focus(); }
  });
  menu.addEventListener('keydown', e => {
    const opts = [...menu.querySelectorAll('.selx-opt')];
    const at = opts.indexOf(document.activeElement);
    if (e.key === 'ArrowDown') { e.preventDefault(); opts[Math.min(at + 1, opts.length - 1)]?.focus(); }
    if (e.key === 'ArrowUp')   { e.preventDefault(); opts[Math.max(at - 1, 0)]?.focus(); }
    if (e.key === 'Escape')    { close(); btn.focus(); }
  });

  /* Anything that changes the select in code — a re-render, a reset — repaints the button. */
  sel.addEventListener('change', paint);
  new MutationObserver(paint).observe(sel, { childList: true, attributes: true, attributeFilter: ['class', 'disabled'] });
}

document.addEventListener('click', () => {
  document.querySelectorAll('.selx-menu.open').forEach(m => {
    m.classList.remove('open');
    m.parentNode.querySelector('.selx-btn')?.setAttribute('aria-expanded', 'false');
  });
});

const enhanceAll = () => document.querySelectorAll('select:not([data-selx])').forEach(enhanceSelect);
enhanceAll();
new MutationObserver(enhanceAll).observe(document.body, { childList: true, subtree: true });
})();
