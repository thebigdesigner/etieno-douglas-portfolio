"use server";

import { revalidatePath } from "next/cache";
import { createAdminClient } from "@/lib/supabase/admin";
import { requireOwner, auditLog } from "@/lib/owner";
import type { FormState } from "@/lib/forms";

export async function setRole(
  userId: string, _prev: FormState, formData: FormData
): Promise<FormState> {
  const owner = await requireOwner();
  const role = String(formData.get("role") ?? "");

  if (!["learner", "instructor", "institution_admin", "operator"].includes(role)) {
    return { error: "Not a role." };
  }
  if (userId === owner.id) {
    return { error: "You cannot change your own role from here." };
  }

  const admin = createAdminClient();
  const { data: ok } = await admin.rpc("admin_set_role", {
    p_user_id: userId, p_role: role,
    p_actor: owner.id, p_actor_email: owner.email,
  });

  if (!ok) return { error: "Could not change that." };

  revalidatePath("/console/people");
  return { ok: true, message: `Now ${role.replace("_", " ")}.` };
}

export async function grantAllowance(
  userId: string, _prev: FormState, formData: FormData
): Promise<FormState> {
  const owner = await requireOwner();

  const extra = Number(formData.get("extra") ?? 0);
  const reason = String(formData.get("reason") ?? "").trim();

  if (!Number.isInteger(extra) || extra < 1 || extra > 10) {
    return { error: "Between 1 and 10." };
  }
  if (reason.length < 5) {
    return { error: "Say why. It goes in the audit log, not to the learner." };
  }

  const admin = createAdminClient();
  await admin.rpc("admin_grant_allowance", {
    p_user_id: userId, p_extra: extra, p_reason: reason,
    p_actor: owner.id, p_actor_email: owner.email,
  });

  revalidatePath("/console/people");
  return { ok: true, message: `${extra} added.` };
}

export async function revokeCertificate(
  _prev: FormState, formData: FormData
): Promise<FormState> {
  const owner = await requireOwner();

  const code = String(formData.get("code") ?? "").trim().toUpperCase();
  const reason = String(formData.get("reason") ?? "").trim();

  if (!code) return { error: "Which certificate?" };
  if (reason.length < 10) {
    return { error: "A revoked certificate needs a reason on the record. Somebody may ask." };
  }

  const admin = createAdminClient();
  const { data: ok } = await admin.rpc("admin_revoke_certificate", {
    p_code: code, p_reason: reason,
    p_actor: owner.id, p_actor_email: owner.email,
  });

  if (!ok) return { error: "No live certificate with that code." };

  revalidatePath("/console/integrity");
  return { ok: true, message: "Revoked. Its verification page now says so." };
}

export async function suspendAccount(
  userId: string, suspend: boolean, _prev: FormState, formData: FormData
): Promise<FormState> {
  const owner = await requireOwner();
  const reason = String(formData.get("reason") ?? "").trim();

  if (suspend && reason.length < 10) {
    return { error: "Say why. Suspending somebody without a recorded reason is not something we do." };
  }
  if (userId === owner.id) return { error: "You cannot suspend yourself." };

  const admin = createAdminClient();
  await admin.from("profiles")
    .update({ status: suspend ? "suspended" : "active" }).eq("id", userId);

  await auditLog(owner, suspend ? "suspend_account" : "restore_account", userId, { reason });

  revalidatePath("/console/people");
  return { ok: true, message: suspend ? "Suspended." : "Restored." };
}

/* ------------------------------------------------------------------ */
/* Account erasure                                                      */
/* ------------------------------------------------------------------ */

/**
 * Complete a deletion request.
 *
 * Anonymises rather than deletes, for the reasons written into 0053: a
 * hard delete cascades into other people's records — the royalty pool,
 * financial history, and the practitioner named on a certificate. The
 * leaver's identity goes; the rows that count things stay, attached to
 * nobody.
 *
 * Irreversible, so it asks for the person's own confirmation the way
 * the account page asks them: the operator types ERASE.
 */
export async function eraseAccount(
  userId: string, _prev: FormState, formData: FormData
): Promise<FormState> {
  const owner = await requireOwner();

  if (String(formData.get("confirm") ?? "").trim().toUpperCase() !== "ERASE") {
    return { error: "Type ERASE to confirm. This cannot be undone." };
  }

  const admin = createAdminClient();
  const { data } = await admin.rpc("erase_account", {
    p_user_id: userId, p_actor: owner.id,
  });

  const row = (data ?? [])[0] as { ok: boolean; reason: string | null } | undefined;
  if (!row?.ok) {
    return { error: row?.reason === "no_account" ? "That account no longer exists." : "Could not complete that." };
  }

  /* The login itself, last.
   *
   * The profile is anonymised above, but auth.users still holds the
   * address they signed in with, and profiles.id references it on
   * delete cascade — so deleting the auth row would take the profile
   * and everything below it, which is the outcome 0053 exists to
   * prevent. The address is replaced with a tombstone instead: nothing
   * to sign in with, nothing to reset, no personal data left.
   */
  const { error: authError } = await admin.auth.admin.updateUserById(userId, {
    email: `deleted-${userId}@splari.invalid`,
    user_metadata: {},
  });
  if (authError) {
    console.error("eraseAccount: auth scrub failed", userId, authError.message);
    return {
      ok: true,
      message: "Records anonymised, but the sign-in address could not be cleared. Check the logs before closing this.",
    };
  }

  revalidatePath("/console/people");
  return { ok: true, message: "Erased. The records that remain are attached to nobody." };
}

/** Withdraw a request — for somebody who asks to stay after all. */
export async function cancelDeletion(userId: string): Promise<FormState> {
  const owner = await requireOwner();
  const admin = createAdminClient();

  /* Restores whatever the status was before the request, not 'active'.
   * An account suspended for abuse that then asked to be deleted would
   * otherwise come back unsuspended, with a withdrawal quietly undoing a
   * moderation decision it had nothing to do with. 0054 records the
   * prior status so this can put back what was actually there. */
  const { data } = await admin.rpc("cancel_deletion_request", {
    p_user_id: userId, p_actor: owner.id,
  });
  const row = (data ?? [])[0] as { ok: boolean; restored_to: string | null } | undefined;

  if (!row?.ok) return { error: "There is no open request for that account." };

  revalidatePath("/console/people");
  return {
    ok: true,
    message:
      row.restored_to === "suspended"
        ? "Request withdrawn. The account stays suspended — it was suspended before they asked."
        : "Request withdrawn and the account is open again. Certificates stay revoked until you restore them.",
  };
}

