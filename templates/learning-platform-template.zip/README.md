> **Template by [Aphinity Digital](https://aphinity.digital).** All marketing copy is placeholder text. Replace it with your own; images are included so you can see the layout. Want it customised and launched? Start a project at https://aphinity.digital

# Your Brand Academy

Next.js 15 (App Router) + Supabase. Sprint 0: deployable skeleton, database schema, and the three marketing pages served from the app.

---

## What is here

```
app/
  layout.tsx              root layout, fonts, metadata
  globals.css             the full design system
  page.tsx                learner homepage
  institutions/page.tsx   institution landing page
  teach/page.tsx          instructor landing page
components/
  SubjectSearch.tsx       accessible custom dropdown (subject × segment)
lib/
  supabase.ts             browser and server clients
supabase/migrations/
  0001_init.sql           full schema
public/
  hero.webp               hero cutout
```

## Running it locally

You need Node 20 or newer.

```bash
npm install
cp .env.example .env.local     # then fill in the Supabase values
npm run dev
```

Open http://localhost:3000

## Setting up Supabase

1. Create a project at supabase.com (free tier).
2. Project Settings → API. Copy the URL, the anon key, and the service role key into `.env.local`.
3. Run the migration. Either paste `supabase/migrations/0001_init.sql` into the SQL editor, or use the CLI:

```bash
npx supabase link --project-ref <your-ref>
npx supabase db push
```

The service role key bypasses row-level security. It belongs in server code only — never in a component marked `"use client"`.

## Deploying

```bash
git init && git add -A && git commit -m "Sprint 0"
gh repo create splari --private --source=. --push
```

Then at vercel.com: New Project → import the repo → add the same environment variables → Deploy.

Every branch you push from now on gets its own preview URL. That is your test environment; you do not need a staging server.

---

## Schema notes

Three things in `0001_init.sql` matter more than they look.

**`topic_completions.revenue_source`** is recorded at completion time. The royalty pool divides by completed topics, and individual and institutional completions divide different pools at different rates. Reconstructing this later from enrolment history is unreliable — record it when it happens.

**`business_holidays`** exists because the four-working-day review promise has to mean the same thing in every country. One published calendar, not a per-learner one. Every SLA timer reads from it.

**`age_checks`** is keyed by device and written *before* the account exists. If someone can enter a date, get blocked, reload and enter a different one, the age gate is decorative.

## Row-level security

RLS is enabled on every table with user data. Policies are deliberately minimal right now — own-row access for learners, public read for published courses and certificate lookups. Add policies as each feature is built, and never disable RLS to make something work.

---

## Next: Sprint 1 — Identity

- Email signup, verification, login, password reset
- Date-of-birth capture → account type (adult / teen / child)
- Parental consent: request, confirmation link, versioned record, 14-day expiry
- Consent withdrawal and deletion
- Institution-provisioned credentials: class code + issued username + PIN

Sprint 1 is done when you can create an adult account, a teen account that waits on a guardian's confirmation, and join a cohort with a username and PIN.

## Environment variables

| Key | Needed for |
|---|---|
| `NEXT_PUBLIC_SUPABASE_URL` | Sprint 0 |
| `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Sprint 0 |
| `SUPABASE_SERVICE_ROLE_KEY` | Sprint 1 (server-side only) |
| `NEXT_PUBLIC_SITE_URL` | Consent and verification links |
| `RESEND_API_KEY`, `EMAIL_FROM` | Sprint 1 |
| `BUNNY_STREAM_*` | Sprint 2 |
| `PADDLE_*` | Sprint 4 |

---

## Deploying to a VPS (Hostinger, Ubuntu 24.04)

Everything needed is in `deploy/`.

```bash
# on the VPS, as root
curl -O https://raw.githubusercontent.com/<you>/splari/main/deploy/setup.sh
chmod +x setup.sh
./setup.sh yourbrand.com you@email.com
```

That installs Docker, sets up UFW and fail2ban, disables SSH password login, adds 2GB of swap (Next.js builds OOM without it on small boxes), and issues the TLS certificate.

Then:

```bash
git clone <your repo> /opt/splari
cd /opt/splari
cp .env.example .env.production   # fill it in
cd deploy && docker compose up -d --build
```

`docker compose` brings up four services: the app, Postgres, Nginx with auto-renewing TLS, and a nightly `pg_dump` keeping seven days of backups in `deploy/backups/`.

### Deploying an update

```bash
cd /opt/splari && git pull && cd deploy && docker compose up -d --build app
```

### Sizing

Minimum **2 vCPU / 8GB** if Postgres runs on the same box. Next.js builds are memory-hungry and will be killed on 4GB while Postgres is also resident. 1 vCPU / 4GB is fine if the database is managed elsewhere.

### What must stay off the VPS

**Video** — adaptive bitrate delivery needs a CDN's edge nodes, not a bigger server. Keep Bunny Stream.

**Email** — a fresh VPS IP has no sending reputation and your verification and consent emails will land in spam, which silently breaks signup. Keep Resend.

### Before you trust it with real users

- Restore a backup into a scratch database and confirm it works. An untested backup is not a backup.
- Point an uptime monitor at the site. Nobody watches a VPS by themselves.
- Confirm `5432` is not reachable from outside: `nc -zv <your-ip> 5432` should fail.

---

## Deploying to Hostinger Cloud (Node.js Apps)

Hostinger's Business and Cloud plans run Node.js apps with GitHub integration, so Next.js runs properly with SSR — no static export needed.

**Important:** Hostinger's included managed database is MySQL. This schema is Postgres (enums, `jsonb`, `inet`, row-level security). Do not convert it. Keep the database on Supabase or Neon — both have free tiers — and use Hostinger for the app only.

1. Push the repo to GitHub.
2. hPanel → **Websites → Add Website → Node.js Apps → Import Git Repository**.
3. Authorise GitHub and pick the repo.
4. Confirm build settings: Node 20+, build `npm run build`, start `npm start`.
5. Add environment variables in the Hostinger app settings — never commit them.
6. Deploy, then map your domain.

Pushes to `main` redeploy automatically after that.

Note: npm commands run as part of Hostinger's deploy step and cannot be run over SSH on these plans. If you need a one-off script, run it locally against the same database.

---

## Keeping dependencies patched

Next.js moved to a monthly security release cadence in 2026, with patches announced in advance. Supported lines are **16.x (Active LTS)** and **15.5.x (Maintenance LTS)** — older minors do not receive patches, so staying on one of those two lines is the whole strategy.

Check and update:

```bash
npm audit
npm install next@latest
```

Do this at least monthly, and always before a release. `npm audit` in CI is worth adding once you have a pipeline.

---

## Optional: a free preview on GitHub Pages

GitHub Pages serves **static files only** — no server, no database, no authentication. It works for the marketing pages as they are now, but it cannot run anything from Sprint 1 onward. Treat it as a shareable preview, not the real deployment.

The repository must be **public** for Pages on the free plan.

1. Push to GitHub.
2. Repo → **Settings → Pages → Source: GitHub Actions**.
3. If the site will live at `https://<user>.github.io/<repo>/` rather than a custom domain, add a repository variable: **Settings → Secrets and variables → Actions → Variables → New**, named `BASE_PATH`, value `/<repo>` (e.g. `/splari`). Skip this if you are using a custom domain.
4. Push to `main`. The workflow in `.github/workflows/pages.yml` builds and publishes.

The static build is triggered by `STATIC_EXPORT=1`, so it does not affect local development, the Hostinger deployment, or the Docker build — each path sets its own flag.

---

## Sprint 1 — Identity (built)

### Age policy

One global rule, set in `lib/age.ts`. Change it there and nowhere else.

| Age | What happens |
|---|---|
| Under 13 | Cannot register alone. Institution enrolment only. |
| 13–15 | Account created, locked until a guardian confirms by email. |
| 16–17 | Registers alone. Minor protections apply. |
| 18+ | Full account. |

**Minor protections** (anyone under 18): no marketing email, name hidden on public
certificate pages, minimal retention.

### Why the age gate is a separate step

The verdict is written to `age_checks`, keyed by an httpOnly device cookie, **before**
the account exists. Reloading and entering a different date does not get past it. The
row is consumed when the account is created, so it cannot be reused.

Segment options are filtered by age too — a 14-year-old is never offered
"Running a business".

### Parental consent

Verifiable consent, not a checkbox. Email plus confirmation link is accepted for
internal-use-only data under COPPA and is generally sufficient under GDPR Article 8.

- Consent is a **versioned record** (`consent_version`), never a boolean. When the
  wording changes materially, bump `CONSENT_VERSION` — prior consent no longer covers it.
- Two tokens: one confirms, one lets the guardian return later to review or withdraw.
- Unconfirmed after 14 days, the pending account is deleted.
- Withdrawal suspends the account immediately.

### Cohort learners

Class code + issued username + 6-digit PIN. No email at any point. Under the hood a
synthetic address (`<cohort-id>.<username>@cohort.splari.internal`) satisfies Supabase
Auth; the real identity lives in `cohort_seats`. Only an issued username can claim a
seat, and the cohort seat ceiling is enforced in `claim_cohort_seat` — a leaked class
code alone gets nobody in.

### Routes

| Route | Purpose |
|---|---|
| `/signup` | Age gate |
| `/signup/details` | Name, email, password, segment, guardian email if needed |
| `/signup/too-young` | Under 13 — points at institutions |
| `/signup/check-email` | Verification sent |
| `/signup/awaiting-consent` | Waiting on a guardian |
| `/login` | Email and password |
| `/join` | Class code, username, PIN |
| `/consent/[token]` | Guardian confirms |
| `/consent/manage/[token]` | Guardian reviews or withdraws |
| `/auth/callback` | Email verification exchange |
| `/dashboard` | Signed-in landing page |

### Before this runs

1. Create a Supabase project.
2. Run both migrations in order: `0001_init.sql`, then `0002_identity.sql`.
3. Set in `.env.local` and in your host's environment variables:
   `NEXT_PUBLIC_SUPABASE_URL`, `NEXT_PUBLIC_SUPABASE_ANON_KEY`,
   `SUPABASE_SERVICE_ROLE_KEY`, `NEXT_PUBLIC_SITE_URL`.
4. Supabase → Authentication → URL Configuration → add
   `<site-url>/auth/callback` as a redirect URL.
5. `RESEND_API_KEY` is optional in development — without it, consent emails print
   to the terminal so the flow is testable before a sending domain is verified.

The service role key bypasses row-level security. Server code only; never in a
`"use client"` file.

### Testing it

- Sign up with a date making you 25 → verification email → log in → dashboard.
- Sign up with a date making you 14 → guardian email asked for → consent link printed
  in the terminal → open it → account activates → log in.
- Sign up with a date making you 11 → blocked, sent to the institutions page.
- Try reloading the age gate after being blocked and entering a different date — you
  should still be blocked.

---

## Sprint 2 — Learning engine (built)

### Routes

| Route | Purpose |
|---|---|
| `/courses` | Catalogue, filterable by `?subject=` and `?segment=` |
| `/courses/[slug]` | Course detail — outline, project brief, published rubric |
| `/learn/[slug]/[topicId]` | Topic player, quiz, progress |

### The gate

A topic unlocks when every topic before it is complete. Resolved in one place —
the `course_outline` SQL function — so the sidebar, the course page and the player
can never disagree about what is unlocked.

- Topic quizzes are marked server-side at **80%**.
- Retakes are unlimited, but **two consecutive failures start a 30-minute cooldown**
  (`quiz_cooldown_until`). Without it, a four-option quiz is brute-forceable.
- Questions and options are shuffled with a **deterministic seed** per learner and
  topic — stable if they reload, different between learners.

### The answer key never reaches the browser

`quiz_items.correct` is only ever read by the server action that grades an attempt.
The client receives prompts and options, and after submitting, per-question
correctness plus the explanation. RLS allows reading quiz rows, so if you later add
a client-side query, select columns explicitly — never `select("*")` on `quiz_items`.

### Completions carry their revenue source

`topic_completions.revenue_source` is set at completion time from the enrolment
source: cohort → `institution`, otherwise `individual`. The royalty pool divides
these at different rates (35% and 30%), and it cannot be reconstructed later.

### Video

`lib/video.ts` builds a Bunny Stream embed from `NEXT_PUBLIC_BUNNY_LIBRARY_ID` and
`topics.video_uid`. With neither set, topics render text-only — so course authoring
is not blocked on a video provider. Swap providers by editing that one file.

### Seed course

`0003_learning.sql` inserts one published course — *Reading a set of accounts* —
with two modules, four topics, five quiz questions and a three-criterion rubric.
The first topic is free. **Delete that `do $$ ... end $$` block before launch.**

### Testing it

1. Run `0003_learning.sql` in the Supabase SQL editor.
2. Visit `/courses` — the seed course appears.
3. Open it while logged out: the first topic is readable, then a signup gate.
4. Log in, start the course, and fail a quiz twice in a row — the cooldown appears.
5. Wait it out or clear `quiz_attempts` for that topic, pass at 80%, and the next
   topic unlocks.

### Still open

Instructor application and the operator review queue are **Sprint 6**. The Teach page
CTA points at its own on-page anchor until then, not a dead route.

---

## A rule worth remembering

A file marked `"use server"` may **only export async functions**. Exporting a
constant or a type from one breaks the entire module — every importer then reports
"the module has no exports at all", which points at the wrong file and produces a
confusing cascade of errors.

So shared constants and types live outside the action modules:

- `lib/forms.ts` — `FormState`
- `lib/learning.ts` — `PASS_MARK`, `QuizResult`

If a new build fails with "Only async functions are allowed to be exported",
that is what has happened.

---

## Sprint 3 — Catalogue, conversion and a UI pass

### Shared chrome

`SiteHeader` and `SiteFooter` now render on every page. Previously each page carried
its own copy, which is how navigation quietly drifts apart.

`SiteHeader` is deliberately **not** async. Auth state lives in `AuthNav`, a client
component, so the marketing and catalogue pages still statically generate. Making the
header async would have turned every page dynamic to show one name in the corner.
The trade is a brief unauthenticated nav before hydration.

### Catalogue

- Real filter UI on both axes — subject and segment — reflected in the URL, so a
  filtered view is shareable and indexable.
- `generateMetadata` per filter combination.
- Empty state distinguishes "no results for this filter" from "nothing published yet",
  and offers the way out.
- Loading skeleton in `app/courses/loading.tsx`.

### Course pages

`Course` JSON-LD structured data, Open Graph metadata, and the rubric published in
advance — a learner should know what they are being marked on before they start.

### The paywall

Sits at **the end of module one**, never at signup (`lib/access.ts`). Gating at
signup kills conversion; gating after a learner has felt one module of value is the
pattern that works.

Access is granted by an active subscription **or** a cohort enrolment, since
institutional learners are covered by their institution's plan.

### Dashboard

Real content: courses in progress with completion percentages, a direct link to the
next unlocked topic, courses ready for assessment, and account state. Empty states
point somewhere useful rather than saying "nothing here".

### Supporting pages

`not-found.tsx`, `error.tsx` (with the digest reference for support), `loading.tsx`,
`sitemap.ts` and `robots.ts`. Robots disallows `/dashboard`, `/learn/`, `/consent/`,
`/auth/` and `/join` — anything private or naming a learner.

### A rule that caught me twice

Postgres reserves `POSITION`. It is fine as a table column but not in a
`RETURNS TABLE` signature, where the parser expects a type. `course_outline` returns
`pos` for that reason.

### Layout structure

Pages that carry site navigation live in the `app/(site)` **route group**. The
parentheses shape the layout tree without appearing in URLs — `/courses` is still
`/courses`. `app/(site)/layout.tsx` renders the header and footer once; the pages
inside contain only their own content.

Three things sit deliberately outside it:

- **Auth screens** (`/login`, `/signup`, `/join`, `/consent`) use a centred card with
  no navigation. Fewer exits during a signup flow.
- **`/learn`** replaces the nav with a progress bar. Full site navigation above
  someone mid-lesson is a distraction and an exit route.
- **`not-found.tsx`** sits at the root so it can catch unmatched URLs anywhere, and
  therefore renders its own header and footer.

The announcement bar is site-wide, defined once in `SiteHeader`. Per-page
announcements would require the layout to know which route it is wrapping, which
means reading headers and losing static generation on every page.

Active nav highlighting is handled by `NavLinks`, a client component using
`usePathname`. That keeps the layout static — unlike `headers()`, `usePathname` does
not opt a route out of prerendering.

### Two mirrored rules about module boundaries

Both cost me a build, and they are easy to trip over because the error message points
somewhere other than the cause.

**A `"use server"` file may only export async functions.** Exporting a constant or a
type breaks the whole module, and every importer then reports "the module has no
exports at all". Shared constants live in `lib/forms.ts` and `lib/learning.ts`.

**A `"use client"` file should not be the home for a value a server component
imports.** The import resolves to a client-reference proxy rather than the value, so
`NAV.map is not a function` at render time. Shared constants live in `lib/nav.ts`.

The rule underneath both: **constants and types belong in plain modules.** Files
marked `"use client"` or `"use server"` export components and functions, nothing else.

---

## Password and PIN recovery

Three account types, three recovery paths.

| Route | For | How it works |
|---|---|---|
| `/forgot` | Adults and teens | Supabase sends a reset link to the account address |
| `/reset` | — | Where the link lands; sets the new password |
| `/join/forgot-pin` | Cohort learners | No email exists, so recovery goes through the institution |

**The request page always gives the same answer**, whether or not an account exists at
that address. Saying "no account found" turns the page into a way to discover who has
signed up — a real concern here, because a portion of the accounts belong to minors.

**Cohort learners cannot self-recover by design.** They have no email address, so a
reset link has nowhere to go. `/join/forgot-pin` tells them what to give their teacher.
The admin-side action that clears a PIN is part of the institution tooling in Sprint 7;
until then it is a manual database update.

**Under-16 accounts reset to the learner's own address, not the guardian's.** Consent
covers the account existing and being used; it is not a claim over access. Worth
revisiting if a school asks for something different.

Supabase needs `<site-url>/auth/callback` in its redirect URL list for this to work —
the same entry already required for email verification.

---

## Sprint 5 — Assessment (built ahead of subscriptions)

Built before Sprint 4 deliberately: the review engine is the differentiator and has no
external dependency, whereas subscriptions cannot be tested until a merchant account is
approved. Subscriptions slot in when that lands.

### Routes

| Route | Who |
|---|---|
| `/courses/[slug]/submit` | Learner — final project |
| `/review` | Instructor or operator — the queue |
| `/review/[submissionId]` | Instructor or operator — assessing one project |
| `/verify/[code]` | Anyone — public certificate check |

### The four working days

`add_working_days` skips weekends and anything in `business_holidays`. **One published
calendar, applied globally** — a per-learner calendar would mean the same promise meant
different things in different countries.

The queue is ordered by deadline, oldest first, and colour-coded: amber within a day,
red past it. `review_queue_status` exposes `due_soon` and `breached` so the operator
console can act before the promise breaks rather than after.

### What the database guarantees

Submission and assessment both run through Postgres functions, so the rules cannot be
bypassed by a bug in the UI:

- **Every topic must be complete** before the project opens.
- **The allowance is checked and decremented atomically** with the submission.
- **The first resubmission after a "revise" verdict is free** — `consumed_allowance` is
  false on attempt 2.
- **Cohort learners never consume an allowance**; their institution's plan covers it.
- **The certificate is issued inside `record_review`**, in the same transaction as the
  pass. The two can never disagree.
- **$18.85 credits the reviewer on completion**, not on enrolment.

### Minors

`certificates.show_name` is set from `minor_protections` at issue time. The public
verification page shows the course, date, reviewer and code, but never a name for an
under-18 — to anyone, including the school. Verification pages are `noindex` and
excluded in `robots.ts`.

### Files

Submissions go to a **private** Supabase Storage bucket. Learners can only write into
their own folder, enforced by a storage policy rather than by the UI. Reviewers see
signed URLs valid for one hour, generated server-side.

Type and size are checked before upload: 20MB, and PDF, Word, Excel, text or images.

### Reviewer access

There is no instructor application flow yet — that is Sprint 6. To grant access now:

```sql
update profiles set role = 'instructor' where email = 'them@example.com';
insert into instructors (id, state) values ('<their-uuid>', 'active');
```

Set a course's `instructor_id` to that person and their submissions will route to them.
Submissions on a course with no instructor sit in the queue as `submitted` for an
operator to pick up.

### Testing it

1. Run `0004_assessment.sql`.
2. Complete every topic of the seed course.
3. Give yourself an allowance:
   `insert into cert_allowances (user_id, period_start, period_end, included)
    values ('<uuid>', now(), now() + interval '1 year', 3);`
4. Submit at `/courses/reading-a-set-of-accounts/submit`.
5. Promote a second account to instructor, open `/review`, assess it.
6. On a pass, a certificate code is issued — check it at `/verify/[code]`.

---

## Sprints 6 and 7 — Studio, institutions, operations

Run `0005_studio_institutions.sql` after `0004`.

### Roles decide where you land

`/dashboard` redirects by role: instructors to `/studio`, institution admins to
`/institution`, operators to `/admin/sla`. Learners stay put.

| Surface | Role | What it does |
|---|---|---|
| `/teach/apply` | Anyone signed in | Instructor application |
| `/studio` | Instructor | Courses, availability, review queue link |
| `/studio/[slug]` | Instructor | Curriculum, quizzes, rubric, submit for review |
| `/studio/earnings` | Instructor | Statement, payout runs, **pool audit** |
| `/institution` | Institution admin | Cohorts, provisioning, progress |
| `/institution/cohorts/[id]` | Institution admin | Usernames, PIN resets, CSV export |
| `/institution/invoices` | Institution admin | Monthly invoices |
| `/admin/sla` | Operator | Breached and due-soon queue, reserve reassignment |
| `/admin/applications` | Operator | Approve or decline instructors |
| `/admin/courses` | Operator | The rubric gate |
| `/admin/institutions` | Operator | Generate invoices |
| `/admin/payouts` | Operator | Calculate pools, run payouts |

### The rubric gate is enforced, not advisory

`submit_course_for_review` refuses anything with fewer than three topics, fewer than
three questions, a brief under 120 characters, or fewer than two rubric criteria. The
studio shows the same checklist live, so an instructor knows what is missing before
they try. On publication, the first topic is automatically marked free.

### Seats, not codes

`provision_seats` issues a username per seat up front. A leaked class code alone gets
nobody in — joining needs an issued username too, and the ceiling is enforced in the
database. Codes can be regenerated without affecting learners already in.

### Billing and pools are one function each

`generate_invoice` counts distinct learners with **at least one topic completed that
month** — joining or watching part of a video does not count — and itemises unused
seats at zero.

`calculate_pool` takes the month's revenue, applies 35% for subscriptions or 30% for
institutions, divides by completed topics from that source, and credits each instructor
their share in the same transaction. The figures land in `pool_periods`, which is what
`/studio/earnings` shows instructors so they can check the arithmetic themselves.

`run_payouts` prepares weekly balances; anything under $20 is marked below threshold and
rolls forward.

### Still manual

Institution accounts are created by an operator calling `create_institution` — there is
no self-serve signup at that tier, and there should not be. Revenue figures for the pool
are entered by hand until the payment provider is connected in Sprint 4.

---

## Notifications and instrumentation

Run `0006_analytics.sql`.

### Why these emails exist

A four-working-day turnaround that nobody is told about is, from the learner's side,
indistinguishable from silence. Every template in `lib/notifications.ts` exists because
the product makes a promise the person cannot otherwise see being kept.

| Trigger | To | Says |
|---|---|---|
| Project submitted | Learner | The deadline, in writing |
| Project submitted | Reviewer | Their deadline |
| Review passed | Learner | Reviewer's name, certificate code |
| Changes asked for | Learner | Whether the next attempt is free |
| Due within a day | Reviewer | Hours remaining |
| Due soon or breached | Operator | The list, with a link to reassign |
| Weekly | Institution admin | Cohort digest |

Cohort learners hold a synthetic address, so nothing is sent to them — their admin gets
one digest instead. `lib/email.ts` prints to the terminal when `RESEND_API_KEY` is
unset, so the whole flow is testable before a sending domain is verified.

### Scheduled jobs

`vercel.json` registers two crons: SLA twice daily on weekdays, digest on Monday
mornings. Both routes refuse to run without `CRON_SECRET` — they are public URLs, and
without a shared secret anyone could trigger a mail-out by guessing the path.

The SLA job warns a reviewer **once** per submission, using `escalated_at` as the guard.

### Event names are a closed set

`EventName` in `lib/track.ts` is a union type, not a string. Free-text names drift, and
then the gates cannot be measured because half the events are spelled two ways.

`track()` swallows its own errors. Instrumentation must never break a user flow — if the
insert fails, the person still gets what they came for.

### /admin/metrics

Three views back it:

- **`launch_metrics`** — every phase gate in one row, including SLA adherence.
- **`funnel_daily`** — distinct people per stage per day, so a reload does not inflate
  the numerator.
- **`topic_dropoff`** — where learners fail. A high failure rate on one question is
  usually a badly written question rather than a difficult topic.

---

## Closing the audit gaps

Run `0007_appeals_access.sql`.

### Appeals now route

`/admin/appeals` assigns a second reviewer, and `assign_appeal` refuses to pick the
person who gave the first verdict. The reviewer opens `/review/appeal/[id]`, which shows
the brief, the rubric, the learner's grounds and the work — **and deliberately not the
first verdict or its feedback**. A page banner says so, because a reviewer who knows they
are checking someone else's work reads differently from one assessing it fresh.

Overturning issues the certificate the first verdict withheld, in the same transaction.
The appeal reviewer is paid the same $18.85 as any other assessment.

### Legal pages

`/legal/privacy`, `/legal/terms`, `/legal/data-processing`, `/legal/security` and
`/contact`. The institutions page now links to a DPA that exists.

**These need a lawyer before you sign anything.** They are written to be substantively
right and readable, not to be legally sufficient in every jurisdiction you serve. The
security page deliberately says what you do *not* have — no SOC 2, no SSO, no data
residency — because claiming otherwise to an institutional buyer is worse than admitting
it.

### Certificates print

`/certificate/[code]` renders an A4 landscape certificate with a print stylesheet. Not a
generated PDF: the browser's own print-to-PDF produces a better result on every platform
than a server renderer, with no dependency and no font embedding to go wrong. Minors'
certificates show "Name withheld" on any copy but their own.

### Transcripts

`topics.transcript`, enforced — `saveTopic` refuses a topic that has video but no
transcript. It is what makes a topic usable on a connection too weak for video, and the
first thing an institutional buyer asks about on accessibility.

### Instructor departure

`/admin/instructors` records notice or suspension. Either way: courses close to new
enrolments, open reviews release back to the queue, and existing learners keep access for
the notice period plus 90 days — which is what the instructor terms promise.

---

## Onboarding rebuilt — one flow, three intents

Run `0008_onboarding.sql`.

Everyone signs up the same way: **intent → age → details → verified email → their own
dashboard.** Institutions then verify with documents; instructors then complete an
application. Neither blocks the account existing.

### Intent is carried in the database, not the URL

The first step asks what brings you here, and the answer is written to `age_checks`
alongside the age verdict — the same row that already survives the page navigation. A
query string would be tamperable; this is not.

`?intent=instructor` and `?intent=institution` preselect the radio for people arriving
from the Teach and Institutions pages. It only sets the default; the value that counts is
the one submitted.

Teaching and running an organisation are **18+**. The age step refuses those intents for
anyone younger, with a message that points a young applicant at learning instead.

### Institutions: account first, verification before enrolling

Signing up creates the organisation and makes you its admin immediately. You can look
around, read courses, see how cohorts work. What you cannot do is enrol anyone —
`createCohort` calls `institution_can_enrol`, so the gate is in the database rather than
the form.

Upload a registration document, a letter on headed paper, or photo ID at
`/institution/verify`. Files go to a **private** bucket, owner-scoped by storage policy.
An operator reviews at `/admin/verification` with one-hour signed links, and the decision
emails them either way — a rejection requires a reason, because "declined" with no
explanation wastes everyone's time.

The reason this gate exists at all: an institution enrols other people's learners, and
some of those learners are children.

### Instructors: role without permission

Signing up with instructor intent creates the `instructors` row in `applied` state and
sets the role. The role alone does nothing — `requireRole` additionally checks
`instructor_is_active`, so an applicant sees `/studio/pending` and cannot create courses
or take reviews until an operator approves them.

The public `/teach/apply` route is gone. An application is now something you complete
from inside your own account, which means we already know who you are.

### Dashboards have no marketing chrome

`/dashboard` moved out of the `(site)` route group. Every signed-in surface — learner
dashboard, studio, review queue, institution, admin — now uses `components/AppBar`
instead: logo, section label, section links, name, log out.

A pricing link above somebody's course progress is an exit, not a service. The marketing
header belongs on marketing pages.

---

## Open studio, templates, materials, assistant

Run `0009_studio_open.sql`. Add `ANTHROPIC_API_KEY` for the assistant.

### The gate moved from the person to the course

Udemy's shape rather than Alison's. Signing up as an instructor lands you in `active`
with nothing published — three questions, then the studio. The check happens when a
course is submitted, not before somebody is allowed to try.

Alison requires a training course and a test course before you may build anything: about
two hours before you have made a thing. That is a good filter and a bad funnel, and the
filter it applies is "can they build a course", which is not what our credential rests on.

### The creator course is optional, and the off switch is real

`/studio/creator-course` — six lessons, fifteen minutes, nothing gated on it. A weekly
strip appears in the studio for anyone who has not read it.

It is a **strip, not a modal**. A modal over somebody's half-built course teaches them to
hit the X without reading, at which point the nudge is worthless. Three responses: read
it, not now, or stop asking. "Stop asking" is honoured permanently, and the guide is
still reachable under Help.

### Templates seed structure, not layout

Five shapes — walkthrough, diagnostic, build, foundations, blank. Picking one creates the
modules, the topics, a project brief pattern and a **starting rubric** to edit.

The blank page is what stops people finishing a course. A layout picker would not fix
that; a half-written rubric might.

### Topics hold anything

`topic_materials` — video, PDF, slides, downloads, audio, links, as many per topic as it
needs. Uploads go to a private bucket and reach learners through one-hour signed links.

The publication gate now rejects **empty topics**: under 40 characters of text and no
material attached is a blank page, and blank pages are what learners complain about.

Transcripts follow the video material rather than a column, and are still enforced.

### Free courses

`courses.is_free` bypasses the paywall entirely. Alison's model, and the fastest route to
a catalogue worth browsing — a practitioner will write one to be read before they will
write one to be sold.

### The assistant

`/api/assistant`, free, on the marketing pages only. It answers from `assistant_catalogue`
— published courses and their topics — plus the platform facts in the system prompt.

**What it will not do:** write course descriptions, module titles, project briefs or
rubrics. The whole credential rests on a practitioner having written those, and an
AI-drafted rubric produces inconsistent verdicts, which is the one failure that makes a
certificate worthless. It says so when asked.

The endpoint is unauthenticated, so it is rate limited per hour by user or IP — 12
anonymous, 40 signed in — through `assistant_allow`. Without that it is a way for
somebody to spend our money. It is deliberately absent from the studio, dashboards and
the review queue: those are places people work, not places they browse.

### The header call to action follows the page

`AuthNav` reads the pathname and offers the signup that matches what somebody is
reading:

| Page | Button |
|---|---|
| `/teach` | Start teaching → `?intent=instructor` |
| `/institutions` | Set up your organisation → `?intent=institution` |
| Everywhere else | Get started → learner |

Somebody reading the teaching page and clicking "Get started" means teaching. Sending
them into the learner flow makes them start again, and some of them do not.

The mobile menu lists all three signup paths with the relevant one first, rather than
assuming everybody is a learner. The footer carries a direct entry for each audience.

Institution copy no longer offers to book a call — the account is self-serve and
verification is the step that follows.

---

## Owner console — `/console`

Run `0010_console.sql`. Set `OWNER_EMAILS` to a comma-separated list.

This is separate from `/admin`. The distinction is deliberate:

- **`/admin`** is the operations surface — the queue. SLA, verification, applications,
  courses awaiting review, appeals, payouts. Anybody with the operator role works here.
- **`/console`** is the owner surface — the business. Money, people, catalogue health,
  integrity, audit.

### Two locks, not one

A role column alone is a single point of failure: whoever compromises an operator
account, or has write access to the database, inherits everything. The console
additionally requires the signed-in email to appear in `OWNER_EMAILS`, which lives in
the environment — so removing somebody's access is a deploy, not an `UPDATE`.

An **empty `OWNER_EMAILS` locks everybody out** rather than letting everybody in. Getting
that default the wrong way round is how these things go wrong.

Every page calls `requireOwner()` itself rather than relying on the layout. `/console` is
excluded in `robots.ts` and carries `noindex`.

### Everything is audited

`admin_audit` records who did what, to whom, when, and why. Role changes, granted
allowances, suspensions and revocations all write a row. `/console/audit` reads it and
cannot edit it — a log you can quietly amend is not a log.

Suspending somebody or revoking a certificate **requires a written reason**. If the
person later asks why, there is an answer.

You cannot change your own role or suspend yourself from the console. Locking yourself
out is not a recoverable mistake.

### What the pages watch

**Overview** — the four gates, live alerts (breached reviews, SLA under 90%, instructor
cost above institutional revenue, a catalogue under fifteen courses), and links across to
the operations surface.

**Money** — invoiced revenue by month against instructor cost, and a per-instructor
ledger of accrued versus paid. It says plainly that subscription revenue is missing until
a provider is connected, because a partial figure presented as complete is worse than no
figure.

**People** — search, role changes, allowance grants, suspension. Flags consents about to
expire at fourteen days.

**Catalogue** — enrolment and completion per course, drafts stuck unsubmitted, subjects
with fewer than three courses, and the questions learners fail most.

**Integrity** — SLA adherence, average turnaround, pass rate, appeals. It warns when the
**pass rate goes above 95%**: either the projects are too easy or reviewers are being
generous, and both quietly empty the certificate of meaning. Certificate revocation lives
here.

---

## Signup split into three steps

Run `0011_instructor_views.sql`.

`/signup` → `/signup/age` → `/signup/details`. Separate pages, because the three paths
diverge and cramming them into one form produced a screen headed "First, how old are
you?" whose first question was something else entirely.

The intent is held in an httpOnly cookie between step one and two, then written to
`age_checks` with the age verdict. `?intent=` still preselects for people arriving from
the Teach or Institutions pages.

### Each path asks only its own questions

The segment question — High School, University, Business Owners — is a **learner**
question. It decides which level of course we show them. An instructor was being asked
it, which made no sense; that was a bug and it is fixed.

| | Learner | Instructor | Institution |
|---|---|---|---|
| Name, email, password | yes | yes | yes |
| Which describes you best | **yes** | no | no |
| What do you do | no | **yes** | no |
| Organisation, country, website | no | no | **yes** |
| Guardian email | if under 16 | n/a (18+) | n/a (18+) |

The instructor's headline is captured at signup and carried into the `instructors` row,
so the studio does not ask for it again. `/studio/start` now asks two questions, not
three.

## Instructor dashboard

`/studio` was a course list. It is now a dashboard that answers "what needs doing".

**A to-do strip** at the top, most urgent first: reviews past four days, reviews due
within a day, second readings assigned, courses sent back for changes. When there is
nothing wrong and work is waiting, it says so in green rather than staying silent —
silence reads as broken.

**Four numbers**: queue depth with SLA reliability, this month's earnings and what is
unpaid, learners and how many certified, courses live and in draft.

**Next up** — the four most urgent submissions, colour-coded, straight to the assessment
screen.

**Per-course cards** showing enrolments, certified, completion rate and 30-day activity.
Completion is highlighted when it drops **under 20% with more than five enrolled** — a
course nobody finishes is a content problem, and the instructor is the only person who
can fix it.

**Recently assessed** — the last five verdicts, so an instructor can see what they said
before a resubmission of the same work lands.

Three views back it (`0011`), so the numbers an instructor sees and the numbers in the
owner console come from the same place.

New courses moved to `/studio/new`, which keeps the dashboard about the work rather than
about starting more of it.

### Date of birth is a learner question

Instructors and institutions confirm **18 or over** with a checkbox instead of giving a
date. Nothing downstream reads their date, so asking for it collects data we do not need.

The assertion is still recorded, because it is not decorative: instructors get paid and
assess work submitted by under-18s, and institution admins hold children's records. What
changed is that we stopped storing a birthday to establish it.

Learners still give a full date — for them the answer decides which protections apply and
whether a guardian has to confirm.

### Step progress on every signup screen

`StepProgress` — three dots, a label each, a fill bar. People abandon forms they cannot
see the end of, and this costs nothing.

### The course editor collapses

Five sections, each collapsible, each carrying a summary of its own state so a closed
section still tells you whether it needs attention — "3 modules, 8 topics, 5 questions",
or "Nothing yet — two criteria minimum". Ticks appear as each is satisfied.

Topic panels nest the same pattern: Teaching, Materials, Quiz.

Sections open themselves when they are the thing to do next — the basics on a new course,
the curriculum when it has topics but fewer than three, the submit gate once everything
passes. Fully open, the editor ran to several screens of inputs before an instructor had
typed anything, which is how people abandon a form.

---

## Every dashboard is a sidebar app

All five signed-in surfaces — learner, studio, review, institution, console — now share
`AppShell`: a grouped left rail, a slim top bar, and a content column. Same structure,
different rails.

### Why grouped rather than flat

A studio contains three different jobs — building courses, assessing work, getting paid.
A flat list of seven links makes them look equivalent. Headings separate them, and live
badges show where the work is: the review queue carries its depth, the operator's queues
carry theirs, an unverified institution shows an exclamation.

### The pattern on each home page

**Greeting** — time-aware, with a one-line summary of where things stand.

**To-dos** — what is actually waiting on this person, most time-sensitive first. When
there is nothing, it says so rather than vanishing; a section that disappears reads as
broken.

**Panels** — the tinted cards for things somebody might do next, in the Edura bento
accents rather than a single brand colour.

The console reuses the same shell with the dark palette layered over it, because owner
work and operator work should not look identical.

### What went

`DashNav` (the tab strip) and `AppBar` (the old top bar) are removed — the rail does both
jobs. Pages no longer wrap themselves in `<main class="rev__main"><div class="wrap">`;
the shell provides that.

---

## Student features

Run `0012_student.sql`.

### Thumbnails, and why they are required

Courses had no image anywhere. A catalogue of text blocks does not get browsed, so a
thumbnail is now a **publication requirement** — `submit_course_for_review` refuses
without one, alongside the topic, quiz, brief and rubric checks.

The bucket is **public**, unlike submissions and verification documents. Thumbnails
appear on the marketing catalogue, which is served to people who are not signed in, and
a signed URL per card would mean twenty round-trips to render one page.

Alt text is required at upload — screen readers and search both use it, and asking for it
once at upload is easier than chasing it later.

Courses without one still render as a card: `CourseThumb` falls back to a tinted panel
carrying the subject initials, in that subject's accent. A gap where an image should be
looks broken; a coloured panel looks deliberate.

### The player resumes

Third-party players do not expose `currentTime` across origins, so `Player` counts
elapsed wall-clock time while the tab is visible and writes it every thirty seconds and
on `pagehide`. It is approximate. Approximate is enough to put somebody back near where
they stopped, and losing your place in a twelve-minute video is a small thing that stops
people returning.

Coming back offers to resume or start over, rather than deciding for them.

### Search

`search_courses` — Postgres full text over titles, summaries, subjects, segments and
topic titles. More than enough at this catalogue size, and it avoids running a second
service.

The empty state asks them to tell us what was missing, because a search with no results
is the most useful signal you get about what to commission next.

### Saved courses

A star on the course page, a list at `/dashboard/saved`. Somebody who finds three courses
they want and has time for one needs somewhere to put the other two.

### Notes

Per topic, private, and the interface says so — nobody assessing their project sees them.
Saved on demand rather than continuously, so the learner knows where they stand.

---

## 18+ platform, no learner segments

Run `0013_adults_only.sql`.

### What went, and what that removed

Your Brand is now for adults. Signup asks you to confirm you are 18 or over — one checkbox,
no date of birth stored. Gone with it: the age gate, parental consent, the fourteen-day
expiry, guardian management links, and name suppression on certificates.

Consent records already in the table are **kept, not dropped**. They are the evidence
that consent was properly obtained for accounts created under the old rules, and deleting
that evidence would be the wrong instinct. Anyone left mid-consent is suspended rather
than silently promoted to an adult account.

Organisations are now responsible for confirming their own learners are adults, which is
written into the data processing terms rather than enforced in our signup.

### Segments replaced by level

The five learner segments are gone. An adult deciding whether a course suits them is
better served by a difficulty level and an hours estimate than by being asked to pick a
bracket for themselves.

Courses now carry **level** (beginner, intermediate, advanced) and an **hours range**.
Both are publication requirements — a card without them cannot be judged.

Hours are a range because a single number reads as a promise.

### Alison-style catalogue

`CourseCard` is used everywhere a course appears: thumbnail, level badge, free badge,
subject, title, instructor, then the line a learner actually decides on — hours and how
many others have taken it.

`SubjectGrid` shows the six subjects with live counts. A subject with no number reads as
a placeholder; a count tells somebody there is something behind it.

Filters are subject, level, and free-only, plus full text search. Three axes that
describe the course rather than the person.

Two views back this: `subject_counts` and `course_cards`, so the homepage, catalogue and
saved list all read the same numbers.

## Learner dashboard

Run `0014_learner_stats.sql`.

Rebuilt on the pattern in the reference: profile block in the rail, a stat row, tabs with
counts, and **rows rather than cards** for courses in progress.

Rows are the right shape here because the decision is "carry on with which one", and that
needs a progress bar, how stale it is, and how much is left — none of which fits a card.

### The four numbers

**Courses completed** as "2 of 5" rather than a bare count, so the denominator is visible.

**Start to completion** — of the courses you began, how many you finished. The honest
version of a completion rate.

**Average quiz score** takes the **best attempt per topic**, not every attempt. Retakes
are unlimited by design, and averaging all of them would punish somebody for practising.

**Certificates earned**, which is the one that matters.

### Tabs carry counts

Somebody with nothing saved can see that without clicking into an empty list. The
separate `/dashboard/courses` and `/dashboard/saved` routes are gone — they are views of
the same list.

### Rows

Last activity is relative — "over 30 days ago" rather than a date, because the point is
staleness, and it turns amber past thirty days.

Time remaining comes from the instructor's hours estimate and how far through they are.
It is an estimate presented as one.

The button changes with state: start, continue, submit the project, being assessed, or
see the certificate. One control that always does the next right thing.

---

## Security fixes — object-level authorization

Run `0015_cohort_pin_lockout.sql`.

Three surfaces checked *what role* the caller had but never *whether the record
was theirs*. Because every server action reaches for `createAdminClient()`,
which bypasses RLS, Postgres never got a chance to catch it either — the id
arriving from the form or the URL was trusted the moment the role check passed.

- **Studio.** `requireCourseAccess(courseId)` replaces the bare role check in
  every course-mutating action. `courseIdForModule/Topic/Material` resolve a
  child id back to its course first, so a module, topic, quiz item, rubric
  criterion or material can only be touched through a course the caller owns.
  Operators still pass through.
- **Cohorts.** `requireCohortAccess(cohortId)` resolves the caller's own
  institution and compares it to the cohort's. `resetPin` additionally checks
  the seat belongs to that cohort — the cohort check alone does not prove a
  mismatched seat id is in scope. The cohort page itself now 404s rather than
  rendering another organisation's roster.
- **Review.** `recordReview` and `/review/[submissionId]` both require the
  submission to be assigned to the caller. Without it, any instructor could
  read another learner's private files and bank the $18.85.

The pattern to keep: **an id that arrived from the client is not a permission.**
A role says which surface someone may use; it never says which row. Either use
an ownership-checked helper, or go through the user-scoped client in
`lib/supabase/server.ts` so RLS enforces it.

### Also closed

**Stored XSS on the public course page.** `JSON.stringify` does not escape `<`,
so an instructor-authored title containing `</script>` broke out of the JSON-LD
tag. Now escaped to `\u003c`. Worth noting `saveCourseDetails` has no state
check, so a published title can still be edited without re-review.

**Cohort PIN brute force.** A 6-digit PIN had no lockout — the quiz has one
precisely because four options are guessable, and a PIN is worth more. Five
failures in fifteen minutes now locks the seat for fifteen. Only failures are
recorded, so the window ages out on its own.

**Username enumeration.** The join form gave a different error for an unknown
username than for a wrong PIN, so anyone holding a class code could list every
valid username in it before guessing anything. One message now covers all three
fields.

**`CRON_SECRET`** is compared with `timingSafeEqual` rather than `===`.

**Pre-existing build failure.** `RowCourse` was missing `enrolment_id` and
`course_id`, both of which `learner_courses` returns and the dashboard uses.
`npm run build` failed on it before any of the above.

---

## Google and LinkedIn sign-in

Run `0016_oauth_profile_name.sql`.

Buttons on `/login` and `/signup`, posting to `signInWithGoogle` /
`signInWithLinkedIn` in `app/actions/auth.ts`. Both go through the existing
`/auth/callback` route — the same one email verification and password reset
already use.

### It only creates learner accounts

Deliberately. Instructor signup needs a headline and institution signup needs an
organisation name and country, and all of it has to be captured *before* the
account exists. An OAuth redirect leaves the app before any of those fields are
on screen. Those two intents still go through `/signup` → intent → details.

The buttons say so rather than failing silently three screens later.

### No age step

`handle_new_user()` already defaults `account_type` to `adult` when signup
metadata is absent, which is exactly what an OAuth-created `auth.users` row
looks like. The 18+ confirmation is surfaced as a line of copy next to the
buttons rather than an extra screen — the same commitment, one fewer step.

### The name comes from the provider

`handle_new_user()` read only `display_name`, a key this app sets itself.
Google and LinkedIn send `full_name` / `name`, so an OAuth account previously
landed with a null display name — a blank greeting, a blank certificate, and
"Learner" in every reviewer-facing view. It now falls back through all three,
with our own key first so the email path is unchanged.

### Suspended accounts

The password path refuses them; the callback now does too, or OAuth would have
been a way straight back in. `/auth/callback` also refuses any `next` that is
not an app-relative path — an open redirect there would be handed a live
session on the way out.

### Configuring the providers

Credentials live in Supabase, not in `.env` — there is nothing to add to
`.env.example`.

1. **Google.** Google Cloud Console → APIs & Services → Credentials → OAuth
   client ID (Web application). Authorised redirect URI:
   `https://<project-ref>.supabase.co/auth/v1/callback`.
2. **LinkedIn.** LinkedIn Developers → your app → Auth. Request the *Sign In
   with LinkedIn using OpenID Connect* product. Same redirect URI.
3. Supabase → Authentication → Providers → enable **Google** and **LinkedIn
   (OIDC)**, paste each client ID and secret.
4. Supabase → Authentication → URL Configuration → confirm
   `<site-url>/auth/callback` is in the redirect list. It already is if email
   verification works.

The provider is `linkedin_oidc`, not `linkedin` — the older one is deprecated.

### Worth knowing

`/login` is now server-rendered rather than static, because it reads
`?error=`. It is a form page behind no SEO value, so this is a fair trade, but
it is a change: if you would rather keep it static, move the error read into
`LoginForm` with `useSearchParams`.

---

## Sara's model provider

`lib/llm.ts` is the only place that talks to a model. The route builds the
prompt and enforces the rate limit; the provider layer decides who answers.

Gemini is used when `GEMINI_API_KEY` is set, Anthropic when only
`ANTHROPIC_API_KEY` is. Neither, and the assistant reports itself
unconfigured rather than failing oddly. Switching provider is an environment
change and a redeploy.

**Free-tier model ids move.** Google adds, renames and drops models from the
free row without much notice, so the id is `GEMINI_MODEL` rather than a
constant. If Sara starts 404ing, check the current id in Google AI Studio
first — that is the likeliest cause by a distance.

**Two things the free tier costs you.** There is a daily request cap in the
low hundreds on Flash models, well under what the app's own rate limits
allow, so a busy day will hit Google's ceiling before it hits ours — the
route returns a 429 saying Sara is done for the day rather than a generic
error. And Google may use free-tier prompts to improve their models. Learners
type odd things into a chat box; if that matters, the paid tier or Anthropic
does not train on the input.

Prompt, catalogue grounding, role notes and rate limits are provider-agnostic
and unchanged.


---

## Video hosting

`topics.video_uid` holds whatever identifies the asset, and `lib/video.ts`
works out the provider from the value itself. Topics can therefore mix
sources, and moving a lesson between providers is a field edit rather than a
migration.

| Put this in the field | What happens | Cost |
| --- | --- | --- |
| `https://youtu.be/abc123…` or a bare 11-char id | youtube-nocookie embed, `rel=0` so other people's videos are not suggested at the end of a paid lesson | Free |
| `https://vimeo.com/12345` | Vimeo player, `dnt=1` | Free tier is small |
| `<user-id>/lesson.mp4` (a slash) | Private Supabase `videos` bucket, played through a one-hour signed URL | Free tier: ~1GB stored, 5GB egress/month |
| Anything else | Bunny Stream asset, needs `NEXT_PUBLIC_BUNNY_LIBRARY_ID` | ~$1/month minimum |

**Only the bucket route enforces the paywall.** The signed URL is minted in
the learn page *after* the existing access check, so an unentitled learner
never receives a playable link. A YouTube unlisted link, by contrast, plays
for anybody who has it — fine while testing, not something to put paid
content behind once there are paying learners.

**Self-hosted files get better progress tracking.** A same-origin `<video>`
exposes `currentTime`, so resume position is real. Third-party iframes do
not, which is why those still fall back to counting wall-clock seconds while
the tab is visible.

No transcoding happens on the bucket route — upload a web-ready MP4
(H.264/AAC, 720p is plenty) or browsers will struggle.


---

## Pricing and currency

Currency is resolved per visitor from Vercel's `x-vercel-ip-country` header
and mapped in `lib/pricing.ts`. (Superseded: sales are now charged in the
single `SALE_CURRENCY`, and payments go through Paystack — see "Payments"
in MARKETPLACE.md.)

**Prices are a fixed table per currency, not a converted USD amount.** A
stored exchange rate goes stale and starts quietly underselling: a 30% naira
move means somebody buys Complete for the price of Starter. A live FX call
would instead put a third-party outage between a customer and checkout.
Round local numbers also read as prices rather than as conversions.

The table in `lib/pricing.ts` is set at plausible round values and **needs
reviewing before real payments**. Local purchasing power, not the spot rate,
is what should set them — $11 is a different proposition in Lagos than in
London, and that is the main argument for geo-pricing in the first place.

Geo is a default, not a verdict: the billing page offers a currency switcher,
because VPNs and travellers exist. Whatever is chosen is stored on the
checkout intent, and the webhook validates the paid amount against *that*
currency — comparing a naira payment to a dollar figure would pass trivially.

Only currencies Paystack settles can actually be charged (NGN, GHS, ZAR,
KES, XOF, EGP, and USD once enabled on the account).

**One copy conflict to resolve:** the marketing homepage says "The same three
plans and the same prices everywhere in the world" and the footer says "Same
plans and prices everywhere. Shown in USD." Both are now false. They need
rewriting before launch.

---

## Payment confirmation, homepage routing, audit fixes

### The receipt

`paymentConfirmed` in `lib/notifications.ts`, sent from `fulfilPayment` **inside the
`!already` guard**. Both the webhook and the return page call fulfilment, so sending
outside that guard would confirm the same payment twice.

It doubles as the receipt: amount, provider reference, renewal date. Somebody who has
just paid wants three things — that it worked, what they now have, and when they will be
charged again.

`sendReceipt` never throws. A failed email must not turn a successful payment into a
failed fulfilment: the money is already taken and the access is already granted.

Cohort learners are skipped — their synthetic address goes nowhere.

### Signed-in visitors skip the pitch

`/` now redirects by role: instructors to `/studio`, institution admins to
`/institution`, operators to `/admin/sla`, everyone else to `/dashboard`.

The marketing page moved into `components/MarketingHome.tsx` and is rendered by both `/`
(for signed-out visitors) and `/home` (always). **One copy** — two copies of a 700-line
page drift, and the one nobody looks at goes stale.

### Audit items closed

**`app/plans/` deleted.** Orphaned duplicate of `/dashboard/plans`, priced from the
USD-only table so a Nigerian visitor saw `$13` and was charged `₦8,000`. It also carried
the `.maybeSingle()` bug fixed in `0026`.

**CI replaced.** `pages.yml` deployed a static export, impossible for an SSR app, so it
failed on every push — and a build that always fails teaches people to ignore the red
mark. Now `checks.yml`: `tsc --noEmit` then `next build`.

**Container queries finished.** Fourteen more rules moved off viewport queries onto
`@container body`, because with the navigation open a column can be 400px inside a 1300px
window and a media query never fires.

Two things this turned up that the first pass missed:

- Converting only the *mid* breakpoints left the narrow ones on viewport, and since the
  container blocks sit later in the file they would have won at equal specificity — two
  columns on a phone. Both had to move, ordered widest-first so the narrower wins.
- `.stats3` was already handled by `@container pancol`, which measures the actual column
  the tiles live in. The body-level rule added was redundant and coarser, and was removed.

No selector now appears in both a `@media` and a `@container` block.

**`.maybeSingle()` sweep.** The two remaining flags are false positives — both filter on
`profiles.id`, the primary key.

---

## Mobile, rebuilt against a real browser

Rendered at 390×844 in headless Chromium rather than reasoned about. The blocked
Playwright CDN is worked around by installing `@sparticuz/chromium` from npm and
extracting its brotli-compressed binary — the browser CDN is blocked at the network
layer, npm is not.

### The viewport meta tag was missing entirely

Every page rendered at the browser's 980px fallback and was scaled down to fit. Text
unreadably small, every media query behaving as though it were a desktop. This affected
the whole site and nothing in the CSS could have compensated for it.

`maximumScale` is deliberately absent — capping zoom stops people who need to enlarge
text and buys nothing.

### One navigation, not two

`MobileTabs` is deleted. It duplicated the rail's destinations in a second component, and
two lists of the same thing drift apart. The rail now runs on every screen: slim by
default, expanding on hover, toggled by the button where there is no hover. On a phone
it narrows to 60px and its panel overlays rather than pushes.

### Square

`--r`, `--r-lg` and `--r-xl` are `0`. Cards, panels, inputs and the video frame are
rectangles. Pills, avatars, progress bars and icon tiles keep their radius — squaring
those reads as a mistake rather than a decision.

### Colour

Six saturated pairs, one per subject, carried consistently across the subject tile, the
card spine and the badge, so a learner starts recognising "the teal one" before reading
the label. Each pair is a fill plus an ink that clears 4.5:1 on it.

The promo panel follows the second reference: gradient, two cropped circles, coral
button.

### Fixed, all found by rendering

- The announcement bar took three lines before any content; now one, truncated, with the
  secondary links dropped since they are in the menu anyway.
- "Popular searches" rendered as `Prompt engineering,Bookkeeping` — JSX collapses the
  newline after a comma. Now chips on mobile, with real search links.
- Filter chips were 31px, the search field ~140px wide with a truncated placeholder.
  Both were fixed twice: the first attempt used `pointer:coarse`, which a touchscreen
  laptop matches and a headless browser does not, and `.cat__side .fchip` outranked a
  bare `.fchip` on specificity regardless of source order.
- The assistant pill shrinks to its icon on a phone, so a fixed element obstructs a
  thumb-sized circle rather than a 150px bar.
- `6 × 5 — Subjects by learner type` was left over from the five-segment model removed
  two releases ago.

### Side navigation — repaired

Enabling the rail on mobile exposed that it had been broken for a while and only ever
seen on desktop, where the old rules still happened to cover it.

**The stylesheet was a generation behind the component.** `AppSidebar` had been rewritten
around `.nv__inner` / `.nv__head` / `.nv__nav` / `.nv__group` / `.nv__heading`, while
`globals.css` still carried only the older `.nv__rail` set. Six of ten classes had no
rules at all — unstyled links stacked in source order, an avatar with no box, the name
overlapping its own "View profile" link. 47 dead rules for the retired generation are
removed.

**"Browse courses" appeared twice** — once from the Discover group and again from a
hardcoded link in the sidebar footer. The footer copy is gone.

**The rail collapsed to 14px** once its panel became absolutely positioned: the shell's
grid column is `auto`, so with nothing in flow to measure, the track sized to the
padding. The rail now carries an explicit width and only the overlay animates — widening
the rail itself reflows the page under a pointer already moving toward a target.

**On a phone** the rail narrows to 62px and the panel becomes a sheet, since 266px of a
390px screen is most of it. Hover does not exist there, so only the toggle opens it.

Verified at four states — slim, expanded, phone, phone expanded — by rendering the
component against the real stylesheet rather than by reading it.

### Mobile is a hamburger, not a rail

A permanent 62px rail costs a sixth of a 390px screen for something reached a few times
a session, and there is no hover on a phone to expand it with. So below 1000px the rail
is a sheet: off-screen at `translate:-100% 0`, opened by a hamburger in the top bar,
closed by the scrim, by Escape, or by navigating.

The toggle has to live in the top bar rather than inside the sheet — a button inside an
off-screen panel can never open it. `NavToggle` flips the class on `.nv` and listens for
a close event the sidebar dispatches, which keeps one source of truth without lifting a
single boolean into a context provider.

The scrim renders after the `<aside>` so `.nv.is-open + .nv__scrim` matches; before it,
the sibling selector could never fire.

Above 1000px nothing changes: the rail is always present, slim by default, widening on
hover, and the hamburger is hidden because a button to reveal something already on screen
is noise.

### Controls keep their corners

Squaring everything took the radius off buttons and inputs too, and a pressable thing
reads as pressable partly from its shape — a square button is a flat block of colour.

`--r-btn: 10px` is a separate token from the card radius, so the two can move
independently. Cards, panels and the video frame stay rectangles; buttons, inputs,
selects, textareas and the nav toggles get 10px; chips, tags and the assistant pill stay
fully round, because there the shape is the affordance.
