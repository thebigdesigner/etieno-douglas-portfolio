import Link from "next/link";
import { Suspense } from "react";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import DashTabs from "@/components/DashTabs";
import CourseRow, { type RowCourse } from "@/components/CourseRow";
import CourseCard, { type CardCourse } from "@/components/CourseCard";

export const metadata = { title: "My courses" };
export const dynamic = "force-dynamic";

type SearchParams = Promise<{ view?: string }>;

type OutlineRow = { topic_id: string; completed: boolean; unlocked: boolean };

/**
 * The course list used to live only as a card on the dashboard, and the rail's
 * "My courses" pointed at /dashboard?view=progress — the default view of the
 * page you were already on, so clicking it appeared to do nothing. This is the
 * real destination.
 */
export default async function MyCoursesPage({ searchParams }: { searchParams: SearchParams }) {
  const { view = "progress" } = await searchParams;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const admin = createAdminClient();

  const [{ data: enrolled }, { data: saved }] = await Promise.all([
    admin.from("learner_courses").select("*").eq("user_id", user!.id)
      .order("last_active", { ascending: false, nullsFirst: false }),
    admin.from("saved_courses")
      .select("courses(slug, title, summary, subject, level, hours_low, hours_high, is_free, thumbnail_path)")
      .eq("user_id", user!.id),
  ]);

  const all = (enrolled ?? []) as RowCourse[];
  const inProgress = all.filter((c) => Number(c.pct ?? 0) < 100);
  const completed = all.filter((c) => Number(c.pct ?? 0) >= 100);
  const certified = all.filter((c) => c.certificate_code);

  const savedCourses: CardCourse[] = [];
  for (const row of saved ?? []) {
    const c = row.courses as unknown as CardCourse | null;
    if (c) savedCourses.push(c);
  }

  // Resume links, only for the rows actually shown.
  const shown = (view === "completed" ? completed : inProgress).slice(0, 24);
  const withNext = await Promise.all(
    shown.map(async (c) => {
      if (Number(c.pct ?? 0) >= 100) return c;
      const { data: outline } = await admin.rpc("course_outline", {
        p_course_id: c.course_id, p_user_id: user!.id,
      });
      const rows = (outline ?? []) as OutlineRow[];
      const nextTopic = rows.find((t) => !t.completed && t.unlocked) ?? rows[0];
      return { ...c, nextTopicId: nextTopic?.topic_id ?? null };
    })
  );

  return (
    <>
      <div className="dash__bar">
        <div>
          <div className="eyebrow">Your learning</div>
          <h1 className="dash__title">My courses</h1>
        </div>
        <Link className="btn btn--fill" href="/courses">Browse the catalogue</Link>
      </div>

      <div className="card" style={{ marginTop: 22 }}>
        <Suspense fallback={<div className="dtabs" />}>
          <DashTabs tabs={[
            { label: "In progress", value: "progress", count: inProgress.length },
            { label: "Completed", value: "completed", count: completed.length },
            { label: "Certificates", value: "certificates", count: certified.length },
            { label: "Saved", value: "saved", count: savedCourses.length },
          ]} />
        </Suspense>

        {view === "saved" ? (
          savedCourses.length === 0 ? (
            <Empty
              title="Nothing saved yet"
              body="Star a course while you are browsing and it waits here. Useful when you find three you want and have time for one."
            />
          ) : (
            <div className="ccards ccards--list">
              {/* Rows, like the other tabs in this panel. The dashboard's own
                  Saved tab was changed and this one was missed — two pages
                  render the same tab set and only one of them was fixed. */}
              {savedCourses.map((c) => <CourseCard key={c.slug} course={c} />)}
            </div>
          )
        ) : view === "certificates" ? (
          certified.length === 0 ? (
            <Empty
              title="No certificates yet"
              body="Finish a course, submit the final project, and a working practitioner assesses it within four working days."
            />
          ) : (
            <div className="crows">
              {certified.map((c) => <CourseRow key={c.enrolment_id} course={c} />)}
            </div>
          )
        ) : withNext.length === 0 ? (
          <Empty
            title={view === "completed" ? "Nothing finished yet" : "You have not started anything"}
            body={
              view === "completed"
                ? "Courses you finish every topic of will appear here, ready for the final project."
                : "The first topic of every course is free, so you can look around before deciding on anything."
            }
          />
        ) : (
          <div className="crows">
            {withNext.map((c) => <CourseRow key={c.enrolment_id} course={c} />)}
          </div>
        )}
      </div>
    </>
  );
}

function Empty({ title, body }: { title: string; body: string }) {
  return (
    <div className="empty" style={{ marginTop: 24 }}>
      <p className="empty__h">{title}</p>
      <p className="empty__p">{body}</p>
      <Link className="btn btn--fill btn--lg" href="/courses" style={{ marginTop: 20 }}>
        Browse courses
      </Link>
    </div>
  );
}
