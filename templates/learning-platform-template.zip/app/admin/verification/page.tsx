import { createAdminClient } from "@/lib/supabase/admin";
import VerificationDecision from "./VerificationDecision";

export const metadata = { title: "Verification queue" };
export const dynamic = "force-dynamic";

export default async function VerificationQueuePage() {
  const admin = createAdminClient();

  const { data: institutions } = await admin
    .from("institutions")
    .select("id, name, contact_email, country, website, submitted_at, owner_id")
    .eq("verification", "pending")
    .order("submitted_at", { ascending: true });

  const rows = institutions ?? [];
  const ids = rows.map((i) => i.id);

  const { data: docs } = ids.length
    ? await admin.from("institution_documents")
        .select("id, institution_id, kind, filename, path").in("institution_id", ids)
    : { data: [] };

  // Signed links, one hour. The bucket is private.
  const linked = await Promise.all(
    (docs ?? []).map(async (d) => {
      const { data } = await admin.storage.from("verification").createSignedUrl(d.path, 3600);
      return { ...d, url: data?.signedUrl ?? null };
    })
  );

  return (
    <>
        <h1 className="sec__h" style={{ fontSize: 30, marginTop: 34 }}>
          {rows.length} awaiting verification
        </h1>
        <p className="sec__meta">
          They can already use the account — this decides whether they can enrol learners.
          Some of those learners will be children, which is what this check is for.
        </p>

        {rows.length === 0 ? (
          <div className="empty" style={{ marginTop: 28 }}>
            <p className="empty__h">Nothing waiting</p>
            <p className="empty__p">Organisations appear here when they submit documents.</p>
          </div>
        ) : (
          <div className="apps">
            {rows.map((i) => {
              const mine = linked.filter((d) => d.institution_id === i.id);
              return (
                <article key={i.id} className="app">
                  <div className="app__head">
                    <div>
                      <div className="app__name">{i.name}</div>
                      <div className="app__hl">
                        {i.country} · {i.contact_email}
                        {i.website && (
                          <> · <a href={i.website} target="_blank" rel="noreferrer">{i.website}</a></>
                        )}
                      </div>
                    </div>
                    <span className="rq__sub num">
                      {i.submitted_at && new Date(i.submitted_at).toLocaleDateString()}
                    </span>
                  </div>

                  <div className="app__field">
                    <div className="eyebrow">Documents</div>
                    <div className="rvw__files" style={{ marginTop: 10 }}>
                      {mine.length === 0 ? (
                        <span className="studio__hint">None attached.</span>
                      ) : mine.map((d) => (
                        <a key={d.id} className="rvw__file" href={d.url ?? "#"}
                          target="_blank" rel="noreferrer">
                          {d.filename}
                        </a>
                      ))}
                    </div>
                  </div>

                  <VerificationDecision institutionId={i.id} />
                </article>
              );
            })}
          </div>
        )}
      </>
  );
}
