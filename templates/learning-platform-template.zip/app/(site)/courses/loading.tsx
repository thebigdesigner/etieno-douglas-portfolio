export default function Loading() {
  return (
    <main className="sec">
      <div className="wrap">
        <div className="skel skel--h" />
        <div className="skel skel--p" />
        <div className="courses" style={{ marginTop: 34 }}>
          {[0, 1, 2, 3].map((i) => (
            <div key={i} className="crs">
              <div className="skel skel--line" style={{ width: "70%" }} />
              <div className="skel skel--line" style={{ width: "95%", marginTop: 14 }} />
              <div className="skel skel--line" style={{ width: "60%", marginTop: 8 }} />
              <div className="skel skel--pill" style={{ marginTop: 20 }} />
            </div>
          ))}
        </div>
      </div>
    </main>
  );
}
