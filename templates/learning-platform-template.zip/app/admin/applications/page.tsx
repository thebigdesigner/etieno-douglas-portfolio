import { createAdminClient } from "@/lib/supabase/admin";
import DecisionForm from "./DecisionForm";

export const metadata = { title: "Instructor applications" };
export const dynamic = "force-dynamic";

export default async function ApplicationsPage() {
  const admin = createAdminClient();

  const { data: apps } = await admin
    .from("instructors")
    .select("id, headline, bio, proposed_course, work_sample, applied_at, profiles(display_name, email)")
    .eq("state", "applied")
    .order("applied_at", { ascending: true });

  const rows = apps ?? [];

  return (
    <>
        <h1 className="sec__h" style={{ fontSize: 30, marginTop: 34 }}>
          {rows.length} application{rows.length === 1 ? "" : "s"}
        </h1>
        <p className="sec__meta">
          Approval stays manual. We look for people who currently do the work, can say
          specifically why something is good, and can hold four days.
        </p>

        {rows.length === 0 ? (
          <div className="empty" style={{ marginTop: 28 }}>
            <p className="empty__h">Nothing waiting</p>
            <p className="empty__p">New applications appear here as they come in.</p>
          </div>
        ) : (
          <div className="apps">
            {rows.map((a) => {
              const p = a.profiles as unknown as { display_name: string; email: string } | null;
              return (
                <article key={a.id} className="app">
                  <div className="app__head">
                    <div>
                      <div className="app__name">{p?.display_name ?? "Applicant"}</div>
                      <div className="app__hl">{a.headline}</div>
                    </div>
                    <span className="rq__sub num">
                      {new Date(a.applied_at).toLocaleDateString()}
                    </span>
                  </div>

                  <div className="app__field">
                    <div className="eyebrow">About their work</div>
                    <p>{a.bio}</p>
                  </div>
                  <div className="app__field">
                    <div className="eyebrow">Course they would teach</div>
                    <p>{a.proposed_course}</p>
                  </div>
                  {a.work_sample && (
                    <div className="app__field">
                      <div className="eyebrow">Sample</div>
                      <p><a href={a.work_sample} target="_blank" rel="noreferrer">{a.work_sample}</a></p>
                    </div>
                  )}

                  <DecisionForm instructorId={a.id} />
                </article>
              );
            })}
          </div>
        )}
      </>
  );
}
