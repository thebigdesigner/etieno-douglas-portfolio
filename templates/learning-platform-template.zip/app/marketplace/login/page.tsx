import type { Metadata } from "next";
import Link from "next/link";
import { redirect } from "next/navigation";
import { marketBase, mk } from "@/lib/marketplace/url";
import { mkNext } from "@/lib/marketplace/next";
import { studioViewer } from "@/lib/marketplace/studio";
import AuthShell from "@/components/marketplace/auth/AuthShell";
import { GoogleButton, LoginForm } from "@/components/marketplace/auth/AuthForms";

export const metadata: Metadata = { title: "Sign in", robots: { index: false } };

type Props = { searchParams: Promise<{ next?: string; error?: string }> };

export default async function MarketLogin({ searchParams }: Props) {
  const [sp, base] = await Promise.all([searchParams, marketBase()]);
  const next = mkNext(sp.next);
  if (await studioViewer().catch(() => null)) redirect(mk(base, next));
  const q = next === "/" ? "" : `?next=${encodeURIComponent(next)}`;
  return (
    <AuthShell homeHref={mk(base, "/")} title="Sign in to buy and sell" lead="Use your Your Brand account. The same one works on Your Brand Academy."
      foot={<>New to Your Brand? <Link href={mk(base, `/signup${q}`)} className="au__link">Create an account</Link></>}>
      {sp.error === "oauth" && <p className="au__msg au__msg--err" role="alert">Google sign-in did not complete. Try again, or use your email.</p>}
      <GoogleButton next={next} />
      <div className="au__or"><span>or with email</span></div>
      <LoginForm next={next} forgotHref={mk(base, "/forgot")} />
    </AuthShell>
  );
}
