"use server";

import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { markArrival } from "@/lib/arrival";
import { track } from "@/lib/track";
import { DELETED_ACCOUNT } from "@/lib/account-messages";
import { marketBase, mk } from "@/lib/marketplace/url";
import { marketCallback } from "@/lib/marketplace/origin";
import type { FormState } from "@/lib/forms";

/**
 * Marketplace sign-in and signup. One Your Brand account underneath — the
 * same auth user and profiles row the Academy uses, created by the same
 * handle_new_user() trigger — but every screen and every redirect stays in
 * the marketplace. Only the wording and the destination differ from
 * app/actions/auth.ts; the account checks are the same ones.
 */

const EMAIL = /^[^@\s]+@[^@\s]+\.[^@\s]+$/;

/** Where to go after signing in: a path inside the marketplace, never elsewhere. */
function nextPath(raw: FormDataEntryValue | null): string {
  const v = typeof raw === "string" ? raw : "";
  // Short form only ("/studio", "/item/x"). mk() adds /marketplace when needed.
  if (!v.startsWith("/") || v.startsWith("//") || v.includes("\\") || v.startsWith("/marketplace")) return "/";
  return v;
}

async function go(path: string): Promise<never> {
  redirect(mk(await marketBase(), path));
}

export async function mkLogin(_prev: FormState, fd: FormData): Promise<FormState> {
  const email = String(fd.get("email") ?? "").trim().toLowerCase();
  const password = String(fd.get("password") ?? "");
  if (!EMAIL.test(email) || !password) return { error: "Enter your email and password." };

  const supabase = await createClient();
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });
  if (error) {
    if (error.message.toLowerCase().includes("confirm")) {
      return { error: "Confirm your email first — the link is in your inbox. Check spam if it is not there." };
    }
    return { error: "That email and password do not match. Please try again." };
  }

  // Same three refusals as the Academy login, for the same reasons.
  const { data: profile } = await supabase.from("profiles").select("status").eq("id", data.user.id).maybeSingle();
  if (!profile) { await supabase.auth.signOut(); return { error: "We could not open that account. Please contact hello@yourbrand.com." }; }
  if (profile.status === "deleted") { await supabase.auth.signOut(); return { error: DELETED_ACCOUNT }; }
  if (profile.status === "suspended") { await supabase.auth.signOut(); return { error: "This account is suspended. Contact support if you think that is wrong." }; }

  await markArrival();
  return go(nextPath(fd.get("next")));
}

export async function mkSignup(_prev: FormState, fd: FormData): Promise<FormState> {
  const name = String(fd.get("display_name") ?? "").trim();
  const email = String(fd.get("email") ?? "").trim().toLowerCase();
  const password = String(fd.get("password") ?? "");
  const next = nextPath(fd.get("next"));

  if (name.length < 2) return { error: "Please enter your name." };
  if (!EMAIL.test(email)) return { error: "Please enter a valid email address." };
  if (password.length < 8) return { error: "Your password needs to be at least 8 characters." };
  // Buying and selling are contracts; the Academy's minor flow (guardian
  // consent) does not apply here, so the marketplace is adults only.
  if (fd.get("adult") !== "on") return { error: "You need to be 18 or over to buy or sell on the marketplace." };

  const supabase = await createClient();
  const { data, error } = await supabase.auth.signUp({
    email, password,
    options: {
      emailRedirectTo: await marketCallback(next),
      data: { display_name: name, account_type: "adult", intent: "learner", source: "marketplace" },
    },
  });
  if (error) {
    if (error.message.toLowerCase().includes("already")) {
      return { error: "There is already a Your Brand account with that email. Sign in with it instead." };
    }
    return { error: error.message };
  }
  await track("account_created", data.user?.id ?? null, { intent: "learner", source: "marketplace" });

  // Email confirmation on: no session yet, they finish from the link.
  if (!data.session) {
    return { ok: true, message: `Check ${email} for a link to confirm your account. It brings you back here, signed in.` };
  }
  await markArrival();
  return go(next);
}

export async function mkGoogle(fd: FormData): Promise<void> {
  const next = nextPath(fd.get("next"));
  const supabase = await createClient();
  const { data, error } = await supabase.auth.signInWithOAuth({
    provider: "google",
    options: { redirectTo: await marketCallback(next) },
  });
  if (error || !data.url) return go("/login?error=oauth");
  redirect(data.url);
}

export async function mkRequestReset(_prev: FormState, fd: FormData): Promise<FormState> {
  const email = String(fd.get("email") ?? "").trim().toLowerCase();
  if (!EMAIL.test(email)) return { error: "Please enter a valid email address." };
  const supabase = await createClient();
  await supabase.auth.resetPasswordForEmail(email, { redirectTo: await marketCallback("/reset") });
  // Same answer either way, so this page cannot be used to find out who has an account.
  return { ok: true, message: "If there is an account with that address, a reset link is on its way." };
}

export async function mkSetPassword(_prev: FormState, fd: FormData): Promise<FormState> {
  const password = String(fd.get("password") ?? "");
  const confirm = String(fd.get("confirm") ?? "");
  if (password.length < 8) return { error: "Your password needs to be at least 8 characters." };
  if (password !== confirm) return { error: "Those two passwords do not match." };
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return { error: "That reset link has expired. Request a new one." };
  const { error } = await supabase.auth.updateUser({ password });
  if (error) return { error: error.message };
  await markArrival();
  return go("/");
}

export async function mkLogout(): Promise<void> {
  const supabase = await createClient();
  await supabase.auth.signOut();
  return go("/");
}
