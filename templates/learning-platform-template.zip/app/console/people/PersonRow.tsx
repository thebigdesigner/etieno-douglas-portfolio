"use client";

import { useActionState, useState } from "react";
import { useFormStatus } from "react-dom";
import { setRole, grantAllowance, suspendAccount } from "@/app/actions/console";
import type { FormState } from "@/lib/forms";
import Alert from "@/components/Alert";

type Person = {
  id: string; display_name: string | null; email: string | null;
  role: string; status: string; account_type: string; created_at: string;
};

const initial: FormState = {};

function Btn({ label }: { label: string }) {
  const { pending } = useFormStatus();
  return <button className="btn btn--line" disabled={pending}>{pending ? "…" : label}</button>;
}

export default function PersonRow({ person, isSelf }: { person: Person; isSelf: boolean }) {
  const [open, setOpen] = useState(false);
  const [roleState, changeRole] = useActionState(setRole.bind(null, person.id), initial);
  const [allowState, grant] = useActionState(grantAllowance.bind(null, person.id), initial);
  const suspended = person.status === "suspended";
  const [susState, toggle] = useActionState(
    suspendAccount.bind(null, person.id, !suspended), initial
  );

  const isCohort = (person.email ?? "").endsWith("@cohort.splari.internal");

  return (
    <article className={`person${open ? " is-open" : ""}`}>
      <button className="person__head" onClick={() => setOpen(!open)}>
        <div>
          <span className="person__name">{person.display_name ?? "No name"}</span>
          <span className="person__email">
            {isCohort ? "Joined through a school" : person.email}
          </span>
        </div>
        <div className="person__tags">
          {suspended && <span className="pill pill--lock">Suspended</span>}
          <span className={`pill${person.role !== "learner" ? " pill--free" : ""}`}>
            {person.role.replace("_", " ")}
          </span>
        </div>
      </button>

      {open && (
        <div className="person__body">
          <div className="person__meta num">
            Joined {new Date(person.created_at).toLocaleDateString()} · {person.account_type}
          </div>

          {isSelf ? (
            <p className="studio__hint" style={{ marginTop: 14 }}>
              This is you. Role and suspension controls are disabled on your own account
              deliberately — locking yourself out of the console is not a recoverable
              mistake.
            </p>
          ) : (
            <div className="person__acts">
              <form action={changeRole} className="ctools__inline">
                <label className="field">
                  <span className="field__label">Role</span>
                  <select name="role" defaultValue={person.role}>
                    <option value="learner">Learner</option>
                    <option value="instructor">Instructor</option>
                    <option value="institution_admin">Institution admin</option>
                    <option value="operator">Operator</option>
                  </select>
                </label>
                <Btn label="Change" />
              </form>
              {roleState.error && <Alert kind="error">{roleState.error}</Alert>}
              {roleState.ok && <Alert kind="success">{roleState.message}</Alert>}

              <form action={grant} className="ctools__inline">
                <label className="field" style={{ maxWidth: 110 }}>
                  <span className="field__label">Extra certifications</span>
                  <input name="extra" type="number" min={1} max={10} defaultValue={1} />
                </label>
                <label className="field" style={{ maxWidth: 260 }}>
                  <span className="field__label">Why</span>
                  <input name="reason" placeholder="Support case, goodwill, error" required />
                </label>
                <Btn label="Grant" />
              </form>
              {allowState.error && <Alert kind="error">{allowState.error}</Alert>}
              {allowState.ok && <Alert kind="success">{allowState.message}</Alert>}

              <form action={toggle} className="ctools__inline">
                <label className="field" style={{ maxWidth: 300 }}>
                  <span className="field__label">
                    {suspended ? "Restore this account" : "Suspend this account"}
                  </span>
                  <input name="reason" placeholder={suspended ? "Optional" : "Reason — required"}
                    required={!suspended} />
                </label>
                <Btn label={suspended ? "Restore" : "Suspend"} />
              </form>
              {susState.error && <Alert kind="error">{susState.error}</Alert>}
              {susState.ok && <Alert kind="success">{susState.message}</Alert>}
            </div>
          )}
        </div>
      )}
    </article>
  );
}
