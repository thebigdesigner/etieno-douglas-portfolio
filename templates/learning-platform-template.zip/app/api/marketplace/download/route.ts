import { NextResponse } from "next/server";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";

export const dynamic = "force-dynamic";

/**
 * Hands a buyer their file.
 *
 * The bucket is private and has no read policy, so the only way to the
 * file is a signed URL minted here, after checking this person actually
 * owns this item. Ten minutes is long enough to start a download of a
 * large file and short enough that a shared link is worthless.
 *
 * Ownership is a paid order or, for free items, a recorded claim. The
 * product's current price is never trusted: an item that was free when
 * claimed stays claimed even if its creator starts charging.
 */
export async function GET(request: Request) {
  const slug = new URL(request.url).searchParams.get("item") ?? "";
  if (!slug) return NextResponse.json({ error: "no item" }, { status: 400 });

  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) return NextResponse.json({ error: "sign in" }, { status: 401 });

  const admin = createAdminClient();
  const { data: product } = await admin.from("mk_products").select("id, title").eq("slug", slug).maybeSingle();
  if (!product) return NextResponse.json({ error: "no such item" }, { status: 404 });

  const [{ count: paid }, { count: claimed }] = await Promise.all([
    admin.from("mk_orders").select("id", { head: true, count: "exact" })
      .eq("user_id", user.id).eq("product_id", product.id).eq("status", "paid"),
    admin.from("mk_downloads").select("id", { head: true, count: "exact" })
      .eq("user_id", user.id).eq("product_id", product.id),
  ]);
  if (!paid && !claimed) return NextResponse.json({ error: "not yours" }, { status: 403 });

  const { data: file } = await admin.from("mk_product_files")
    .select("path, name").eq("product_id", product.id).maybeSingle();
  if (!file?.path) return NextResponse.json({ error: "no file yet" }, { status: 404 });

  const { data: signed, error } = await admin.storage.from("mk-files")
    .createSignedUrl(file.path, 600, { download: file.name ?? `${slug}.zip` });
  if (error || !signed?.signedUrl) {
    console.error("download: signing failed", slug, error?.message);
    return NextResponse.json({ error: "could not prepare the download" }, { status: 500 });
  }

  // Every download is logged: creators see the count, and a leaked file
  // can be traced back to the account it was taken from.
  await admin.from("mk_downloads").insert({ product_id: product.id, user_id: user.id, order_id: null });

  return NextResponse.redirect(signed.signedUrl, { status: 302 });
}
