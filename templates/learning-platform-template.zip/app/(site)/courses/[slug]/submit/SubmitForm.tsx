"use client";
import { useActionState } from "react";
import { submitProject } from "@/app/actions/review";
import type { FormState } from "@/lib/forms";
import SubmitButton from "@/components/SubmitButton";
import FileDrop from "@/components/FileDrop";
import Alert from "@/components/Alert";

const initial: FormState = {};

export default function SubmitForm({ slug }: { slug: string }) {
  const bound = submitProject.bind(null, slug);
  const [state, action] = useActionState(bound, initial);

  return (
    <form action={action} className="auth__form" style={{ marginTop: 34 }}>
      <label className="field">
        <span className="field__label">Your response</span>
        <textarea name="body" rows={14} required minLength={120} />
        <span className="field__hint">
          Write it here, or summarise and attach the full piece below.
        </span>
      </label>

      <div className="field">
        <span className="field__label">Attachments (optional)</span>
        <FileDrop
          name="files" multiple
          accept=".pdf,.docx,.xlsx,.txt,.png,.jpg,.jpeg"
          maxBytes={20 * 1024 * 1024}
          hint="PDF, Word, Excel, text or images. Up to 20MB each."
        />
      </div>

      {state.error && <Alert kind="error">{state.error}</Alert>}

      <SubmitButton>Send for assessment</SubmitButton>

      <p className="auth__fine">
        A working practitioner will read this within four working days and reply with
        written feedback.
      </p>
    </form>
  );
}
