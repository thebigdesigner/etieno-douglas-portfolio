import Link from "next/link";
import NavIcon from "@/components/NavIcon";
import SearchSuggest from "@/components/SearchSuggest";
import NavToggle from "@/components/NavToggle";
import UserMenu from "@/components/UserMenu";
import NotifBell, { type Notif } from "@/components/NotifBell";
import type { NavGroup } from "@/lib/app-nav";

export default function AppTopBar({
  name, groups, brand, helpHref, avatarPath, email, homeHref = "/dashboard",
  notifications = [], unread = 0, cartHref, cartCount = 0,
  searchPlaceholder = "Search courses…",
}: {
  name?: string | null; groups: NavGroup[]; brand: string;
  helpHref: string; avatarPath?: string | null; email?: string | null;
  homeHref?: string; notifications?: Notif[]; unread?: number;
  /** Only the learner surface has a cart; the others pass nothing. */
  cartHref?: string; cartCount?: number;
  /** What the box searches here — the endpoint branches on role, so the
   *  label should say what it will actually return. */
  searchPlaceholder?: string;
}) {
  return (
    <header className="topbar">
      {/* On a phone the rail is a sheet, so the way into it lives here.
          Hidden above 1000px, where the rail is always present. */}
      <NavToggle />
      <span className="mrail__brand mrail__brand--solo">{brand}</span>

      {/* Search sits in the bar, like the reference. Plain GET form: the
          courses page already reads ?query=, so no client JS is needed. */}
      {/* Was a plain GET form posting ?query= to a page that reads ?q= — so
          every search from the top bar returned the entire catalogue. */}
      {/* The endpoint branches on role, so the label says what this box will
          actually return — "Search courses" on the institution surface was
          naming the one thing it does not look at. */}
      <SearchSuggest className="topbar__search" placeholder={searchPlaceholder} />

      <div className="topbar__right">
        <Link className="topbar__icon" href={helpHref} aria-label="Help" title="Help">
          <NavIcon name="help" size={19} />
        </Link>
        <NotifBell items={notifications} unread={unread} />
        <UserMenu
          cartHref={cartHref} cartCount={cartCount}
          name={name} avatarPath={avatarPath} email={email}
          helpHref={helpHref} homeHref={homeHref}
        />
      </div>
    </header>
  );
}
