-- =====================================================================
-- 0049 — a purchase records the price that was agreed, not today's
--
-- record_course_purchases read courses.price_cents at the moment the
-- webhook arrived, which is not the price the buyer saw, agreed to, or
-- paid. Between the two lies the whole checkout: a redirect to
-- Flutterwave, a card form, a bank's 3-D Secure page. Minutes, and an
-- author can edit a price inside them.
--
-- Reproduced against this schema. A $49 course, bought at $49, with the
-- author raising it to $99 before the webhook lands:
--
--   buyer paid                       $49.00
--   purchase recorded                $99.00
--   instructor credited              $56.10
--   platform credited                $24.05
--   assessment reserved              $18.85
--   -> Your Brand owes $74.95 against $49.00 received
--
-- Move the price the other way and the instructor is underpaid instead.
-- Either way the books cannot reconcile, and course_purchases is the
-- table the payout runs read.
--
-- A second fault in the same loop: `continue when price_cents is null`
-- skipped any course whose author had switched it to free mid-checkout.
-- The buyer paid, the loop skipped the row, and no purchase — and so no
-- access — was recorded at all. Silent, and indistinguishable from a
-- webhook that never arrived.
--
-- The fix is to capture the price at checkout and honour it at
-- fulfilment. checkout_intents already stores course_ids and a total;
-- it now stores the per-course prices alongside, in the same order, so
-- a multi-course cart can be settled line by line.
-- =====================================================================

alter table checkout_intents
  add column if not exists course_prices int[];

comment on column checkout_intents.course_prices is
  'Price in cents of each course in course_ids, same order, captured when the intent was created. What the buyer agreed to — fulfilment settles against this, never against the live price. See 0049.';

create or replace function public.record_course_purchases(p_tx_ref text)
returns int
language plpgsql security definer set search_path = public as $$
declare
  v_intent    checkout_intents%rowtype;
  v_course_id uuid;
  v_price     int;
  v_assess    int := 1885;      -- what an assessment costs to pay for
  v_rest      int;
  v_made      int := 0;
  v_idx       int;
begin
  select * into v_intent from checkout_intents where tx_ref = p_tx_ref;
  if not found or v_intent.kind <> 'courses' then return 0; end if;

  v_idx := 0;
  foreach v_course_id in array v_intent.course_ids loop
    v_idx := v_idx + 1;

    -- The agreed price. Intents created before this migration have no
    -- captured prices, so those fall back to the live one — the same
    -- behaviour they have had all along, and only for intents already
    -- in flight when it ships.
    v_price := null;
    if v_intent.course_prices is not null
       and array_length(v_intent.course_prices, 1) >= v_idx then
      v_price := v_intent.course_prices[v_idx];
    end if;

    if v_price is null then
      select price_cents into v_price from courses where id = v_course_id;
    end if;

    -- No price from either source means there is genuinely nothing to
    -- record. Loudly, though: money was taken for this line.
    if v_price is null then
      raise warning 'record_course_purchases: no price for course % on %', v_course_id, p_tx_ref;
      continue;
    end if;

    v_rest := greatest(v_price - v_assess, 0);

    insert into course_purchases (
      user_id, course_id, price_cents, currency, tx_ref,
      assessment_cents, instructor_cents, platform_cents
    )
    values (
      v_intent.user_id, v_course_id, v_price, v_intent.currency, p_tx_ref,
      least(v_assess, v_price),
      floor(v_rest * 0.70)::int,
      v_rest - floor(v_rest * 0.70)::int
    )
    on conflict (user_id, course_id) do nothing;

    if found then v_made := v_made + 1; end if;
  end loop;

  delete from cart_items
   where user_id = v_intent.user_id and course_id = any(v_intent.course_ids);

  update checkout_intents set completed_at = now() where tx_ref = p_tx_ref;
  return v_made;
end; $$;
