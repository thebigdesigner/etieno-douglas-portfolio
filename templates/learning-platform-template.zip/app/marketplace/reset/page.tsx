import type { Metadata } from "next";
import Link from "next/link";
import { marketBase, mk } from "@/lib/marketplace/url";
import { studioViewer } from "@/lib/marketplace/studio";
import AuthShell from "@/components/marketplace/auth/AuthShell";
import { ResetForm } from "@/components/marketplace/auth/AuthForms";

export const metadata: Metadata = { title: "Choose a new password", robots: { index: false } };

/** Reached from the reset email: the callback has already signed them in. */
export default async function MarketReset() {
  const base = await marketBase();
  const signedIn = Boolean(await studioViewer().catch(() => null));
  return (
    <AuthShell homeHref={mk(base, "/")} title="Choose a new password" lead="This changes the password for your Your Brand account everywhere, including the Academy.">
      {signedIn ? <ResetForm /> : (
        <p className="au__msg au__msg--err" role="alert">
          That reset link has expired or was already used. <Link href={mk(base, "/forgot")} className="au__link">Request a new one</Link>.
        </p>
      )}
    </AuthShell>
  );
}
