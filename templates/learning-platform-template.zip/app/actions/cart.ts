"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { newReference, resolveProvider, startCheckout } from "@/lib/payments";
import { SALE_CURRENCY } from "@/lib/pricing";
import { siteUrl } from "@/lib/site";

/**
 * The cart, for courses that are bought.
 *
 * Server-side rather than in the browser: it has to survive a redirect out
 * to the payment provider and back, and the amount charged is computed from
 * it. A cart the client could edit would be a cart the client could price.
 */

async function requireUser(next: string) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect(`/login?next=${encodeURIComponent(next)}`);
  return user;
}

export async function addToCart(slug: string): Promise<void> {
  const user = await requireUser(`/courses/${slug}`);
  const admin = createAdminClient();

  const { data: course } = await admin
    .from("courses")
    .select("id, owner_kind, price_cents, state")
    .eq("slug", slug).maybeSingle();

  // Only a published, priced course can go in a cart. Anything else is
  // free, an organisation's internal course, or not for sale yet — and the
  // cart is the wrong answer to all three.
  //
  // Your Brand-authored courses were excluded here while the subscription
  // covered them. 0063 made them sellable, so the test is the price now,
  // not the owner: without this a Your Brand course showed a price on its page
  // and refused to go in the basket.
  if (
    !course || course.state !== "published" ||
    course.owner_kind === "institution" || course.price_cents == null
  ) {
    redirect(`/courses/${slug}?error=not_for_sale`);
  }

  // Already owned. Sending them to the course is more use than a second copy.
  const { data: owned } = await admin
    .from("course_purchases").select("id")
    .eq("user_id", user.id).eq("course_id", course.id).is("refunded_at", null)
    .maybeSingle();
  if (owned) redirect(`/courses/${slug}`);

  await admin.from("cart_items")
    .upsert({ user_id: user.id, course_id: course.id }, { onConflict: "user_id,course_id" });

  revalidatePath("/dashboard/cart");
  revalidatePath(`/courses/${slug}`);
  redirect("/dashboard/cart");
}

export async function removeFromCart(courseId: string): Promise<void> {
  const user = await requireUser("/dashboard/cart");
  const admin = createAdminClient();
  await admin.from("cart_items").delete()
    .eq("user_id", user.id).eq("course_id", courseId);
  revalidatePath("/dashboard/cart");
}

/**
 * Checkout for a cart.
 *
 * The amount is summed
 * server-side from the courses themselves, never taken from the request,
 * and the intent is written before the redirect so a completed payment can
 * always be matched back to what it was for.
 */
export async function checkoutCart(formData?: FormData): Promise<void> {
  const user = await requireUser("/dashboard/cart");
  const admin = createAdminClient();

  const { data: items } = await admin
    .from("cart_items").select("course_id").eq("user_id", user.id);

  const ids = (items ?? []).map((i) => i.course_id as string);
  if (ids.length === 0) redirect("/dashboard/cart?error=empty");

  const { data: courses } = await admin
    .from("courses").select("id, price_cents, owner_kind, state").in("id", ids);

  const sellable = (courses ?? []).filter(
    (c) => c.state === "published" && c.owner_kind !== "institution" && c.price_cents != null
  );
  if (sellable.length === 0) redirect("/dashboard/cart?error=empty");

  const totalCents = sellable.reduce((n, c) => n + Number(c.price_cents), 0);

  const { data: profile } = await admin
    .from("profiles").select("email, display_name").eq("id", user.id).maybeSingle();
  const email = profile?.email ?? user.email;
  if (!email) redirect("/dashboard/account?error=email");

  // Sales are quoted and charged in one currency. See SALE_CURRENCY.
  const ccy = SALE_CURRENCY;
  const txRef = newReference("courses");

  await admin.from("checkout_intents").insert({
    tx_ref: txRef,
    user_id: user.id,
    kind: "courses",
    plan: null,
    course_ids: sellable.map((c) => c.id),
    // The price of each line, in the same order, as the buyer sees it now.
    // Fulfilment settles against these rather than re-reading the course,
    // which an author can edit while the buyer is on the card form.
    course_prices: sellable.map((c) => Number(c.price_cents)),
    amount_cents: totalCents,
    currency: ccy,
    return_to: "/dashboard/courses",
  });

  let link: string;
  try {
    const started = await startCheckout({
      txRef,
      amount: totalCents / 100,
      currency: ccy,
      email,
      name: profile?.display_name,
      provider: resolveProvider(String(formData?.get?.("provider") ?? "")),
      description: "Your Brand courses",
      redirectUrl: `${siteUrl()}/dashboard/cart/complete`,
      meta: { user_id: user.id, kind: "courses" },
    });
    link = started.url;
    // Which provider took it, so fulfilment verifies with the same one.
    await admin.from("checkout_intents")
      .update({ provider: started.provider, provider_session: started.session })
      .eq("tx_ref", txRef);
  } catch {
    redirect("/dashboard/cart?error=checkout");
  }

  redirect(link);
}
