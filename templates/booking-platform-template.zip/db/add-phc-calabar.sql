-- Coast City <-> Central City
--
-- ! THE FARE BELOW IS A PLACEHOLDER -- NGN 15,000, sitting between your two existing routes.
--   It is a guess. Change it before you send anyone to the page:
--     Staff app -> Routes & fares -> "Coast City -> Central City" -> set fare, times and days -> Save.
--   The website reads fares live, so the correction shows within about two minutes.
--
-- The route is created ON SALE because you asked for it to be visible. That means a passenger
-- could book at NGN 15,000 in the meantime, and you would have to honour it.

insert into routes (tenant_id, from_terminal, to_terminal, fare_kobo, duration_min, operating_days, departures, active)
select t.id, f.id, x.id,
       1500000,                       -- NGN 15,000 placeholder -- change before going on sale
       150,                           -- 2.5 hours, also a placeholder
       array[2,4,6]::smallint[],      -- Tue, Thu, Sat, matching your other routes
       array['08:00'::time],
       true                           -- ON SALE. Change the fare above before you publicise it.
  from tenants t
  join terminals f on f.tenant_id = t.id and f.code = 'phc'
  join terminals x on x.tenant_id = t.id and x.code = 'cal'
 where t.slug = 'ace-trail'
on conflict do nothing;

insert into routes (tenant_id, from_terminal, to_terminal, fare_kobo, duration_min, operating_days, departures, active)
select t.id, f.id, x.id, 1500000, 150, array[2,4,6]::smallint[], array['15:00'::time], true
  from tenants t
  join terminals f on f.tenant_id = t.id and f.code = 'cal'
  join terminals x on x.tenant_id = t.id and x.code = 'phc'
 where t.slug = 'ace-trail'
on conflict do nothing;

select r.id,
       (select city from terminals where id = r.from_terminal) as departs,
       (select city from terminals where id = r.to_terminal)   as arrives,
       r.fare_kobo / 100 as fare, r.active
  from routes r
 where r.tenant_id = (select id from tenants where slug = 'ace-trail')
 order by departs, arrives;
