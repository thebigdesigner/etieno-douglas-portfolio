import type { MkIconName } from "@/lib/marketplace/types";

/**
 * Marketplace glyphs. Same grid, stroke and joins as NavIcon, so the two
 * sets sit side by side without anyone noticing there are two. Kept apart
 * because these are category and commerce glyphs the rest of the app has
 * no use for, and NavIcon's union is imported by every rail.
 */
export const MK_PATHS: Record<MkIconName, string> = {
  cart:     "M3 4.5h2.2l2.1 10a1.5 1.5 0 0 0 1.5 1.2h8.3a1.5 1.5 0 0 0 1.5-1.1L20.5 8H6M9.5 20a1 1 0 1 0 0-2 1 1 0 0 0 0 2ZM17 20a1 1 0 1 0 0-2 1 1 0 0 0 0 2Z",
  trash:    "M4.5 7h15M9.5 7V5h5v2M6.5 7l1 12.5h9l1-12.5M10 11v5M14 11v5",
  layout:   "M4 4.5h16v15H4zM4 9h16M9.5 9v10.5",
  browser:  "M3.5 5h17v14h-17zM3.5 9h17M6.5 7h.01M9 7h.01",
  slides:   "M4 4.5h16v11H4zM12 15.5V20M8.5 20h7M8 12l3-3 2 2 3-3",
  palette:  "M12 3.5a8.5 8.5 0 1 0 0 17c1.2 0 1.8-.9 1.8-1.8 0-1.4-1.1-1.6-1.1-2.7 0-.9.7-1.5 1.6-1.5h2.2a4 4 0 0 0 4-4c0-4-3.8-7-8.5-7ZM7.5 11h.01M9.5 7.5h.01M14 7h.01M17 10h.01",
  shapes:   "M7.5 3.5 11.5 10.5h-8zM17 7a3.5 3.5 0 1 1 0 .01M13.5 13.5h7v7h-7zM3.5 17.5l3.5-3.5 3.5 3.5-3.5 3.5z",
  type:     "M5 6.5V4.5h14v2M12 4.5v15M9 19.5h6",
  music:    "M9 18.5V5.5l11-2v13M9 18.5a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0ZM20 16.5a2.5 2.5 0 1 1-5 0 2.5 2.5 0 0 1 5 0Z",
  wave:     "M3 12h2M7 8v8M11 5v14M15 9v6M19 7v10M21 12h0",
  film:     "M4 4.5h16v15H4zM8 4.5v15M16 4.5v15M4 9h4M4 15h4M16 9h4M16 15h4",
  cube:     "M12 3 20 7.5v9L12 21l-8-4.5v-9zM12 12l8-4.5M12 12v9M12 12 4 7.5",
  book:     "M5 4.5h10.5A3.5 3.5 0 0 1 19 8v12.5H8.5A3.5 3.5 0 0 1 5 17zM5 17a3.5 3.5 0 0 1 3.5-3.5H19",
  code:     "M8.5 7.5 4 12l4.5 4.5M15.5 7.5 20 12l-4.5 4.5M13.5 5l-3 14",
  home:     "M3 10.5 12 3l9 7.5M5.5 9.5V20h13V9.5",
  compass:  "M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18ZM15.5 8.5l-2 5-5 2 2-5z",
  search:   "M11 4a7 7 0 1 1 0 14 7 7 0 0 1 0-14ZM16 16l4.5 4.5",
  heart:    "M12 20s-7.5-4.4-7.5-10A4.3 4.3 0 0 1 12 7.3 4.3 4.3 0 0 1 19.5 10c0 5.6-7.5 10-7.5 10Z",
  star:     "M12 3.5l2.6 5.4 5.9.8-4.3 4.1 1 5.8L12 16.8l-5.2 2.8 1-5.8-4.3-4.1 5.9-.8z",
  download: "M12 4v11M7.5 10.5 12 15l4.5-4.5M4.5 19.5h15",
  chevron:  "M6 9.5 12 15.5 18 9.5",
  "chevron-left": "M14.5 6 8.5 12l6 6",
  help:     "M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18ZM9.5 9.5a2.5 2.5 0 1 1 3.2 2.4c-.5.2-.7.6-.7 1.1v.5M12 16.8v.2",
  academy:  "M2.5 9 12 4.5 21.5 9 12 13.5zM6.5 11v5c2.9 2.4 8.1 2.4 11 0v-5M21.5 9v5",
  menu:     "M3.5 6h17M3.5 12h17M3.5 18h17",
  close:    "M6 6l12 12M18 6L6 18",
  check:    "M5 12.5 9.5 17 19 7.5",
  tag:      "M3.5 12.5V4.5h8l9 9-8 8zM8 8.5h.01",
  clock:    "M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18ZM12 7.5V12l3 2",
  users:    "M9 4a3.5 3.5 0 1 1 0 7 3.5 3.5 0 0 1 0-7ZM2.5 20a6.5 6.5 0 0 1 13 0M16 4.5a3.5 3.5 0 0 1 0 6.9M18 14.2a6.5 6.5 0 0 1 3.5 5.8",
  sliders:  "M4 7h9M17 7h3M4 17h3M11 17h9M15 5v4M9 15v4",
  store:    "M4 9.5 5.5 4.5h13L20 9.5M4 9.5v10h16v-10M4 9.5a2.7 2.7 0 0 0 5.3 0 2.7 2.7 0 0 0 5.4 0 2.7 2.7 0 0 0 5.3 0M9.5 19.5v-5h5v5",
  more:     "M6 12h.01M12 12h.01M18 12h.01",
  file:     "M6 3.5h8l4.5 4.5v12.5H6zM14 3.5V8h4.5",
  sparkle:  "M12 3.5l1.9 4.9 4.9 1.9-4.9 1.9L12 17.1l-1.9-4.9L5.2 10.3l4.9-1.9z",
  "arrow-up": "M12 19V5M6 11l6-6 6 6",
  play:     "M8 5.5v13l10.5-6.5z",
  apps:     "M7 5.5a1.5 1.5 0 1 1 0 .01M17 5.5a1.5 1.5 0 1 1 0 .01M7 16.5a1.5 1.5 0 1 1 0 .01M17 16.5a1.5 1.5 0 1 1 0 .01",
  "arrow-left": "M19 12H5M11 6l-6 6 6 6",
  "arrow-right": "M5 12h14M13 6l6 6-6 6",
  "more-circle": "M12 3a9 9 0 1 1 0 18 9 9 0 0 1 0-18ZM12 7.8v.01M12 12v.01M12 16.2v.01",
  "chevron-right": "M9.5 6l6 6-6 6",
  gift:     "M4 9.5h16v4H4zM5.5 13.5V20h13v-6.5M12 9.5V20M12 9.5S10.8 4.5 8.3 4.5a2.3 2.3 0 0 0 0 4.6c2 0 3.7.4 3.7.4ZM12 9.5s1.2-5 3.7-5a2.3 2.3 0 0 1 0 4.6c-2 0-3.7.4-3.7.4Z",
  bag:      "M5.5 8h13l-1.1 11.2a1.5 1.5 0 0 1-1.5 1.3H8.1a1.5 1.5 0 0 1-1.5-1.3zM9 8V6.6a3 3 0 0 1 6 0V8",
};

/** Glyphs that read better filled than stroked at small sizes. */
const FILLED = new Set<MkIconName>(["star", "play"]);

export default function MkIcon({
  name, size = 18, className, filled,
}: { name: MkIconName; size?: number; className?: string; filled?: boolean }) {
  const fill = filled ?? FILLED.has(name);
  return (
    <svg
      className={className} width={size} height={size} viewBox="0 0 24 24"
      fill={fill ? "currentColor" : "none"} stroke="currentColor"
      strokeWidth={name === "more" ? 3 : name === "apps" ? 4 : 1.7} strokeLinecap="round" strokeLinejoin="round"
      aria-hidden="true" focusable="false"
    >
      <path d={MK_PATHS[name]} />
    </svg>
  );
}
