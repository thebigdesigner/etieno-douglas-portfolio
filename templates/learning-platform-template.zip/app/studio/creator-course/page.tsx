import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import DoneButton from "./DoneButton";
import Alert from "@/components/Alert";

export const metadata = { title: "Making a course people finish" };
export const dynamic = "force-dynamic";

const LESSONS = [
  {
    title: "Teach one thing",
    body: "The courses people abandon try to cover a subject. The ones they finish teach a single capability — reading a set of accounts, writing a concept note, automating one report. If you cannot say what somebody will be able to do afterwards in one sentence, the course is too broad. Narrow it until you can.",
  },
  {
    title: "Write the project first",
    body: "Before the modules, write the thing you will ask them to produce. Everything in the course then exists to get them there, and you will notice immediately which topics are decoration. It also stops the most common failure: four modules of theory and a project nobody is equipped to attempt.",
  },
  {
    title: "The rubric is the hard part",
    body: "Two reviewers reading the same submission should reach the same verdict. That only happens if the rubric describes what a good version looks like, not what the criterion is called. \u201cWell structured\u201d is not a criterion. \u201cSomebody who has to maintain this could pick it up without asking questions\u201d is. Expect to rewrite it once.",
  },
  {
    title: "Say the thing, then stop",
    body: "A topic should take five to twelve minutes. Longer than that and people leave partway and do not come back. If a topic is running long it is usually two topics. Video is not obligatory either — a well-written page with a worksheet often teaches better than a screen recording of you talking.",
  },
  {
    title: "Quiz to check, not to trick",
    body: "The quiz exists so somebody knows whether they took it in, and so the gate means something. Questions should be answerable by anyone who read the topic properly and unanswerable by anyone who skimmed. If most people fail one question, it is usually the question that is wrong, not them.",
  },
  {
    title: "Feedback is the product",
    body: "People can watch videos anywhere. What they cannot get elsewhere is somebody who does this work reading theirs and saying specifically what to change. Budget thirty to forty-five minutes per review and write to the person, not the rubric. This is the part that makes the certificate worth something.",
  },
];

export default async function CreatorCoursePage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  const admin = createAdminClient();
  const { data: instructor } = await admin
    .from("instructors").select("creator_course_done_at").eq("id", user!.id).maybeSingle();

  const done = !!instructor?.creator_course_done_at;

  return (
    <>
        <nav className="crumb" style={{ paddingTop: 28 }}>
          <Link href="/studio">Studio</Link> / Making a course
        </nav>

        <h1 className="sec__h" style={{ fontSize: 32, marginTop: 16 }}>
          Making a course people finish
        </h1>
        <p className="sec__meta">
          Six things, about fifteen minutes. Optional — nothing on the platform is
          gated on it. It exists because the same handful of problems come up in
          almost every first course.
        </p>

        <div className="lessons">
          {LESSONS.map((l, i) => (
            <article key={l.title} className="lesson">
              <span className="lesson__n num">{i + 1}</span>
              <div>
                <h2 className="lesson__h">{l.title}</h2>
                <p className="lesson__p">{l.body}</p>
              </div>
            </article>
          ))}
        </div>

        <div className="lessons__end">
          {done ? (
            <Alert kind="success">
              You have marked this as read. It will not come up again.
            </Alert>
          ) : (
            <DoneButton />
          )}
          <p className="studio__hint" style={{ marginTop: 14 }}>
            You can find this again under Help in the studio, whether or not you turn
            the reminders off.
          </p>
        </div>
      </>
  );
}
