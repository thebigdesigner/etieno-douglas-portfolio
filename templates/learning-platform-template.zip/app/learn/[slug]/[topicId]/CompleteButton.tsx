"use client";
import Link from "next/link";
import { useFormStatus } from "react-dom";
import { completeTopic } from "@/app/actions/learning";

function Inner() {
  const { pending } = useFormStatus();
  return (
    <button className="btn btn--fill btn--lg" disabled={pending}>
      {pending ? "Saving…" : "Mark as done and continue"}
    </button>
  );
}

export default function CompleteButton({
  slug, topicId, completed, nextHref,
}: { slug: string; topicId: string; completed: boolean; nextHref: string }) {
  if (completed) {
    return (
      <div className="learn__done">
        <p className="learn__doneh">Done</p>
        <Link className="btn btn--fill btn--lg" href={nextHref}>Continue</Link>
      </div>
    );
  }
  return (
    <div className="learn__done">
      <form action={completeTopic.bind(null, slug, topicId)}><Inner /></form>
    </div>
  );
}
