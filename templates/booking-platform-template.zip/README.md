# Booking site template by Aphinity Digital

A complete booking website with a customer booking flow and a staff operations dashboard.
All copy is placeholder text from [Aphinity Digital](https://aphinity.digital). Replace it with your own.
Images are kept so you can see the layout; swap them for your own photos and logo in `assets/`.

## Run locally
```bash
npm run dev   # serves the folder at http://localhost:3000
```
Or open `index.html` directly in a browser.

## Where things live
- Brand colours, radii, shadows: `:root` tokens at the top of `<style>` in `index.html`
- Company details, routes, fares, notices, reviews: `const tenant = { … }` in `index.html`
- Photos: `const photos = { … }` and the `assets/` folder
- Staff dashboard: `staff.html` (needs the API in `api/` and a Supabase database, schema in `db/` and `supabase/`)

## Want it customised?
Aphinity Digital can brand it, write the copy and launch it for you: https://aphinity.digital
