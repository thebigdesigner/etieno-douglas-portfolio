import { DEFAULT_CCY, money, type Ccy } from "@/lib/money";

/**
 * "$24", "£19", "₦25,000", or "Free".
 *
 * The currency comes from the product being shown, which carries whichever
 * one the visitor is being priced in. It defaults to dollars so a caller
 * that has not been given one shows the canonical price rather than
 * guessing.
 */
export function price(cents: number, ccy: Ccy = DEFAULT_CCY): string {
  return money(cents, ccy);
}

/** 1240 → "1.2k", 18300 → "18.3k". Under a thousand stays exact. */
export function compact(n: number): string {
  if (n < 1000) return String(n);
  if (n < 1_000_000) return `${(n / 1000).toFixed(n < 10_000 ? 1 : 0).replace(/\.0$/, "")}k`;
  return `${(n / 1_000_000).toFixed(1).replace(/\.0$/, "")}m`;
}

export function shortDate(iso: string): string {
  return new Date(iso).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" });
}

export function initials(name: string): string {
  return name.split(/\s+/).filter(Boolean).slice(0, 2).map((w) => w[0]!.toUpperCase()).join("");
}
