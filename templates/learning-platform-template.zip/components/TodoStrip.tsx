import Link from "next/link";

export type Todo = {
  id: string;
  title: string;
  detail: string;
  href: string;
  cta: string;
  tone?: "bad" | "warn" | "ok";
};

/** The to-do list. Empty is the goal, and an empty state says so rather than
 *  disappearing — silence reads as broken. */
export default function TodoStrip({ todos }: { todos: Todo[] }) {
  if (todos.length === 0) {
    return (
      <section className="todos">
        <h2 className="todos__h">Your to-dos</h2>
        <div className="todo todo--clear">
          <span className="todo__ico" aria-hidden="true">✓</span>
          <div className="todo__body">
            <span className="todo__t">Nothing needs you right now</span>
            <span className="todo__d">Anything waiting on you will appear here.</span>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section className="todos">
      <h2 className="todos__h">
        Your to-dos <span className="todos__n num">{todos.length}</span>
      </h2>
      <div className="todos__list">
        {todos.map((t) => (
          <div key={t.id} className={`todo todo--${t.tone ?? "warn"}`}>
            <span className="todo__ico" aria-hidden="true" />
            <div className="todo__body">
              <span className="todo__t">{t.title}</span>
              <span className="todo__d">{t.detail}</span>
            </div>
            <Link className="todo__cta" href={t.href}>{t.cta}</Link>
          </div>
        ))}
      </div>
    </section>
  );
}
