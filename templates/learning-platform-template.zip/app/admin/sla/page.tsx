import Link from "next/link";
import { createAdminClient } from "@/lib/supabase/admin";
import { requireProfile } from "@/lib/guard";
import { slaLabel } from "@/lib/sla";
import ReassignForm from "./ReassignForm";
import NavIcon from "@/components/NavIcon";

export const metadata = { title: "SLA monitor" };
export const dynamic = "force-dynamic";

export default async function SlaPage() {
  // The admin layout has already established this is an operator; the
  // identity is needed here so they can take a late submission themselves.
  const { user, profile } = await requireProfile(["operator"], { next: "/admin/sla" });
  const admin = createAdminClient();

  const { data: queue } = await admin
    .from("review_queue_status").select("*").order("deadline_at", { ascending: true });

  /* Who can be handed a late submission.
   *
   * This asked the instructors table, filtered to active + accepting +
   * available. In a database with no practitioners that returns nothing,
   * so the dropdown rendered empty and a breached submission could not be
   * reassigned to anybody — the same bug that stopped a course being
   * created, one surface along. eligible_assessors() is the list that
   * decides who may assess, so it is the list of possible reserves. */
  const { data: reserves } = await admin.rpc("eligible_assessors");

  /* An institution's work stays inside the institution.
   *
   * Offering the platform-wide reserve list on every row would hand a
   * stranger a learner's private submission and put their name on the
   * organisation's certificate. reassign_to_reserve refuses it now, so a
   * wrong pick fails safely — but the list should not offer it either.
   * These rows get their own institution's people instead. */
  const instIds = [...new Set(
    (queue ?? [])
      .filter((r) => r.owner_kind === "institution" && r.institution_id)
      .map((r) => r.institution_id as string)
  )];
  const { data: instMembers } = instIds.length
    ? await admin.from("institution_members")
        .select("institution_id, user_id, profiles(display_name)")
        .in("institution_id", instIds)
    : { data: [] };

  const rows = queue ?? [];
  const breached = rows.filter((r) => r.breached);
  const soon = rows.filter((r) => !r.breached && r.due_soon);

  const eligible = ((reserves ?? []) as { id: string; name: string; kind: string }[])
    .map((r) => ({ id: r.id, name: r.name ?? "Reviewer" }));

  // The person reading this page is always an option. Their console
  // authority comes from OWNER_EMAILS, which SQL cannot see, so
  // eligible_assessors will not have listed them — and on a platform with
  // no practitioners yet they are often the only person who can take it.
  const reserveList = eligible.some((r) => r.id === user.id)
    ? eligible
    : [{ id: user.id, name: `${profile?.display_name ?? "You"} (you)` }, ...eligible];

  const reservesFor = (r: { owner_kind?: string | null; institution_id?: string | null }) =>
    r.owner_kind === "institution"
      ? (instMembers ?? [])
          .filter((m) => m.institution_id === r.institution_id)
          .map((m) => ({
            id: m.user_id as string,
            name: (m.profiles as unknown as { display_name: string } | null)?.display_name ?? "Colleague",
          }))
      : reserveList;

  const onTime = rows.length ? Math.round(((rows.length - breached.length) / rows.length) * 100) : 100;

  return (
    <>
      <div className="dash__bar">
        <div>
          <div className="eyebrow">Operations</div>
          <h1 className="dash__title">SLA monitor</h1>
        </div>
      </div>

      <div className="pan">
        <div className="pan__col">
          <div className="hero__panel">
            <div className="hero__eyebrow">The four-day promise</div>
            <h2 className="hero__title">
              {breached.length > 0
                ? `${breached.length} past the promise`
                : soon.length > 0
                  ? `${soon.length} due within a day`
                  : "Everything inside four days"}
            </h2>
            <p className="hero__sub">
              The promise is ours, not the instructor&rsquo;s. Escalate at day three,
              reassign at day four — the learner should never feel it.
            </p>
            <div style={{ marginTop: 18, position: "relative" }}>
              <div className="prog">
                <div className="prog__fill" style={{ width: `${onTime}%` }} />
              </div>
            </div>
          </div>

          <div className="stats3">
            <div className="stat3">
              <div className="eyebrow">Past the promise</div>
              <div className="stat3__v num" style={{ color: breached.length ? "#9B2C22" : undefined }}>
                {breached.length}
              </div>
              <div className="stat3__n">Reassign these now</div>
            </div>
            <div className="stat3">
              <div className="eyebrow">Due within a day</div>
              <div className="stat3__v num">{soon.length}</div>
              <div className="stat3__n">Nudge the reviewer</div>
            </div>
            <div className="stat3">
              <div className="eyebrow">In the queue</div>
              <div className="stat3__v num">{rows.length}</div>
              <div className="stat3__n">Awaiting assessment</div>
            </div>
          </div>

          <div className="card">
            <div className="card__head"><div className="card__h">The queue</div></div>
            {rows.length === 0 ? (
              <p className="empty2">Every submission has been assessed.</p>
            ) : (
              <div className="rq">
                {rows.map((r) => (
                  <div key={r.submission_id}
                    className={`rq__row${r.breached ? " is-late" : r.due_soon ? " is-soon" : ""}`}>
                    <div>
                      {/* The queue used to be a list you could only look at.
                          Reading the work is the first thing an operator
                          needs when a row goes late. */}
                      <Link className="rq__course" href={`/review/${r.submission_id}`}>
                        {r.course_title}
                      </Link>
                      <div className="rq__learner">
                        {r.learner_name ?? "Learner"}
                        {r.owner_kind === "institution" && (
                          <span className="pill" style={{ marginLeft: 8, fontSize: 11 }}>
                            Institution
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="rq__meta">
                      <span className="rq__sub num">
                        submitted {new Date(r.submitted_at).toLocaleDateString()}
                      </span>
                      <span className={`rq__clock${r.breached ? " is-late" : r.due_soon ? " is-soon" : ""}`}>
                        {slaLabel(r.deadline_at)}
                      </span>
                    </div>
                    <ReassignForm submissionId={r.submission_id} reserves={reservesFor(r)} />
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        <div className="pan__col">
          <div className="card">
            <div className="card__head"><div className="card__h">Reserve reviewers</div></div>
            {reserveList.length === 0 ? (
              <p className="empty2">Nobody is currently available to take reassignments.</p>
            ) : (
              reserveList.slice(0, 6).map((r) => (
                <div className="prow2" key={r.id}>
                  <span className="prow2__ico" aria-hidden="true"><NavIcon name="user" size={17} /></span>
                  <span><span className="prow2__t">{r.name}</span>
                    <span className="prow2__s">Accepting reviews</span></span>
                  <span className="tag tag--go">Free</span>
                </div>
              ))
            )}
          </div>

          <div className="card card--tint">
            <div className="card__h">Why this page exists</div>
            <p className="card__meta" style={{ marginTop: 8, lineHeight: 1.6 }}>
              A certificate is only worth something because a practitioner read the work
              and said so, on time. Every row here is a learner waiting to find out.
            </p>
          </div>
        </div>
      </div>
    </>
  );
}
