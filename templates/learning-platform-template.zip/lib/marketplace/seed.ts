import type { Author, Product } from "./types";

/**
 * Demo catalogue.
 *
 * Only ever read by catalog.ts, and only when the marketplace tables are not
 * reachable AND this is not a production build (or MARKETPLACE_DEMO=1 says
 * otherwise). It exists so the storefront can be reviewed before a single
 * creator has uploaded anything. It must never be what a paying visitor
 * sees, which is why the switch lives in catalog.ts rather than here.
 *
 * Dates hang off a fixed anchor instead of Date.now(), so "new this week"
 * does not drift every time the server restarts.
 */

const ANCHOR = Date.UTC(2026, 8, 15);
const daysAgo = (n: number) => new Date(ANCHOR - n * 86_400_000).toISOString();

export const AUTHORS: Author[] = [
  { handle: "adaeze-studio", name: "Adaeze Studio", person: "Adaeze Okafor", location: "Lagos, Nigeria", hue: 0,
    bio: "Product designer. I make the kits I wished existed when I was shipping fintech apps on a two-person team.",
    joined: "2024-02-11", followers: 4812,
    socials: [{ kind: "dribbble", url: "https://dribbble.com" }, { kind: "x", url: "https://x.com" }, { kind: "instagram", url: "https://instagram.com" }] },
  { handle: "kofi-type", name: "Kofi Type Foundry", person: "Kofi Mensah", location: "Accra, Ghana", hue: 4,
    bio: "Type designer. Most of my faces start as sign-painting on Accra shopfronts and end up with 600 glyphs.",
    joined: "2023-09-02", followers: 9366,
    socials: [{ kind: "instagram", url: "https://instagram.com" }, { kind: "behance", url: "https://behance.net" }] },
  { handle: "lowtide-audio", name: "Lowtide Audio", person: "Tunde Bakare", location: "Ibadan, Nigeria", hue: 3,
    bio: "Producer and session guitarist. Every track ships with stems, because you will want to cut the intro.",
    joined: "2024-06-19", followers: 12094,
    socials: [{ kind: "youtube", url: "https://youtube.com" }, { kind: "instagram", url: "https://instagram.com" }] },
  { handle: "wanjiru-motion", name: "Wanjiru Motion", person: "Wanjiru Kamau", location: "Nairobi, Kenya", hue: 1,
    bio: "Motion designer for broadcast and brands. Templates are organised so you never open a precomp to change a word.",
    joined: "2024-11-30", followers: 3120,
    socials: [{ kind: "behance", url: "https://behance.net" }, { kind: "youtube", url: "https://youtube.com" }, { kind: "instagram", url: "https://instagram.com" }] },
  { handle: "deck-house", name: "Deck House", person: "Samuel Eze", location: "Abuja, Nigeria", hue: 2,
    bio: "I have sat through four hundred pitches. These decks are what the good ones had in common.",
    joined: "2024-03-08", followers: 2255,
    socials: [{ kind: "x", url: "https://x.com" }] },
  { handle: "grain-and-ink", name: "Grain & Ink", person: "Leila Haddad", location: "Casablanca, Morocco", hue: 5,
    bio: "Illustrator. Patterns drawn from zellige and textile archives, redrawn by hand and vectorised properly.",
    joined: "2023-05-21", followers: 7408,
    socials: [{ kind: "instagram", url: "https://instagram.com" }, { kind: "dribbble", url: "https://dribbble.com" }] },
  { handle: "cubefold", name: "Cubefold", person: "Thandiwe Nkosi", location: "Johannesburg, South Africa", hue: 4,
    bio: "3D generalist. Clean topology, real-world scale, and every material named something you can find.",
    joined: "2025-01-14", followers: 1876,
    socials: [{ kind: "instagram", url: "https://instagram.com" }, { kind: "youtube", url: "https://youtube.com" }] },
  { handle: "stackwise", name: "Stackwise", person: "Emeka Obi", location: "Port Harcourt, Nigeria", hue: 1,
    bio: "Engineer. I write the component once, test it properly, and sell it so you do not have to write it at all.",
    joined: "2024-08-01", followers: 2931,
    socials: [{ kind: "x", url: "https://x.com" }] },
];

type Row = [
  slug: string, title: string, category: string, sub: string, author: string,
  price: number, rating: number, ratings: number, downloads: number, age: number,
  formats: string[], tags: string[], summary: string,
  extra?: Partial<Product>,
];

const ROWS: Row[] = [
  // ---- UI kits
  ["kobo-fintech-app-kit", "Kobo — fintech app UI kit", "ui-kits", "mobile", "adaeze-studio", 39, 4.9, 212, 3840, 9,
    ["Figma"], ["fintech", "banking", "wallet", "mobile"],
    "A complete mobile banking flow: onboarding with BVN checks, wallets, transfers, bills and a card screen, in light and dark.",
    { trending: true, featured: true, includes: ["148 screens, light and dark", "Auto-layout on every component", "Variables for colour and spacing", "Onboarding, KYC, transfers, bills and cards"] }],
  ["ledger-admin-dashboard", "Ledger — admin dashboard kit", "ui-kits", "dashboards", "adaeze-studio", 49, 4.8, 97, 1920, 21,
    ["Figma", "Sketch"], ["dashboard", "admin", "saas", "charts"],
    "Tables, filters, chart cards and settings pages for the back office nobody wants to design from scratch.",
    { trending: true }],
  ["harmattan-design-system", "Harmattan design system", "ui-kits", "design-systems", "adaeze-studio", 79, 4.9, 64, 860, 40,
    ["Figma"], ["design system", "tokens", "components"],
    "Tokens, 90 components and usage notes, structured the way an engineering team will actually read it."],
  ["okada-ride-hailing-kit", "Okada — ride-hailing app kit", "ui-kits", "mobile", "adaeze-studio", 29, 4.6, 41, 610, 3,
    ["Figma", "Adobe XD"], ["transport", "maps", "mobile"],
    "Rider and driver apps, map states, trip receipts and a support flow."],

  // ---- Web templates
  ["mainland-saas-landing", "Mainland — SaaS landing page", "web-templates", "landing-pages", "stackwise", 24, 4.7, 133, 2710, 12,
    ["React", "HTML"], ["landing page", "saas", "startup"],
    "A fast, accessible landing page with pricing, FAQ and a changelog, in plain HTML and a Next.js version.",
    { trending: true }],
  ["oja-storefront", "Oja — online shop template", "web-templates", "ecommerce", "stackwise", 59, 4.8, 88, 1340, 18,
    ["React", "WordPress"], ["ecommerce", "shop", "checkout"],
    "Product listings, cart and a checkout ready for Paystack."],
  ["folio-one-page", "Folio — one-page portfolio", "web-templates", "portfolio", "adaeze-studio", 0, 4.5, 402, 9120, 60,
    ["HTML", "Webflow"], ["portfolio", "personal", "free"],
    "A clean one-pager for designers and developers. Free, including for client work."],

  // ---- Presentations
  ["seed-round-pitch-deck", "Seed round pitch deck", "presentations", "pitch-decks", "deck-house", 19, 4.9, 318, 5620, 6,
    ["PowerPoint", "Keynote", "Google Slides"], ["pitch deck", "startup", "investors"],
    "Twenty slides in the order investors expect, with notes on what each one has to prove.",
    { trending: true, featured: true, includes: ["20 slides with speaker notes", "Market-size and traction chart templates", "Cap table slide", "Three colour themes"] }],
  ["lesson-plan-slides", "Classroom lesson slides", "presentations", "education", "deck-house", 0, 4.7, 256, 7810, 30,
    ["Google Slides", "PowerPoint"], ["teaching", "classroom", "free"],
    "Slides for a 45-minute lesson: hook, objectives, worked example, practice and exit ticket."],
  ["quarterly-report-deck", "Quarterly report deck", "presentations", "reports", "deck-house", 15, 4.6, 72, 1180, 14,
    ["PowerPoint", "Keynote"], ["report", "business", "charts"],
    "Editable charts and KPI slides that survive a change of numbers without re-layout."],
  ["ngo-impact-report", "Impact report for nonprofits", "presentations", "reports", "deck-house", 12, 4.8, 49, 640, 4,
    ["Google Slides"], ["nonprofit", "impact", "report"],
    "Programme outcomes, stories and a donor ask, laid out for print and screen."],

  // ---- Graphics
  ["zellige-pattern-pack", "Zellige pattern pack", "graphics", "patterns", "grain-and-ink", 18, 5.0, 144, 2230, 11,
    ["AI", "SVG", "PNG"], ["pattern", "geometric", "tile"],
    "Forty seamless geometric patterns, redrawn by hand from Fez tilework.",
    { trending: true, featured: true }],
  ["market-day-illustrations", "Market day illustrations", "graphics", "illustrations", "grain-and-ink", 26, 4.8, 91, 1470, 25,
    ["AI", "SVG"], ["illustration", "people", "market"],
    "Thirty scenes of traders, buyers and stalls, with swappable characters."],
  ["adire-textures", "Adire indigo textures", "graphics", "textures", "grain-and-ink", 14, 4.9, 77, 1020, 8,
    ["PNG", "PSD"], ["texture", "indigo", "fabric"],
    "High-resolution scans of hand-dyed adire cloth, cleaned and tileable."],
  ["abstract-shapes-free", "Soft abstract shapes", "graphics", "illustrations", "grain-and-ink", 0, 4.4, 521, 11200, 90,
    ["SVG", "PNG"], ["abstract", "shapes", "free"],
    "Background shapes for slides and social posts. Free for any use."],

  // ---- Icons
  ["stroke-240-icons", "Stroke — 240 line icons", "icons", "line", "grain-and-ink", 16, 4.9, 188, 3950, 16,
    ["SVG", "Figma"], ["icons", "line", "interface"],
    "240 interface icons on a 24px grid with a 1.7 stroke. Every one is a single path.",
    { trending: true }],
  ["solid-commerce-icons", "Commerce icons, filled", "icons", "filled", "adaeze-studio", 12, 4.6, 58, 890, 28,
    ["SVG", "Figma"], ["icons", "ecommerce", "filled"],
    "Carts, wallets, receipts and delivery, in a filled style with a matching outline set."],
  ["lottie-micro-icons", "Micro-animated icons", "icons", "animated", "wanjiru-motion", 22, 4.7, 36, 470, 2,
    ["Lottie", "SVG"], ["icons", "animation", "lottie"],
    "Sixty icons with a short state animation each, exported as Lottie and static SVG."],

  // ---- Fonts
  ["harmattan-serif", "Harmattan Serif", "fonts", "serif", "kofi-type", 35, 4.9, 167, 2890, 13,
    ["OTF", "TTF", "WOFF2"], ["serif", "editorial", "book"],
    "A text serif with warm, open counters. Six weights with italics and full African Latin.",
    { trending: true, featured: true, includes: ["12 styles: 6 weights with italics", "Full African Latin, including Yorùbá and Twi diacritics", "Web fonts included", "Old-style and lining numerals"] }],
  ["osu-grotesk", "Osu Grotesk", "fonts", "sans-serif", "kofi-type", 29, 4.8, 124, 2140, 35,
    ["OTF", "WOFF2"], ["sans serif", "interface", "branding"],
    "A grotesk for interfaces and brands. Tight, even colour at small sizes."],
  ["signwriter-display", "Signwriter Display", "fonts", "display", "kofi-type", 19, 5.0, 96, 1760, 7,
    ["OTF", "TTF"], ["display", "signage", "poster"],
    "Chunky, hand-lettered capitals from Accra shop signs, with alternates for every letter."],
  ["kente-script", "Kente Script", "fonts", "script", "kofi-type", 17, 4.6, 53, 780, 22,
    ["OTF", "TTF"], ["script", "handwritten", "wedding"],
    "A connected script with swashes, drawn with a broad nib."],
  ["mono-market", "Market Mono", "fonts", "sans-serif", "kofi-type", 0, 4.7, 610, 14100, 120,
    ["OTF", "WOFF2"], ["monospace", "code", "free"],
    "A monospace for code and receipts. Free, with the source files on GitHub."],

  // ---- Music
  ["lagos-sunrise", "Lagos Sunrise", "music", "afrobeats", "lowtide-audio", 14, 4.9, 233, 4410, 5,
    ["WAV", "MP3", "Stems"], ["afrobeats", "upbeat", "summer"],
    "Bright, percussive afrobeats with a guitar hook. Loops cleanly at 1:04.",
    { trending: true, featured: true, duration: "02:48" }],
  ["late-study-lofi", "Late study (lo-fi)", "music", "lo-fi", "lowtide-audio", 0, 4.8, 702, 18300, 45,
    ["MP3"], ["lo-fi", "calm", "study", "free"],
    "Slow, dusty keys for tutorials and study streams.", { duration: "03:12" }],
  ["harbour-cinematic", "Harbour — cinematic build", "music", "cinematic", "lowtide-audio", 22, 4.7, 88, 1290, 19,
    ["WAV", "MP3", "Stems"], ["cinematic", "trailer", "epic"],
    "Strings and taiko that build to a hit at 1:52. Short and long edits included.", { duration: "02:31" }],
  ["quarterly-townhall", "Townhall — corporate", "music", "corporate", "lowtide-audio", 9, 4.4, 61, 1880, 33,
    ["WAV", "MP3"], ["corporate", "positive", "background"],
    "Unobtrusive and optimistic, for product demos and all-hands videos.", { duration: "02:05" }],
  ["amapiano-drive", "Amapiano Drive", "music", "afrobeats", "lowtide-audio", 16, 4.9, 145, 2560, 2,
    ["WAV", "MP3", "Stems"], ["amapiano", "log drum", "night"],
    "Log drums, shakers and a patient build. Made for night-drive edits.",
    { trending: true, duration: "03:40" }],

  // ---- Sound effects
  ["tap-and-toggle", "Tap & toggle — interface sounds", "sound-effects", "ui-sounds", "lowtide-audio", 8, 4.8, 119, 2300, 10,
    ["WAV"], ["ui", "click", "notification"],
    "120 short interface sounds, levelled to -18 LUFS so none of them jumps out.", { duration: "00:02" }],
  ["market-ambience", "Market ambience", "sound-effects", "ambience", "lowtide-audio", 11, 4.9, 47, 520, 26,
    ["WAV"], ["ambience", "crowd", "field recording"],
    "Field recordings from Balogun and Oshodi markets, in stereo and 5.1.", { duration: "04:00" }],
  ["whoosh-transitions", "Whoosh transitions", "sound-effects", "transitions", "wanjiru-motion", 0, 4.5, 390, 8870, 70,
    ["WAV", "MP3"], ["whoosh", "transition", "free"],
    "Fifty whooshes and risers, free for any edit.", { duration: "00:03" }],

  // ---- Video templates
  ["bold-title-pack", "Bold title pack", "video-templates", "titles", "wanjiru-motion", 28, 4.8, 102, 1650, 15,
    ["After Effects", "Premiere Pro"], ["titles", "typography", "kinetic"],
    "Thirty kinetic titles. Change the words in one panel; nothing to precompose.",
    { trending: true, duration: "00:43" }],
  ["reels-starter-kit", "Reels starter kit", "video-templates", "social", "wanjiru-motion", 18, 4.7, 85, 2020, 9,
    ["CapCut", "Premiere Pro"], ["reels", "tiktok", "vertical"],
    "Vertical intros, captions and end cards sized for Reels, TikTok and Shorts.", { duration: "00:15" }],
  ["ink-logo-reveal", "Ink logo reveal", "video-templates", "logo-reveals", "wanjiru-motion", 12, 4.9, 64, 910, 5,
    ["After Effects"], ["logo", "ink", "reveal"],
    "An ink-bleed reveal that renders in under a minute on a laptop.", { duration: "00:08" }],

  // ---- 3D
  ["danfo-bus-model", "Danfo bus, low-poly", "3d", "models", "cubefold", 21, 4.9, 38, 480, 12,
    ["Blender", "GLB", "FBX"], ["vehicle", "low poly", "lagos"],
    "The yellow Lagos minibus at real-world scale, rigged doors, 8k triangles.", { trending: true }],
  ["studio-product-scene", "Studio product scene", "3d", "scenes", "cubefold", 32, 4.7, 26, 350, 20,
    ["Blender"], ["product", "studio", "lighting"],
    "A lit sweep with three camera presets. Drop your product in and render."],
  ["stylised-characters", "Stylised characters, set of 6", "3d", "characters", "cubefold", 45, 4.8, 19, 240, 6,
    ["Blender", "FBX"], ["character", "rigged", "stylised"],
    "Six rigged characters with shape keys for expressions."],

  // ---- Guides
  ["freelance-pricing-workbook", "Pricing your freelance work", "ebooks", "workbooks", "deck-house", 9, 4.9, 204, 3310, 23,
    ["PDF", "Notion"], ["freelance", "pricing", "business"],
    "A workbook that gets you from an hourly rate to a project price you can defend.",
    { featured: true }],
  ["figma-to-code-guide", "Figma to code, properly", "ebooks", "guides", "stackwise", 15, 4.8, 97, 1540, 17,
    ["PDF", "EPUB"], ["figma", "frontend", "handoff"],
    "How to hand off a design so the build matches it, from both sides of the table."],
  ["content-planner-2027", "Content planner 2027", "ebooks", "planners", "adaeze-studio", 0, 4.6, 812, 15400, 4,
    ["Notion", "PDF"], ["planner", "content", "free"],
    "A year of content in one Notion page. Free."],

  // ---- Code
  ["paystack-checkout-react", "Checkout component for Paystack", "code", "components", "stackwise", 25, 4.9, 71, 1210, 8,
    ["TypeScript"], ["react", "payments", "checkout"],
    "A typed React checkout that handles cards, transfer and USSD, with the webhook verification written for you.",
    { trending: true }],
  ["wp-naira-invoices", "Naira invoices for WordPress", "code", "plugins", "stackwise", 19, 4.5, 44, 690, 29,
    ["PHP"], ["wordpress", "invoices", "vat"],
    "Branded PDF invoices with VAT lines, sent from WooCommerce orders."],
  ["csv-cleanup-scripts", "Spreadsheet clean-up scripts", "code", "scripts", "stackwise", 0, 4.7, 158, 3000, 50,
    ["Python"], ["python", "csv", "free"],
    "Scripts to de-duplicate, normalise phone numbers and split names. Free."],
];

const FILE_SIZE: Record<string, string> = {
  "ui-kits": "84 MB", "web-templates": "12 MB", presentations: "46 MB", graphics: "210 MB",
  icons: "6 MB", fonts: "3 MB", music: "118 MB", "sound-effects": "64 MB",
  "video-templates": "320 MB", "3d": "140 MB", ebooks: "9 MB", code: "1 MB",
};

const INCLUDES: Record<string, string[]> = {
  "ui-kits": ["Organised pages and named layers", "Components with variants", "Documentation page"],
  "web-templates": ["Source files", "Responsive down to 360px", "Setup notes"],
  presentations: ["Every slide editable", "Fonts are free to download", "Setup notes"],
  graphics: ["Vector source files", "High-resolution exports", "Colour variants"],
  icons: ["Every icon as SVG", "Figma library", "Named by use, not by shape"],
  fonts: ["Desktop fonts", "Web fonts", "Specimen PDF"],
  music: ["Full track", "Short edit", "Loopable section"],
  "sound-effects": ["Trimmed and levelled files", "Named by action", "Preview reel"],
  "video-templates": ["Project file", "Tutorial video", "Free fonts listed"],
  "3d": ["Source file", "Textures", "Exports in common formats"],
  ebooks: ["Download for print and screen", "Worksheets", "Updates for free"],
  code: ["Full source", "Readme with examples", "Six months of support"],
};

export const PRODUCTS: Product[] = ROWS.map((r, i): Product => {
  const [slug, title, category, subcategory, author, price, rating, ratings, downloads, age, formats, tags, summary, extra] = r;
  return {
    id: `demo-${i + 1}`,
    currency: "USD" as const,
    slug, title, category, subcategory, author,
    priceCents: price * 100,
    commercialCents: price === 0 ? null : price * 300,
    rating, ratings, downloads,
    publishedAt: daysAgo(age),
    updatedAt: daysAgo(Math.max(0, Math.floor(age / 3))),
    formats, tags, summary,
    includes: extra?.includes ?? INCLUDES[category] ?? [],
    fileSize: FILE_SIZE[category] ?? "10 MB",
    ...extra,
  };
});
