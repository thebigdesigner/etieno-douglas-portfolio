/**
 * Every /api/auth/* route, in one serverless function.
 *
 * Vercel's Hobby plan allows 12 functions per deployment, so the five auth endpoints share one
 * entry point. `vercel.json` rewrites /api/auth/* here and the path decides which handler runs —
 * the URLs the page calls are unchanged.
 */
import google from '../_lib/auth/google.js';
import me from '../_lib/auth/me.js';
import logout from '../_lib/auth/logout.js';
import email from '../_lib/auth/email.js';
import verifyLink from '../_lib/auth/verify.js';
import staffVerify from '../_lib/auth/staff-verify.js';
import cancel from '../_lib/auth/cancel.js';

const routes = { google, me, logout, email, verify: verifyLink, 'staff-verify': staffVerify, cancel };

export default async function handler(req, res) {
  const path = (req.url || '').split('?')[0].replace(/\/+$/, '');
  const action = path.split('/').pop();
  const route = routes[action];
  if (!route) return res.status(404).json({ error: 'not_found', message: 'Unknown auth route' });
  return route(req, res);
}
