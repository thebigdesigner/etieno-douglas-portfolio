import type { Metadata } from "next";
import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { library } from "@/lib/marketplace/library";
import { marketBase, mk } from "@/lib/marketplace/url";
import { studioReady } from "@/lib/marketplace/studio";
import MkIcon from "@/components/marketplace/MkIcon";
import ProductPreview from "@/components/marketplace/ProductPreview";
import { StudioNotice } from "@/components/marketplace/studio/views";

export const metadata: Metadata = { title: "Your library", robots: { index: false } };
export const dynamic = "force-dynamic";

/** Everything this buyer owns, with a download button for each. */
export default async function LibraryPage() {
  const base = await marketBase();
  if (!(await studioReady())) {
    return (
      <StudioNotice icon="clock" title="Not switched on yet">
        The library needs the marketplace database migrations. Once they have run, everything you buy appears here.
      </StudioNotice>
    );
  }

  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    return (
      <StudioNotice icon="users" title="Sign in to see your library"
        action={<Link className="mk-btn mk-btn--fill" href={mk(base, `/login?next=${encodeURIComponent("/library")}`)}>Sign in</Link>}>
        Everything you buy or claim on Your Brand Marketplace stays in your library.
      </StudioNotice>
    );
  }

  const items = await library(user.id);

  if (items.length === 0) {
    return (
      <StudioNotice icon="store" title="Nothing here yet"
        action={<Link className="mk-btn mk-btn--fill" href={mk(base, "/all")}>Browse the marketplace</Link>}>
        Files you buy, and free ones you claim, appear here to download whenever you need them.
      </StudioNotice>
    );
  }

  return (
    <div className="st-wrap">
      <header className="st-head">
        <div>
          <h1 className="st-head__h">Your library</h1>
          <p className="st-head__p">{items.length} item{items.length === 1 ? "" : "s"}. Yours to download as often as you like.</p>
        </div>
      </header>

      <ul className="mk-lib">
        {items.map(({ product, licence, boughtAt, hasFile }) => (
          <li key={product.id} className="mk-lib__row">
            <Link href={mk(base, `/item/${product.slug}`)} className="mk-lib__thumb" tabIndex={-1} aria-hidden="true">
              <ProductPreview product={product} className="mk-lib__img" label="" />
            </Link>
            <div className="mk-lib__txt">
              <Link href={mk(base, `/item/${product.slug}`)} className="mk-lib__title">{product.title}</Link>
              <span className="mk-lib__meta">
                {licence === "free" ? "Free" : licence === "commercial" ? "Commercial licence" : "Personal licence"}
                {boughtAt && ` · ${new Date(boughtAt).toLocaleDateString("en-GB", { day: "numeric", month: "short", year: "numeric" })}`}
                {product.fileSize && ` · ${product.fileSize}`}
              </span>
            </div>
            {hasFile ? (
              <a className="mk-btn mk-btn--fill" href={`/api/marketplace/download?item=${encodeURIComponent(product.slug)}`}>
                <MkIcon name="download" size={17} />Download
              </a>
            ) : (
              <span className="mk-lib__wait">The creator has not uploaded the file yet</span>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}
