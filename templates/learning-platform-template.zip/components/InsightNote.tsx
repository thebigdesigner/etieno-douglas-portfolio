"use client";

import { useEffect, useState } from "react";

/**
 * The pace note.
 *
 * This used to be a fixed sentence — "keep that up and you will be through
 * your current course inside a fortnight" — rendered whenever the weekly
 * count was above zero. It was the same fortnight for somebody two topics in
 * and somebody with one topic left, so it was decoration rather than
 * information, and it could not be got rid of.
 *
 * The text is now worked out from the learner's own rate and what is actually
 * left, on the server, and passed in. This component only decides whether to
 * show it. Dismissal is remembered for the current week, so it can be waved
 * away without coming back the same afternoon; a new week is new information
 * and earns another go.
 */
export default function InsightNote({
  id, children,
}: {
  /** Changes when the underlying fact changes — dismissal is keyed to it. */
  id: string;
  children: React.ReactNode;
}) {
  // Starts hidden. Rendering it and then removing it in an effect produces a
  // flash of a note the learner already dismissed.
  const [state, setState] = useState<"checking" | "show" | "hidden">("checking");

  useEffect(() => {
    try {
      setState(localStorage.getItem("splari:insight") === id ? "hidden" : "show");
    } catch {
      setState("show");   // private mode, or storage disabled
    }
  }, [id]);

  if (state !== "show") return null;

  return (
    <div className="insight">
      <span className="insight__ico" aria-hidden="true">▲</span>
      <span className="insight__body">{children}</span>
      <button
        type="button"
        className="insight__x"
        aria-label="Dismiss"
        onClick={() => {
          try { localStorage.setItem("splari:insight", id); } catch { /* no-op */ }
          setState("hidden");
        }}
      >
        ✕
      </button>
    </div>
  );
}
