import Link from "next/link";
import { CATEGORIES, categoryBySlug } from "@/lib/marketplace/categories";
import { getAuthors, listProducts } from "@/lib/marketplace/catalog";
import { compact, price } from "@/lib/marketplace/format";
import { marketBase, mk } from "@/lib/marketplace/url";
import MkIcon from "@/components/marketplace/MkIcon";
import ProductPreview from "@/components/marketplace/ProductPreview";
import { Stars } from "@/components/marketplace/bits";

/**
 * The dense list layout, parked here while we decide where it belongs —
 * most likely as a view of All items, alongside the card grid. The tabs
 * are drawn but inert: they become real filters wherever this lands.
 */
export const metadata = { title: "List view", robots: { index: false } };

export default async function ListPreview() {
  const [base, trending] = await Promise.all([marketBase(), listProducts({ sort: "popular", perPage: 24 })]);
  const authors = await getAuthors(trending.items.map((p) => p.author));

  return (
    <>
      <div className="pv-wshead">
        <h1 className="pv-wshead__h">Marketplace</h1>
        <p className="pv-wshead__n num">{trending.total} items · {CATEGORIES.length} categories</p>
      </div>
      <div className="pv-tabs" role="list">
        {["Trending", "New", "Free", "Top rated"].map((t, i) => (
          <span key={t} role="listitem" className={`pv-tab${i === 0 ? " is-on" : ""}`}>{t}</span>
        ))}
        <Link href={mk(base, "/all")} className="pv-tabs__all">All items<MkIcon name="arrow-right" size={15} /></Link>
      </div>
      <ul className="pv-list">
        {trending.items.map((p) => {
          const cat = categoryBySlug(p.category);
          const href = mk(base, `/item/${p.slug}`);
          return (
            <li key={p.id} className="pv-row">
              <Link href={href} className="pv-row__thumb" tabIndex={-1} aria-hidden="true">
                <ProductPreview product={p} className="pv-card__img" label="" />
              </Link>
              <div className="pv-row__main">
                <Link href={href} className="pv-row__title">{p.title}</Link>
                <span className="pv-row__by">{authors.get(p.author)?.name} · {cat?.name}</span>
              </div>
              <Stars rating={p.rating} count={p.ratings} showValue />
              <span className="pv-row__dl num"><MkIcon name="download" size={14} />{compact(p.downloads)}</span>
              <span className={`pv-row__price num${p.priceCents === 0 ? " is-free" : ""}`}>{price(p.priceCents, p.currency)}</span>
            </li>
          );
        })}
      </ul>
    </>
  );
}
