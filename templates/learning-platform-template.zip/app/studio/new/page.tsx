import Link from "next/link";
import { createAdminClient } from "@/lib/supabase/admin";
import { requireProfile } from "@/lib/guard";
import NewCourseForm from "../NewCourseForm";

export const metadata = { title: "New course" };
export const dynamic = "force-dynamic";

export default async function NewCoursePage() {
  // Only an operator gets the ownership choice, so only an operator pays for
  // the extra query.
  const { user, profile } = await requireProfile(["instructor", "operator"], { next: "/studio/new" });
  const role = profile?.role;

  // Same widening as the console: an allowlisted owner counts as an
  // operator here, but eligible_assessors reads the role column and
  // cannot see the allowlist — so the person choosing must always be
  // in the list they choose from.
  let assessors: { id: string; name: string; kind: string }[] = [];
  if (role === "operator") {
    const { data } = await createAdminClient().rpc("eligible_assessors");
    assessors = data ?? [];
    if (!assessors.some((a) => a.id === user.id)) {
      assessors = [
        { id: user.id, name: profile?.display_name ?? user.email ?? "You", kind: "Your Brand" },
        ...assessors,
      ];
    }
  }

  return (
    <>
      <nav className="crumb" style={{ paddingTop: 28 }}>
        <Link href="/studio">My courses</Link> / Create new course
      </nav>

      {/* Every other studio page carries a title under the crumb. This one
          lost its heading when the step rail went in, so the page began with
          a row of pills and sat higher than its siblings. */}
      <h1 className="sec__h" style={{ fontSize: 28, marginTop: 14 }}>Create a course</h1>
      <p className="sec__meta">
        A name and where it belongs. Everything else is on the next screen, and
        saves itself as you write.
      </p>

      {/* The four steps of getting a course out, named as what they are
          rather than numbered abstractly. Somebody deciding whether to start
          can see the whole shape of the job from here. */}
      {/* Two steps, not four. The middle two were a promise this screen
          cannot keep — everything after creating happens on one page. */}
      <ol className="cstep" aria-label="Step 1 of 2">
        <li className="cstep__i is-now"><span className="cstep__n">1</span> Name it</li>
        <li className="cstep__i"><span className="cstep__n">2</span> Write it</li>
      </ol>

      <NewCourseForm isOperator={role === "operator"} assessors={assessors} />
    </>
  );
}
