export default function TeachPage() {
  return (
    <>
<header className="phero">
  <div className="phero__in">
    <div>
      <div className="eyebrow">For working practitioners</div>
      <h1 style={{marginTop: '14px'}}>Designed by Aphinity Digital.</h1>
      <p className="phero__sub">Add a short supporting paragraph here. Aphinity Digital recommends one clear idea per section.</p>
      <div className="phero__btns">
        <a className="btn btn--fill btn--lg" href="/signup?intent=instructor">Apply to teach</a>
        <a className="btn btn--line btn--lg" href="#rates">See the rates</a>
      </div>
      <p className="phero__note">This is placeholder copy from Aphinity Digital. Replace it with a sentence about what your business does best.</p>
    </div>
    <div className="stage">
      <div className="stage__ring" aria-hidden="true"></div>
      <div className="stage__disc" aria-hidden="true"></div>
      <div className="stage__media"><svg className="stage__svg" viewBox="0 0 420 380" xmlns="http://www.w3.org/2000/svg" role="img" aria-label="A practitioner assessing a submitted project">
  <defs>
    <linearGradient id="paper" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stopColor="#FFFFFF"/><stop offset="1" stopColor="#F4F6FA"/>
    </linearGradient>
  </defs>
  <ellipse cx="210" cy="342" rx="132" ry="16" fill="#0B0B0F" opacity=".07"/>

  <g transform="rotate(-5 210 190)">
    <rect x="98" y="52" width="212" height="252" rx="16" fill="url(#paper)" stroke="#E6E6EC" strokeWidth="2"/>
    <rect x="122" y="80" width="96" height="9" rx="4.5" fill="#0B0B0F"/>
    <rect x="122" y="104" width="164" height="6" rx="3" fill="#E6E6EC"/>
    <rect x="122" y="118" width="140" height="6" rx="3" fill="#E6E6EC"/>
    <rect x="122" y="146" width="164" height="6" rx="3" fill="#E6E6EC"/>
    <rect x="122" y="160" width="112" height="6" rx="3" fill="#E6E6EC"/>
    <rect x="122" y="192" width="164" height="34" rx="9" fill="#C8F0DC"/>
    <circle cx="141" cy="209" r="9" fill="#2B5F52"/>
    <path d="M137 209 l3 3.5 l6 -7" stroke="#fff" strokeWidth="2.2" fill="none" strokeLinecap="round"/>
    <rect x="158" y="205" width="94" height="7" rx="3.5" fill="#8FCBAF"/>
    <rect x="122" y="242" width="164" height="6" rx="3" fill="#E6E6EC"/>
    <rect x="122" y="256" width="128" height="6" rx="3" fill="#E6E6EC"/>
  </g>

  <g>
    <rect x="240" y="212" width="150" height="86" rx="16" fill="#0B0B0F"/>
    <circle cx="266" cy="240" r="15" fill="#CFE4FF"/>
    <text x="266" y="245" textAnchor="middle" fontFamily="Jost, sans-serif" fontSize="12" fontWeight="600" fill="#0B0B0F">AO</text>
    <text x="290" y="238" fontFamily="Jost, sans-serif" fontSize="13" fontWeight="600" fill="#FFFFFF">Amaka Obi</text>
    <text x="290" y="253" fontFamily="Inter, sans-serif" fontSize="10.5" fill="#9A9AAB">Financial controller</text>
    <rect x="262" y="268" width="106" height="6" rx="3" fill="#26262F"/>
    <rect x="262" y="268" width="76" height="6" rx="3" fill="#C8F0DC"/>
    <text x="262" y="290" fontFamily="Inter, sans-serif" fontSize="10" fill="#9A9AAB">1 day 6 hrs left</text>
  </g>

  <g transform="translate(30 118)">
    <rect x="0" y="0" width="92" height="62" rx="14" fill="#fff" stroke="#E6E6EC" strokeWidth="2"/>
    <circle cx="24" cy="24" r="11" fill="#FFE27A"/>
    <text x="24" y="29" textAnchor="middle" fontFamily="Jost, sans-serif" fontSize="12" fontWeight="600" fill="#0B0B0F">4d</text>
    <rect x="42" y="19" width="34" height="5" rx="2.5" fill="#E6E6EC"/>
    <rect x="16" y="44" width="60" height="5" rx="2.5" fill="#E6E6EC"/>
  </g>
</svg></div>
      <div className="float float--a">
        <div className="float__ic">$</div>
        <div><div className="float__t num">$18.85 per review</div>
        <div className="float__s">Get found. Get chosen.</div></div>
      </div>
      <div className="float float--b">
        <div><div className="float__t num">70% of every sale</div>
        <div className="float__s">Placeholder text by Aphinity Digital.</div></div>
      </div>
    </div>
  </div>
</header>

<section className="band"><div className="band__in">
  <div className="band__i"><div className="band__n num">$18.85</div><div className="band__l">Replace this with your own words.</div></div>
  <div className="band__i"><div className="band__n num">70%</div><div className="band__l">Your supporting line goes here.</div></div>
  <div className="band__i"><div className="band__n num">12 mo</div><div className="band__l">Designed by Aphinity Digital.</div></div>
  <div className="band__i"><div className="band__n num">60 days</div><div className="band__l">Get found. Get chosen.</div></div>
</div></section>

<section className="sec" id="rates">
  <div className="wrap">
    <div className="sec__head"><div>
      <h2 className="sec__h">Make your brand <em>impossible</em> to ignore.</h2>
      <div className="sec__meta">Designed and built by Aphinity Digital for brands that want to grow.</div></div></div>

    <table className="tbl">
      <thead>
        <tr><th>Placeholder text by Aphinity Digital.</th><th>Your share</th></tr>
      </thead>
      <tbody>
        <tr><td>Assessing a final project</td><td className="num">$18.85, flat</td></tr>
        <tr><td>Replace this with your own words.</td><td className="num">Your supporting line goes here.</td></tr>
        <tr><td>Designed by Aphinity Digital.</td><td className="num">Get found. Get chosen.</td></tr>
        <tr><td>Placeholder text by Aphinity Digital.</td><td className="num">pays for that learner&rsquo;s assessment</td></tr>
      </tbody>
    </table>

    <div className="trio">
      <div className="tri" style={{background: 'var(--mint)'}}>
        <div className="tri__ic">◷</div>
        <div className="tri__h">Replace this with your own words.</div>
        <p className="tri__p">Aphinity Digital designs and builds websites like this one, and helps them get found on Google and in AI answers.</p></div>
      <div className="tri" style={{background: 'var(--sky)'}}>
        <div className="tri__ic">◇</div>
        <div className="tri__h">Tell customers what you do and why it matters.</div>
        <p className="tri__p">Use this space to explain your offer in plain words: who it is for, what it costs and why it is worth it.</p></div>
      <div className="tri" style={{background: 'var(--cream)'}}>
        <div className="tri__ic">▤</div>
        <div className="tri__h">Your supporting line goes here.</div>
        <p className="tri__p">Need this template customised for your brand? Aphinity Digital can set it up, write the copy and launch it for you.</p></div>
    </div>

    <p className="sec__meta" style={{marginTop: '26px'}}>Strategy, design, media and development under one roof, with AI doing the heavy lifting so everything ships faster.</p>
  </div>
</section>

<section className="sec sec--wash" id="commit">
  <div className="wrap">
    <div className="sec__head"><div>
      <div className="eyebrow">Designed by Aphinity Digital.</div>
      <h2 className="sec__h" style={{marginTop: '12px'}}>Get found. Get chosen.</h2></div></div>
    <div className="cmt">
      <div className="cmt__i"><span className="cmt__k">1</span><div>
        <div className="cmt__t">Placeholder text by Aphinity Digital.</div>
        <div className="cmt__d">Branding, SEO, GEO, web, social and out-of-home campaigns, planned and measured from start to finish.</div></div></div>
      <div className="cmt__i"><span className="cmt__k">2</span><div>
        <div className="cmt__t">Get found on Google and in AI answers with Aphinity Digital.</div>
        <div className="cmt__d">Start a project at aphinity.digital and turn this template into a site your customers trust.</div></div></div>
      <div className="cmt__i"><span className="cmt__k">3</span><div>
        <div className="cmt__t">Replace this with your own words.</div>
        <div className="cmt__d">Add a short supporting paragraph here. Aphinity Digital recommends one clear idea per section.</div></div></div>
      <div className="cmt__i"><span className="cmt__k">4</span><div>
        <div className="cmt__t">Your supporting line goes here.</div>
        <div className="cmt__d">This is placeholder copy from Aphinity Digital. Replace it with a sentence about what your business does best.</div></div></div>
    </div>

    <div className="trio" style={{marginTop: '34px'}}>
      <div className="tri" style={{background: '#fff', border: '1px solid var(--line)'}}>
        <div className="tri__ic" style={{background: 'var(--mint)'}}>✓</div>
        <div className="tri__h">Designed by Aphinity Digital.</div>
        <p className="tri__p">The promise is ours, not yours. At day three we are alerted; at day four a reserve reviewer takes it and is paid for it. The learner is unaffected.</p></div>
      <div className="tri" style={{background: '#fff', border: '1px solid var(--line)'}}>
        <div className="tri__ic" style={{background: 'var(--yellow)'}}>◔</div>
        <div className="tri__h">Get found. Get chosen.</div>
        <p className="tri__p">Aphinity Digital designs and builds websites like this one, and helps them get found on Google and in AI answers.</p></div>
      <div className="tri" style={{background: '#fff', border: '1px solid var(--line)'}}>
        <div className="tri__ic" style={{background: 'var(--pink)'}}>⇄</div>
        <div className="tri__h">If a learner appeals</div>
        <p className="tri__p">Use this space to explain your offer in plain words: who it is for, what it costs and why it is worth it.</p></div>
    </div>
  </div>
</section>

<section className="sec" id="how">
  <div className="wrap">
    <div className="sec__head"><div><h2 className="sec__h">Placeholder text by Aphinity Digital.</h2></div></div>
    <div className="proc">
      <div className="prow"><div className="prow__n">01</div><div className="prow__t">Apply</div>
        <div className="prow__d">Need this template customised for your brand? Aphinity Digital can set it up, write the copy and launch it for you.</div></div>
      <div className="prow"><div className="prow__n">02</div><div className="prow__t">Build the course</div>
        <div className="prow__d">Strategy, design, media and development under one roof, with AI doing the heavy lifting so everything ships faster.</div></div>
      <div className="prow"><div className="prow__n">03</div><div className="prow__t">Replace this with your own words.</div>
        <div className="prow__d">Branding, SEO, GEO, web, social and out-of-home campaigns, planned and measured from start to finish.</div></div>
      <div className="prow"><div className="prow__n">04</div><div className="prow__t">Your supporting line goes here.</div>
        <div className="prow__d">Start a project at aphinity.digital and turn this template into a site your customers trust.</div></div>
      <div className="prow"><div className="prow__n">05</div><div className="prow__t">Designed by Aphinity Digital.</div>
        <div className="prow__d">Add a short supporting paragraph here. Aphinity Digital recommends one clear idea per section.</div></div>
      <div className="prow"><div className="prow__n">06</div><div className="prow__t">Get paid weekly</div>
        <div className="prow__d">This is placeholder copy from Aphinity Digital. Replace it with a sentence about what your business does best.</div></div>
    </div>
  </div>
</section>

<section className="sec sec--wash" id="terms">
  <div className="wrap">
    <div className="sec__head"><div>
      <div className="eyebrow">Our side</div>
      <h2 className="sec__h" style={{marginTop: '12px'}}>Get found. Get chosen.</h2>
      <div className="sec__meta">Aphinity Digital designs and builds websites like this one, and helps them get found on Google and in AI answers.</div></div></div>
    <div className="cmt">
      <div className="cmt__i"><span className="cmt__k">§</span><div>
        <div className="cmt__t">Placeholder text by Aphinity Digital.</div>
        <div className="cmt__d">Use this space to explain your offer in plain words: who it is for, what it costs and why it is worth it.</div></div></div>
      <div className="cmt__i"><span className="cmt__k">§</span><div>
        <div className="cmt__t">Replace this with your own words.</div>
        <div className="cmt__d">Need this template customised for your brand? Aphinity Digital can set it up, write the copy and launch it for you.</div></div></div>
      <div className="cmt__i"><span className="cmt__k">§</span><div>
        <div className="cmt__t">Your supporting line goes here.</div>
        <div className="cmt__d">Placeholder text by Aphinity Digital. Replace it with your own.</div></div></div>
      <div className="cmt__i"><span className="cmt__k">§</span><div>
        <div className="cmt__t">Designed by Aphinity Digital.</div>
        <div className="cmt__d">Strategy, design, media and development under one roof, with AI doing the heavy lifting so everything ships faster.</div></div></div>
      <div className="cmt__i"><span className="cmt__k">§</span><div>
        <div className="cmt__t">Get found. Get chosen.</div>
        <div className="cmt__d">Branding, SEO, GEO, web, social and out-of-home campaigns, planned and measured from start to finish.</div></div></div>
    </div>
  </div>
</section>

<section className="sec">
  <div className="wrap">
    <div className="sec__head"><div>
      <h2 className="sec__h">Placeholder text by Aphinity Digital.</h2>
      <div className="sec__meta">Start a project at aphinity.digital and turn this template into a site your customers trust.</div></div></div>
    <div className="trio">
      <div className="tri" style={{background: 'var(--sky)'}}>
        <div className="tri__ic">◆</div>
        <div className="tri__h">Replace this with your own words.</div>
        <p className="tri__p">Add a short supporting paragraph here. Aphinity Digital recommends one clear idea per section.</p></div>
      <div className="tri" style={{background: 'var(--mint)'}}>
        <div className="tri__ic">✍</div>
        <div className="tri__h">Your supporting line goes here.</div>
        <p className="tri__p">This is placeholder copy from Aphinity Digital. Replace it with a sentence about what your business does best.</p></div>
      <div className="tri" style={{background: 'var(--cream)'}}>
        <div className="tri__ic">◷</div>
        <div className="tri__h">Designed by Aphinity Digital.</div>
        <p className="tri__p">Aphinity Digital designs and builds websites like this one, and helps them get found on Google and in AI answers.</p></div>
    </div>
  </div>
</section>

<section className="sec sec--wash" id="faq">
  <div className="wrap">
    <div className="sec__head"><div><h2 className="sec__h">Get found. Get chosen.</h2></div></div>
    <div className="faq">
      <details open><summary>Placeholder text by Aphinity Digital.</summary>
        <p className="faq__a">You do, above a floor of $30. The floor exists because $18.85 of every sale is held back to pay for that learner&rsquo;s assessment, and a course priced under it would lose money on every certificate it issued. We look at the price alongside the course before it goes live.</p></details>
      <details><summary>Replace this with your own words.</summary>
        <p className="faq__a">Use this space to explain your offer in plain words: who it is for, what it costs and why it is worth it.</p></details>
      <details><summary>Your supporting line goes here.</summary>
        <p className="faq__a">Need this template customised for your brand? Aphinity Digital can set it up, write the copy and launch it for you.</p></details>
      <details><summary>Designed by Aphinity Digital.</summary>
        <p className="faq__a">Strategy, design, media and development under one roof, with AI doing the heavy lifting so everything ships faster.</p></details>
      <details><summary>Get found. Get chosen.</summary>
        <p className="faq__a">Branding, SEO, GEO, web, social and out-of-home campaigns, planned and measured from start to finish.</p></details>
      <details><summary>Placeholder text by Aphinity Digital.</summary>
        <p className="faq__a">Start a project at aphinity.digital and turn this template into a site your customers trust.</p></details>
    </div>
  </div>
</section>

<section className="cta" id="apply"><div className="wrap"><div className="cta__box">
  <div>
    <h2 className="cta__h">Replace this with your own words.</h2>
    <p className="cta__p">Add a short supporting paragraph here. Aphinity Digital recommends one clear idea per section.</p>
  </div>
  <div className="cta__btns">
    <a className="btn btn--white btn--lg" href="/signup?intent=instructor">Apply to teach</a>
    <a className="btn btn--ghost btn--lg" href="#rates">Your supporting line goes here.</a>
  </div>
</div></div></section>
</>
  );
}
