import { NextResponse } from "next/server";
import { siteUrl } from "@/lib/site";
import { createAdminClient } from "@/lib/supabase/admin";
import { sendEmail } from "@/lib/email";
import { cohortDigest } from "@/lib/notifications";
import { runJob } from "@/lib/cron";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

/** Weekly. Cohort learners have no email, so their admin gets one digest
 *  rather than each learner getting nothing. */
export async function GET(request: Request) {
  return runJob("digest", request, async () => {
  const admin = createAdminClient();
  const { data: cohorts } = await admin
    .from("cohorts").select("id, name, institution_id").eq("state", "active");

  let sent = 0;

  for (const cohort of cohorts ?? []) {
    const { data: rows } = await admin
      .from("cohort_progress").select("*").eq("cohort_id", cohort.id);

    const seats = rows ?? [];
    const joined = seats.filter((s) => s.user_id).length;
    const active = seats.filter((s) => Number(s.topics_done) > 0).length;
    const passed = seats.reduce((n, s) => n + Number(s.projects_passed ?? 0), 0);
    const inactive = seats.filter(
      (s) => s.user_id && s.last_active &&
        Date.now() - new Date(s.last_active).getTime() > 14 * 86400_000
    ).length;

    if (joined === 0) continue;

    const { data: members } = await admin
      .from("institution_members").select("user_id").eq("institution_id", cohort.institution_id);

    for (const m of members ?? []) {
      const { data: profile } = await admin
        .from("profiles").select("display_name, email").eq("id", m.user_id).maybeSingle();
      if (!profile?.email) continue;

      await sendEmail({
        to: profile.email,
        ...cohortDigest({
          admin: profile.display_name ?? "there",
          cohort: cohort.name,
          joined, active, passed, inactive,
          url: `${siteUrl()}/institution/cohorts/${cohort.id}`,
        }),
      });
      sent += 1;
    }
  }

  return { cohorts: cohorts?.length ?? 0, sent };
  });
}
