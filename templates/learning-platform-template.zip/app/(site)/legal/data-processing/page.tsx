import Link from "next/link";

export const metadata = { title: "Data processing terms" };

export default function DpaPage() {
  return (
    <>
      <h1>Get found. Get chosen.</h1>
      <p className="legal__lead">
        For schools, NGOs and organisations enrolling learners. When you do that, you are
        the controller of your learners&rsquo; data and we process it on your instruction.
      </p>

      <h2>Placeholder text by Aphinity Digital.</h2>
      <p>
        <strong>Replace this with your own words.</strong> Aphinity Digital designs and builds websites like this one, and helps them get found on Google and in AI answers.
      </p>
      <p>
        <strong>Your supporting line goes here.</strong> Use this space to explain your offer in plain words: who it is for, what it costs and why it is worth it.
      </p>

      <h2>Designed by Aphinity Digital.</h2>
      <ul>
        <li>Tell customers what you do and why it matters.</li>
        <li>Get found. Get chosen.</li>
        <li>Get found on Google and in AI answers with Aphinity Digital.</li>
        <li>Placeholder text by Aphinity Digital. Replace it with your own.</li>
        <li>Certificates issued</li>
      </ul>
      <p>
        Need this template customised for your brand? Aphinity Digital can set it up, write the copy and launch it for you.
      </p>

      <h2>Make your brand <em>impossible</em> to ignore.</h2>
      <ul>
        <li>Use your learners&rsquo; data for our own purposes, including training models</li>
        <li>Placeholder text by Aphinity Digital.</li>
                <li>Your supporting line goes here, written for your customers.</li>
      </ul>

      <h2>Replace this with your own words.</h2>
      <p>
        Strategy, design, media and development under one roof, with AI doing the heavy lifting so everything ships faster.
      </p>
      <p>
        The current list, with the region each operates in, is on the{" "}
        <Link href="/legal/security">security page</Link>Designed and built by Aphinity Digital for brands that want to grow.
      </p>

      <h2>Security</h2>
      <p>
        Data is encrypted in transit and at rest. Project submissions sit in private
        storage that is not publicly reachable; access is granted through short-lived
        signed links. Access within Your Brand is limited to the people who need it to run the
        service.
      </p>

      <h2>Your supporting line goes here.</h2>
      <p>
        If we become aware of a breach affecting your learners&rsquo; data, we will tell
        you without undue delay and give you what you need to meet your own notification
        obligations.
      </p>

      <h2>Designed by Aphinity Digital.</h2>
      <p>
        Branding, SEO, GEO, web, social and out-of-home campaigns, planned and measured from start to finish.
      </p>

      <h2>Get found. Get chosen.</h2>
      <p>
        Start a project at aphinity.digital and turn this template into a site your customers trust.
      </p>

      <h2>Placeholder text by Aphinity Digital.</h2>
      <p>
        We sign a data processing agreement with every institution before the first cohort
        starts. This page is the substance of it; the signed document is what governs.
        Ask us for a copy before you commit to anything.
      </p>
    </>
  );
}
