-- =====================================================================
-- 0055 — the reserve list has the same problem the assessor list had
--
-- The SLA monitor offers reserves from `instructors`, filtered to
-- active + accepts_reviews + available. In a database where every
-- account is a learner that returns nothing, so the dropdown renders
-- with only its placeholder and the browser says "Please select an item
-- in the list" — a breached submission that cannot be reassigned to
-- anybody.
--
-- Exactly the bug that stopped a course being created, one surface
-- along: a list built from the instructors table in a product where
-- 0042 decided an assessor is a person, not necessarily a practitioner.
-- eligible_assessors() is the answer there and is the answer here.
--
-- reassign_to_reserve (0046) already validates against
-- eligible_assessors() for non-institution courses, so the picker and
-- the check now agree. One person that list cannot vouch for is the
-- acting operator themself: console authority lives in OWNER_EMAILS,
-- which SQL cannot see. So the function takes the actor and accepts a
-- reserve who is that actor — the same narrow exception createCourse
-- makes, and for the same reason. It widens nothing: the caller has
-- already been established by the app, and can only reach past the list
-- to their own id.
-- =====================================================================

create or replace function public.reassign_to_reserve(
  p_submission_id uuid,
  p_reserve_id uuid,
  p_actor uuid default null
)
returns boolean
language plpgsql security definer set search_path = public as $$
declare
  v_course courses%rowtype;
  v_ok     boolean;
begin
  select c.* into v_course
    from submissions s
    join enrolments e on e.id = s.enrolment_id
    join courses    c on c.id = e.course_id
   where s.id = p_submission_id;

  if not found then return false; end if;

  if v_course.owner_kind = 'institution' then
    -- An organisation's work stays inside the organisation, whoever is
    -- doing the reassigning.
    select exists (
      select 1 from institution_members m
       where m.user_id = p_reserve_id
         and m.institution_id = v_course.institution_id
    ) into v_ok;
  else
    select exists (
      select 1 from eligible_assessors() a where a.id = p_reserve_id
    ) or (p_actor is not null and p_reserve_id = p_actor) into v_ok;
  end if;

  if not v_ok then return false; end if;

  update submissions
     set assigned_reviewer_id = p_reserve_id,
         reassigned_at = now(),
         state = 'assigned'
   where id = p_submission_id
     and state in ('submitted','assigned','in_review');
  return found;
end; $$;

revoke all on function public.reassign_to_reserve(uuid, uuid, uuid) from public, anon, authenticated;
grant execute on function public.reassign_to_reserve(uuid, uuid, uuid) to service_role;

-- The two-argument form from 0046 is dropped so a stale call cannot
-- resolve to it and skip the actor rule entirely.
drop function if exists public.reassign_to_reserve(uuid, uuid);
