/**
 * Transactional templates.
 *
 * Every one of these exists because the product makes a promise the person
 * cannot otherwise see being kept. A four-working-day turnaround that nobody
 * is told about is, from the learner's side, indistinguishable from silence.
 */

type Mail = { subject: string; html: string; text: string };

const BRAND = `<p style="font-family:'Jost',system-ui,sans-serif;font-size:24px;font-weight:600;margin:0 0 22px;color:#0B0B0F">Your Brand</p>`;

function wrap(inner: string) {
  return `<div style="font-family:system-ui,sans-serif;max-width:520px;margin:0 auto;padding:28px;color:#0B0B0F;line-height:1.6">${BRAND}${inner}</div>`;
}

function button(href: string, label: string) {
  return `<p style="margin:24px 0"><a href="${href}" style="display:inline-block;background:#1F5CFF;color:#fff;text-decoration:none;padding:13px 26px;border-radius:999px;font-weight:600">${label}</a></p>`;
}

function box(inner: string) {
  return `<div style="background:#F6F6F9;border-radius:14px;padding:18px;margin:18px 0;font-size:14px">${inner}</div>`;
}

/* ---------------- learner ---------------- */

export function submissionReceived(o: {
  name: string; course: string; deadline: Date; url: string;
}): Mail {
  const by = o.deadline.toLocaleDateString("en-GB", {
    weekday: "long", day: "numeric", month: "long",
  });

  return {
    subject: `Your ${o.course} project is with a reviewer`,
    text: `Hello ${o.name},

Your final project for ${o.course} has gone to a working practitioner.

You will hear back by ${by} at the latest — four working days, which is the commitment we make on every project.

Track it here: ${o.url}

If it ever runs past that, we hand it to a reserve reviewer. The wait is our problem, not yours.`,
    html: wrap(`
      <p>Hello ${o.name},</p>
      <p>Your final project for <strong>${o.course}</strong> has gone to a working practitioner.</p>
      ${box(`You will hear back by <strong>${by}</strong> at the latest — four working days, which is the commitment we make on every project.`)}
      ${button(o.url, "Track your project")}
      <p style="font-size:13px;color:#7C7C88">If it ever runs past that, we hand it to a reserve reviewer. The wait is our problem, not yours.</p>
    `),
  };
}

/**
 * A certificate exists. Sent for every route that issues one — the exam
 * path, an upheld appeal, an owner issuing by hand — except a review pass,
 * which has its own email that already says it.
 *
 * The two kinds say different things because they are different things, and
 * an employer will be told which.
 */
/**
 * Somebody bought a course.
 *
 * Says what the instructor actually earned, not the sticker price — the
 * assessment is reserved out of every sale, and an email quoting $49 when
 * $21.10 is coming would be the wrong number to remember.
 *
 * The buyer is not named. Knowing somebody bought it is the news; who they
 * are is the earnings page's business, not an email's.
 */
export function coursePurchased(o: {
  name: string; course: string; amount: string; share: string;
  total: number; url: string;
}): Mail {
  const headline = o.total === 1
    ? `First sale — ${o.course}`
    : `New sale — ${o.course}`;

  const count = o.total === 1
    ? "That is the first copy sold."
    : `That is ${o.total} sold.`;

  return {
    subject: headline,
    text: `Hello ${o.name},

Somebody bought ${o.course}. ${count}

They paid ${o.amount}, and ${o.share} of that is yours. The rest covers the assessment of their final project and the platform's share.

Your earnings: ${o.url}`,
    html: wrap(`
      <p>Hello ${o.name},</p>
      <p>Somebody bought <strong>${o.course}</strong>. ${count}</p>
      ${box(`They paid <strong>${o.amount}</strong>, and <strong>${o.share}</strong> of that is yours. The rest covers the assessment of their final project and the platform's share.`)}
      ${button(o.url, "See your earnings")}
    `),
  };
}

export function certificateIssued(o: {
  name: string; course: string; code: string; certUrl: string; verifyUrl: string;
  kind: "assessed" | "examined"; reviewer?: string;
}): Mail {
  const how = o.kind === "examined"
    ? "You passed the final examination, so the course is complete."
    : `${o.reviewer || "A working practitioner"} assessed your final project and passed it.`;

  const what = o.kind === "examined"
    ? "It records the examination you passed. It does not carry a practitioner's name, because nobody assessed the work by hand."
    : "It carries the name of the practitioner who assessed you, next to your own.";

  return {
    subject: `Your certificate — ${o.course}`,
    text: `Hello ${o.name},

${how}

Your certificate for ${o.course} is issued. ${what}

Anyone can check it with the code ${o.code}.

See it: ${o.certUrl}
Verify: ${o.verifyUrl}`,
    html: wrap(`
      <p>Hello ${o.name},</p>
      <p>${how}</p>
      ${box(`Your certificate for <strong>${o.course}</strong> is issued. ${what} Anyone can check it with the code <strong>${o.code}</strong>.`)}
      ${button(o.certUrl, "See your certificate")}
      <p style="font-size:13px;color:#7C7C88">Or verify it at <a href="${o.verifyUrl}" style="color:#1F5CFF">${o.verifyUrl}</a></p>
    `),
  };
}

export function reviewPassed(o: {
  name: string; course: string; reviewer: string; code: string; url: string; certUrl: string;
}): Mail {
  return {
    subject: `You passed — ${o.course}`,
    text: `Hello ${o.name},

${o.reviewer} has assessed your final project for ${o.course}, and you passed.

Your certificate is issued. It carries their name next to yours, and anyone can check it with the code ${o.code}.

Read the feedback: ${o.url}
Your certificate: ${o.certUrl}`,
    html: wrap(`
      <p>Hello ${o.name},</p>
      <p><strong>${o.reviewer}</strong> has assessed your final project for <strong>${o.course}</strong>, and you passed.</p>
      ${box(`Your certificate is issued. It carries their name next to yours, and anyone can check it with the code <strong>${o.code}</strong>.`)}
      ${button(o.url, "Read the feedback")}
      <p style="font-size:13px;color:#7C7C88"><a href="${o.certUrl}" style="color:#1F5CFF">See your certificate</a></p>
    `),
  };
}

export function reviewRevise(o: {
  name: string; course: string; reviewer: string; url: string; free: boolean;
}): Mail {
  const freeLine = o.free
    ? "Your next attempt is free — it does not use another certification."
    : "This one uses a certification from your plan.";

  return {
    subject: `Changes asked for — ${o.course}`,
    text: `Hello ${o.name},

${o.reviewer} has read your final project for ${o.course} and asked for some changes before it can pass.

The feedback lists exactly what needs to be different. ${freeLine}

Read it here: ${o.url}

If you think the rubric was applied wrongly, you can ask for a second opinion from a reviewer who cannot see the first verdict.`,
    html: wrap(`
      <p>Hello ${o.name},</p>
      <p><strong>${o.reviewer}</strong> has read your final project for <strong>${o.course}</strong> and asked for some changes before it can pass.</p>
      ${box(`The feedback lists exactly what needs to be different. ${freeLine}`)}
      ${button(o.url, "Read the feedback")}
      <p style="font-size:13px;color:#7C7C88">If you think the rubric was applied wrongly, you can ask for a second opinion from a reviewer who cannot see the first verdict.</p>
    `),
  };
}

/* ---------------- instructor ---------------- */

export function newSubmission(o: {
  reviewer: string; course: string; deadline: Date; url: string;
}): Mail {
  const by = o.deadline.toLocaleDateString("en-GB", {
    weekday: "long", day: "numeric", month: "long",
  });

  return {
    subject: `A project to assess — ${o.course}`,
    text: `Hello ${o.reviewer},

Somebody has submitted their final project on ${o.course}.

Due by ${by}. That is four working days from their submission.

Open the queue: ${o.url}

If you cannot get to it, tell us and we will pass it to a reserve. Better that than a learner waiting.`,
    html: wrap(`
      <p>Hello ${o.reviewer},</p>
      <p>Somebody has submitted their final project on <strong>${o.course}</strong>.</p>
      ${box(`Due by <strong>${by}</strong> — four working days from their submission.`)}
      ${button(o.url, "Open the queue")}
      <p style="font-size:13px;color:#7C7C88">If you cannot get to it, tell us and we will pass it to a reserve. Better that than a learner waiting.</p>
    `),
  };
}

export function reviewDueSoon(o: {
  reviewer: string; course: string; hours: number; url: string;
}): Mail {
  return {
    subject: `Due tomorrow — ${o.course}`,
    text: `Hello ${o.reviewer},

A project on ${o.course} is due in about ${o.hours} hours.

Open the queue: ${o.url}

If today is not possible, say so and we will hand it to a reserve.`,
    html: wrap(`
      <p>Hello ${o.reviewer},</p>
      <p>A project on <strong>${o.course}</strong> is due in about ${o.hours} hours.</p>
      ${button(o.url, "Open the queue")}
      <p style="font-size:13px;color:#7C7C88">If today is not possible, say so and we will hand it to a reserve.</p>
    `),
  };
}

/* ---------------- operator ---------------- */

export function slaEscalation(o: { items: { course: string; learner: string; label: string }[]; url: string }): Mail {
  const lines = o.items.map((i) => `· ${i.course} — ${i.learner} — ${i.label}`).join("\n");
  const rows = o.items
    .map((i) => `<tr><td style="padding:6px 0">${i.course}</td><td style="padding:6px 0;color:#7C7C88">${i.learner}</td><td style="padding:6px 0;text-align:right;font-weight:600">${i.label}</td></tr>`)
    .join("");

  return {
    subject: `${o.items.length} review${o.items.length === 1 ? "" : "s"} needs attention`,
    text: `These are close to or past the four-day promise:\n\n${lines}\n\nReassign to a reserve: ${o.url}`,
    html: wrap(`
      <p>These are close to or past the four-day promise.</p>
      <table style="width:100%;border-collapse:collapse;font-size:14px">${rows}</table>
      ${button(o.url, "Open the SLA monitor")}
    `),
  };
}

/* ---------------- institution ---------------- */

export function cohortDigest(o: {
  admin: string; cohort: string; joined: number; active: number;
  passed: number; inactive: number; url: string;
}): Mail {
  return {
    subject: `${o.cohort} — this week`,
    text: `Hello ${o.admin},

${o.cohort} this week:

Joined: ${o.joined}
Active: ${o.active}
Projects passed: ${o.passed}
Not back in two weeks: ${o.inactive}

You are billed on active learners only. See the cohort: ${o.url}`,
    html: wrap(`
      <p>Hello ${o.admin},</p>
      <p><strong>${o.cohort}</strong> this week:</p>
      ${box(`
        <table style="width:100%;font-size:14px">
          <tr><td>Joined</td><td style="text-align:right;font-weight:600">${o.joined}</td></tr>
          <tr><td>Active</td><td style="text-align:right;font-weight:600">${o.active}</td></tr>
          <tr><td>Projects passed</td><td style="text-align:right;font-weight:600">${o.passed}</td></tr>
          <tr><td>Not back in two weeks</td><td style="text-align:right;font-weight:600">${o.inactive}</td></tr>
        </table>
      `)}
      ${button(o.url, "See the cohort")}
      <p style="font-size:13px;color:#7C7C88">You are billed on active learners only — anyone who never starts costs you nothing.</p>
    `),
  };
}

/* ---------------- payment ---------------- */

/**
 * Sent once, when a payment first turns into access.
 *
 * It doubles as the receipt, so it carries the amount and the provider
 * reference. Somebody who has just paid wants to know two things: that it
 * worked, and what they now have. There is no third thing here any more —
 * before 0063 this told them when they would next be charged, and now the
 * answer is never, which is worth saying plainly rather than leaving out.
 */
export function purchaseConfirmed(o: {
  name: string;
  courses: { title: string; url: string }[];
  amount: string;
  reference: string;
  url: string;
}): Mail {
  const one = o.courses.length === 1;
  const list = o.courses.map((c) => c.title);
  const heading = one
    ? `You bought ${list[0]}`
    : `You bought ${o.courses.length} courses`;

  return {
    subject: `${heading} — payment confirmed`,
    text: `Hello ${o.name},

Your payment went through. ${one ? "This course is" : "These courses are"} yours now, and there is nothing to renew.

${list.map((t) => `· ${t}`).join("\n")}

What comes with ${one ? "it" : "each of them"}:
· Every topic, the final exam and the project
· One assessment by a working practitioner, already paid for
· Written feedback within four working days
· A certificate anyone can verify with a code

Paid: ${o.amount}
Reference: ${o.reference}

Start here: ${o.url}

Keep this email — it is your receipt.`,
    html: wrap(`
      <p>Hello ${o.name},</p>
      <p>Your payment went through. ${one ? "This course is" : "These courses are"} yours now, and there is nothing to renew.</p>
      ${box(`
        <p style="margin:0 0 10px;font-weight:600">${one ? "Your course" : "Your courses"}</p>
        ${o.courses.map((c) => `<p style="margin:0 0 6px"><a href="${c.url}" style="color:#0B0B0F">${c.title}</a></p>`).join("")}
      `)}
      ${box(`
        <p style="margin:0 0 10px;font-weight:600">What comes with ${one ? "it" : "each of them"}</p>
        <p style="margin:0 0 6px">Every topic, the final exam and the project</p>
        <p style="margin:0 0 6px">One assessment by a working practitioner, already paid for</p>
        <p style="margin:0 0 6px">Written feedback within four working days</p>
        <p style="margin:0">A certificate anyone can verify with a code</p>
      `)}
      <table style="width:100%;font-size:14px;color:#7C7C88;margin-top:18px">
        <tr><td style="padding:5px 0">Paid</td><td style="padding:5px 0;text-align:right;color:#0B0B0F">${o.amount}</td></tr>
        <tr><td style="padding:5px 0">Reference</td><td style="padding:5px 0;text-align:right;color:#0B0B0F">${o.reference}</td></tr>
      </table>
      <p style="font-size:13px;color:#7C7C88;margin-top:20px">Keep this email — it is your receipt. There is no renewal date and nothing to cancel.</p>
    `),
  };
}

/* ---------------- marketplace ---------------- */

/**
 * The buyer's receipt. Separate from purchaseConfirmed because that one
 * talks about assessors, feedback and certificates — true of a course and
 * nonsense about a font. What a file buyer needs is the download, the
 * licence they chose, and the reference to quote if it goes wrong.
 */
export function itemsPurchased(o: {
  name: string;
  items: { title: string; licence: string; url: string }[];
  amount: string;
  reference: string;
  url: string;
}): Mail {
  const one = o.items.length === 1;
  const heading = one ? `You bought ${o.items[0].title}` : `You bought ${o.items.length} items`;
  const line = (i: { title: string; licence: string }) =>
    `${i.title} — ${i.licence} licence`;

  return {
    subject: `${heading} — payment confirmed`,
    text: `Hello ${o.name},

Your payment went through. ${one ? "It is" : "They are"} in your library now, ready to download.

${o.items.map((i) => `· ${line(i)}`).join("\n")}

Paid: ${o.amount}
Reference: ${o.reference}

Download: ${o.url}

Updates to ${one ? "this item" : "these items"} are included — when a creator improves a file, the new version is waiting in your library at no extra cost.

Keep this email — it is your receipt.`,
    html: wrap(`
      <p>Hello ${o.name},</p>
      <p>Your payment went through. ${one ? "It is" : "They are"} in your library now, ready to download.</p>
      ${box(o.items.map((i) => `
        <p style="margin:0 0 6px"><a href="${i.url}" style="color:#0B0B0F">${i.title}</a>
        <span style="color:#7C7C88"> — ${i.licence} licence</span></p>`).join(""))}
      ${box(`
        <p style="margin:0">Paid <strong>${o.amount}</strong></p>
        <p style="margin:6px 0 0;color:#7C7C88">Reference ${o.reference}</p>
      `)}
      ${button(o.url, one ? "Download it" : "Download them")}
      <p style="font-size:13px;color:#7C7C88">Updates are included — when a creator improves a file, the new version is waiting in your library at no extra cost.</p>
      <p style="font-size:13px;color:#7C7C88">Keep this email — it is your receipt.</p>
    `),
  };
}

/**
 * The creator's side of the same event. Deliberately states the hold date
 * rather than only the amount: "you earned $40" followed by a balance
 * that cannot be withdrawn reads as a broken promise, where "available
 * from the 12th" reads as a rule.
 */
export function itemSold(o: {
  name: string; item: string; licence: string;
  gross: string; fee: string | null; net: string;
  availableOn: string; url: string;
}): Mail {
  return {
    subject: `You sold ${o.item}`,
    text: `Hello ${o.name},

Someone bought ${o.item} on the ${o.licence} licence.

They paid: ${o.gross}
${o.fee ? `Platform fee: ${o.fee}\n` : ""}Your share: ${o.net}

It clears on ${o.availableOn}, after the seven-day hold, and can be withdrawn from your earnings page then.

${o.url}`,
    html: wrap(`
      <p>Hello ${o.name},</p>
      <p>Someone bought <strong>${o.item}</strong> on the ${o.licence} licence.</p>
      ${box(`
        <p style="margin:0">They paid ${o.gross}</p>
        ${o.fee ? `<p style="margin:6px 0 0;color:#7C7C88">Platform fee ${o.fee}</p>` : ""}
        <p style="margin:6px 0 0;font-weight:600">Your share ${o.net}</p>
      `)}
      <p>It clears on <strong>${o.availableOn}</strong>, after the seven-day hold, and can be withdrawn from your earnings page then.</p>
      ${button(o.url, "See your earnings")}
    `),
  };
}

/** An item passed review and is live. */
export function itemApproved(o: { name: string; item: string; url: string }): Mail {
  return {
    subject: `${o.item} is live`,
    text: `Hello ${o.name},

${o.item} passed review and is on the marketplace now. Anyone can find it, and you will get an email the first time it sells.

See it as buyers do: ${o.url}`,
    html: wrap(`
      <p>Hello ${o.name},</p>
      <p><strong>${o.item}</strong> passed review and is on the marketplace now. Anyone can find it, and you will get an email the first time it sells.</p>
      ${button(o.url, "See it as buyers do")}
    `),
  };
}

/**
 * Sent back for changes. The note is the whole email — an author who is
 * told "not yet" without being told why cannot act, and will either guess
 * or give up.
 */
export function itemNeedsChanges(o: { name: string; item: string; note: string; url: string }): Mail {
  return {
    subject: `${o.item} needs a change before it goes live`,
    text: `Hello ${o.name},

We read through ${o.item} and it is not quite ready. Here is what needs doing:

${o.note}

Make the change and submit it again — it goes back in the same queue, and there is no limit on attempts.

${o.url}`,
    html: wrap(`
      <p>Hello ${o.name},</p>
      <p>We read through <strong>${o.item}</strong> and it is not quite ready. Here is what needs doing:</p>
      ${box(`<p style="margin:0;white-space:pre-wrap">${o.note}</p>`)}
      <p>Make the change and submit it again — it goes back in the same queue, and there is no limit on attempts.</p>
      ${button(o.url, "Open the item")}
    `),
  };
}

/**
 * A file the buyer already owns has been replaced. Only worth sending
 * when the creator says what changed: an email that reads "something was
 * updated" gives the reader nothing to decide with.
 */
export function itemUpdated(o: { name: string; item: string; note: string; url: string }): Mail {
  return {
    subject: `${o.item} has been updated`,
    text: `Hello ${o.name},

${o.item}, which you own, has a new version. From the creator:

${o.note}

It is in your library — download it again whenever you like, at no extra cost.

${o.url}`,
    html: wrap(`
      <p>Hello ${o.name},</p>
      <p><strong>${o.item}</strong>, which you own, has a new version. From the creator:</p>
      ${box(`<p style="margin:0;white-space:pre-wrap">${o.note}</p>`)}
      <p>It is in your library — download it again whenever you like, at no extra cost.</p>
      ${button(o.url, "Go to your library")}
    `),
  };
}
