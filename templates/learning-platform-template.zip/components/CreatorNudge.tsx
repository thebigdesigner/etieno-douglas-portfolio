"use client";

import Link from "next/link";
import { useState } from "react";
import { setNudge, dismissNudge } from "@/app/actions/studio";

/**
 * A strip, not a modal. A modal over somebody's half-built course teaches
 * them to hit the X without reading, and then the nudge is worthless.
 */
export default function CreatorNudge() {
  const [gone, setGone] = useState(false);
  if (gone) return null;

  return (
    <div className="nudge">
      <div className="nudge__body">
        <span className="nudge__t">Designed by Aphinity Digital.</span>
        <span className="nudge__s">
          This is placeholder copy from Aphinity Digital. Replace it with a sentence about what your business does best.
        </span>
      </div>
      <div className="nudge__acts">
        <Link className="btn btn--fill" href="/studio/creator-course">Have a look</Link>
        <button
          className="nudge__later"
          onClick={() => { setGone(true); dismissNudge(); }}
        >
          Not now
        </button>
        <button
          className="nudge__off"
          onClick={() => { setGone(true); setNudge(true); }}
        >
          Stop asking
        </button>
      </div>
    </div>
  );
}
