"use client";

import Link from "next/link";
import { useEffect, useRef, useState } from "react";
import { CATEGORIES } from "@/lib/marketplace/categories";
import { mk } from "@/lib/marketplace/href";
import MkIcon from "@/components/marketplace/MkIcon";

/**
 * The blue category band from the reference. Twelve categories, four or so
 * visible, the arrow scrolling the rest into view. It is a real scrolling
 * list underneath, so touch, trackpad and keyboard all work without it.
 */
export default function CategoryStrip({ base }: { base: string }) {
  const ref = useRef<HTMLUListElement>(null);
  const [atStart, setAtStart] = useState(true);
  const [atEnd, setAtEnd] = useState(false);

  const measure = () => {
    const el = ref.current;
    if (!el) return;
    setAtStart(el.scrollLeft < 4);
    setAtEnd(el.scrollLeft + el.clientWidth >= el.scrollWidth - 4);
  };
  useEffect(() => {
    measure();
    window.addEventListener("resize", measure);
    return () => window.removeEventListener("resize", measure);
  }, []);

  const go = (dir: 1 | -1) => ref.current?.scrollBy({ left: dir * ref.current.clientWidth * 0.8, behavior: "smooth" });

  return (
    <div className="mk-strip">
      {!atStart && (
        <button type="button" className="mk-strip__arrow mk-strip__arrow--l" onClick={() => go(-1)}>
          <MkIcon name="chevron-left" size={18} /><span className="sr">Previous categories</span>
        </button>
      )}
      <ul className="mk-strip__list" ref={ref} onScroll={measure} aria-label="Categories">
        {CATEGORIES.map((c) => (
          <li key={c.slug}>
            <Link href={mk(base, `/${c.slug}`)} className="mk-strip__item">
              <MkIcon name={c.icon} size={30} />
              <span>{c.name}</span>
            </Link>
          </li>
        ))}
      </ul>
      {!atEnd && (
        <button type="button" className="mk-strip__arrow" onClick={() => go(1)}>
          <MkIcon name="chevron-right" size={18} /><span className="sr">More categories</span>
        </button>
      )}
    </div>
  );
}
