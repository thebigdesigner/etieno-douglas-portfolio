"use client";
import { setNudge } from "@/app/actions/studio";
import { useFormStatus } from "react-dom";

function Btn({ label }: { label: string }) {
  const { pending } = useFormStatus();
  return <button className="btn btn--line" disabled={pending}>{pending ? "…" : label}</button>;
}

export default function NudgeToggle({ off, done }: { off: boolean; done: boolean }) {
  if (done) {
    return (
      <p className="studio__hint" style={{ marginTop: 14 }}>
        You have marked the guide as read, so it will not come up again either way.
      </p>
    );
  }

  return (
    <div className="acct__row">
      <div>
        <div className="acct__k">
          {off ? "Reminders are off" : "Weekly reminder about the guide"}
        </div>
        <p className="acct__v">
          {off
            ? "We will not mention it again. The guide is still here whenever you want it."
            : "Once a week until you have read it, or until you turn this off. Never a pop-up over your work."}
        </p>
      </div>
      <form action={setNudge.bind(null, !off)}>
        <Btn label={off ? "Turn reminders on" : "Turn reminders off"} />
      </form>
    </div>
  );
}
