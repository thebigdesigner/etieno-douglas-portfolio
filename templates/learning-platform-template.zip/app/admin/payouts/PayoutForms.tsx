"use client";
import { useActionState } from "react";
import { runPoolCalculation, runPayouts } from "@/app/actions/institution";
import type { FormState } from "@/lib/forms";
import SubmitButton from "@/components/SubmitButton";
import Alert from "@/components/Alert";

const initial: FormState = {};

export default function PayoutForms() {
  const [poolState, poolAction] = useActionState(runPoolCalculation, initial);
  const [payState, payAction] = useActionState(runPayouts, initial);

  const lastMonth = new Date();
  lastMonth.setMonth(lastMonth.getMonth() - 1);

  return (
    <div className="ctools" style={{ marginTop: 26 }}>
      <div className="ctools__forms">
        <h2 className="sub__h2">Calculate a pool</h2>
        <form action={poolAction} className="auth__form">
          <div className="studio__two">
            <label className="field">
              <span className="field__label">Month</span>
              <input name="month" type="month" defaultValue={lastMonth.toISOString().slice(0, 7)} required />
            </label>
            <label className="field">
              <span className="field__label">Source</span>
              <select name="source" defaultValue="individual">
                <option value="individual">Subscriptions (35%)</option>
                <option value="institution">Institutions (30%)</option>
              </select>
            </label>
          </div>
          <label className="field">
            <span className="field__label">Revenue for that month (USD)</span>
            <input name="revenue" type="number" step="0.01" min="0" required />
            <span className="field__hint">
              Net of refunds, from the payment provider. This is the figure the pool
              divides.
            </span>
          </label>
          {poolState.error && <Alert kind="error">{poolState.error}</Alert>}
          {poolState.ok && <Alert kind="success">{poolState.message}</Alert>}
          <SubmitButton>Calculate and credit</SubmitButton>
        </form>
      </div>

      <div className="ctools__forms">
        <h2 className="sub__h2">Run payouts</h2>
        <form action={payAction} className="auth__form">
          <label className="field">
            <span className="field__label">Week commencing</span>
            <input name="week" type="date" required />
            <span className="field__hint">
              Balances under $20 roll to the following week.
            </span>
          </label>
          {payState.error && <Alert kind="error">{payState.error}</Alert>}
          {payState.ok && <Alert kind="success">{payState.message}</Alert>}
          <SubmitButton>Prepare run</SubmitButton>
        </form>
      </div>
    </div>
  );
}
