-- =====================================================================
-- 0061 — notifications for the people who run the place
--
-- The bell exists, works, and is mounted on exactly one surface: the
-- learner dashboard. Console, admin, studio and institution have none.
-- So everything that needs a person to act — a course waiting for
-- review, an organisation waiting on verification, an appeal, a
-- breached SLA, an overdue deletion request — is visible only if
-- somebody happens to open the right page.
--
-- That is the same shape as the crons: the work is being done, and
-- nothing tells anyone it is waiting. It matters more here because
-- several of these carry promises with clocks on them. A deletion
-- request has thirty days in writing. An assessment has four working
-- days on every page of the site.
--
-- Two functions, following learner_notifications exactly: derived from
-- rows that already exist, never a second copy that could drift.
--
--   operator_notifications   what Your Brand has to act on
--   instructor_notifications what a practitioner has to act on
--
-- Both return the same shape the bell already renders, so nothing in
-- the component changes.
-- =====================================================================

create or replace function public.operator_notifications(p_user_id uuid)
returns table (kind text, title text, body text, at timestamptz, href text)
language sql stable security definer set search_path = public as $$
  -- Courses waiting for a decision.
  select 'review'::text,
         'Course awaiting review',
         c.title || ' is waiting for a decision',
         c.created_at,
         '/admin/courses/' || c.slug
    from courses c
   where c.state = 'in_review'

  union all

  -- Organisations that cannot start until somebody looks.
  select 'review',
         'Verification waiting',
         i.name || ' has submitted documents',
         i.submitted_at,
         '/admin/verification'
    from institutions i
   where i.verification = 'pending'
     and i.submitted_at is not null

  union all

  -- Appeals: a second reader is owed, and the learner is waiting.
  select 'review',
         'Appeal to assign',
         'A learner has appealed a verdict',
         a.created_at,
         '/admin/appeals'
    from appeals a
   where a.resolved_at is null
     and a.second_reviewer_id is null

  union all

  -- The four-day promise, already broken.
  select 'sla',
         'Assessment overdue',
         q.course_title || ' — ' || coalesce(q.learner_name, 'a learner') || ' is past the deadline',
         q.deadline_at,
         '/admin/sla'
    from review_queue_status q
   where q.breached

  union all

  -- Thirty days, in writing, on the account page.
  select 'sla',
         'Deletion request overdue',
         coalesce(d.display_name, 'Someone') || ' asked to be erased and the 30 days have passed',
         d.due_at,
         '/console/people'
    from deletion_queue d
   where d.state = 'pending' and d.overdue

  union all

  -- Practitioners waiting to hear back.
  select 'review',
         'Instructor application',
         'Somebody has applied to teach',
         ia.created_at,
         '/admin/applications'
    from instructor_applications ia
   where ia.state in ('submitted','reviewing')

  order by 4 desc
  limit 20;
$$;

create or replace function public.instructor_notifications(p_user_id uuid)
returns table (kind text, title text, body text, at timestamptz, href text)
language sql stable security definer set search_path = public as $$
  -- Work assigned to them, with the clock running.
  select 'review'::text,
         case when q.breached then 'Assessment overdue' else 'Project to assess' end,
         q.course_title || ' — ' || coalesce(q.learner_name, 'a learner'),
         q.submitted_at,
         '/review/' || q.submission_id::text
    from review_queue_status q
   where q.assigned_reviewer_id = p_user_id

  union all

  -- A verdict on their own course.
  select 'certificate',
         case when c.state = 'published' then 'Course published'
              else 'Changes asked for' end,
         c.title,
         coalesce(c.published_at, c.created_at),
         '/studio/' || c.slug
    from courses c
   where c.instructor_id = p_user_id
     and c.state in ('published', 'revision_requested')
     and coalesce(c.published_at, c.created_at) > now() - interval '30 days'

  union all

  -- Money in. Sales and pool credits both land here.
  select 'certificate',
         case e.type when 'review' then 'Assessment fee'
                     when 'referral' then 'Referral'
                     else 'Royalty pool' end,
         '$' || to_char(e.amount_cents / 100.0, 'FM999999990.00')
           || coalesce(' — ' || e.note, ''),
         e.created_at,
         '/studio/earnings'
    from earnings_entries e
   where e.instructor_id = p_user_id
     and e.created_at > now() - interval '30 days'

  order by 4 desc
  limit 20;
$$;

revoke all on function public.operator_notifications(uuid) from public, anon;
revoke all on function public.instructor_notifications(uuid) from public, anon;
grant execute on function public.operator_notifications(uuid) to authenticated, service_role;
grant execute on function public.instructor_notifications(uuid) to authenticated, service_role;
