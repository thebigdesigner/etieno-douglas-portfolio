/**
 * Shown while a route's data is fetched. Dots in the middle of an empty
 * page read as a fault rather than a wait, and a bare progress bar leaves
 * the same emptiness underneath it — so the page is stood in for: a
 * heading, two lines of text and a few cards at the sizes the real ones
 * use, with a hairline sweep along the top edge. Nothing jumps when the
 * content arrives, because the shapes are already the right height.
 */
export default function Loading() {
  return (
    <div className="pageload" role="status" aria-live="polite">
      <span className="pageload__bar" />
      <span className="sr">Loading</span>
      <div className="wrap" aria-hidden="true">
        <div className="skel skel--h" />
        <div className="skel skel--p" />
        <div className="pageload__grid">
          {Array.from({ length: 3 }, (_, i) => (
            <div className="pageload__card" key={i}>
              <div className="skel skel--line" style={{ width: "72%" }} />
              <div className="skel skel--line" style={{ width: "94%", marginTop: 14 }} />
              <div className="skel skel--line" style={{ width: "58%", marginTop: 8 }} />
              <div className="skel skel--pill" style={{ marginTop: 20 }} />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
