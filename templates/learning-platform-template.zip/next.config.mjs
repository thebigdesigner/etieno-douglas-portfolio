import { fileURLToPath } from 'node:url';
import { dirname } from 'node:path';

const projectRoot = dirname(fileURLToPath(import.meta.url));

/** @type {import('next').NextConfig} */
const isStatic = process.env.STATIC_EXPORT === '1';   // GitHub Pages
const isDocker = process.env.DOCKER_BUILD === '1';     // VPS / Docker

const nextConfig = {
  reactStrictMode: true,
  experimental: {
    // Server actions cap request bodies at 1MB by default. The avatar form
    // accepts up to 3MB, so anything larger was rejected by the framework
    // before the action ran — which surfaces as a full error page rather
    // than the inline message the form is designed to show.
    serverActions: { bodySizeLimit: '5mb' },
  },
  // Pin the workspace root so a stray package-lock.json further up the
  // filesystem cannot confuse Turbopack about where the project starts.
  turbopack: { root: projectRoot },
  ...(isDocker ? { output: 'standalone' } : {}),
  ...(isStatic
    ? {
        output: 'export',
        images: { unoptimized: true },
        trailingSlash: true,
        basePath: process.env.BASE_PATH || '',
      }
    : {
        images: {
          formats: ['image/avif', 'image/webp'],
          remotePatterns: [
            {
              protocol: 'https',
              hostname: '**.supabase.co',
              pathname: '/storage/v1/object/public/**',
            },
          ],
        },
      }),
};

export default nextConfig;
