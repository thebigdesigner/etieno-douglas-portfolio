import Link from "next/link";
import AuthShell from "@/components/AuthShell";
import JoinForm from "./JoinForm";

export const metadata = { title: "Join your class" };

export default function JoinPage() {
  return (
    <AuthShell
      eyebrow="For learners in a class"
      title="Join your class"
      intro="Your teacher gave you a class code and a username. You do not need an email address."
      footer={
        <>
          <Link href="/join/forgot-pin">Forgotten your PIN?</Link>
          <br />
          Not part of a class? <Link href="/signup">Create your own account</Link>
        </>
      }
    >
      <JoinForm />
    </AuthShell>
  );
}
