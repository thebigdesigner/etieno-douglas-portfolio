-- =====================================================================
-- Owner console
-- =====================================================================

-- Operators run the day to day. Owners can do things that cannot be undone.
alter type user_role add value if not exists 'owner';

-- ---------------------------------------------------------------------
-- Every privileged action is written down. Suspending someone or revoking
-- a certificate should leave a trace with a name against it.
-- ---------------------------------------------------------------------
create table admin_actions (
  id          uuid primary key default gen_random_uuid(),
  actor_id    uuid references profiles(id) on delete set null,
  action      text not null,
  subject_type text not null,        -- user, course, institution, certificate
  subject_id  text not null,
  reason      text,
  detail      jsonb,
  created_at  timestamptz not null default now()
);

create index on admin_actions (created_at desc);
create index on admin_actions (subject_type, subject_id);

alter table admin_actions enable row level security;

create or replace function public.log_admin_action(
  p_actor uuid, p_action text, p_subject_type text,
  p_subject_id text, p_reason text, p_detail jsonb
)
returns void
language sql security definer set search_path = public as $$
  insert into admin_actions (actor_id, action, subject_type, subject_id, reason, detail)
  values (p_actor, p_action, p_subject_type, p_subject_id, p_reason, p_detail);
$$;

-- ---------------------------------------------------------------------
-- Money. Subscription revenue is not in the system until the payment
-- provider is connected, so this reports what we can actually count and
-- says nothing about what we cannot.
-- ---------------------------------------------------------------------
create or replace view public.revenue_monthly as
with months as (
  select date_trunc('month', d)::date as month
    from generate_series(current_date - interval '11 months', current_date, interval '1 month') d
)
select m.month,
       coalesce((select sum(i.amount_cents) from invoices i
                  where i.period_month = m.month and i.state in ('issued','paid')), 0) as institution_cents,
       coalesce((select sum(i.amount_cents) from invoices i
                  where i.period_month = m.month and i.state = 'paid'), 0)            as institution_collected_cents,
       coalesce((select sum(ee.amount_cents) from earnings_entries ee
                  where date_trunc('month', ee.created_at)::date = m.month), 0)       as instructor_cost_cents,
       coalesce((select count(*) from reviews r
                  where date_trunc('month', r.completed_at)::date = m.month), 0)      as reviews,
       coalesce((select count(*) from certificates c
                  where date_trunc('month', c.issued_at)::date = m.month), 0)         as certificates
  from months m
 order by m.month desc;

-- ---------------------------------------------------------------------
-- Whether the promise is being kept, by instructor. This is the number
-- that decides whether the differentiator survives contact with volume.
-- ---------------------------------------------------------------------
create or replace view public.instructor_health as
select i.id,
       p.display_name,
       p.email,
       i.state,
       i.available,
       count(distinct c.id) filter (where c.state = 'published')          as courses_live,
       count(distinct r.id)                                              as reviews_done,
       count(distinct r.id) filter (where r.within_sla)                   as reviews_in_sla,
       round(100.0 * count(distinct r.id) filter (where r.within_sla)
             / nullif(count(distinct r.id), 0), 1)                        as sla_pct,
       count(distinct s.id) filter (where s.state in ('submitted','assigned','in_review'))
                                                                          as queue_now,
       coalesce(sum(ee.amount_cents), 0)                                  as earned_cents,
       max(r.completed_at)                                                as last_review
  from instructors i
  join profiles p on p.id = i.id
  left join courses c on c.instructor_id = i.id
  left join reviews r on r.reviewer_id = i.id
  left join submissions s on s.assigned_reviewer_id = i.id
  left join earnings_entries ee on ee.instructor_id = i.id
 group by i.id, p.display_name, p.email, i.state, i.available;

-- ---------------------------------------------------------------------
-- Everything an owner should look at before anything else.
-- ---------------------------------------------------------------------
create or replace view public.owner_attention as
select
  (select count(*) from review_queue_status where breached)                as sla_breached,
  (select count(*) from review_queue_status where due_soon and not breached) as sla_due_soon,
  (select count(*) from institutions where verification = 'pending')       as verifications_waiting,
  (select count(*) from courses where state = 'in_review')                 as courses_waiting,
  (select count(*) from appeals where resolved_at is null)                 as appeals_open,
  (select count(*) from instructors where state = 'applied')               as applications_waiting,
  (select count(*) from invoices where state = 'overdue')                  as invoices_overdue,
  (select count(*) from profiles
     where status = 'pending_consent' and created_at < now() - interval '10 days') as consent_expiring,
  (select count(*) from submissions
     where state in ('submitted','assigned','in_review') and assigned_reviewer_id is null) as unassigned;

-- ---------------------------------------------------------------------
-- Owner powers. Each writes to the audit log in the same transaction, so
-- an action without a trace is not a state that can exist.
-- ---------------------------------------------------------------------
create or replace function public.owner_set_role(
  p_actor uuid, p_user_id uuid, p_role user_role, p_reason text
)
returns boolean
language plpgsql security definer set search_path = public as $$
declare v_old user_role;
begin
  select role into v_old from profiles where id = p_user_id;
  if not found then return false; end if;

  update profiles set role = p_role where id = p_user_id;

  perform log_admin_action(p_actor, 'set_role', 'user', p_user_id::text, p_reason,
                           jsonb_build_object('from', v_old, 'to', p_role));
  return true;
end; $$;

create or replace function public.owner_suspend_user(
  p_actor uuid, p_user_id uuid, p_suspend boolean, p_reason text
)
returns boolean
language plpgsql security definer set search_path = public as $$
begin
  update profiles
     set status = case when p_suspend then 'suspended'::profile_status else 'active'::profile_status end
   where id = p_user_id;
  if not found then return false; end if;

  perform log_admin_action(p_actor, case when p_suspend then 'suspend_user' else 'restore_user' end,
                           'user', p_user_id::text, p_reason, null);
  return true;
end; $$;

create or replace function public.owner_revoke_certificate(
  p_actor uuid, p_code text, p_reason text
)
returns boolean
language plpgsql security definer set search_path = public as $$
begin
  update certificates
     set revoked_at = now(), revoke_reason = p_reason
   where code = p_code and revoked_at is null;
  if not found then return false; end if;

  perform log_admin_action(p_actor, 'revoke_certificate', 'certificate', p_code, p_reason, null);
  return true;
end; $$;

create or replace function public.owner_unpublish_course(
  p_actor uuid, p_course_id uuid, p_reason text
)
returns boolean
language plpgsql security definer set search_path = public as $$
begin
  update courses set state = 'unpublished' where id = p_course_id and state = 'published';
  if not found then return false; end if;

  perform log_admin_action(p_actor, 'unpublish_course', 'course', p_course_id::text, p_reason, null);
  return true;
end; $$;

revoke all on function public.log_admin_action(uuid, text, text, text, text, jsonb) from public, anon, authenticated;
revoke all on function public.owner_set_role(uuid, uuid, user_role, text) from public, anon, authenticated;
revoke all on function public.owner_suspend_user(uuid, uuid, boolean, text) from public, anon, authenticated;
revoke all on function public.owner_revoke_certificate(uuid, text, text) from public, anon, authenticated;
revoke all on function public.owner_unpublish_course(uuid, uuid, text) from public, anon, authenticated;
