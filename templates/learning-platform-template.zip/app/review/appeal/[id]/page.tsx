import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import AppealDecision from "./AppealDecision";

export const metadata = { title: "Second reading" };
export const dynamic = "force-dynamic";

type Params = Promise<{ id: string }>;

export default async function AppealReviewPage({ params }: { params: Params }) {
  const { id } = await params;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  const admin = createAdminClient();
  const { data: appeal } = await admin
    .from("appeals")
    .select("id, submission_id, grounds, second_reviewer_id, resolved_at")
    .eq("id", id).maybeSingle();

  if (!appeal) notFound();
  if (appeal.second_reviewer_id !== user!.id) redirect("/review");
  if (appeal.resolved_at) redirect("/review");

  const { data: sub } = await admin
    .from("submissions")
    .select("id, body, file_paths, attempt_no, enrolment_id")
    .eq("id", appeal.submission_id).maybeSingle();

  const { data: enrolment } = await admin
    .from("enrolments").select("course_id, user_id").eq("id", sub!.enrolment_id).maybeSingle();

  const { data: course } = await admin
    .from("courses").select("id, title, project_brief").eq("id", enrolment!.course_id).maybeSingle();

  const { data: criteria } = await admin
    .from("rubric_criteria").select("id, title, descriptor, max_score")
    .eq("course_id", course!.id).order("position");

  const files = await Promise.all(
    (sub!.file_paths ?? []).map(async (path: string) => {
      const { data } = await admin.storage.from("submissions").createSignedUrl(path, 3600);
      return { name: path.split("/").pop() ?? "attachment", url: data?.signedUrl ?? null };
    })
  );

  return (
    <div className="rvw">
        <nav className="crumb" style={{ paddingTop: 28 }}>
          <Link href="/review">Review queue</Link> / Second reading
        </nav>

        <div className="rvw__head">
          <div>
            <h1 className="rvw__h">{course!.title}</h1>
            <p className="rvw__meta">
              <span className="pill">Appeal</span>
              <span style={{ marginLeft: 10 }}>Attempt {sub!.attempt_no}</span>
            </p>
          </div>
        </div>

        <div className="blind">
          <div className="eyebrow">Read this cold</div>
          <p className="blind__p">
            You are not being shown the first verdict or the first reviewer&rsquo;s
            feedback, deliberately. Assess the work against the rubric as if you were
            seeing it for the first time — because as far as this decision goes, you are.
          </p>
        </div>

        <section className="rvw__brief">
          <div className="eyebrow">The brief they were given</div>
          <p className="rvw__briefp">{course!.project_brief}</p>
        </section>

        <section className="rvw__prior" style={{ background: "var(--blue-soft)" }}>
          <div className="eyebrow">What the learner says</div>
          <p className="rvw__priorp">{appeal.grounds}</p>
        </section>

        <section className="rvw__work">
          <h2 className="sub__h2">Their submission</h2>
          <div className="rvw__body">{sub!.body}</div>
          {files.length > 0 && (
            <div className="rvw__files">
              {files.map((f) => (
                <a key={f.name} className="rvw__file" href={f.url ?? "#"} target="_blank" rel="noreferrer">
                  {f.name}
                </a>
              ))}
            </div>
          )}
        </section>

        <AppealDecision appealId={appeal.id} criteria={criteria ?? []} />
    </div>
  );
}
