"use client";

import { useFormStatus } from "react-dom";

export default function StudioSubmit({ children, kind = "fill" }: { children: React.ReactNode; kind?: "fill" | "line" }) {
  const { pending } = useFormStatus();
  return (
    <button type="submit" className={`mk-btn mk-btn--${kind}`} disabled={pending} aria-busy={pending}>
      {pending ? "Saving…" : children}
    </button>
  );
}
