"use client";

import Link from "next/link";
import MkIcon from "@/components/marketplace/MkIcon";
import { useCart } from "@/lib/marketplace/cart";

/** The top bar's Cart, with a count once there is something in it. */
export default function CartButton({ href }: { href: string }) {
  const n = useCart().length;
  return (
    <Link href={href} className="mk-top__act mk-cartbtn">
      <span className="mk-cartbtn__ico">
        <MkIcon name="cart" size={21} />
        {n > 0 && <span className="mk-cartbtn__n num" aria-hidden="true">{n > 9 ? "9+" : n}</span>}
      </span>
      <span className="mk-top__lab">Cart</span>
      {n > 0 && <span className="sr">, {n} {n === 1 ? "item" : "items"}</span>}
    </Link>
  );
}
