import { openPayouts } from "@/lib/marketplace/wallet";
import { money, type Ccy } from "@/lib/currency";
import PayoutDecision from "./PayoutDecision";

export const metadata = { title: "Creator withdrawals" };
export const dynamic = "force-dynamic";

/**
 * Withdrawals waiting to be sent. The wallet was already debited when the
 * creator asked, so approving changes nothing financial — the money moves
 * when you send the transfer from the bank or Paystack, and "Mark paid"
 * records that you did. Sending one back returns the money to the wallet.
 */
export default async function AdminPayoutsPage() {
  const rows = await openPayouts();
  // Totalled per currency: adding naira to pounds would mean a rate.
  const totals = rows.reduce<Record<string, number>>((acc, r) => {
    acc[r.currency] = (acc[r.currency] ?? 0) + r.amountCents; return acc;
  }, {});

  return (
    <>
      <h1 className="sec__h" style={{ fontSize: 30, marginTop: 34 }}>
        {rows.length} withdrawal{rows.length === 1 ? "" : "s"} to send
      </h1>
      <p className="sec__meta">
        {rows.length > 0 && <>{Object.entries(totals).map(([c, n]) => money(n, c as Ccy)).join(" and ")} in total. </>}
        Check the account name matches the creator before sending money, then mark it paid with the transfer reference.
      </p>

      {rows.length === 0 ? (
        <div className="empty" style={{ marginTop: 28 }}>
          <p className="empty__h">Nothing waiting</p>
          <p className="empty__p">Requests appear here when a creator withdraws from their marketplace wallet.</p>
        </div>
      ) : (
        <div className="apps">
          {rows.map((r) => (
            <article key={r.id} className="app">
              <div className="app__head">
                <div>
                  <div className="app__name">{money(r.amountCents, r.currency)} — {r.creator?.display_name ?? "Creator"}</div>
                  <div className="app__hl">
                    @{r.creator?.handle} · requested {new Date(r.requestedAt).toLocaleDateString("en-GB")} · {r.status}
                  </div>
                </div>
              </div>
              <div className="app__field">
                <div className="eyebrow">Send to</div>
                <p>
                  {r.account.account_name} · {r.account.bank_name} · {r.account.account_number} ·{" "}
                  {r.account.currency} ({r.account.country})
                </p>
              </div>
              <PayoutDecision id={r.id} status={r.status} />
            </article>
          ))}
        </div>
      )}
    </>
  );
}
