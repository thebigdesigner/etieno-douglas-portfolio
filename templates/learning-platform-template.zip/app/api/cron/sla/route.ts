import { NextResponse } from "next/server";
import { siteUrl } from "@/lib/site";
import { createAdminClient } from "@/lib/supabase/admin";
import { sendEmail } from "@/lib/email";
import { reviewDueSoon, slaEscalation } from "@/lib/notifications";
import { slaLabel } from "@/lib/sla";
import { track } from "@/lib/track";
import { runJob } from "@/lib/cron";

export const dynamic = "force-dynamic";
export const maxDuration = 60;

/**
 * Runs a few times a day.
 *
 * Day three: warn the reviewer and alert an operator — before the promise
 * breaks, not after. Day four: flag it as breached so the SLA monitor surfaces
 * it for reassignment.
 */
export async function GET(request: Request) {
  return runJob("sla", request, async () => {
  const admin = createAdminClient();
  const { data: queue } = await admin.from("review_queue_status").select("*");
  const rows = queue ?? [];

  const dueSoon = rows.filter((r) => r.due_soon && !r.breached);
  const breached = rows.filter((r) => r.breached);

  let warned = 0;

  for (const r of dueSoon) {
    if (!r.assigned_reviewer_id) continue;

    // Only warn once per submission.
    const { data: already } = await admin
      .from("submissions").select("escalated_at").eq("id", r.submission_id).maybeSingle();
    if (already?.escalated_at) continue;

    const { data: reviewer } = await admin
      .from("profiles").select("display_name, email").eq("id", r.assigned_reviewer_id).maybeSingle();

    if (reviewer?.email) {
      const hours = Math.max(
        1, Math.round((new Date(r.deadline_at).getTime() - Date.now()) / 3600_000)
      );
      await sendEmail({
        to: reviewer.email,
        ...reviewDueSoon({
          reviewer: reviewer.display_name ?? "there",
          course: r.course_title,
          hours,
          url: `${siteUrl()}/review`,
        }),
      });
      warned += 1;
    }

    await admin.from("submissions")
      .update({ escalated_at: new Date().toISOString() }).eq("id", r.submission_id);
  }

  for (const r of breached) {
    await track("sla_breached", null, {
      submissionId: r.submission_id, course: r.course_title,
    });
  }

  const attention = [...breached, ...dueSoon];
  if (attention.length > 0) {
    const { data: operators } = await admin
      .from("profiles").select("email").eq("role", "operator");

    const mail = slaEscalation({
      items: attention.map((r) => ({
        course: r.course_title,
        learner: r.learner_name ?? "Learner",
        label: slaLabel(r.deadline_at),
      })),
      url: `${siteUrl()}/admin/sla`,
    });

    for (const op of operators ?? []) {
      if (op.email) await sendEmail({ to: op.email, ...mail });
    }
  }

  return { checked: rows.length, warned, breached: breached.length };
  });
}
