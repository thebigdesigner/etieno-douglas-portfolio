"use client";

import { useEffect } from "react";
import Link from "next/link";

/**
 * The whole-page failure card.
 *
 * The digest is shown deliberately: it is the only string that ties what a
 * person saw to a line in the server logs, and asking somebody to describe
 * an error is a much worse way to find it.
 */
export default function Error({
  error, reset,
}: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    console.error(error);
  }, [error]);

  return (
    <main className="oops">
      <div className="oops__card">
        <span className="oops__ring" aria-hidden="true">
          <span className="oops__disc">!</span>
        </span>
        <h1 className="oops__h">Something went wrong at our end</h1>
        <p className="oops__p">
          This is not your fault, and nothing you had saved is lost. Try again —
          if it keeps happening, send us the reference below.
        </p>
        <div className="oops__btns">
          <button className="btn btn--fill btn--lg" onClick={reset}>
            Try again <span aria-hidden="true">→</span>
          </button>
          <Link className="oops__quiet" href="/">
            <span aria-hidden="true">✕</span> Back to the homepage
          </Link>
        </div>
        {error.digest && <p className="oops__ref num">Reference: {error.digest}</p>}
      </div>
    </main>
  );
}
