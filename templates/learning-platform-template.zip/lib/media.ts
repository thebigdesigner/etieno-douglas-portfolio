/**
 * Thumbnails live in a public bucket, so the URL is deterministic and there
 * is no signing round-trip on a catalogue page showing twenty of them.
 */
export function thumbnailUrl(path: string | null | undefined): string | null {
  if (!path) return null;
  // A full URL is used as-is, matching how avatars and videos resolve. That
  // lets a thumbnail be hosted anywhere during the test phase, and a bucket
  // path later, without the column meaning two different things.
  if (path.startsWith("http://") || path.startsWith("https://")) return path;

  const base = process.env.NEXT_PUBLIC_SUPABASE_URL;
  if (!base) return null;
  return `${base}/storage/v1/object/public/thumbnails/${path}`;
}

/** Six subjects, six accents. A course without a thumbnail still reads as a
 *  card rather than a gap. */
/**
 * One hue per subject, used on the tile, the card spine and the badge. A
 * learner starts recognising "the teal one" before they read the label,
 * which is the whole reason for keeping it consistent.
 */
export function subjectTint(subject: string): string {
  const map: Record<string, string> = {
    "Artificial Intelligence": "violet",
    "Entrepreneurship": "coral",
    "Technology": "indigo",
    "Business Skills": "teal",
    "Creative": "amber",
    "Career": "lime",
  };
  return map[subject] ?? "teal";
}
