"use server";

import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { newReference, resolveProvider, startCheckout } from "@/lib/payments";
import { marketBase, mk } from "@/lib/marketplace/url";
import { marketOrigin } from "@/lib/marketplace/origin";
import { DEFAULT_CCY, readCurrency, type Ccy } from "@/lib/currency";

/**
 * Buying from the marketplace.
 *
 * The cart lives in the buyer's browser, so what arrives here is a list of
 * slugs and licences — never prices. Every price is read from the database
 * at this moment, the order rows are written before anyone leaves for the
 * payment page, and fulfilment settles against those rows. A buyer editing
 * localStorage changes nothing but which items they are buying.
 */

export type CartLineInput = { slug: string; licence: "personal" | "commercial" };
export type CheckoutResult = { error: string } | { url: string } | { freed: string[] };

const MAX_LINES = 20;

export async function startMarketplaceCheckout(
  lines: CartLineInput[], provider?: string | null
): Promise<CheckoutResult> {
  const base = await marketBase();
  if (!Array.isArray(lines) || lines.length === 0) return { error: "Your cart is empty." };
  // Narrowed to something actually configured; a tampered value falls back
  // rather than failing at the payment page.
  // Resolved against the currency below, once the cart has been priced.
  if (lines.length > MAX_LINES) return { error: `A cart can hold ${MAX_LINES} items. Buy in two goes.` };

  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    // Keep the cart; they come back to it signed in.
    redirect(mk(base, `/login?next=${encodeURIComponent("/cart")}`));
  }

  const admin = createAdminClient();
  const slugs = [...new Set(lines.map((l) => String(l.slug)))].slice(0, MAX_LINES);
  const { data: products, error } = await admin.from("mk_products")
    .select("id, slug, title, price_cents, commercial_price_cents, state, creator_id, " +
            "mk_product_prices(currency, price_cents, commercial_cents)")
    .in("slug", slugs);
  if (error) { console.error("checkout: products", error.message); return { error: "Could not start checkout. Try again." }; }

  type Priced = { currency: string; price_cents: number; commercial_cents: number | null };
  type Row = {
    id: string; slug: string; title: string; price_cents: number; commercial_price_cents: number | null;
    state: string; creator_id: string; mk_product_prices?: Priced[] | null;
  };
  const byslug = new Map(((products ?? []) as unknown as Row[]).map((p) => [p.slug, p]));

  /**
   * The whole cart is charged in one currency. A buyer browsing in naira
   * buys in naira only if every item in the basket has a naira price its
   * creator set; otherwise the lot reverts to dollars. Mixing currencies
   * in one payment is not possible, and converting one of them would mean
   * inventing a rate.
   */
  const wanted: Ccy = await readCurrency();
  const priceIn = (p: { mk_product_prices?: Priced[] | null }, ccy: Ccy) =>
    ccy === DEFAULT_CCY ? null : (p.mk_product_prices ?? []).find((r) => r.currency === ccy) ?? null;
  const everyLineHasIt = lines.every((l) => {
    const p = byslug.get(String(l.slug));
    return p ? Boolean(priceIn(p, wanted)) : false;
  });
  const currency: Ccy = wanted !== DEFAULT_CCY && everyLineHasIt ? wanted : DEFAULT_CCY;
  type Line = { productId: string; slug: string; title: string; licence: "personal" | "commercial"; cents: number; creator: string };
  const priced: Line[] = [];

  for (const l of lines) {
    const p = byslug.get(String(l.slug));
    if (!p) return { error: "One of those items is no longer available. Remove it and try again." };
    if (p.state !== "published") return { error: `"${p.title}" is no longer on sale. Remove it from your cart.` };
    const licence = l.licence === "commercial" ? "commercial" : "personal";
    const local = priceIn(p, currency);
    const cents = local
      ? (licence === "commercial" && local.commercial_cents ? local.commercial_cents : local.price_cents)
      : (licence === "commercial" && p.commercial_price_cents ? p.commercial_price_cents : p.price_cents);
    if (priced.some((x) => x.productId === p.id)) continue;   // same item twice is one licence
    priced.push({ productId: p.id, slug: p.slug, title: p.title, licence, cents, creator: p.creator_id });
  }

  // Free items need no payment: record the right to download and move on.
  const free = priced.filter((l) => l.cents === 0);
  const paid = priced.filter((l) => l.cents > 0);

  if (free.length) {
    await admin.from("mk_downloads").insert(
      free.map((l) => ({ product_id: l.productId, user_id: user.id, order_id: null }))
    );
  }
  if (paid.length === 0) return { freed: free.map((l) => l.slug) };

  const totalCents = paid.reduce((n, l) => n + l.cents, 0);
  const { data: profile } = await admin.from("profiles").select("email, display_name").eq("id", user.id).maybeSingle();
  const email = profile?.email ?? user.email;
  if (!email) return { error: "Add an email address to your account before buying." };

  const txRef = newReference("mk");
  const { error: intentError } = await admin.from("checkout_intents").insert({
    tx_ref: txRef, user_id: user.id, kind: "marketplace", plan: null,
    course_ids: [], amount_cents: totalCents, currency,
    return_to: "/marketplace/library",
  });
  if (intentError) { console.error("checkout: intent", intentError.message); return { error: "Could not start checkout. Try again." }; }

  const { error: orderError } = await admin.from("mk_orders").insert(
    paid.map((l) => ({
      user_id: user.id, product_id: l.productId, creator_id: l.creator, licence: l.licence,
      amount_cents: l.cents, usd_cents: currency === DEFAULT_CCY ? l.cents : null,
      currency, tx_ref: txRef, status: "pending",
    }))
  );
  if (orderError) { console.error("checkout: orders", orderError.message); return { error: "Could not start checkout. Try again." }; }

  const origin = await marketOrigin();
  try {
    const started = await startCheckout({
      txRef,
      amount: totalCents / 100,
      currency,
      email,
      name: profile?.display_name,
      description: paid.length === 1 ? paid[0].title : `${paid.length} items from Your Brand Marketplace`,
      provider: resolveProvider(provider, currency),
      redirectUrl: `${origin}${mk(base, "/cart/complete")}`,
      meta: { user_id: user.id, kind: "marketplace" },
    });
    await admin.from("checkout_intents")
      .update({ provider: started.provider, provider_session: started.session }).eq("tx_ref", txRef);
    return { url: started.url };
  } catch (e) {
    console.error("checkout: provider", e);
    await admin.from("mk_orders").update({ status: "failed" }).eq("tx_ref", txRef);
    return { error: "The payment page would not open. Try again in a moment." };
  }
}

/** A free item, taken straight from its page without a cart. */
export async function claimFreeItem(slug: string): Promise<{ error: string } | { ok: true }> {
  const base = await marketBase();
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect(mk(base, `/login?next=${encodeURIComponent(`/item/${slug}`)}`));

  const admin = createAdminClient();
  const { data: p } = await admin.from("mk_products")
    .select("id, price_cents, state").eq("slug", slug).maybeSingle();
  if (!p || p.state !== "published") return { error: "That item is not available." };
  if (p.price_cents > 0) return { error: "That item is not free." };

  // One row per claim (the buyer may download again later from their
  // library); the count on the listing goes up once per claim.
  await admin.from("mk_downloads").insert({ product_id: p.id, user_id: user.id, order_id: null });
  await admin.rpc("mk_bump_downloads", { p_product: p.id });
  return { ok: true };
}

export type CartPricing = {
  currency: Ccy;
  /** Cents per slug, in `currency`, for the licence asked for. */
  lines: Record<string, number>;
  total: number;
  /** True when the visitor's currency was dropped for want of a price. */
  fellBack: boolean;
};

/**
 * Re-prices a cart at the moment it is shown.
 *
 * The browser's cart remembers what an item cost when it was added, which
 * goes stale when a creator changes a price or the visitor switches
 * currency. This is the authority; the stored figure is only a placeholder
 * until this returns.
 */
export async function priceCart(lines: CartLineInput[]): Promise<CartPricing> {
  const wanted = await readCurrency();
  const empty: CartPricing = { currency: wanted, lines: {}, total: 0, fellBack: false };
  if (!Array.isArray(lines) || lines.length === 0) return empty;

  const admin = createAdminClient();
  const { data } = await admin.from("mk_products")
    .select("slug, price_cents, commercial_price_cents, mk_product_prices(currency, price_cents, commercial_cents)")
    .in("slug", lines.map((l) => String(l.slug)).slice(0, MAX_LINES));

  type Priced = { currency: string; price_cents: number; commercial_cents: number | null };
  type Row = { slug: string; price_cents: number; commercial_price_cents: number | null; mk_product_prices?: Priced[] | null };
  const rows = (data ?? []) as unknown as Row[];
  const byslug = new Map(rows.map((r) => [r.slug, r]));

  const local = (r: Row) => (r.mk_product_prices ?? []).find((p) => p.currency === wanted);
  const everyLineHasIt = wanted !== DEFAULT_CCY && lines.every((l) => {
    const r = byslug.get(String(l.slug));
    return r ? Boolean(local(r)) : false;
  });
  const currency: Ccy = everyLineHasIt ? wanted : DEFAULT_CCY;

  const out: Record<string, number> = {};
  for (const l of lines) {
    const r = byslug.get(String(l.slug));
    if (!r) continue;
    const p = currency === DEFAULT_CCY ? null : local(r);
    out[r.slug] = p
      ? (l.licence === "commercial" && p.commercial_cents ? p.commercial_cents : p.price_cents)
      : (l.licence === "commercial" && r.commercial_price_cents ? r.commercial_price_cents : r.price_cents);
  }

  return {
    currency,
    lines: out,
    total: Object.values(out).reduce((n, c) => n + c, 0),
    fellBack: wanted !== DEFAULT_CCY && currency === DEFAULT_CCY,
  };
}
