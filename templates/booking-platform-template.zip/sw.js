/**
 * Your Brand service worker — offline tickets.
 *
 * Network-first for everything it touches, so a phone with signal always gets the live site
 * and live data; the cache is only ever a fallback. What it keeps:
 *   - pages (navigations) and /assets/*        so the site itself opens offline
 *   - the customer's own data: /api/auth/me, /api/bookings?mine=1, /api/bookings/<ref>?phone=
 *     — only on this device, only what this browser already fetched while online
 * Nothing else (payments, staff, the assistant) is ever cached.
 *
 * Bump VERSION to drop old caches after a big change.
 */
const VERSION = 'v1';
const PAGES = `pages-${VERSION}`, ASSETS = `assets-${VERSION}`, DATA = `data-${VERSION}`;

self.addEventListener('install', e => {
  e.waitUntil(caches.open(PAGES).then(c => c.addAll(['/', '/account'])).catch(() => {}));
  self.skipWaiting();
});
self.addEventListener('activate', e => {
  e.waitUntil((async () => {
    for (const k of await caches.keys()) if (![PAGES, ASSETS, DATA].includes(k)) await caches.delete(k);
    await self.clients.claim();
  })());
});

const isData = u => u.pathname === '/api/auth/me' ||
  (u.pathname === '/api/bookings' && u.searchParams.get('mine') === '1') ||
  (/^\/api\/bookings\/[^/]+$/.test(u.pathname) && u.searchParams.get('phone'));

async function networkFirst(req, cacheName, fallbackUrl) {
  try {
    const res = await fetch(req);
    if (res.ok) { const copy = res.clone(); caches.open(cacheName).then(c => c.put(req, copy)).catch(() => {}); }
    return res;
  } catch (err) {
    const hit = await caches.match(req) || (fallbackUrl && await caches.match(fallbackUrl));
    if (!hit) throw err;
    /* Tell the page this came from the phone, not the server, so it can say so. */
    const h = new Headers(hit.headers); h.set('x-from-cache', '1');
    return new Response(await hit.blob(), { status: hit.status, statusText: hit.statusText, headers: h });
  }
}

self.addEventListener('fetch', e => {
  const req = e.request;
  if (req.method !== 'GET') return;
  const u = new URL(req.url);
  if (u.origin !== location.origin) return;
  if (req.mode === 'navigate') {
    if (/^\/(staff|terminal|api)(\/|$)/.test(u.pathname)) return;
    return e.respondWith(networkFirst(req, PAGES, '/'));
  }
  if (u.pathname.startsWith('/assets/')) return e.respondWith(networkFirst(req, ASSETS));
  if (isData(u)) return e.respondWith(networkFirst(req, DATA));
});
