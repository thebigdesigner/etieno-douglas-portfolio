"use client";

import { useEffect, useRef, useState } from "react";
import { usePathname } from "next/navigation";
import NavIcon from "@/components/NavIcon";
import AiChatBot from "@/components/AiChatBot";
import BotFace from "@/components/BotFace";

type Turn = { role: "user" | "assistant"; content: string };

const OPENERS = [
  "What should I learn to get into data work?",
  "How does the assessment actually work?",
  "Is there anything free?",
  "I run a school — how does this work for us?",
];

export default function Assistant() {
  const [open, setOpen] = useState(false);
  const [turns, setTurns] = useState<Turn[]>([]);
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const sessionId = useRef<string>("");
  const scroller = useRef<HTMLDivElement>(null);
  const pathname = usePathname();

  useEffect(() => {
    // Per-tab, not persisted. Nothing to clear up afterwards.
    sessionId.current = Math.random().toString(36).slice(2) + Date.now().toString(36);
  }, []);

  useEffect(() => {
    scroller.current?.scrollTo({ top: scroller.current.scrollHeight, behavior: "smooth" });
  }, [turns, busy]);

  // Escape closes, like any other dialog.
  useEffect(() => {
    if (!open) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setOpen(false); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [open]);

  async function ask(question: string) {
    const q = question.trim();
    if (!q || busy) return;

    setError(null);
    setInput("");
    setTurns((t) => [...t, { role: "user", content: q }]);
    setBusy(true);

    try {
      const res = await fetch("/api/assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        // The path lets the assistant answer "how do I do this here" without
        // the caller asserting anything about who they are — the route reads
        // the role from the session, never from the body.
        body: JSON.stringify({
          question: q, sessionId: sessionId.current, history: turns, path: pathname,
        }),
      });
      const data = await res.json();

      if (!res.ok) {
        setError(data.error ?? "Something went wrong.");
      } else {
        setTurns((t) => [...t, { role: "assistant", content: data.answer }]);
      }
    } catch {
      setError("Could not reach the assistant. Check your connection.");
    } finally {
      setBusy(false);
    }
  }

  /** Course links become clickable; everything else stays as typed. */
  function render(text: string) {
    const parts = text.split(/(\/courses\/[a-z0-9-]+)/g);
    return parts.map((part, i) =>
      part.startsWith("/courses/")
        ? <a key={i} href={part}>{part.replace("/courses/", "").replace(/-/g, " ")}</a>
        : <span key={i}>{part}</span>
    );
  }

  // The launcher is the bot now. It is the same corner and the same action;
  // keeping the pill as well would have put two launchers on top of each
  // other, which is the one thing a fixed-position widget cannot survive.
  if (!open) return <AiChatBot onOpen={() => setOpen(true)} />;

  return (
    <div className="ask" role="dialog" aria-label="Ask Sara, the Your Brand assistant">
      <header className="ask__head">
        <div className="ask__title">Ask Sara</div>
        <div className="ask__headr">
          <span className="ask__pill">Free</span>
          <button className="ask__x" onClick={() => setOpen(false)} aria-label="Close">✕</button>
        </div>
      </header>

      <div className="ask__body" ref={scroller}>
        {/* The opening state is a single centred greeting under the mark,
            rather than a stack of buttons. The suggestions are still there —
            they just stop being the first thing the panel is. */}
        {turns.length === 0 && (
          <div className="ask__intro">
            {/* The same bot as the launcher, not a second mark. The panel
                opens from that button, so a different face here would read
                as having been handed to somebody else. */}
            <span className="ask__face" aria-hidden="true">
              <BotFace idPrefix="askbot" />
            </span>
            <p className="ask__hello">
              Ask me anything about the courses.
              <span>I only answer from what is on Your Brand.</span>
            </p>
            <div className="ask__openers">
              {OPENERS.map((o) => (
                <button key={o} className="ask__opener" onClick={() => ask(o)}>{o}</button>
              ))}
            </div>
          </div>
        )}

        {turns.map((t, i) => (
          <div key={i} className={`ask__turn ask__turn--${t.role}`}>
            {t.role === "assistant" ? render(t.content) : t.content}
          </div>
        ))}

        {busy && (
          <div className="ask__turn ask__turn--assistant ask__busy">
            <span /><span /><span />
          </div>
        )}

        {error && <p className="ask__err" role="alert">{error}</p>}
      </div>

      {/* The composer is one bordered field with the controls inside it, so
          the input reads as the whole bottom of the panel rather than a box
          with a button beside it. */}
      <form
        className="ask__form"
        onSubmit={(e) => { e.preventDefault(); ask(input); }}
      >
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Write your question…"
          maxLength={500}
          aria-label="Your question"
        />
        <div className="ask__tools">
          <span className="ask__count">{input.length}/500</span>
          <button
            className="ask__send"
            disabled={busy || !input.trim()}
            aria-label="Send"
          >
            ↑
          </button>
        </div>
      </form>
    </div>
  );
}
