/** Clears the session cookie. */
export default async function handler(req, res) {
  res.setHeader('Set-Cookie', 'atx_session=; Path=/; HttpOnly; Secure; SameSite=Lax; Max-Age=0');
  return res.status(200).json({ ok: true });
}
