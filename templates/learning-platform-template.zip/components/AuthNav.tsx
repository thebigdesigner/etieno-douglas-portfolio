"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useState } from "react";
import { createClient } from "@/lib/supabase/client";
import UserMenu from "@/components/UserMenu";

/**
 * The signup call to action follows the page. Somebody reading the teaching
 * page and clicking "Get started" means teaching — sending them into the
 * learner flow makes them start again.
 */
function ctaFor(pathname: string): { href: string; label: string } {
  if (pathname.startsWith("/teach")) {
    return { href: "/signup?intent=instructor", label: "Start teaching" };
  }
  if (pathname.startsWith("/institutions")) {
    return { href: "/signup?intent=institution", label: "Set up your organisation" };
  }
  return { href: "/signup", label: "Get started" };
}

/**
 * Auth state lives here rather than in SiteHeader so the marketing and
 * catalogue pages can still be statically generated.
 */
export default function AuthNav() {
  const pathname = usePathname();
  const [name, setName] = useState<string | null>(null);
  const [avatarPath, setAvatarPath] = useState<string | null>(null);
  const [email, setEmail] = useState<string | null>(null);
  const [known, setKnown] = useState(false);

  useEffect(() => {
    const supabase = createClient();
    let cancelled = false;

    supabase.auth.getUser().then(async ({ data }) => {
      if (cancelled) return;
      if (!data.user) { setKnown(true); return; }

      // select("*") so a column added by a later migration cannot make this
      // error out and silently render the signed-out header.
      const { data: profile } = await supabase
        .from("profiles").select("*").eq("id", data.user.id).maybeSingle();

      if (!cancelled) {
        setName(profile?.display_name ?? "Your account");
        setAvatarPath(profile?.avatar_path ?? null);
        setEmail(profile?.email ?? data.user.email ?? null);
        setKnown(true);
      }
    });

    return () => { cancelled = true; };
  }, []);

  if (!known) return <div className="nav__right nav__right--wait" aria-hidden />;

  // Signed in on a marketing or catalogue page: the same account control as
  // the app, so browsing the catalogue while logged in no longer looks like
  // being logged out.
  if (name) {
    return (
      <div className="nav__right">
        <Link className="nav__login" href="/dashboard">Dashboard</Link>
        <UserMenu name={name} avatarPath={avatarPath} email={email} helpHref="/contact" />
      </div>
    );
  }

  const cta = ctaFor(pathname);

  return (
    <div className="nav__right">
      <Link className="nav__login" href="/login">Log in</Link>
      <Link className="btn btn--fill" href={cta.href}>{cta.label}</Link>
    </div>
  );
}
