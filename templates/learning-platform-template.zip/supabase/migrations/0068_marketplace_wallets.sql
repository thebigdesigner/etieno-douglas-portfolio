-- =====================================================================
-- Creator wallets, the 80/20 split, and withdrawals.
--
-- Money model, written down once so code and database agree:
--
--   * Marketplace prices are held in USD cents on mk_products. A buyer may
--     pay in another currency; the order records what was charged, in what
--     currency, and the USD value used for the split, so a later exchange
--     rate cannot change what a creator earned.
--   * Your Brand keeps 20% of every sale. The creator's 80% is written to the
--     wallet ledger as one row per event — never a running total that code
--     can edit. The balance is the sum of the rows, which means the books
--     can always be reconstructed and a wrong entry is corrected by adding
--     its reverse, not by editing history.
--   * A sale is *pending* for 7 days before it can be withdrawn. Card
--     chargebacks and refunds land inside that window; without it a
--     creator could withdraw money that later has to be given back, and
--     Your Brand would be paying for it.
-- =====================================================================

-- Buyers outside Africa pay in their own currency; 0065 allowed USD only.
alter table mk_orders drop constraint if exists mk_orders_currency_check;
alter table mk_orders add constraint mk_orders_currency_check
  check (currency in ('USD','NGN','GHS','ZAR','KES','EUR','GBP'));

alter table mk_orders add column if not exists provider text;
alter table mk_orders add column if not exists provider_ref text;
alter table mk_orders add column if not exists creator_id uuid references mk_creators(id) on delete restrict;
-- What the sale was worth in USD, at the rate used when it was taken.
alter table mk_orders add column if not exists usd_cents integer check (usd_cents >= 0);
alter table mk_orders add column if not exists commission_cents integer check (commission_cents >= 0);
alter table mk_orders add column if not exists creator_cents integer check (creator_cents >= 0);
create index if not exists mk_orders_creator_idx on mk_orders (creator_id, created_at desc);

-- Which provider a checkout went to, so fulfilment verifies with the right
-- one and a Stripe session can be looked up by its own id.
alter table checkout_intents add column if not exists provider text not null default 'paystack';
alter table checkout_intents add column if not exists provider_session text;

-- ---------------------------------------------------------------- rates
-- Your Brand keeps this share of every marketplace sale.
create or replace function mk_commission_bp() returns integer
  language sql immutable as $$ select 2000 $$;   -- 20.00%, in basis points

-- ------------------------------------------------------------- accounts
-- Where a creator's money goes. One per creator, replaced not versioned.
-- No RLS policy on purpose: bank details are read by the service role
-- only, never by the browser, even the owner's.
create table if not exists mk_payout_accounts (
  creator_id     uuid primary key references mk_creators(id) on delete cascade,
  country        text not null default 'NG',
  currency       text not null default 'NGN',
  bank_code      text,
  bank_name      text,
  account_number text,
  account_name   text,
  details        jsonb not null default '{}'::jsonb,   -- anything a non-NG method needs
  verified_at    timestamptz,
  updated_at     timestamptz not null default now()
);
alter table mk_payout_accounts enable row level security;

-- -------------------------------------------------------------- payouts
create table if not exists mk_payouts (
  id            uuid primary key default gen_random_uuid(),
  creator_id    uuid not null references mk_creators(id) on delete restrict,
  amount_cents  integer not null check (amount_cents > 0),   -- USD cents
  status        text not null default 'requested'
                check (status in ('requested','approved','paid','rejected','cancelled')),
  -- A copy of the account as it was when requested: if a creator edits
  -- their bank details later, the record of where money actually went
  -- must not change with it.
  account       jsonb not null default '{}'::jsonb,
  reference     text,
  note          text,
  requested_at  timestamptz not null default now(),
  decided_at    timestamptz,
  paid_at       timestamptz
);
create index if not exists mk_payouts_creator_idx on mk_payouts (creator_id, requested_at desc);
create index if not exists mk_payouts_open_idx on mk_payouts (status, requested_at) where status in ('requested','approved');
alter table mk_payouts enable row level security;

-- --------------------------------------------------------------- ledger
create table if not exists mk_wallet_entries (
  id            uuid primary key default gen_random_uuid(),
  creator_id    uuid not null references mk_creators(id) on delete cascade,
  kind          text not null check (kind in ('sale','refund','withdrawal','withdrawal_reversed','adjustment')),
  -- Positive credits the creator, negative debits them. USD cents.
  amount_cents  integer not null,
  -- When a credit becomes withdrawable. Immediate for anything but a sale.
  available_at  timestamptz not null default now(),
  order_id      uuid references mk_orders(id) on delete set null,
  payout_id     uuid references mk_payouts(id) on delete set null,
  note          text,
  created_at    timestamptz not null default now(),
  -- One credit per order, so a webhook retry cannot pay twice.
  unique (order_id, kind)
);
create index if not exists mk_wallet_creator_idx on mk_wallet_entries (creator_id, created_at desc);
alter table mk_wallet_entries enable row level security;

-- Balances. available: cleared and not yet withdrawn. pending: sales still
-- inside the 7-day window. Money in a requested payout is already debited,
-- so it cannot be requested twice.
create or replace function mk_wallet_balance(p_creator uuid)
returns table (available_cents bigint, pending_cents bigint, lifetime_cents bigint, withdrawn_cents bigint)
language sql stable as $$
  select
    coalesce(sum(amount_cents) filter (where available_at <= now()), 0)::bigint,
    coalesce(sum(amount_cents) filter (where available_at > now()), 0)::bigint,
    coalesce(sum(amount_cents) filter (where kind = 'sale'), 0)::bigint,
    coalesce(-sum(amount_cents) filter (where kind = 'withdrawal'), 0)::bigint
  from mk_wallet_entries where creator_id = p_creator;
$$;

-- ------------------------------------------------------- record a sale
-- Called by fulfilment once the payment is verified. Idempotent: the
-- unique (order_id, kind) makes a second call a no-op, which matters
-- because payment webhooks retry.
create or replace function mk_record_sale(p_order_id uuid, p_hold_days integer default 7)
returns void language plpgsql security definer set search_path = public as $$
declare
  v_order   mk_orders%rowtype;
  v_creator uuid;
  v_usd     integer;
  v_fee     integer;
begin
  select * into v_order from mk_orders where id = p_order_id for update;
  if not found or v_order.status <> 'paid' then return; end if;

  select creator_id into v_creator from mk_products where id = v_order.product_id;
  if v_creator is null then return; end if;

  v_usd := coalesce(v_order.usd_cents, v_order.amount_cents);
  v_fee := round(v_usd * mk_commission_bp() / 10000.0);

  update mk_orders
     set creator_id = v_creator,
         usd_cents = v_usd,
         commission_cents = v_fee,
         creator_cents = v_usd - v_fee
   where id = p_order_id;

  insert into mk_wallet_entries (creator_id, kind, amount_cents, available_at, order_id, note)
  values (v_creator, 'sale', v_usd - v_fee,
          coalesce(v_order.paid_at, now()) + make_interval(days => p_hold_days),
          p_order_id, 'Sale, less 20% platform fee')
  on conflict (order_id, kind) do nothing;
end;
$$;

-- --------------------------------------------------- request a withdrawal
-- Debits the wallet and opens a payout in one transaction, so a creator
-- cannot request the same money twice by clicking twice.
create or replace function mk_request_payout(p_creator uuid, p_amount_cents integer)
returns uuid language plpgsql security definer set search_path = public as $$
declare
  v_available bigint;
  v_account   mk_payout_accounts%rowtype;
  v_payout    uuid;
begin
  if p_amount_cents is null or p_amount_cents <= 0 then
    raise exception 'amount must be positive' using errcode = '22023';
  end if;

  select * into v_account from mk_payout_accounts where creator_id = p_creator;
  if not found or v_account.account_number is null then
    raise exception 'no payout account' using errcode = 'P0002';
  end if;

  -- Lock the ledger rows so two requests cannot read the same balance.
  perform 1 from mk_wallet_entries where creator_id = p_creator for update;
  select available_cents into v_available from mk_wallet_balance(p_creator);
  if v_available < p_amount_cents then
    raise exception 'insufficient available balance' using errcode = 'P0001';
  end if;

  insert into mk_payouts (creator_id, amount_cents, account)
  values (p_creator, p_amount_cents, to_jsonb(v_account) - 'creator_id')
  returning id into v_payout;

  insert into mk_wallet_entries (creator_id, kind, amount_cents, payout_id, note)
  values (p_creator, 'withdrawal', -p_amount_cents, v_payout, 'Withdrawal requested');

  return v_payout;
end;
$$;

-- ------------------------------------------- reject or cancel a payout
-- Puts the money back. The original debit stays: the ledger records what
-- happened, and a reversal is another row, never an edit.
create or replace function mk_reverse_payout(p_payout uuid, p_status text, p_note text default null)
returns void language plpgsql security definer set search_path = public as $$
declare v_p mk_payouts%rowtype;
begin
  select * into v_p from mk_payouts where id = p_payout for update;
  if not found or v_p.status in ('paid','rejected','cancelled') then return; end if;

  update mk_payouts set status = p_status, note = p_note, decided_at = now() where id = p_payout;

  insert into mk_wallet_entries (creator_id, kind, amount_cents, payout_id, note)
  values (v_p.creator_id, 'withdrawal_reversed', v_p.amount_cents, p_payout,
          coalesce(p_note, 'Withdrawal ' || p_status));
end;
$$;
