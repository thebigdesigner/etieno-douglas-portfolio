import { createAdminClient } from "@/lib/supabase/admin";
import { requireUser } from "@/lib/guard";
import { learnerNav } from "@/lib/app-nav";
import AppShell from "@/components/AppShell";
import { redirect } from "next/navigation";

export default async function DashboardLayout({ children }: { children: React.ReactNode }) {
  // No role allowlist here: /dashboard is the fallback every other guard
  // redirects to, so gating it by role risks bouncing back to itself.
  const { user, profile } = await requireUser();

  // Everyone else has a home of their own.
  if (profile?.role === "instructor") redirect("/studio");
  if (profile?.role === "institution_admin") redirect("/institution");
  if (profile?.role === "operator") redirect("/admin/sla");

  // One round trip rather than two: fetching every enrolment id only to feed
  // it back as an .in() list meant a second wait, and the list grows forever.
  const admin = createAdminClient();

  const { data: notifications } = await admin
    .rpc("learner_notifications", { p_user_id: user.id });
  const seen = profile?.notifications_seen_at
    ? new Date(profile.notifications_seen_at).getTime() : 0;
  const unread = (notifications ?? [])
    .filter((n: { at: string }) => new Date(n.at).getTime() > seen).length;

  const { count: cartCount } = await admin
    .from("cart_items").select("course_id", { count: "exact", head: true })
    .eq("user_id", user.id);

  const { count: awaiting } = await admin
    .from("submissions")
    .select("id, enrolments!inner(user_id)", { count: "exact", head: true })
    .eq("enrolments.user_id", user.id)
    .in("state", ["submitted", "assigned", "in_review"]);

  return (
    <AppShell
      brand="Student"
      settingsHref="/dashboard/account"
      cartHref="/dashboard/cart"
      cartCount={cartCount ?? 0}
      name={profile?.display_name}
      profile={{ name: profile?.display_name ?? "Learner", id: user.id, avatarPath: profile?.avatar_path }}
      email={profile?.email ?? user.email}
      notifications={notifications ?? []}
      unread={unread}
      groups={learnerNav(awaiting ?? 0)}
    >
      {children}
    </AppShell>
  );
}
