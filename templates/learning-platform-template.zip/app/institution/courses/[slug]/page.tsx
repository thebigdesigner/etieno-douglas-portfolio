import CourseScreen from "@/app/studio/[slug]/CourseScreen";

export const dynamic = "force-dynamic";

type Params = Promise<{ slug: string }>;

/** The same editor as the studio and the console, inside the institution's
 *  shell. The guard that matters is in requireCourseAccess, which checks the
 *  course belongs to this admin's organisation. */
export default async function InstitutionCoursePage({ params }: { params: Params }) {
  const { slug } = await params;
  return <CourseScreen slug={slug} backHref="/institution/courses" backLabel="Your courses" />;
}
