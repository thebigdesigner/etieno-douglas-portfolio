/**
 * Your Brand assistant — the chat on the customer site.
 *
 * It used to answer from a paragraph of facts written into this file (which had drifted: it
 * still said departures were Tuesday, Thursday and Saturday). Now it works like a person at the
 * desk with the booking system open: it looks things up with tools that read the live database,
 * and it only states a fare, a time or a seat count that a tool returned.
 *
 * Tools (all read-only apart from contact_office, which files a message for the office):
 *   search_departures   live departures, seats left and fares for a route and date
 *   find_booking        a booking's status — only with the reference AND the phone number
 *   prepare_booking     fills in the booking form for the customer to review and pay
 *   contact_office      passes a charter, waitlist or call-back request to the Messages screen
 *
 * The model never takes payment, never changes a booking and never cancels one. Where an action
 * is needed it hands the customer a button that opens the right page, and the page does the rest
 * exactly as it would for anyone.
 *
 * Providers, tried in order, both free for an MVP and both speaking the OpenAI chat format with
 * tools, so there is one code path:
 *   GEMINI_API_KEY   Google AI Studio (free tier). Model: AI_MODEL, default gemini-3.8-flash
 *   GROQ_API_KEY     Groq (free tier). Model: GROQ_MODEL, default openai/gpt-oss-120b
 * Model IDs retire; both are environment variables so a retirement is a dashboard change.
 *
 * Privacy: on free tiers the providers may use prompts to improve their models. Booking
 * look-ups therefore send the model the trip facts only — never names, phone numbers or emails.
 */
import { opsAlert } from './_lib/ops-alert.js';
import { select, insert, tenant as tenantRow, limited, clientIp, lagosToday, departsAt,
         lookupBlocked, lookupMissed } from './_lib/db.js';
import { cancellationQuote } from './_lib/cancel-policy.js';
import { runAgent, providers } from './_lib/ai.js';

const REF = /^[A-Z]{2,5}-[A-Z0-9]{4,10}(-[A-Z0-9]{2,6})?$/;
const last7 = s => String(s || '').replace(/\D/g, '').slice(-7);
const naira = n => '₦' + Math.round(n).toLocaleString('en-NG');
const DAYS = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
const addDays = (iso, n) => new Date(Date.parse(`${iso}T12:00:00Z`) + n * 864e5).toISOString().slice(0, 10);
const weekday = iso => DAYS[new Date(`${iso}T12:00:00Z`).getUTCDay()];
const MONTHS = ['January','February','March','April','May','June','July','August','September','October','November','December'];
/* Dates go to the model already written the way a person says them, so they reach the customer
   that way too — models copy what they are given, and were echoing 2026-09-19. */
const human = iso => `${weekday(iso)} ${Number(iso.slice(8, 10))} ${MONTHS[Number(iso.slice(5, 7)) - 1]}`;

/* ---------------------------------------------------------------- what the business is
   Read from the database on every cold start and cached for two minutes, so the assistant
   quotes what a manager set in the dashboard this morning, not what was typed in a file. */
let cache = { at: 0, data: null };
async function business() {
  if (cache.data && Date.now() - cache.at < 120000) return cache.data;
  const t = await tenantRow();
  const s = t.settings || {};
  const terms = await select('terminals', `tenant_id=eq.${t.id}&active=is.true&select=id,code,city,name,address,phone,whatsapp,opens_at`);
  const byId = Object.fromEntries(terms.map(x => [x.id, x]));
  const rows = await select('routes', `tenant_id=eq.${t.id}&active=is.true&select=id,from_terminal,to_terminal,fare_kobo,duration_min,departures,operating_days`);
  const routes = rows.filter(r => byId[r.from_terminal] && byId[r.to_terminal]).map(r => ({
    id: r.id, from: byId[r.from_terminal].code, to: byId[r.to_terminal].code,
    fromCity: byId[r.from_terminal].city, toCity: byId[r.to_terminal].city,
    fare: r.fare_kobo / 100, minutes: r.duration_min,
    departures: (r.departures || []).map(x => String(x).slice(0, 5)).sort(),
    days: (r.operating_days || []).length === 7 ? 'every day' : (r.operating_days || []).map(d => DAYS[d]).join(', ')
  }));
  const data = {
    tenantId: t.id, name: t.name || 'Your Brand',
    terminals: terms.map(x => ({ code: x.code, city: x.city, name: x.name, address: x.address || 'address to be confirmed',
      phone: x.phone || null, whatsapp: x.whatsapp || null, opens: x.opens_at ? String(x.opens_at).slice(0, 5) : null })),
    routes,
    policy: {
      arriveBeforeMin: Number(s.arrive_before_min ?? 30), checkInCloseMin: Number(s.check_in_close_min ?? 15),
      childFarePct: Math.round(Number(s.child_fare_ratio ?? 0.75) * 100), holdMinutes: Number(s.hold_minutes ?? 15),
      cancelFreeHours: Number(s.cancel_free_hours ?? 24), cancelFeePct: Number(s.cancel_fee_pct ?? 25),
      noRefundHours: Number(s.no_refund_hours ?? 2)
    },
    contact: { phone: s.contact_phone || terms.find(x => x.phone)?.phone || null, tollFree: s.toll_free || null, email: s.contact_email || null },
    bankTransfer: Boolean(s.bank_account_number),
    settings: s
  };
  cache = { at: Date.now(), data };
  return data;
}

function systemPrompt(b, today) {
  const cal = Array.from({ length: 14 }, (_, i) => { const d = addDays(today, i); return `${weekday(d)} ${d}${i === 0 ? ' (today)' : i === 1 ? ' (tomorrow)' : ''}`; });
  const p = b.policy;
  return `You are the customer assistant for ${b.name}, an intercity road transport company in South-South Nigeria running Toyota Sequoia SUVs (5 passengers each) between North City, Coast City and Central City. You help people on the company website.

HOW TO WORK
- You have tools that read the live booking system. For departures, seats, fares on a date, or anything about a specific booking, ALWAYS call a tool first and answer only from what it returns. Never guess or invent a time, fare, seat count, date or booking detail.
- Terminal codes: ${b.terminals.map(t => `${t.code} = ${t.city}`).join(', ')}. People say "PH", "Coast City", "Cal" — map them to these.
- Work out dates from the calendar below. "Tomorrow", "this Saturday", "next Friday" must become an exact YYYY-MM-DD before you call a tool. If a date is ambiguous, ask.
- If you need something to proceed (route, date, how many people, reference and phone), ask for it — one short question at a time. Do not ask for anything you already have from the conversation.
- Never assume where someone is travelling FROM. If they name only the destination (e.g. "seats to Central City"), ask where they are leaving from, naming the terminals that serve that destination.
- When you list departures, say how many seats are left if it is 3 or fewer ("only 2 seats left"), and mention sold-out departures.
- To book: call search_departures so the customer sees real times and seats, then prepare_booking. The customer finishes (seats, names, payment) on the page. You cannot take payment and must never ask for card details, bank PINs or OTPs.
- Bookings: you may discuss a booking only after the customer gives BOTH the reference (like ATX-UP2209-1JC62) and the phone number it was booked with, and find_booking confirms it. Never reveal anything about a booking otherwise.
- Cancelling or refunds: explain what the policy gives them (find_booking returns the figure), then tell them to tap the button to open their booking, where "Cancel this booking" sends a confirmation link to their email. You cannot cancel anything yourself.
- Charter (hire a whole vehicle), a waitlist for a full departure, or wanting a call back: collect name, phone number and the details, read them back, and only after the customer confirms, call contact_office.
- If something is outside what you know or can do, say so plainly and give the phone number.

STYLE
- Warm, clear, efficient Nigerian English. If the customer writes in Pidgin, reply in simple Pidgin.
- Short: usually 1–3 sentences. Use a line break between departures when listing several. No markdown, no asterisks.
- Money as ₦18,000. Times as 07:00. Dates as "Tuesday 22 September".
- Don't repeat the customer's question back. Don't apologise more than once. Don't end every message with "anything else?".

TODAY IS ${weekday(today)} ${today} (Lagos time). Next 14 days: ${cal.join('; ')}.

COMPANY FACTS (from the live system)
Routes: ${b.routes.map(r => `${r.fromCity} → ${r.toCity}: ${naira(r.fare)} per adult, about ${Math.round(r.minutes / 6) / 10} hours, departs ${r.departures.join(' and ')} (${r.days})`).join('; ')}.
Terminals: ${b.terminals.map(t => `${t.name} (${t.city}): ${t.address}${t.phone ? `, phone ${t.phone}` : ''}${t.whatsapp ? `, WhatsApp ${t.whatsapp}` : ''}${t.opens ? `, opens ${t.opens} on departure days` : ''}`).join('; ')}.
Contact: ${[b.contact.phone && `phone ${b.contact.phone}`, b.contact.tollFree && `toll-free ${b.contact.tollFree}`, b.contact.email && `email ${b.contact.email}`].filter(Boolean).join(', ') || 'use a terminal phone number'}.
Check-in: arrive ${p.arriveBeforeMin} minutes before departure; check-in closes ${p.checkInCloseMin} minutes before. Bring an ID matching the passenger name.
Fares: children 2–10 pay ${p.childFarePct}% of the adult fare; infants under 2 sit on a lap and don't need a seat (tell the desk at check-in). Every other passenger needs a seat.
Luggage: bags are checked at the terminal before boarding.
Paying online: card or bank app through Paystack${b.bankTransfer ? ', or bank transfer to the company account (then upload the receipt on the booking page)' : ''}. USSD is not offered. Cash or POS at the terminal. The company never asks anyone to pay into a personal account. An unpaid online booking holds the seats for ${p.holdMinutes} minutes.
Refunds: cancel more than ${p.cancelFreeHours} hours before departure = full refund of what was paid; between ${p.noRefundHours} and ${p.cancelFreeHours} hours = refund less ${p.cancelFeePct}%; within ${p.noRefundHours} hours or after departure = no refund. Travel credits from Trail points are not refundable. If the company cancels a departure: free move to the next seat or a full refund.
Trail points: signed-in customers earn points on every trip they board, which turn into travel credit codes sent by email; enter the code at payment.
Tickets arrive by email with a QR code. No SMS is sent.`;
}

/* ---------------------------------------------------------------- tools */
const TOOLS = [
  { type: 'function', function: { name: 'search_departures',
    description: 'Live departures for one route on one date: times, seats left, fare. If there are none that day, also returns the next dates that have departures.',
    parameters: { type: 'object', properties: {
      from: { type: 'string', description: 'terminal code, e.g. uyo' }, to: { type: 'string', description: 'terminal code, e.g. phc' },
      date: { type: 'string', description: 'YYYY-MM-DD' } }, required: ['from', 'to', 'date'] } } },
  { type: 'function', function: { name: 'find_booking',
    description: 'Status of one booking. Needs the booking reference and the phone number it was made with, both given by the customer.',
    parameters: { type: 'object', properties: { reference: { type: 'string' }, phone: { type: 'string' } }, required: ['reference', 'phone'] } } },
  { type: 'function', function: { name: 'prepare_booking',
    description: 'Open the booking form on the page with the trip filled in, for the customer to choose seats, enter names and pay. Use after search_departures shows seats are available.',
    parameters: { type: 'object', properties: {
      from: { type: 'string' }, to: { type: 'string' }, date: { type: 'string', description: 'YYYY-MM-DD' },
      return_date: { type: 'string', description: 'YYYY-MM-DD, only for a round trip' },
      adults: { type: 'integer', minimum: 1, maximum: 5 }, children: { type: 'integer', minimum: 0, maximum: 4 } },
      required: ['from', 'to', 'date', 'adults'] } } },
  { type: 'function', function: { name: 'contact_office',
    description: 'Send a request to the office staff, who will call the customer. Only after the customer has confirmed the details you read back.',
    parameters: { type: 'object', properties: {
      purpose: { type: 'string', enum: ['charter', 'waitlist', 'callback'] },
      name: { type: 'string' }, phone: { type: 'string' },
      details: { type: 'string', description: 'route, date, number of people, and anything else they said' } },
      required: ['purpose', 'name', 'phone', 'details'] } } }
];

async function runTool(name, args, ctx) {
  const b = ctx.business;
  const code = c => String(c || '').toLowerCase().trim();
  const known = c => b.terminals.some(t => t.code === c);
  const isDate = d => /^\d{4}-\d{2}-\d{2}$/.test(d || '');

  if (name === 'search_departures') {
    const from = code(args.from), to = code(args.to), date = args.date;
    if (!known(from) || !known(to) || from === to) return { error: `Unknown route. Terminals are ${b.terminals.map(t => t.code).join(', ')}.` };
    if (!isDate(date)) return { error: 'date must be YYYY-MM-DD' };
    if (date < ctx.today) return { error: 'That date has passed.' };
    const route = b.routes.find(r => r.from === from && r.to === to);
    if (!route) return { error: `We do not run ${from} to ${to}.` };
    const closeMin = b.policy.checkInCloseMin;
    const day = async d => {
      const trips = await select('trips', `tenant_id=eq.${b.tenantId}&route_id=eq.${route.id}&depart_date=eq.${d}&status=eq.scheduled` +
        `&select=id,depart_time,capacity,fare_kobo,trip_seats(state,held_until)&order=depart_time.asc`);
      const cutoff = Date.now() + closeMin * 60000, now = Date.now();
      return trips.filter(tr => departsAt(d, tr.depart_time) > cutoff).map(tr => ({
        time: String(tr.depart_time).slice(0, 5), fare: naira(tr.fare_kobo / 100),
        seatsLeft: (tr.trip_seats || []).filter(s => s.state === 'free' || (s.state === 'held' && s.held_until && Date.parse(s.held_until) < now)).length,
        capacity: tr.capacity }));
    };
    const list = await day(date);
    if (list.length) return { route: `${route.fromCity} to ${route.toCity}`, date: human(date), departures: list, childFare: `${b.policy.childFarePct}% of adult` };
    const next = [];
    for (let i = 1; i <= 10 && next.length < 3; i++) {
      const d = addDays(date, i); const l = await day(d);
      if (l.length) next.push({ date: human(d), departures: l });
    }
    return { route: `${route.fromCity} to ${route.toCity}`, date: human(date), departures: [], note: 'No departures on sale that day.', nextAvailable: next };
  }

  if (name === 'find_booking') {
    const ref = String(args.reference || '').toUpperCase().replace(/\s+/g, ''), phone = String(args.phone || '');
    if (!REF.test(ref)) return { error: 'That does not look like a booking reference. It looks like ATX-UP2209-1JC62.' };
    if (last7(phone).length < 7) return { error: 'Need the phone number the booking was made with.' };
    if (await lookupBlocked(ctx.req, phone)) return { error: 'Too many wrong attempts. Ask them to wait a few minutes or call the terminal.' };
    const rows = await select('bookings', `tenant_id=eq.${b.tenantId}&reference=eq.${ref}&select=reference,status,total_kobo,contact_phone,` +
      'passengers(status,seat_no,trip:trips(status,depart_date,depart_time,driver:drivers(name),vehicle:vehicles(label,plate),route:routes(from_terminal,to_terminal))),' +
      'payments(status,amount_kobo,channel),refunds(status,amount_kobo)');
    if (!rows.length || last7(rows[0].contact_phone) !== last7(phone)) {
      await lookupMissed(ctx.req, phone);
      return { found: false, note: 'No booking with that reference and phone number. Ask them to check both, as written in the ticket email.' };
    }
    const bk = rows[0];
    const terms = await select('terminals', `tenant_id=eq.${b.tenantId}&select=id,city`);
    const city = id => terms.find(x => x.id === id)?.city || '';
    const legs = new Map();
    for (const p of bk.passengers) {
      if (!p.trip) continue; const k = `${p.trip.depart_date} ${p.trip.depart_time}`;
      if (!legs.has(k)) legs.set(k, { date: p.trip.depart_date, time: String(p.trip.depart_time).slice(0, 5), status: p.trip.status,
        from: city(p.trip.route?.from_terminal), to: city(p.trip.route?.to_terminal), seats: [],
        driver: p.trip.driver?.name || null, vehicle: [p.trip.vehicle?.label, p.trip.vehicle?.plate].filter(Boolean).join(' ') || null });
      legs.get(k).seats.push(p.seat_no);
    }
    const legList = [...legs.values()].sort((x, y) => `${x.date}${x.time}`.localeCompare(`${y.date}${y.time}`));
    const paid = (bk.payments || []).filter(x => x.status === 'success').reduce((a, x) => a + x.amount_kobo, 0);
    const q = cancellationQuote({ status: bk.status, legs: legList, passengers: bk.passengers, payments: bk.payments, settings: b.settings });
    const refund = (bk.refunds || []).find(r => r.status === 'pending');
    ctx.action = { type: 'booking', ref: bk.reference, phone };
    ctx.actionLabel = 'Open my booking';
    return {
      found: true, reference: bk.reference,
      status: { pending: 'booked but NOT PAID yet — seats are held only briefly', confirmed: 'confirmed and paid', cancelled: 'cancelled', refunded: 'cancelled and refunded', expired: 'expired: it was never paid and the seats were released' }[bk.status] || bk.status,
      people: bk.passengers.length / Math.max(1, legList.length),
      legs: legList.map(l => ({ trip: `${l.from} to ${l.to}`, when: `${human(l.date)} at ${l.time}`, seats: l.seats.sort((x, y) => x - y),
        tripStatus: l.status, driver: l.driver, vehicle: l.vehicle })),
      total: naira(bk.total_kobo / 100), paid: naira(paid / 100),
      refundInProgress: refund ? naira(refund.amount_kobo / 100) : null,
      cancelling: q.allowed ? { allowed: true, wouldRefund: naira(q.refundKobo / 100), rule: q.band } : { allowed: false, why: q.reason },
      note: 'The page button opens the booking, where they can see the ticket and QR, add it to a calendar, or cancel.'
    };
  }

  if (name === 'prepare_booking') {
    const from = code(args.from), to = code(args.to);
    if (!known(from) || !known(to) || from === to) return { error: 'Unknown route.' };
    if (!isDate(args.date) || args.date < ctx.today) return { error: 'Need a valid future date YYYY-MM-DD.' };
    if (args.return_date && (!isDate(args.return_date) || args.return_date < args.date)) return { error: 'The return date must be on or after the outbound date.' };
    const adults = Math.min(5, Math.max(1, parseInt(args.adults, 10) || 1)), children = Math.min(4, Math.max(0, parseInt(args.children, 10) || 0));
    if (adults + children > 5) return { error: 'A Sequoia takes 5 passengers. For more, suggest two bookings or a charter.' };
    ctx.action = { type: 'search', tab: args.return_date ? 'round' : 'oneway', from, to, date: args.date, returnDate: args.return_date || null, adults, children };
    ctx.actionLabel = 'Choose seats';
    return { ok: true, note: 'A button is now under your message. Tell the customer to tap it to pick seats, enter names and pay. Seats are only held once they reach the payment step.' };
  }

  if (name === 'contact_office') {
    const nm = String(args.name || '').trim(), ph = String(args.phone || '').trim(), details = String(args.details || '').trim();
    if (nm.length < 2 || ph.replace(/\D/g, '').length < 9) return { error: 'Need their name and a phone number.' };
    if (await limited(`assistant-office:ip:${clientIp(ctx.req)}`, 3, 3600)) return { error: 'Already sent several requests. Give them the phone number instead.' };
    const topic = args.purpose === 'charter' ? 'hire a vehicle' : 'booking';
    const label = { charter: 'Charter request', waitlist: 'Waitlist', callback: 'Call-back request' }[args.purpose] || 'Request';
    await insert('feedback', [{ tenant_id: b.tenantId, name: nm.slice(0, 120), phone: ph.slice(0, 32), topic,
      message: `${label} (via the website assistant): ${details}`.slice(0, 4000) }], 'return=minimal');
    return { sent: true, note: 'Staff see this in their Messages screen and will call. Do not promise an exact time; charter quotes usually come within one working day.' };
  }
  return { error: 'unknown tool' };
}

/* A cheap first filter per instance; the database limit holds across instances. */
const hits = new Map();
function tooMany(ip) {
  const now = Date.now(), list = (hits.get(ip) || []).filter(t => now - t < 60000);
  list.push(now); hits.set(ip, list); if (hits.size > 5000) hits.clear();
  return list.length > 20;
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST only' });
  const ip = clientIp(req);
  if (tooMany(ip) || await limited(`assistant:ip:${ip}`, 40, 600))
    return res.status(429).json({ error: 'Too many questions, please wait a moment.' });

  const { question, history = [] } = req.body || {};
  if (typeof question !== 'string' || !question.trim() || question.length > 800) return res.status(400).json({ error: 'bad question' });
  if (!providers().length) return res.status(503).json({ error: 'assistant not configured' });

  const today = lagosToday();
  let b;
  try { b = await business(); }
  catch (err) { console.error('assistant could not read the business:', err.message); return res.status(503).json({ error: 'assistant unavailable' }); }

  /* The page sends the conversation including the question just asked; drop that copy. */
  const past = history.filter(m => m && typeof m.content === 'string' && ['user', 'assistant'].includes(m.role))
    .map(m => ({ role: m.role, content: m.content.slice(0, 1200) }));
  if (past.length && past[past.length - 1].role === 'user' && past[past.length - 1].content.trim() === question.trim()) past.pop();

  const ctx = { business: b, today, req, action: null, actionLabel: null };
  try {
    const out = await runAgent({ system: systemPrompt(b, today), history: past.slice(-14), question: question.trim(),
      tools: TOOLS, exec: (name, args) => runTool(name, args, ctx), maxRounds: 5, budgetMs: 22000,
      /* A provider that fails half-way hands over clean: no button left over from its attempt. */
      onProvider: () => { ctx.action = null; ctx.actionLabel = null; } });
    return res.status(200).json({ reply: out.reply.replace(/\*\*?/g, '').slice(0, 1200),
      action: ctx.action, actionLabel: ctx.actionLabel, via: out.provider, tools: out.used.map(u => u.tool) });
  } catch (err) {
    console.error('assistant unavailable:', err.diagnosis || err.message);   // never shown to the customer
    await opsAlert('ai:down:customer', { severity: 'warning', title: 'The website chat assistant is not answering',
      detail: { why: err.diagnosis || err.message, note: 'Customers get the simple built-in answers meanwhile.' }, everyMin: 720 });
  }
  return res.status(503).json({ error: 'assistant unavailable' });
}
