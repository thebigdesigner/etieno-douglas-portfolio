import type { Metadata, Viewport } from "next";
import { siteUrl } from "@/lib/site";
import { Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";

/**
 * One face throughout, matching the sidebar concept: a geometric sans with a
 * tall x-height that stays legible at 11px section labels and still has
 * presence in a letterspaced wordmark.
 *
 * --font-jost and --font-inter are kept as aliases rather than renamed. They
 * are referenced 153 times across globals.css; pointing both at the new face
 * swaps the typography everywhere in one place, and swapping back — or to a
 * different face entirely — is this one import plus the two aliases below.
 */
const display = Plus_Jakarta_Sans({
  subsets: ["latin"],
  weight: ["400", "500", "600", "700"],
  variable: "--font-splari",
  display: "swap",
});

/**
 * Without this every page renders at the browser's 980px fallback width and
 * is scaled down to fit — text unreadably small, and every media query
 * behaving as though it were a desktop. It was missing entirely.
 *
 * maximumScale is deliberately absent: capping zoom stops people who need
 * to enlarge text, and buys nothing.
 */
export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
  themeColor: [
    { media: "(prefers-color-scheme: light)", color: "#ffffff" },
    { media: "(prefers-color-scheme: dark)", color: "#0B0B0F" },
  ],
};

export const metadata: Metadata = {
  metadataBase: new URL(siteUrl()),
  title: {
    default: "Your Brand Academy — Learn a skill. Have a practitioner sign off on it.",
    template: "%s · Your Brand",
  },
  description:
    "Placeholder description by Aphinity Digital. Describe your platform in one sentence.",
  openGraph: { type: "website", siteName: "Your Brand" },
};

/**
 * The nav is light, full stop.
 *
 * A pre-paint script used to read `splari-nav-theme` from localStorage and
 * set data-nav from it. The switch that wrote that value (NavTheme) is not
 * mounted on any surface, so the dark rail could be entered but never left:
 * anyone carrying a stale 'dark' in storage was stuck with it and had no
 * control to change it back. Clearing the key on one machine would not have
 * helped the next person holding it.
 *
 * The dark rules and the NavTheme component are both still in the codebase.
 * Bringing dark back is mounting the switch and restoring this script — not
 * rewriting anything.
 */

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" className={display.variable} data-nav="light">
      <body>{children}</body>
    </html>
  );
}
