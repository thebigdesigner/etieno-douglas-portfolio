-- =====================================================================
-- 0036 — an instructor hears about a sale
--
-- A purchase currently notifies nobody. The learner gets their course and
-- the instructor finds out by looking at earnings, which is a poor way to
-- learn that somebody paid you.
--
-- Same shape as the certificate email in 0035, and for the same reason:
-- purchases are written by record_course_purchases inside the database,
-- and SQL cannot send mail. A column marks who has been told; the app
-- sweeps for the rest.
-- =====================================================================

alter table course_purchases
  add column if not exists instructor_notified_at timestamptz;

comment on column course_purchases.instructor_notified_at is
  'When the instructor was emailed about this sale. Null means the sweep still owes them one.';

-- Anything bought before this existed is not news any more.
update course_purchases set instructor_notified_at = purchased_at
 where instructor_notified_at is null;

create index if not exists purchases_unnotified
  on course_purchases (purchased_at) where instructor_notified_at is null;

-- ---------------------------------------------------------------------
-- What the sweep needs: the sale, the course, the instructor to tell, and
-- their share of it.
--
-- The learner is deliberately not named. An instructor does not need to
-- know who bought it to know that somebody did, and the earnings page is
-- where the detail belongs.
-- ---------------------------------------------------------------------
create or replace function public.purchases_awaiting_instructor_email(p_limit int default 50)
returns table (
  purchase_id      uuid,
  course_title     text,
  course_slug      text,
  price_cents      int,
  instructor_cents int,
  currency         text,
  purchased_at     timestamptz,
  instructor_name  text,
  instructor_email text,
  sales_total      int
)
language sql
stable
security definer set search_path = public
as $$
  select cp.id, co.title, co.slug, cp.price_cents, cp.instructor_cents,
         cp.currency, cp.purchased_at, p.display_name, p.email,
         -- How many this course has sold in total, so the first one reads
         -- as a first and the fiftieth does not read the same.
         (select count(*)::int from course_purchases x
           where x.course_id = cp.course_id and x.refunded_at is null)
    from course_purchases cp
    join courses  co on co.id = cp.course_id
    join profiles p  on p.id = co.instructor_id
   where cp.instructor_notified_at is null
     and cp.refunded_at is null
     and p.email is not null
   order by cp.purchased_at
   limit p_limit;
$$;

create or replace function public.mark_purchase_notified(p_purchase_id uuid)
returns void
language sql
security definer set search_path = public
as $$
  update course_purchases set instructor_notified_at = now() where id = p_purchase_id;
$$;
