"use client";
import { useActionState } from "react";
import { setNewPassword } from "@/app/actions/auth";
import type { FormState } from "@/lib/forms";
import SubmitButton from "@/components/SubmitButton";
import Alert from "@/components/Alert";

const initial: FormState = {};

export default function ResetForm() {
  const [state, action] = useActionState(setNewPassword, initial);

  return (
    <form action={action} className="auth__form">
      <label className="field">
        <span className="field__label">New password</span>
        <input name="password" type="password" autoComplete="new-password" minLength={8} required autoFocus />
        <span className="field__hint">At least 8 characters.</span>
      </label>
      <label className="field">
        <span className="field__label">Type it again</span>
        <input name="confirm" type="password" autoComplete="new-password" minLength={8} required />
      </label>

      {state.error && <Alert kind="error">{state.error}</Alert>}

      <SubmitButton>Save and log in</SubmitButton>
    </form>
  );
}
