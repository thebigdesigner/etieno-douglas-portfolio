"use client";

import Link from "next/link";
import { useEffect, useState, useTransition } from "react";
import { mk } from "@/lib/marketplace/href";
import { price } from "@/lib/marketplace/format";
import { clearCart, lineCents, removeFromCart, useCart } from "@/lib/marketplace/cart";
import { priceCart, startMarketplaceCheckout, type CartPricing } from "@/app/actions/marketplace-checkout";
import { DEFAULT_CCY, CCY_LABEL, type Ccy } from "@/lib/money";
import PayChoice from "@/components/PayChoice";
import type { ProviderChoice } from "@/lib/payments";
import MkIcon from "@/components/marketplace/MkIcon";
import ProductPreview from "@/components/marketplace/ProductPreview";

/**
 * The cart page.
 *
 * Prices come back from the server as soon as the page loads: the browser
 * remembers what an item cost when it was added, which goes stale when a
 * creator changes a price or the visitor switches currency. Until that
 * returns, the remembered figures are shown so the page is never blank.
 */
export default function CartView({ base, payOptions, ccy }: {
  base: string; payOptions: Record<string, ProviderChoice[]>; ccy: Ccy;
}) {
  const lines = useCart();
  const [pricing, setPricing] = useState<CartPricing | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [provider, setProvider] = useState<string>("");
  const [pending, start] = useTransition();

  const key = lines.map((l) => `${l.slug}:${l.licence}`).join(",");
  useEffect(() => {
    let live = true;
    if (!lines.length) { setPricing(null); return; }
    priceCart(lines.map((l) => ({ slug: l.slug, licence: l.licence })))
      .then((p) => { if (live) setPricing(p); })
      .catch(() => undefined);
    return () => { live = false; };
    // Re-priced whenever the contents change; the currency change arrives
    // as a full refresh, which remounts this.
  }, [key]);   // eslint-disable-line react-hooks/exhaustive-deps

  const shown: Ccy = pricing?.currency ?? ccy;
  const centsFor = (slug: string, fallback: number) => pricing?.lines[slug] ?? fallback;
  const options = payOptions[shown] ?? [];

  const checkout = () => start(async () => {
    setError(null);
    const res = await startMarketplaceCheckout(lines.map((l) => ({ slug: l.slug, licence: l.licence })), provider);
    if ("error" in res) { setError(res.error); return; }
    // Free items need no payment; the cart is done either way, and the
    // payment page is where anything paid continues.
    if ("freed" in res) { clearCart(); window.location.href = mk(base, "/library"); return; }
    window.location.href = res.url;
  });
  const total = pricing?.total ?? lines.reduce((s, l) => s + lineCents(l), 0);

  if (!lines.length) {
    return (
      <section className="mk-cart mk-cart--empty">
        <span className="mk-cart__emptyico"><MkIcon name="cart" size={30} /></span>
        <h1 className="mk-cart__h">Your cart is empty</h1>
        <p className="mk-cart__p">Items you add from a product page wait here until you check out.</p>
        <Link href={mk(base, "/all")} className="mk-btn mk-btn--fill">Browse all items</Link>
      </section>
    );
  }

  return (
    <section className="mk-cart">
      <h1 className="mk-cart__h">Cart <span className="mk-cart__count num">{lines.length}</span></h1>
      <div className="mk-cart__grid">
        <ul className="mk-cart__list">
          {lines.map((l) => (
            <li key={l.slug} className="mk-cart__line">
              <Link href={mk(base, `/item/${l.slug}`)} className="mk-cart__thumb" tabIndex={-1} aria-hidden="true">
                <ProductPreview product={l.product} className="mk-cart__img" label="" />
              </Link>
              <div className="mk-cart__info">
                <Link href={mk(base, `/item/${l.slug}`)} className="mk-cart__title">{l.product.title}</Link>
                <span className="mk-cart__lic">{l.licence === "commercial" ? "Commercial licence" : "Personal licence"}</span>
              </div>
              <span className="mk-cart__price num">{price(centsFor(l.slug, lineCents(l)), shown)}</span>
              <button type="button" className="mk-cart__rm" onClick={() => removeFromCart(l.slug)}
                aria-label={`Remove ${l.product.title}`}>
                <MkIcon name="trash" size={18} />
              </button>
            </li>
          ))}
        </ul>

        <aside className="mk-panel mk-cart__sum">
          <div className="mk-cart__row"><span>Subtotal</span><span className="num">{price(total, shown)}</span></div>
          <p className="mk-cart__fine">Taxes, if any, are worked out at checkout.</p>
          {pricing?.fellBack && (
            <p className="mk-cart__note">
              Charged in US dollars: not every item in this cart has a price in {CCY_LABEL[ccy]}.
            </p>
          )}
          {options.length === 0 ? (
            <p className="mk-buy__note" role="status">
              We cannot take {CCY_LABEL[shown]} yet. Switch currency at the top of the page to check out.
            </p>
          ) : (
            <PayChoice options={options} onPick={setProvider} />
          )}
          <button type="button" className="mk-btn mk-btn--fill mk-btn--wide" onClick={checkout} disabled={pending}>
            <MkIcon name="bag" size={18} />{pending ? "Opening checkout…" : "Check out"}
          </button>
          {error && <p className="mk-buy__note" role="alert">{error}</p>}
          <p className="mk-cart__fine">One payment per item, no subscription. Future updates are included.</p>
        </aside>
      </div>
    </section>
  );
}
