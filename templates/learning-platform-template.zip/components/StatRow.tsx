export type Stat = {
  value: string;
  label: string;
  icon: "book" | "flag" | "score" | "award";
  tint: "violet" | "coral" | "amber" | "teal" | "indigo" | "lime";
};

const ICONS: Record<Stat["icon"], React.ReactNode> = {
  book: (
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M4 5.5A1.5 1.5 0 0 1 5.5 4H10a2 2 0 0 1 2 2v13a1.5 1.5 0 0 0-1.5-1.5h-5A1.5 1.5 0 0 1 4 16V5.5Z"
        stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" />
      <path d="M20 5.5A1.5 1.5 0 0 0 18.5 4H14a2 2 0 0 0-2 2v13a1.5 1.5 0 0 1 1.5-1.5h5A1.5 1.5 0 0 0 20 16V5.5Z"
        stroke="currentColor" strokeWidth="1.6" strokeLinejoin="round" />
    </svg>
  ),
  flag: (
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <path d="M6 21V4M6 5h11l-2.5 4L17 13H6" stroke="currentColor" strokeWidth="1.6"
        strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
  score: (
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <circle cx="12" cy="12" r="8.2" stroke="currentColor" strokeWidth="1.6" />
      <path d="M12 3.8A8.2 8.2 0 0 1 19.4 15" stroke="currentColor" strokeWidth="3"
        strokeLinecap="round" />
    </svg>
  ),
  award: (
    <svg viewBox="0 0 24 24" fill="none" aria-hidden="true">
      <circle cx="12" cy="9" r="5.2" stroke="currentColor" strokeWidth="1.6" />
      <path d="M8.5 13.6 7 21l5-2.4L17 21l-1.5-7.4" stroke="currentColor" strokeWidth="1.6"
        strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  ),
};

export default function StatRow({ stats }: { stats: Stat[] }) {
  return (
    <div className="statrow">
      {stats.map((s) => (
        <div key={s.label} className={`stat tone-${s.tint}`}>
          <span className="stat__ico">{ICONS[s.icon]}</span>
          <span className="stat__body">
            <span className="stat__v num">{s.value}</span>
            <span className="stat__l">{s.label}</span>
          </span>
        </div>
      ))}
    </div>
  );
}
