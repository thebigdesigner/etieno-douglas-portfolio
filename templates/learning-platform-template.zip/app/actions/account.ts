"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { track } from "@/lib/track";
import { isOwnerEmail } from "@/lib/owner";
import type { FormState } from "@/lib/forms";

async function me() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");
  return { supabase, user };
}

const AVATAR_MAX = 3 * 1024 * 1024;
const AVATAR_TYPES = ["image/jpeg", "image/png", "image/webp"];

export async function dismissSuggestion(slug: string): Promise<void> {
  const { user } = await me();
  const admin = createAdminClient();

  const { data: course } = await admin
    .from("courses").select("id").eq("slug", slug).maybeSingle();
  if (!course) return;

  await admin
    .from("dismissed_suggestions")
    .upsert({ user_id: user.id, course_id: course.id }, { onConflict: "user_id,course_id" });

  revalidatePath("/dashboard");
}

export async function markNotificationsSeen(): Promise<void> {
  const { user } = await me();
  const admin = createAdminClient();
  await admin
    .from("profiles")
    .update({ notifications_seen_at: new Date().toISOString() })
    .eq("id", user.id);
}

/* ------------------------------------------------------------------ */
/* Profile picture                                                     */
/* ------------------------------------------------------------------ */
export async function uploadAvatar(_prev: FormState, formData: FormData): Promise<FormState> {
  const { user } = await me();

  const file = formData.get("avatar");
  if (!(file instanceof File) || file.size === 0) return { error: "Choose an image." };
  if (file.size > AVATAR_MAX) return { error: "That image is over 3MB. Compress it and try again." };
  if (!AVATAR_TYPES.includes(file.type)) return { error: "JPEG, PNG or WebP." };

  const admin = createAdminClient();
  const ext = file.type === "image/png" ? "png" : file.type === "image/webp" ? "webp" : "jpg";
  // Timestamped so a replacement busts any CDN cache of the old one.
  const path = `${user.id}/${Date.now()}.${ext}`;

  const { error: upErr } = await admin.storage
    .from("avatars").upload(path, file, { contentType: file.type, upsert: true });
  if (upErr) return { error: "Upload failed. Please try again." };

  // Clear out the previous file rather than leaving orphans in the bucket.
  // A provider URL is not ours to delete, so only bucket paths are removed.
  const { data: existing } = await admin
    .from("profiles").select("avatar_path").eq("id", user.id).maybeSingle();
  if (existing?.avatar_path && !existing.avatar_path.startsWith("http")) {
    await admin.storage.from("avatars").remove([existing.avatar_path]);
  }

  const { error } = await admin
    .from("profiles").update({ avatar_path: path }).eq("id", user.id);
  if (error) return { error: "Uploaded, but could not be saved. Try again." };

  revalidatePath("/dashboard/account");
  revalidatePath("/dashboard");
  return { ok: true, message: "Picture updated." };
}

export async function removeAvatar(): Promise<void> {
  const { user } = await me();
  const admin = createAdminClient();

  const { data: existing } = await admin
    .from("profiles").select("avatar_path").eq("id", user.id).maybeSingle();
  if (existing?.avatar_path && !existing.avatar_path.startsWith("http")) {
    await admin.storage.from("avatars").remove([existing.avatar_path]);
  }

  await admin.from("profiles").update({ avatar_path: null }).eq("id", user.id);
  revalidatePath("/dashboard/account");
  revalidatePath("/dashboard");
}

/* ------------------------------------------------------------------ */
/* Profile                                                             */
/* ------------------------------------------------------------------ */
export async function updateProfile(_prev: FormState, formData: FormData): Promise<FormState> {
  const { user } = await me();
  const name = String(formData.get("display_name") ?? "").trim();
  if (name.length < 2) return { error: "Please enter your name." };

  const admin = createAdminClient();

  // The name on an issued certificate does not change retrospectively —
  // it was verified at the point a practitioner signed it.
  const { data: certs } = await admin
    .from("certificates").select("id, enrolments!inner(user_id)")
    .eq("enrolments.user_id", user.id).limit(1);

  const { error } = await admin
    .from("profiles").update({ display_name: name }).eq("id", user.id);

  if (error) return { error: "Could not save. Please try again." };

  revalidatePath("/dashboard/account");
  return {
    ok: true,
    message: certs && certs.length > 0
      ? "Saved. Certificates already issued keep the name they were signed with."
      : "Saved.",
  };
}

export async function changePassword(_prev: FormState, formData: FormData): Promise<FormState> {
  const { supabase } = await me();

  const password = String(formData.get("password") ?? "");
  const confirm = String(formData.get("confirm") ?? "");

  if (password.length < 8) return { error: "At least 8 characters." };
  if (password !== confirm) return { error: "Those two passwords do not match." };

  const { error } = await supabase.auth.updateUser({ password });
  if (error) return { error: error.message };

  return { ok: true, message: "Password changed." };
}

/**
 * Cohort learners hold a synthetic address and can adopt a real one at the
 * end of a term, so their certificates outlive the cohort.
 */
export async function claimEmail(_prev: FormState, formData: FormData): Promise<FormState> {
  const { supabase, user } = await me();
  const email = String(formData.get("email") ?? "").trim().toLowerCase();

  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
    return { error: "Please enter a valid email address." };
  }

  const { error } = await supabase.auth.updateUser({ email });
  if (error) return { error: error.message };

  const admin = createAdminClient();
  await admin.from("profiles").update({ email }).eq("id", user.id);

  return {
    ok: true,
    message: "Check that address for a confirmation link. Until you click it, keep using your username and PIN.",
  };
}

/* ------------------------------------------------------------------ */
/* Data rights                                                         */
/* ------------------------------------------------------------------ */
export async function exportMyData(): Promise<FormState> {
  const { user } = await me();
  const admin = createAdminClient();

  const [profile, enrolments, completions, attempts, submissions, certificates] =
    await Promise.all([
      admin.from("profiles").select("*").eq("id", user.id).maybeSingle(),
      admin.from("enrolments").select("*").eq("user_id", user.id),
      admin.from("topic_completions").select("*, enrolments!inner(user_id)")
        .eq("enrolments.user_id", user.id),
      admin.from("quiz_attempts").select("*, enrolments!inner(user_id)")
        .eq("enrolments.user_id", user.id),
      admin.from("submissions").select("*, enrolments!inner(user_id)")
        .eq("enrolments.user_id", user.id),
      admin.from("certificates").select("*, enrolments!inner(user_id)")
        .eq("enrolments.user_id", user.id),
    ]);

  return {
    ok: true,
    message: JSON.stringify(
      {
        exported_at: new Date().toISOString(),
        profile: profile.data,
        enrolments: enrolments.data,
        topic_completions: completions.data,
        quiz_attempts: attempts.data,
        submissions: submissions.data,
        certificates: certificates.data,
      },
      null,
      2
    ),
  };
}

export async function requestDeletion(_prev: FormState, formData: FormData): Promise<FormState> {
  const { user } = await me();
  const confirm = String(formData.get("confirm") ?? "").trim().toUpperCase();

  if (confirm !== "DELETE") {
    return { error: 'Type DELETE to confirm.' };
  }

  /* An allowlisted owner cannot delete themselves.
   *
   * request_account_deletion refuses role = 'operator', but the console
   * gate is OWNER_EMAILS, not the role column — deliberately, so a
   * compromised database cannot grant it. An owner whose profile still
   * says 'learner' therefore passes the database check, gets suspended,
   * and is locked out of the only surface that could undo it. The two
   * gates disagreeing is the exact failure this codebase already fixed
   * once; the check has to happen here, where the allowlist is visible. */
  if (isOwnerEmail(user.email)) {
    return {
      error:
        "This account runs Your Brand, so it cannot delete itself — you would lock yourself out of the console with no way back in. Remove the address from OWNER_EMAILS first.",
    };
  }

  const admin = createAdminClient();
  const { data } = await admin.rpc("request_account_deletion", {
    p_user_id: user.id,
    p_reason: String(formData.get("reason") ?? "").trim() || null,
  });

  const row = (data ?? [])[0] as
    | { ok: boolean; reason: string | null; due_at: string | null }
    | undefined;

  if (!row?.ok) {
    if (row?.reason === "already_requested") {
      return {
        error: `You have already asked us to delete this account. We complete it by ${
          row.due_at ? new Date(row.due_at).toLocaleDateString() : "the agreed date"
        }.`,
      };
    }
    if (row?.reason === "operator_account") {
      return {
        error:
          "This account runs Your Brand, so it cannot delete itself — locking the only account that can reach the console is not something we could undo. Ask another operator.",
      };
    }
    return { error: "Could not process that. Please contact hello@yourbrand.com." };
  }

  await track("deletion_requested", user.id, {});

  /* Sign them out, and say so.
   *
   * This is why deleting an account looked like it did nothing: the
   * profile was suspended, but `suspended` is only checked at login, so
   * the existing session carried on working. You typed DELETE, got a
   * confirmation, and every page still loaded normally — which reads as
   * a broken button rather than a completed request.
   *
   * signOut ends the session, so the state of the account and what the
   * person can see finally agree. */
  const supabase = await createClient();
  await supabase.auth.signOut();

  redirect("/login?error=deleted_ok");
}


/**
 * Whether this person's initials may appear among the recent buyers of an
 * item they bought. Off means they are never shown, anywhere, including on
 * things they bought before turning it off.
 */
export async function setPurchaseVisibility(_prev: FormState, formData: FormData): Promise<FormState> {
  const { user } = await me();
  const show = String(formData.get("show_purchases") ?? "") === "on";

  const { error } = await createAdminClient()
    .from("profiles").update({ show_purchases: show }).eq("id", user.id);
  if (error) return { error: "Could not save that. Please try again." };

  revalidatePath("/dashboard/account");
  return { ok: true, message: show ? "Your initials may appear on items you buy." : "Your purchases are private." };
}
