import { createAdminClient } from "@/lib/supabase/admin";
import { sendEmail } from "@/lib/email";
import { certificateIssued, coursePurchased } from "@/lib/notifications";
import { siteUrl } from "@/lib/site";

/**
 * Email the learner about any certificate they have not been told about.
 *
 * A sweep rather than a call at each issuing site, because certificates are
 * created in the database — by the review function, by
 * issue_exam_certificate, by an upheld appeal, and by hand — and SQL cannot
 * send mail. One sweep covers every route including ones that do not exist
 * yet; a call site per route covers the ones somebody remembered.
 *
 * Marking happens per certificate, immediately after its own send, so a
 * failure halfway through a batch does not re-send the ones already
 * delivered. Sending twice is worse than sending late.
 */
export async function sweepCertificateEmails(limit = 50): Promise<{
  sent: number; failed: number;
}> {
  const admin = createAdminClient();

  const { data: rows, error } = await admin
    .rpc("certificates_awaiting_email", { p_limit: limit });

  if (error) {
    console.error("certificates_awaiting_email failed", error);
    return { sent: 0, failed: 0 };
  }

  const base = siteUrl();
  let sent = 0;
  let failed = 0;

  for (const row of (rows ?? []) as {
    code: string; kind: "assessed" | "examined"; reviewer_name: string | null;
    learner_name: string | null; learner_email: string; course_title: string;
  }[]) {
    try {
      await sendEmail({
        to: row.learner_email,
        ...certificateIssued({
          name: row.learner_name ?? "there",
          course: row.course_title,
          code: row.code,
          kind: row.kind,
          reviewer: row.reviewer_name ?? undefined,
          certUrl: `${base}/certificate/${row.code}`,
          verifyUrl: `${base}/verify/${row.code}`,
        }),
      });

      await admin.rpc("mark_certificate_notified", { p_code: row.code });
      sent += 1;
    } catch (e) {
      // Left unmarked, so the next sweep tries again. A certificate the
      // learner never hears about is the failure worth retrying.
      console.error("certificate email failed", row.code, e);
      failed += 1;
    }
  }

  return { sent, failed };
}

/**
 * Tell instructors about sales they have not heard about.
 *
 * Same sweep pattern as the certificates above, for the same reason: the
 * purchase row is written by record_course_purchases inside the database,
 * where no email can be sent from.
 */
export async function sweepSaleEmails(limit = 50): Promise<{
  sent: number; failed: number;
}> {
  const admin = createAdminClient();

  const { data: rows, error } = await admin
    .rpc("purchases_awaiting_instructor_email", { p_limit: limit });

  if (error) {
    console.error("purchases_awaiting_instructor_email failed", error);
    return { sent: 0, failed: 0 };
  }

  const base = siteUrl();
  let sent = 0;
  let failed = 0;

  const money = (cents: number, ccy: string) =>
    new Intl.NumberFormat("en", { style: "currency", currency: ccy || "USD" })
      .format((cents ?? 0) / 100);

  for (const row of (rows ?? []) as {
    purchase_id: string; course_title: string; price_cents: number;
    instructor_cents: number; currency: string; sales_total: number;
    instructor_name: string | null; instructor_email: string;
  }[]) {
    try {
      await sendEmail({
        to: row.instructor_email,
        ...coursePurchased({
          name: row.instructor_name ?? "there",
          course: row.course_title,
          amount: money(row.price_cents, row.currency),
          share: money(row.instructor_cents, row.currency),
          total: row.sales_total,
          url: `${base}/studio/earnings`,
        }),
      });

      await admin.rpc("mark_purchase_notified", { p_purchase_id: row.purchase_id });
      sent += 1;
    } catch (e) {
      console.error("sale email failed", row.purchase_id, e);
      failed += 1;
    }
  }

  return { sent, failed };
}
