import Link from "next/link";
import { categoryBySlug } from "@/lib/marketplace/categories";
import { getAuthors, isDemo, listProducts } from "@/lib/marketplace/catalog";
import { price } from "@/lib/marketplace/format";
import { marketBase, mk } from "@/lib/marketplace/url";
import type { Author, Product } from "@/lib/marketplace/types";
import MkIcon from "@/components/marketplace/MkIcon";
import ProductPreview from "@/components/marketplace/ProductPreview";
import HeroCarousel from "@/components/marketplace/HeroCarousel";
import { DemoNote, ProductShelf, SectionHead } from "@/components/marketplace/bits";

/**
 * The shop front, following the store layout the owner supplied: the wide
 * feature beside a rotating card, two tiles, a row of small cards, then
 * the collection bands and the large covers underneath.
 *
 * The collections use large covers on purpose: a font has to be legible
 * and a deck readable before anyone clicks, which a 78px tile cannot do.
 *
 * The category band from the reference is deliberately absent — twelve
 * equal cells in a slab of blue fought with everything around them. The
 * categories are in the rail, on All items, and in the tiles below.
 */

function BigCard({ p, base, author }: { p: Product; base: string; author?: Author }) {
  const cat = categoryBySlug(p.category);
  return (
    <article className="pv-card">
      <Link href={mk(base, `/item/${p.slug}`)} className="pv-card__link">
        <span className="pv-card__media"><ProductPreview product={p} className="pv-card__img" label="" /></span>
        <span className="pv-card__title">{p.title}</span>
      </Link>
      <span className="pv-card__meta">
        <span>{author?.name ?? cat?.name}</span>
        <span className={`num${p.priceCents === 0 ? " is-free" : ""}`}>{price(p.priceCents, p.currency)}</span>
      </span>
    </article>
  );
}

/** Editorial rather than algorithmic: each one answers a job someone
 *  arrives with, and pulls one item from each category it names. */
const COLLECTIONS = [
  { title: "Everything for a pitch", line: "A deck, a font and a soundtrack that hold together.", cats: ["presentations", "fonts", "music"], tag: "pitch deck" },
  { title: "Start a brand", line: "Marks, patterns and type for a shop that opens next month.", cats: ["graphics", "fonts", "icons"], tag: "brand" },
  { title: "Sound for video", line: "Cleared music and effects, trimmed and levelled.", cats: ["music", "sound-effects", "video-templates"], tag: "video" },
];

/** The first clause of a summary, for the feature card's one line. */
function oneLine(p: Product): string {
  const first = p.summary.split(/(?<=[.:;])\s/)[0].replace(/[.:;]$/, "");
  return first.length > 70 ? `${first.slice(0, 68).trimEnd()}…` : first;
}

const WORDLESS = new Set(["ui", "graphic", "icons", "audio", "3d", "code"]);

/**
 * Download counts alone put the free items at the top of every shelf —
 * free is downloaded most, so "trending" became a list of giveaways and
 * the paid catalogue never appeared on the home page. Paid items lead,
 * each group still ordered by downloads, and free has its own tile.
 */
function paidFirst(items: Product[]): Product[] {
  return [...items.filter((p) => p.priceCents > 0), ...items.filter((p) => p.priceCents === 0)];
}

export default async function MarketplaceHome() {
  const [base, trending, newest, free, demo] = await Promise.all([
    marketBase(),
    listProducts({ sort: "popular", perPage: 30 }),
    listProducts({ sort: "newest", perPage: 12 }),
    listProducts({ price: "free", sort: "popular", perPage: 4 }),
    isDemo(),
  ]);
  const pool = paidFirst([...trending.items, ...newest.items]);
  const authors = await getAuthors([...pool, ...free.items].map((p) => p.author));
  const all = mk(base, "/all");

  // The feature card writes its own caption over the cover, so covers that
  // already print their name — decks, books, fonts — are left to the rows.
  const featurePool = pool.filter((p, i, a) => a.findIndex((x) => x.id === p.id) === i)
    .filter((p) => WORDLESS.has(categoryBySlug(p.category)?.preview ?? ""));
  const featured = [...featurePool.filter((p) => p.featured), ...featurePool.filter((p) => !p.featured)].slice(0, 4);

  // An item appears in one collection only, so the bands do not repeat.
  const used = new Set<string>();
  const bands = COLLECTIONS.map((c) => ({
    ...c,
    picks: c.cats.map((cat) => {
      const pick = pool.find((p) => p.category === cat && !used.has(p.id));
      if (pick) used.add(pick.id);
      return pick;
    }).filter(Boolean) as Product[],
  })).filter((c) => c.picks.length > 0);

  return (
    <>
      {demo && <DemoNote />}

      <section className="mk-heroes">
        <Link href={all} className="mk-hero">
          <img src="/marketplace/banners/hero-camera.jpg" alt="" className="mk-hero__photo" />
          <span className="mk-hero__txt">
            <h1 className="mk-hero__title">
              <span className="mk-hero__h">Be creative</span>
              <span className="mk-hero__h2">with files made by people who use them</span>
            </h1>
            <span className="mk-hero__p">
              {trending.total.toLocaleString("en-US")} templates, fonts, sounds and graphics. Pay once, use it in your work.
            </span>
          </span>
        </Link>
        <HeroCarousel
          slides={[
            {
              href: mk(base, "/studio"), title: "Sell your work",
              line: "Open a shop and earn from every download",
              image: "/marketplace/banners/feature-portrait.jpg", focus: "50% 38%",
            },
            ...featured.map((p) => ({ href: mk(base, `/item/${p.slug}`), title: p.title.split(" — ")[0], line: oneLine(p), product: p })),
          ]}
        />
      </section>

      <section className="mk-tiles-row" aria-label="Browse">
        <Link href={`${all}?sort=popular`} className="mk-tile mk-tile--top">
          <MkIcon name="star" size={28} filled={false} />
          <span className="mk-tile__h">Top items</span>
          <span className="mk-tile__p">Trending and most downloaded</span>
        </Link>
        <Link href={`${all}?price=free`} className="mk-tile mk-tile--free">
          <MkIcon name="gift" size={28} />
          <span className="mk-tile__h">Free to download</span>
          <span className="mk-tile__p">Yours for any project</span>
        </Link>
        <Link href={all} className="mk-tile mk-tile--all">
          <MkIcon name="apps" size={26} />
          <span className="mk-tile__h">Every category</span>
          <span className="mk-tile__p">All {trending.total} items in one place</span>
        </Link>
      </section>

      <section className="mk-sec">
        <SectionHead title="Trending now" href={`${all}?sort=popular`} />
        <ProductShelf items={paidFirst(trending.items).slice(0, 6)} base={base} authors={authors} />
      </section>

      {bands.map((c, i) => (
        <section key={c.title} className={`pv-story pv-story--${i % 2 ? "alt" : "norm"}`}>
          <div className="pv-story__txt">
            <h2 className="pv-story__h">{c.title}</h2>
            <p className="pv-story__p">{c.line}</p>
            <Link className="pv-story__link" href={`${mk(base, "/search")}?q=${encodeURIComponent(c.tag)}`}>
              Browse the collection<MkIcon name="arrow-right" size={16} />
            </Link>
          </div>
          <div className="pv-story__items">
            {c.picks.map((p) => <BigCard key={p.id} p={p} base={base} author={authors.get(p.author)} />)}
          </div>
        </section>
      ))}

      <section className="mk-sec">
        <SectionHead title="New this week" href={`${all}?sort=newest`} />
        <div className="pv-grid pv-grid--4">
          {newest.items.slice(0, 4).map((p) => <BigCard key={p.id} p={p} base={base} author={authors.get(p.author)} />)}
        </div>
      </section>
    </>
  );
}
