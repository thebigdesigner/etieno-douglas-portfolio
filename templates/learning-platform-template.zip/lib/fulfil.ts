import { createAdminClient } from "@/lib/supabase/admin";
import { verifyPayment } from "@/lib/payments";
import { verifyByReference as flutterwaveVerify } from "@/lib/flutterwave";
import { isCurrency, formatPrice } from "@/lib/pricing";
import { sendEmail } from "@/lib/email";
import { sweepSaleEmails } from "@/lib/certificate-email";
import { purchaseConfirmed, itemsPurchased, itemSold } from "@/lib/notifications";
import { isCcy, money } from "@/lib/money";
import { siteUrl } from "@/lib/site";

export type FulfilResult =
  | { ok: true; already: boolean }
  | { ok: false; reason: string };

/**
 * Turn a paid transaction into access.
 *
 * Called from two places on purpose. The webhook is the reliable path, but
 * it depends on the provider reaching us — a misconfigured URL, a wrong
 * secret, or a local tunnel that is not running all produce the same
 * symptom: money taken and nothing unlocked. So the return page calls this
 * too. Both fulfilment functions are idempotent — record_course_purchases on
 * the unique (user_id, course_id), record_institution_licences on its own —
 * so whichever arrives second is a no-op rather than a second grant.
 *
 * Every check still runs on both paths. The return page is attacker-
 * reachable, so it gets no shortcuts the webhook does not get.
 */
export async function fulfilPayment(txRef: string): Promise<FulfilResult> {
  const admin = createAdminClient();

  const { data: intent, error: intentError } = await admin
    .from("checkout_intents").select("*").eq("tx_ref", txRef).maybeSingle();

  // Distinguish "no such intent" from "no such table". Both used to log the
  // same "no intent", which sends you looking at checkout when the real
  // answer is that 0024 was never pushed and the table does not exist.
  if (intentError) {
    console.error("checkout_intents lookup failed", txRef, intentError);
    return { ok: false, reason: `intent lookup failed: ${intentError.message}` };
  }

  if (!intent) {
    console.error("no checkout intent for", txRef);
    return { ok: false, reason: "no intent" };
  }

  // Verified with the provider directly, never against what was posted or
  // what came back on the redirect.
  //
  // Paystack is the provider. Flutterwave references (splari_courses_…,
  // underscores, which Paystack refuses) can still arrive for a few days
  // after the switch — a buyer who paid just before the deploy, or a
  // delayed webhook — so those are still checked with Flutterwave.
  // Remove this branch and lib/flutterwave.ts once FLUTTERWAVE_LEGACY_UNTIL
  // in MARKETPLACE.md has passed.
  const legacy = txRef.startsWith("splari_");
  const verified = legacy
    ? await flutterwaveVerify(txRef)
    : await verifyPayment(intent.provider, txRef, intent.provider_session);
  if (!verified) {
    console.error(`${legacy ? "flutterwave" : intent.provider} verify returned nothing for`, txRef);
    return { ok: false, reason: "verify failed" };
  }
  if (!verified.ok) return { ok: false, reason: "not successful" };

  if (!isCurrency(intent.currency)) return { ok: false, reason: "bad currency" };

  // A cart of courses. Same verification above — the
  // payment is confirmed with the provider before anything is granted — but
  // what it buys is different, so it forks here rather than being a second
  // fulfilment path that could drift from this one.
  // An institution buying licences. Same verification, different holder.
  if (intent.kind === "licences") {
    const expected = Number(intent.amount_cents) / 100;
    if (verified.currency !== intent.currency) return { ok: false, reason: "currency mismatch" };
    if (verified.amount < expected) return { ok: false, reason: "amount mismatch" };

    const alreadyDone = !!intent.completed_at;
    const { error: licenceError } = await admin
      .rpc("record_institution_licences", { p_tx_ref: txRef });

    if (licenceError) {
      console.error("record_institution_licences failed", txRef, licenceError);
      return { ok: false, reason: "licence failed" };
    }

    if (!alreadyDone) {
      await sweepSaleEmails(10);
      await sendReceipt(intent.user_id, intent.course_ids as string[],
                        intent.currency, expected, verified.providerRef);
    }
    return { ok: true, already: alreadyDone };
  }

  // Marketplace items. Same verification; what it buys is a download
  // rather than a course, and it also credits the creator's wallet.
  if (intent.kind === "marketplace") {
    const expected = Number(intent.amount_cents) / 100;
    if (verified.currency !== intent.currency) return { ok: false, reason: "currency mismatch" };
    if (verified.amount < expected) {
      console.error("marketplace amount mismatch", txRef, verified.amount, expected);
      return { ok: false, reason: "amount mismatch" };
    }

    const alreadyDone = !!intent.completed_at;
    const { error: purchaseError } = await admin.rpc("mk_record_purchase", { p_tx_ref: txRef });
    if (purchaseError) {
      console.error("mk_record_purchase failed", txRef, purchaseError);
      return { ok: false, reason: "purchase failed" };
    }
    if (!alreadyDone) {
      await admin.from("checkout_intents").update({ completed_at: new Date().toISOString() }).eq("tx_ref", txRef);
      // After the intent is closed, so a slow mail provider can never hold
      // up the thing the buyer is waiting for, which is access.
      await mkPurchaseEmails(txRef, verified.providerRef);
    }
    return { ok: true, already: alreadyDone };
  }

  if (intent.kind === "courses") {
    const expectedCourses = Number(intent.amount_cents) / 100;

    if (verified.currency !== intent.currency) {
      console.error("currency mismatch", txRef, verified.currency, intent.currency);
      return { ok: false, reason: "currency mismatch" };
    }
    if (verified.amount < expectedCourses) {
      console.error("amount mismatch", txRef,
        `paid ${verified.amount} ${verified.currency}`, `expected ${expectedCourses}`);
      return { ok: false, reason: "amount mismatch" };
    }

    const alreadyDone = !!intent.completed_at;

    // Idempotent in the database: a replayed webhook inserts nothing and
    // returns 0, so the guard here is about the receipt, not the purchase.
    const { error: purchaseError } = await admin
      .rpc("record_course_purchases", { p_tx_ref: txRef });

    if (purchaseError) {
      console.error("record_course_purchases failed", txRef, purchaseError);
      return { ok: false, reason: "purchase failed" };
    }

    // Tell the instructors now. Both sweeps mark what they send, so calling
    // them here and nightly cannot double up.
    //
    // The buyer's receipt goes inside the same guard: both the webhook and
    // the return page call this, so sending outside it would confirm one
    // payment twice.
    if (!alreadyDone) {
      await sweepSaleEmails(10);
      await sendReceipt(intent.user_id, intent.course_ids as string[],
                        intent.currency, expectedCourses, verified.providerRef);
    }

    return { ok: true, already: alreadyDone };
  }

  // Nothing else is sellable. A plan intent cannot be created any more —
  // 0063 put that in a check constraint — but a historic one could still
  // arrive from a replayed webhook, and granting nothing is the right
  // answer to a product we no longer sell.
  console.error("unfulfillable intent kind", txRef, intent.kind);
  return { ok: false, reason: `unsupported kind: ${intent.kind}` };
}

/**
 * The receipt. Deliberately never throws — a failed email must not turn a
 * successful payment into a failed fulfilment, because the money is already
 * taken and the access is already granted.
 */
async function sendReceipt(
  userId: string,
  courseIds: string[],
  currency: string,
  amount: number,
  reference: string
) {
  try {
    const admin = createAdminClient();

    const { data: profile } = await admin
      .from("profiles").select("display_name, email").eq("id", userId).maybeSingle();

    // Cohort learners hold a synthetic address that goes nowhere.
    if (!profile?.email || profile.email.endsWith("@cohort.splari.internal")) return;

    const { data: courses } = await admin
      .from("courses").select("title, slug").in("id", courseIds);

    // A receipt naming nothing is worse than a slightly late one — if the
    // titles cannot be read, the amount and reference still have to reach
    // the person who paid, so this falls back rather than returning.
    const named = (courses ?? []).map((c) => ({
      title: c.title as string,
      url: `${siteUrl()}/courses/${c.slug}`,
    }));

    await sendEmail({
      to: profile.email,
      ...purchaseConfirmed({
        name: profile.display_name ?? "there",
        courses: named.length ? named : [{ title: "Your purchase", url: `${siteUrl()}/dashboard/courses` }],
        amount: isCurrency(currency) ? formatPrice(currency, amount) : `${amount} ${currency}`,
        reference,
        url: `${siteUrl()}/dashboard/courses`,
      }),
    });
  } catch (err) {
    console.error("receipt email failed for", userId, err);
  }
}


/**
 * Receipts for a marketplace cart, and a sale notice for each creator in
 * it. Runs once per checkout, after the intent is closed.
 *
 * Every step is allowed to fail quietly. A receipt that does not arrive
 * is a bad day; a receipt that throws inside fulfilment would leave a
 * paid buyer without their download, which is a refund.
 */
async function mkPurchaseEmails(txRef: string, reference: string) {
  try {
    const admin = createAdminClient();
    const { data: orders } = await admin
      .from("mk_orders")
      .select("id, user_id, licence, amount_cents, currency, creator_cents, commission_cents, " +
              "mk_products(title, slug, mk_creators(display_name, user_id))")
      .eq("tx_ref", txRef).eq("status", "paid");
    if (!orders?.length) return;

    type Row = {
      id: string; user_id: string; licence: string; amount_cents: number; currency: string;
      creator_cents: number | null; commission_cents: number | null;
      mk_products: { title: string; slug: string;
        mk_creators: { display_name: string; user_id: string } | { display_name: string; user_id: string }[] | null }
        | { title: string; slug: string; mk_creators: unknown }[] | null;
    };
    const rows = orders as unknown as Row[];
    const one = <T,>(v: T | T[] | null): T | null => (Array.isArray(v) ? v[0] ?? null : v);
    const site = siteUrl();
    const ccy = (c: string) => (isCcy(c) ? c : "USD");

    // ---- the buyer's receipt, one email for the whole cart
    const buyerId = rows[0].user_id;
    const { data: buyer } = await admin.from("profiles")
      .select("email, display_name").eq("id", buyerId).maybeSingle();
    const total = rows.reduce((n, r) => n + r.amount_cents, 0);

    if (buyer?.email) {
      await sendEmail({
        to: buyer.email,
        ...itemsPurchased({
          name: buyer.display_name ?? "there",
          items: rows.map((r) => {
            const prod = one(r.mk_products) as { title: string; slug: string } | null;
            return {
              title: prod?.title ?? "Your purchase",
              licence: r.licence,
              url: `${site}/marketplace/item/${prod?.slug ?? ""}`,
            };
          }),
          amount: money(total, ccy(rows[0].currency)),
          reference,
          url: `${site}/marketplace/library`,
        }),
      });
    }

    // ---- one notice per sale, to whoever made the thing
    for (const r of rows) {
      const prod = one(r.mk_products) as
        { title: string; mk_creators: { display_name: string; user_id: string } | { display_name: string; user_id: string }[] | null } | null;
      const shop = prod ? one(prod.mk_creators) : null;
      if (!shop) continue;
      const { data: seller } = await admin.from("profiles")
        .select("email").eq("id", shop.user_id).maybeSingle();
      if (!seller?.email) continue;

      // The hold is set by mk_record_sale, so it is read back rather than
      // recalculated here — two places computing the same date is two
      // places to get it wrong.
      const { data: entry } = await admin.from("mk_wallet_entries")
        .select("available_at").eq("order_id", r.id).eq("kind", "sale").maybeSingle();
      const clears = entry?.available_at
        ? new Date(entry.available_at as string).toLocaleDateString("en-GB",
            { day: "numeric", month: "long", year: "numeric" })
        : "the end of the seven-day hold";

      const c = ccy(r.currency);
      const fee = r.commission_cents ?? 0;
      await sendEmail({
        to: seller.email,
        ...itemSold({
          name: shop.display_name,
          item: prod?.title ?? "your item",
          licence: r.licence,
          gross: money(r.amount_cents, c),
          fee: fee > 0 ? money(fee, c) : null,
          net: money(r.creator_cents ?? r.amount_cents - fee, c),
          availableOn: clears,
          url: `${site}/marketplace/studio/earnings`,
        }),
      });
    }
  } catch (err) {
    console.error("marketplace emails failed for", txRef, err);
  }
}
