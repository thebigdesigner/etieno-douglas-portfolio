"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { setCurrency } from "@/app/actions/currency";
import { CCY_SHORT, CURRENCIES, type Ccy } from "@/lib/money";

/**
 * Changing the currency on show. The guess from a visitor's country is
 * only ever a starting point, so this is always visible rather than
 * hidden behind a settings page.
 */
export default function CurrencySwitch({ value, className = "" }: { value: Ccy; className?: string }) {
  const [ccy, setCcy] = useState<Ccy>(value);
  const [pending, start] = useTransition();
  const router = useRouter();

  const pick = (next: Ccy) => {
    if (next === ccy) return;
    setCcy(next);
    start(async () => { await setCurrency(next); router.refresh(); });
  };

  return (
    <label className={`ccy ${className}`} data-pending={pending || undefined}>
      <span className="sr">Currency</span>
      <select className="ccy__sel" value={ccy} disabled={pending}
        onChange={(e) => pick(e.target.value as Ccy)}>
        {CURRENCIES.map((c) => <option key={c} value={c}>{CCY_SHORT[c]}</option>)}
      </select>
    </label>
  );
}
