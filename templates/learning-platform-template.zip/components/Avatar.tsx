import { avatarUrl, initials } from "@/lib/avatar";

/**
 * A picture where there is one, initials where there is not.
 *
 * Deliberately not next/image: avatars come from a Supabase public bucket
 * and from Google and LinkedIn CDNs, and adding every provider host to
 * next.config just to optimise a 40px circle is not a good trade.
 */
export default function Avatar({
  name, path, size = 40, className = "",
}: {
  name?: string | null;
  path?: string | null;
  size?: number;
  className?: string;
}) {
  const url = avatarUrl(path);
  const style = { width: size, height: size, fontSize: Math.round(size * 0.36) };

  if (url) {
    return (
      <img
        className={`avatar ${className}`.trim()}
        src={url}
        alt={name ? `${name}'s profile picture` : "Profile picture"}
        style={style}
        loading="lazy"
      />
    );
  }

  return (
    <span className={`avatar avatar--fb ${className}`.trim()} style={style} aria-hidden="true">
      {initials(name)}
    </span>
  );
}
