/**
 * POST /api/ticket  { reference, phone }
 * Re-sends the ticket for a booking that is already paid.
 *
 * The caller supplies only a reference and the phone number used to book. Everything in the email
 * comes from the database, and an unpaid booking is refused — so this cannot be used to send
 * invented tickets from our domain.
 */
import { configured, select, tenant, fail, limited, lookupBlocked, lookupMissed } from './_lib/db.js';
import { sendTicketEmail } from './_lib/ticket-email.js';

const last7 = s => String(s || '').replace(/\D/g, '').slice(-7);

export default async function handler(req, res) {
  if (req.method !== 'POST') return fail(res, 405, 'method', 'POST only');
  if (!configured()) return fail(res, 503, 'not_configured', 'Not configured');

  const reference = String(req.body?.reference || '').toUpperCase();
  const phone = String(req.body?.phone || '');
  if (!/^[A-Z]{2,5}-[A-Z0-9]{4,10}(-[A-Z0-9]{2,6})?$/.test(reference)) return fail(res, 400, 'bad_reference', 'Check the reference');
  if (last7(phone).length < 7) return fail(res, 400, 'bad_phone', 'Enter the phone number used to book');
  if (await lookupBlocked(req, phone)) return fail(res, 429, 'too_many', 'Too many attempts. Please wait a few minutes.');
  if (await limited(`ticket:${reference}`, 3, 600)) return fail(res, 429, 'too_many', 'Ticket already sent a few times. Please wait.');

  try {
    const t = await tenant();
    const rows = await select('bookings', `tenant_id=eq.${t.id}&reference=eq.${reference}&select=contact_phone,status`);
    // Same answer for a wrong reference as for a wrong phone: no fishing for references.
    if (!rows.length || last7(rows[0].contact_phone) !== last7(phone)) {
      await lookupMissed(req, phone);
      return fail(res, 404, 'not_found', 'No booking found for that reference and phone number');
    }
    if (rows[0].status !== 'confirmed')
      return fail(res, 409, 'not_paid', 'This booking is not paid yet, so there is no ticket to send');

    const out = await sendTicketEmail(reference);
    return res.status(200).json(out);
  } catch (err) {
    if (err.code === 'no_email') return fail(res, 409, 'no_email', 'No email address on this booking');
    if (err.code === 'not_configured') return fail(res, 503, 'not_configured', 'Email is not switched on');
    console.error('ticket resend failed:', err.message);
    return fail(res, 502, 'send_failed', 'Could not send the ticket');
  }
}
