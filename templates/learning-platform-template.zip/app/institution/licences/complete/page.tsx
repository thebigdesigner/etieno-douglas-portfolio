import Link from "next/link";
import { redirect } from "next/navigation";
import { fulfilPayment } from "@/lib/fulfil";

export const metadata = { title: "Licences" };
export const dynamic = "force-dynamic";

// Paystack returns ?reference= (and ?trxref=, the same value). tx_ref is
// what Flutterwave sent, still accepted for payments made before the switch.
type Params = Promise<{ reference?: string; trxref?: string; tx_ref?: string; status?: string }>;

export default async function LicenceCompletePage({ searchParams }: { searchParams: Params }) {
  const sp = await searchParams;
  const txRef = sp.reference ?? sp.trxref ?? sp.tx_ref;
  const status = sp.status;
  if (!txRef || status === "cancelled") redirect("/institution/licences?error=checkout");

  const result = await fulfilPayment(txRef);

  return (
    <>
      <div className="dash__bar">
        <div>
          <div className="eyebrow">Admin</div>
          <h1 className="dash__title">
            {result.ok ? "Licensed" : "We could not confirm that payment"}
          </h1>
        </div>
      </div>

      <div className="card">
        <p className="card__meta" style={{ maxWidth: "52ch" }}>
          {result.ok
            ? "Those courses are open to every cohort you run, including the project assessment for each learner who reaches it."
            : "If money left your account, nothing is lost — this page will confirm it once the provider does. Reload in a minute, and send us the reference if it still says this."}
        </p>
        <Link className="btn btn--fill btn--lg" href="/institution/licences" style={{ marginTop: 18 }}>
          Back to licences
        </Link>
      </div>
    </>
  );
}
