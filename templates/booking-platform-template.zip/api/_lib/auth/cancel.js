/**
 * GET  /api/auth/cancel?t=TOKEN  — says exactly what cancelling will do, with one button
 * POST /api/auth/cancel  t=TOKEN — cancels the booking and records any refund due
 *
 * The link was emailed to the booking's own address by the cancel-request action. GET never
 * changes anything (mail scanners open links); only the POST spends the token. The refund is
 * worked out again at the moment of cancelling, because the policy depends on how close to
 * departure it is and the email may have been opened hours later.
 */
import { configured, select, update, rpc, audit, tenant, fail } from '../db.js';
import { verify } from './session.js';
import { confirmPage, tokenOf } from './confirm-page.js';
import { cancellationQuote } from '../cancel-policy.js';

const naira = k => '₦' + Math.round(k / 100).toLocaleString('en-NG');
const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));

function page(res, status, title, body) {
  res.setHeader('Content-Type', 'text/html; charset=utf-8');
  res.setHeader('Cache-Control', 'no-store');
  res.status(status).end(`<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex"><title>${esc(title)} — Your Brand</title>
<style>body{margin:0;min-height:100vh;display:grid;place-items:center;background:#f4f5f7;font:400 16px/1.55 system-ui,-apple-system,Segoe UI,Roboto,sans-serif;color:#15171c}
main{background:#fff;border-radius:16px;padding:32px 28px;max-width:420px;width:calc(100% - 32px);box-shadow:0 8px 30px rgba(16,24,40,.08)}
h1{font-size:21px;margin:0 0 10px}p{margin:0 0 14px;color:#444}a.btn{display:block;text-align:center;background:#59ED05;color:#15171c;font-weight:700;text-decoration:none;border-radius:10px;padding:14px}</style>
</head><body><main><h1>${esc(title)}</h1>${body}<a class="btn" href="/">Back to Your Brand</a></main></body></html>`);
}

async function load(bookingId) {
  const rows = await select('bookings', `id=eq.${bookingId}&select=id,tenant_id,reference,status,total_kobo,` +
    'passengers(status,trip:trips(status,depart_date,depart_time)),payments(status,amount_kobo,channel)');
  const b = rows[0]; if (!b) return null;
  const legs = [...new Map(b.passengers.filter(x => x.trip).map(x => [`${x.trip.depart_date}${x.trip.depart_time}`,
    { date: x.trip.depart_date, time: String(x.trip.depart_time).slice(0, 5), status: x.trip.status }])).values()];
  return { b, legs };
}
const explain = q => q.band === 'unpaid' ? 'Nothing was paid, so there is nothing to refund. Your seats go back on sale.'
  : q.refundKobo > 0 ? `${naira(q.refundKobo)} will be refunded${q.band === 'fee' ? ` (what you paid less the ${q.feePct}% late-cancellation fee)` : ''}. Refunds go back the way you paid.`
  : 'It is now too close to departure for a refund under our policy, but the seats will be released.';

export default async function handler(req, res) {
  const secret = process.env.SESSION_SECRET;
  if (!secret || !configured()) return fail(res, 503, 'not_configured', 'Not switched on');
  const token = tokenOf(req);
  const claims = verify(token, secret);
  if (!claims || claims.kind !== 'cancel' || !claims.jti || !claims.booking)
    return page(res, 400, 'This link has expired', '<p>Cancellation links work once and for 30 minutes. Ask for a new one from Find my booking.</p>');

  try {
    const t = await tenant();
    const tok = (await select('login_tokens', `jti=eq.${claims.jti}&select=id,used_at,expires_at`))[0];
    if (!tok || tok.used_at || Date.parse(tok.expires_at) < Date.now())
      return page(res, 400, 'This link has already been used', '<p>If the booking still shows as active in Find my booking, ask for a new link.</p>');

    const got = await load(claims.booking);
    if (!got) return page(res, 404, 'Booking not found', '<p>Call the terminal with your reference.</p>');
    const { b, legs } = got;
    const q = cancellationQuote({ status: b.status, legs, passengers: b.passengers, payments: b.payments, settings: t.settings });
    if (!q.allowed) return page(res, 409, `Booking ${b.reference}`, `<p>${esc(q.reason)}</p>`);

    if (req.method !== 'POST') return confirmPage(res, { action: '/api/auth/cancel', token, danger: true,
      title: `Cancel booking ${b.reference}?`, detail: `${explain(q)} This cannot be undone.`, button: 'Cancel my booking' });

    const spent = await update('login_tokens', `id=eq.${tok.id}&used_at=is.null`, { used_at: new Date().toISOString() });
    if (!spent?.length) return page(res, 400, 'This link has already been used', '<p>Nothing more needs doing.</p>');

    const outcome = await rpc('customer_cancel', { p_booking: b.id, p_refund_kobo: q.refundKobo, p_reason: `Cancelled online by the customer (${q.band})` });
    if (outcome === 'already') return page(res, 200, `Booking ${b.reference}`, '<p>This booking was already cancelled.</p>');
    if (outcome !== 'cancelled') return page(res, 409, `Booking ${b.reference}`, '<p>This booking can no longer be cancelled online. Call the terminal.</p>');

    await audit({ tenant_id: t.id, actor_type: 'customer', action: 'booking.cancelled_online', entity: 'booking', entity_id: b.id,
      detail: { reference: b.reference, refund_kobo: q.refundKobo, band: q.band } });
    return page(res, 200, `Booking ${b.reference} is cancelled`,
      q.refundKobo > 0
        ? `<p>${naira(q.refundKobo)} is on its way back to you. Card refunds usually show within 5 to 10 working days, depending on your bank; transfers go back to the account that paid.</p>`
        : `<p>${q.band === 'unpaid' ? 'Nothing was paid, so there is nothing to refund.' : 'No refund is due under our policy.'} The seats have been released.</p>`);
  } catch (err) {
    console.error('cancel failed:', err.message);
    return page(res, 500, 'Something went wrong', '<p>Your booking has not been changed. Please try again, or call the terminal.</p>');
  }
}
