-- =====================================================================
-- Self-hosted video, for the test phase.
--
-- Private, unlike thumbnails and avatars. Course video sits behind the
-- module-one paywall, and a public bucket would mean anyone holding the
-- URL walks straight past it. Playback therefore goes through a signed
-- URL minted server-side, after the access check the learn page already
-- performs.
--
-- Supabase's free tier is roughly 1GB stored and 5GB egress a month —
-- enough for a handful of test lessons, not enough for a catalogue. The
-- resolver in lib/video.ts also accepts YouTube and Vimeo links, which
-- is the cheaper route while the library is still small.
-- =====================================================================

insert into storage.buckets (id, name, public, file_size_limit)
values ('videos', 'videos', false, 524288000)
on conflict (id) do nothing;

-- Instructors write into their own folder only.
create policy "instructors upload own video"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'videos' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "instructors replace own video"
  on storage.objects for update to authenticated
  using (bucket_id = 'videos' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "instructors remove own video"
  on storage.objects for delete to authenticated
  using (bucket_id = 'videos' and (storage.foldername(name))[1] = auth.uid()::text);

-- Deliberately no select policy for `authenticated`: reads happen with the
-- service role when signing a URL, so enrolment and payment are checked in
-- application code rather than being implied by being logged in.
