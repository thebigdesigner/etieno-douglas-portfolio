import type { IconName } from "@/components/NavIcon";

/**
 * The rails for every signed-in surface. (lib/nav.ts is the marketing header —
 * different thing, deliberately not merged.)
 *
 * These used to be written inline in each layout, which meant /studio and
 * /review carried two copies of the same rail, and they had already drifted
 * apart. A rail belongs to a surface, not to a route, so it lives here once
 * and every layout that opens that surface reads it.
 */

export type NavItem = {
  label: string;
  href: string;
  icon: IconName;
  badge?: number | string;
  /** Trailing affordance on the item — a shortcut, not a second nav link. */
  action?: { label: string; href: string; icon: IconName };
  /**
   * Views of the same destination, revealed when the parent is current.
   * Only for genuine sub-views: a child here means the same page filtered,
   * never a different page that happens to feel related.
   */
  children?: { label: string; href: string; icon: IconName }[];
};

export type NavGroup = {
  heading?: string;
  items: NavItem[];
};

/** Shared by /studio and /review — one surface, two entry points. */
export function studioNav(queue: number): NavGroup[] {
  return [
    // One entry, not two. Overview and Courses both pointed at /studio, so
    // the rail listed the same page twice and lit both of them up as
    // current. /studio is the course list with the queue and earnings on
    // top of it, and "Courses" is the truer name for that.
    { heading: "Teaching", items: [
      {
        label: "Courses", href: "/studio", icon: "book",
        action: { label: "New course", href: "/studio/new", icon: "plus" },
      },
      { label: "Review queue", href: "/review", icon: "inbox", badge: queue },
    ]},
    { heading: "Money", items: [
      { label: "Earnings", href: "/studio/earnings", icon: "wallet" },
    ]},
    { heading: "Help", items: [
      { label: "Making a course", href: "/studio/creator-course", icon: "play" },
      { label: "Guides", href: "/studio/help", icon: "help" },
    ]},
  ];
}

export function learnerNav(awaiting: number): NavGroup[] {
  return [
    // No heading on the first group: it is the surface you are already on,
    // so "Your dashboard" above the dashboard link was a label for nothing.
    { items: [
      // Was "Courses and certificates" — two lines inside the active pill,
      // and it named a destination that also exists two rows below it.
      { label: "Dashboard", href: "/dashboard", icon: "home" },
      {
        label: "My courses", href: "/dashboard/courses", icon: "book",
        // Real views of /dashboard/courses, not separate pages. They were
        // reachable only from the tab strip once you were already there,
        // and "Saved" was duplicated down in Discover as if it were a
        // different destination.
        children: [
          { label: "In progress", href: "/dashboard/courses", icon: "play" },
          { label: "Completed", href: "/dashboard/courses?view=completed", icon: "award" },
          { label: "Saved", href: "/dashboard/courses?view=saved", icon: "bookmark" },
        ],
      },
      { label: "Projects", href: "/dashboard/submissions", icon: "inbox", badge: awaiting },
      { label: "Certificates", href: "/dashboard/certificates", icon: "award" },
    ]},
    { heading: "Discover", items: [
      { label: "Browse courses", href: "/courses", icon: "search" },
      { label: "Cart", href: "/dashboard/cart", icon: "wallet" },
    ]},
    // Account is deliberately absent: it lives in the avatar menu now, and
    // a one-item group under a "You" heading spent a whole heading on it.
  ];
}

export function institutionNav(unverified: boolean): NavGroup[] {
  return [
    { items: [{ label: "Cohorts", href: "/institution", icon: "users" }] },
    { heading: "Teaching", items: [
      {
        label: "Your courses", href: "/institution/courses", icon: "book",
        action: { label: "Write a course", href: "/institution/courses/new", icon: "plus" },
      },
    ]},
    { heading: "Admin", items: [
      { label: "Course licences", href: "/institution/licences", icon: "cart" },
      { label: "Invoices", href: "/institution/invoices", icon: "receipt" },
      {
        label: "Verification", href: "/institution/verify", icon: "shield",
        badge: unverified ? "!" : undefined,
      },
    ]},
    { heading: "Browse", items: [
      { label: "Catalogue", href: "/courses", icon: "search" },
    ]},
  ];
}

export function operationsNav(counts: {
  breached: number; verifications: number; courses: number;
  applications: number; appeals: number;
}): NavGroup[] {
  return [
    { items: [
      { label: "Metrics", href: "/admin/metrics", icon: "chart" },
      { label: "SLA monitor", href: "/admin/sla", icon: "clock", badge: counts.breached },
    ]},
    { heading: "Queues", items: [
      { label: "Verification", href: "/admin/verification", icon: "shield", badge: counts.verifications },
      { label: "Courses", href: "/admin/courses", icon: "book", badge: counts.courses },
      { label: "Marketplace", href: "/admin/marketplace", icon: "list" },
      { label: "Creator withdrawals", href: "/admin/marketplace/payouts", icon: "coins" },
      { label: "Applications", href: "/admin/applications", icon: "list", badge: counts.applications },
      { label: "Appeals", href: "/admin/appeals", icon: "scales", badge: counts.appeals },
    ]},
    { heading: "Manage", items: [
      { label: "Instructors", href: "/admin/instructors", icon: "user" },
      { label: "Institutions", href: "/admin/institutions", icon: "building" },
      { label: "Pools and payouts", href: "/admin/payouts", icon: "coins" },
    ]},
    { heading: "Teaching", items: [
      {
        // /admin is the review queue: it decides on courses other people
        // wrote, and has no authoring of its own. That is the right split,
        // but an operator signs in straight into /admin, so with no link
        // out of it "Your Brand cannot create a course" was true of every
        // surface they could actually see. Same omission the console
        // carried until it gained the entry below.
        label: "Your courses", href: "/studio", icon: "book",
        action: { label: "Write a course", href: "/studio/new", icon: "plus" },
      },
    ]},
  ];
}

export function consoleNav(breached: number): NavGroup[] {
  return [
    { items: [
      { label: "Overview", href: "/console", icon: "home" },
    ]},
    { heading: "Business", items: [
      { label: "Money", href: "/console/money", icon: "wallet" },
      {
        label: "Catalogue", href: "/console/catalogue", icon: "book",
        // Writing a course was reachable only by knowing the studio URL.
        // It is the same editor either way — an operator creating one gets
        // the ownership choice, an instructor does not.
        action: { label: "Write a course", href: "/console/catalogue/new", icon: "plus" },
      },
      { label: "People", href: "/console/people", icon: "users" },
    ]},
    { heading: "Oversight", items: [
      { label: "Integrity", href: "/console/integrity", icon: "activity", badge: breached },
      { label: "Audit", href: "/console/audit", icon: "list" },
    ]},
    { heading: "Day to day", items: [
      { label: "Operations", href: "/admin/sla", icon: "clock" },
    ]},
  ];
}
