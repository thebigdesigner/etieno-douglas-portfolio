"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import type { FormState } from "@/lib/forms";

async function me() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  return user;
}

/* ------------------------------------------------------------------ */
/* Saved courses                                                       */
/* ------------------------------------------------------------------ */
export async function toggleSaved(slug: string): Promise<void> {
  const user = await me();
  if (!user) redirect(`/login?next=/courses/${slug}`);

  const admin = createAdminClient();
  const { data: course } = await admin
    .from("courses").select("id").eq("slug", slug).maybeSingle();
  if (!course) return;

  const { data: existing } = await admin
    .from("saved_courses").select("course_id")
    .eq("user_id", user.id).eq("course_id", course.id).maybeSingle();

  if (existing) {
    await admin.from("saved_courses")
      .delete().eq("user_id", user.id).eq("course_id", course.id);
  } else {
    await admin.from("saved_courses")
      .insert({ user_id: user.id, course_id: course.id });
  }

  revalidatePath(`/courses/${slug}`);
  revalidatePath("/dashboard/saved");
}

/* ------------------------------------------------------------------ */
/* Notes — private to the learner. Nobody assessing their project sees  */
/* these, and the interface says so.                                    */
/* ------------------------------------------------------------------ */
export async function saveNote(
  topicId: string, _prev: FormState, formData: FormData
): Promise<FormState> {
  const user = await me();
  if (!user) return { error: "You need to be signed in." };

  const body = String(formData.get("body") ?? "").trim();
  const admin = createAdminClient();

  if (!body) {
    await admin.from("topic_notes")
      .delete().eq("user_id", user.id).eq("topic_id", topicId);
    return { ok: true, message: "Note cleared." };
  }

  const { error } = await admin.from("topic_notes").upsert(
    { user_id: user.id, topic_id: topicId, body, updated_at: new Date().toISOString() },
    { onConflict: "user_id,topic_id" }
  );

  if (error) return { error: "Could not save that. Try again." };
  return { ok: true, message: "Saved." };
}

/* ------------------------------------------------------------------ */
/* Playback position                                                   */
/* ------------------------------------------------------------------ */
export async function savePosition(
  topicId: string, seconds: number, duration: number
): Promise<void> {
  const user = await me();
  if (!user) return;

  const admin = createAdminClient();
  await admin.rpc("save_position", {
    p_user_id: user.id,
    p_topic_id: topicId,
    p_seconds: Math.max(0, Math.floor(seconds)),
    p_duration: Math.max(0, Math.floor(duration)) || null,
  });
}
