"use client";

import { useEffect, useState } from "react";
import NavIcon from "@/components/NavIcon";

/**
 * Light / dark switch for the navigation.
 *
 * Scoped to the nav on purpose. The reference concept shows a sidebar in two
 * skins, not a whole application in two skins, and a half-themed app is worse
 * than a consistent one — so this writes data-nav on <html> and only the .nv
 * block reads it. Widening it later is a CSS job, not a component job.
 *
 * The preference is written before paint by the script in the layout, so the
 * panel never flashes light before switching.
 */
export const NAV_THEME_KEY = "splari-nav-theme";

export default function NavTheme() {
  const [dark, setDark] = useState(false);

  // Read on mount rather than during render: the server has no idea what the
  // browser preference is, and guessing produces a hydration mismatch.
  useEffect(() => {
    setDark(document.documentElement.dataset.nav === "dark");
  }, []);

  const flip = () => {
    const next = !dark;
    setDark(next);
    document.documentElement.dataset.nav = next ? "dark" : "light";
    try {
      window.localStorage.setItem(NAV_THEME_KEY, next ? "dark" : "light");
    } catch {
      // Private browsing refuses storage. The switch still works for this
      // session; it just will not be remembered.
    }
  };

  return (
    <button
      type="button"
      className="nv__theme"
      onClick={flip}
      aria-pressed={dark}
      title={dark ? "Switch to light navigation" : "Switch to dark navigation"}
    >
      <span className="nv__themelab">{dark ? "Dark" : "Light"}</span>
      <span className="nv__switch" aria-hidden="true">
        <span className="nv__knob">
          <NavIcon name={dark ? "moon" : "sun"} size={11} />
        </span>
      </span>
      <span className="sr">
        {dark ? "Switch to light navigation" : "Switch to dark navigation"}
      </span>
    </button>
  );
}
