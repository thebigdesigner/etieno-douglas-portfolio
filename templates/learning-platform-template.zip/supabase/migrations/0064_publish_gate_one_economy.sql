-- =====================================================================
-- 0064 — the publish gate catches up with 0063
--
-- Two holes, both in submit_course_for_review, and both the same shape:
-- a course can go live that nobody can pay for.
--
-- 1. The price check only applied to instructor-owned courses.
--
--    That was right when it was written. A Your Brand-authored course was
--    covered by the subscription and correctly carried no price — the
--    null WAS the answer to "how does somebody get this". 0063 removed
--    the subscription, so a Your Brand course is now bought or free like any
--    other, and a null price means nobody can reach it.
--
--    Left alone, a Your Brand-authored course with no price and is_free
--    false passes the gate, publishes, appears in the catalogue, and
--    returns `unpriced` from course_entitlement to every learner who
--    opens it. That reason exists as an honest failure state, not as
--    something reachable by pressing Publish.
--
--    The check is now about the course rather than its owner: not free,
--    no price, no publish. Whoever wrote it.
--
-- 2. min_course_price_cents() has never been called by anything.
--
--    0030 defined it — $30 — and explained exactly why it matters: the
--    assessment inside every sale costs $18.85 to pay for, so a course
--    priced under that loses money on every certificate it issues. Then
--    nothing ever read it. An author could set $5, publish, and each
--    sale would owe a reviewer nearly four times what came in.
--
--    Enforced here, at the only moment it can be: before the course is
--    live and anybody has bought it.
--
-- Restated in full — create or replace cannot patch a body.
-- =====================================================================

create or replace function public.submit_course_for_review(p_course_id uuid, p_instructor_id uuid)
returns table (ok boolean, reason text)
language plpgsql security definer set search_path = public as $$
declare
  v_course courses%rowtype;
  v_topics int; v_criteria int; v_quiz int; v_empty int; v_exam int;
begin
  select * into v_course from courses where id = p_course_id and instructor_id = p_instructor_id;
  if not found then
    return query select false, 'not_yours'; return;
  end if;

  if v_course.state not in ('draft','revision_requested') then
    return query select false, 'wrong_state'; return;
  end if;

  if v_course.thumbnail_path is null then
    return query select false, 'no_thumbnail'; return;
  end if;
  if v_course.hours_low is null or v_course.hours_high is null then
    return query select false, 'no_hours'; return;
  end if;

  -- How is somebody meant to get this? Free, or bought. There is no third
  -- answer since 0063, and the owner no longer changes it: a Your Brand course
  -- with no price is as unreachable as an instructor's.
  if not v_course.is_free and v_course.price_cents is null then
    return query select false, 'no_price'; return;
  end if;

  -- A sale has to cover the assessment it promises. Below the floor every
  -- certificate issued costs more to review than the course brought in.
  if not v_course.is_free
     and v_course.price_cents < min_course_price_cents() then
    return query select false, 'price_below_minimum'; return;
  end if;

  -- Live topics only, so archiving cannot take a published course below the
  -- minimum it had to clear to get there.
  v_topics := live_topic_count(p_course_id);
  if v_topics < 3 then return query select false, 'too_few_topics'; return; end if;

  select count(*) into v_empty
    from topics t join modules m on m.id = t.module_id
   where m.course_id = p_course_id
     and m.archived_at is null and t.archived_at is null
     and coalesce(length(trim(t.body)), 0) < 40
     and not exists (select 1 from topic_materials tm where tm.topic_id = t.id);
  if v_empty > 0 then return query select false, 'empty_topics'; return; end if;

  select count(*) into v_quiz
    from quiz_items q join topics t on t.id = q.topic_id
    join modules m on m.id = t.module_id
   where m.course_id = p_course_id
     and m.archived_at is null and t.archived_at is null;
  if v_quiz < 3 then return query select false, 'too_few_questions'; return; end if;

  -- Five is a low bar deliberately: enough that 80% means four out of five,
  -- without asking for an exam paper before a first course can ship.
  select count(*) into v_exam from exam_items where course_id = p_course_id;
  if v_exam < 5 then return query select false, 'too_few_exam_questions'; return; end if;

  -- Only where there is a project to assess.
  if v_course.requires_project then
    if coalesce(length(trim(v_course.project_brief)), 0) < 120 then
      return query select false, 'brief_too_short'; return;
    end if;

    select count(*) into v_criteria from rubric_criteria where course_id = p_course_id;
    if v_criteria < 2 then return query select false, 'rubric_too_thin'; return; end if;
  end if;

  update courses set state = 'in_review' where id = p_course_id;
  return query select true, null::text;
end; $$;

comment on function public.submit_course_for_review(uuid, uuid) is
  'The publish gate. Every condition here is one a learner would otherwise meet as a broken page. Since 0064 the price checks apply to every owner_kind, because 0063 made the catalogue one economy.';
