-- =====================================================================
-- 0060 — an erased account must not block a new one
--
-- Reported: somebody deleted their account, the erasure was completed,
-- and signing up again with the same details still says the account is
-- suspended.
--
-- Two causes, and the second is the one that bites.
--
-- 1. The sign-in address was released from the application, after the
--    database work, with an auth admin call that could fail on its own.
--    eraseAccount reports that case — "the sign-in address could not be
--    cleared" — but by then the erasure is already recorded as complete,
--    so a failure leaves the address permanently taken with nothing
--    tracking it. Moved into the function, where it happens or the whole
--    erasure rolls back.
--
-- 2. auth.identities was never touched, and for a Google or LinkedIn
--    account that is the thing that matters. GoTrue matches an OAuth
--    sign-in on the provider identity, not on the email — so tombstoning
--    the address changes nothing. The same Google account resolves to
--    the old auth.users row, the app reads a profile with status
--    'deleted', and refuses. The person is told their account is
--    suspended while looking at a brand new signup form, which is both
--    wrong and impossible to act on.
--
-- Deleting the identity rows is what frees an OAuth signup. The
-- auth.users row itself still cannot go: profiles.id references it on
-- delete cascade, and that cascade is what 0053 exists to prevent.
--
-- ---------------------------------------------------------------------
-- Repair
-- ---------------------------------------------------------------------
-- release_erased_identities() does the same for accounts erased before
-- this migration. It is safe to run repeatedly and only ever touches
-- profiles already at status 'deleted'.
-- =====================================================================

create or replace function public.release_sign_in(p_user_id uuid)
returns void
language plpgsql security definer set search_path = public, auth as $$
begin
  -- Nothing to sign in with, nothing to reset, no address left.
  update auth.users
     set email = 'deleted-' || p_user_id::text || '@splari.invalid',
         raw_user_meta_data = '{}'::jsonb
   where id = p_user_id;

  -- And nothing for an OAuth provider to match against, which is what
  -- actually frees a Google or LinkedIn signup.
  delete from auth.identities where user_id = p_user_id;
end; $$;

revoke all on function public.release_sign_in(uuid) from public, anon, authenticated;
grant execute on function public.release_sign_in(uuid) to service_role;

-- Fold it into erasure so it cannot be half-done.
create or replace function public.erase_account(p_user_id uuid, p_actor uuid)
returns table (ok boolean, reason text)
language plpgsql security definer set search_path = public as $$
declare
  v_blocking int;
  v_course   record;
begin
  if not exists (select 1 from profiles where id = p_user_id) then
    return query select false, 'no_account'; return;
  end if;

  select count(*) into v_blocking
    from courses c
   where c.instructor_id = p_user_id
     and c.owner_kind <> 'instructor'::course_owner_kind
     and c.state in ('published', 'in_review');

  if v_blocking > 0 then
    return query select false, 'assessor_on_other_courses'; return;
  end if;

  for v_course in
    select id from courses
     where instructor_id = p_user_id
       and owner_kind = 'instructor'::course_owner_kind
       and state = 'published'
  loop
    perform retire_course(v_course.id, p_actor);
  end loop;

  update instructors set state = 'suspended', accepts_reviews = false, available = false
   where id = p_user_id;

  update profiles set
    display_name       = 'Deleted account',
    email              = null,
    date_of_birth      = null,
    guardian_email     = null,
    segment            = null,
    avatar_path        = null,
    avatar_alt         = null,
    marketing_opt_in   = false,
    status             = 'deleted'
  where id = p_user_id;

  update certificates c set show_name = false
    from enrolments e
   where e.id = c.enrolment_id and e.user_id = p_user_id;

  update submissions s set body = null, file_paths = '{}'
    from enrolments e
   where e.id = s.enrolment_id and e.user_id = p_user_id;

  delete from topic_notes where user_id = p_user_id;
  delete from assistant_turns t using assistant_threads th
   where th.id = t.thread_id and th.user_id = p_user_id;
  delete from assistant_threads where user_id = p_user_id;
  delete from assistant_usage where bucket_key = 'user:' || p_user_id::text;
  delete from saved_courses where user_id = p_user_id;
  delete from dismissed_suggestions where user_id = p_user_id;
  delete from cart_items where user_id = p_user_id;

  update events set user_id = null where user_id = p_user_id;
  update cohort_seats set user_id = null where user_id = p_user_id;

  -- Inside the transaction now. If this cannot happen, neither does the
  -- erasure, rather than the erasure completing and the address staying
  -- taken with nothing recording it.
  perform release_sign_in(p_user_id);

  update deletion_requests
     set state = 'completed', completed_at = now(), completed_by = p_actor
   where user_id = p_user_id and state = 'pending';

  perform log_admin_action(p_actor, 'erase_account', 'profile', p_user_id::text,
                           'Erasure completed; records anonymised, sign-in released', null);

  return query select true, null::text;
end; $$;

-- ---------------------------------------------------------------------
-- Repair for anyone erased before this.
-- ---------------------------------------------------------------------
create or replace function public.release_erased_identities()
returns table (released int)
language plpgsql security definer set search_path = public, auth as $$
declare v_count int := 0; v_id uuid;
begin
  for v_id in
    select p.id from profiles p
     join auth.users u on u.id = p.id
    where p.status = 'deleted'
      and (u.email not like 'deleted-%@splari.invalid'
           or exists (select 1 from auth.identities i where i.user_id = p.id))
  loop
    perform release_sign_in(v_id);
    v_count := v_count + 1;
  end loop;
  return query select v_count;
end; $$;

revoke all on function public.release_erased_identities() from public, anon, authenticated;
grant execute on function public.release_erased_identities() to service_role;
