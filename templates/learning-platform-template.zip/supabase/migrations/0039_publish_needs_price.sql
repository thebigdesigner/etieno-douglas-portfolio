-- =====================================================================
-- 0039 — a course cannot go live unpayable
--
-- Two holes in submit_course_for_review, both from changes made after it
-- was written:
--
--   · It never checks how a learner is meant to pay. An instructor course
--     with no price and no free flag publishes happily, appears in the
--     catalogue, and gives every learner who opens it needs_purchase with
--     a price of null. Nobody can buy it and nobody can read it.
--
--   · It counts topics directly rather than through live_topic_count(),
--     which 0033 added and nothing ever used. So a course can publish
--     with three topics and then archive two of them and stay live, below
--     a minimum the gate exists to enforce.
--
-- Restated in full: create or replace cannot patch a body.
-- =====================================================================
create or replace function public.submit_course_for_review(p_course_id uuid, p_instructor_id uuid)
returns table (ok boolean, reason text)
language plpgsql security definer set search_path = public as $$
declare
  v_course courses%rowtype;
  v_topics int; v_criteria int; v_quiz int; v_empty int; v_exam int;
begin
  select * into v_course from courses where id = p_course_id and instructor_id = p_instructor_id;
  if not found then
    return query select false, 'not_yours'; return;
  end if;

  if v_course.state not in ('draft','revision_requested') then
    return query select false, 'wrong_state'; return;
  end if;

  if v_course.thumbnail_path is null then
    return query select false, 'no_thumbnail'; return;
  end if;
  if v_course.hours_low is null or v_course.hours_high is null then
    return query select false, 'no_hours'; return;
  end if;

  -- How is somebody meant to get this? Free, covered by a plan, or bought.
  -- A priced instructor course is fine, a free one is fine, and one that is
  -- neither is a course nobody can reach.
  if v_course.owner_kind = 'instructor'
     and not v_course.is_free
     and v_course.price_cents is null then
    return query select false, 'no_price'; return;
  end if;

  -- Live topics only, so archiving cannot take a published course below the
  -- minimum it had to clear to get there.
  v_topics := live_topic_count(p_course_id);
  if v_topics < 3 then return query select false, 'too_few_topics'; return; end if;

  select count(*) into v_empty
    from topics t join modules m on m.id = t.module_id
   where m.course_id = p_course_id
     and m.archived_at is null and t.archived_at is null
     and coalesce(length(trim(t.body)), 0) < 40
     and not exists (select 1 from topic_materials tm where tm.topic_id = t.id);
  if v_empty > 0 then return query select false, 'empty_topics'; return; end if;

  select count(*) into v_quiz
    from quiz_items q join topics t on t.id = q.topic_id
    join modules m on m.id = t.module_id
   where m.course_id = p_course_id
     and m.archived_at is null and t.archived_at is null;
  if v_quiz < 3 then return query select false, 'too_few_questions'; return; end if;

  -- Five is a low bar deliberately: enough that 80% means four out of five,
  -- without asking for an exam paper before a first course can ship.
  select count(*) into v_exam from exam_items where course_id = p_course_id;
  if v_exam < 5 then return query select false, 'too_few_exam_questions'; return; end if;

  -- Only where there is a project to assess.
  if v_course.requires_project then
    if coalesce(length(trim(v_course.project_brief)), 0) < 120 then
      return query select false, 'brief_too_short'; return;
    end if;

    select count(*) into v_criteria from rubric_criteria where course_id = p_course_id;
    if v_criteria < 2 then return query select false, 'rubric_too_thin'; return; end if;
  end if;

  update courses set state = 'in_review' where id = p_course_id;
  return query select true, null::text;
end; $$;
