-- =====================================================================
-- 0046 — a reassignment cannot cross an institution's wall
--
-- reassign_to_reserve moved a submission to any id it was handed, and
-- the SLA monitor offered every active practitioner as a reserve. That
-- was safe while every course was Your Brand's or a practitioner's. Since
-- 0041 an institution writes private courses, and since 0042 a member
-- of that organisation assesses them — so a breached institution
-- submission could be reassigned to an unrelated practitioner, which
-- hands a stranger a learner's private work and puts their name on
-- the organisation's certificate.
--
-- Two changes:
--
--   · reassign_to_reserve refuses a reserve who is not eligible for
--     that particular course. Enforced here rather than only in the
--     picker, because the picker is a list in a form and the id in it
--     is client-supplied.
--
--   · review_queue_status carries owner_kind and institution_id, so
--     the monitor can offer the right reserves per row instead of one
--     platform-wide list. Columns appended; existing order preserved.
-- =====================================================================

create or replace function public.reassign_to_reserve(p_submission_id uuid, p_reserve_id uuid)
returns boolean
language plpgsql security definer set search_path = public as $$
declare
  v_course courses%rowtype;
  v_ok     boolean;
begin
  select c.* into v_course
    from submissions s
    join enrolments e on e.id = s.enrolment_id
    join courses    c on c.id = e.course_id
   where s.id = p_submission_id;

  if not found then return false; end if;

  -- Who may take this course's work. An institution course stays inside
  -- the organisation; anything else may go to any eligible assessor.
  if v_course.owner_kind = 'institution' then
    select exists (
      select 1 from institution_members m
       where m.user_id = p_reserve_id
         and m.institution_id = v_course.institution_id
    ) into v_ok;
  else
    select exists (
      select 1 from eligible_assessors() a where a.id = p_reserve_id
    ) into v_ok;
  end if;

  if not v_ok then return false; end if;

  update submissions
     set assigned_reviewer_id = p_reserve_id,
         reassigned_at = now(),
         state = 'assigned'
   where id = p_submission_id
     and state in ('submitted','assigned','in_review');
  return found;
end; $$;

revoke all on function public.reassign_to_reserve(uuid, uuid) from public, anon, authenticated;
grant execute on function public.reassign_to_reserve(uuid, uuid) to service_role;

-- Existing column order preserved exactly; the two new columns appended.
create or replace view public.review_queue_status as
 SELECT s.id AS submission_id,
    s.state,
    s.submitted_at,
    s.deadline_at,
    s.assigned_reviewer_id,
    s.escalated_at,
    c.title AS course_title,
    p.display_name AS learner_name,
    (now() > s.deadline_at) AS breached,
    (now() > (s.deadline_at - '1 day'::interval)) AS due_soon,
    c.owner_kind,
    c.institution_id
   FROM (((submissions s
     JOIN enrolments e ON ((e.id = s.enrolment_id)))
     JOIN courses c ON ((c.id = e.course_id)))
     JOIN profiles p ON ((p.id = e.user_id)))
  WHERE (s.state = ANY (ARRAY['submitted'::submission_state, 'assigned'::submission_state, 'in_review'::submission_state]));
