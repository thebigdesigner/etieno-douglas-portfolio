import { NextResponse, type NextRequest } from "next/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { createClient } from "@/lib/supabase/server";
import { askModel, configuredProvider } from "@/lib/llm";

export const dynamic = "force-dynamic";
export const maxDuration = 30;

const HOURLY_LIMIT_ANON = 12;
const HOURLY_LIMIT_USER = 40;
const MAX_QUESTION = 500;

type Course = {
  slug: string; title: string; summary: string | null;
  subject: string; is_free: boolean; topics: string | null;
};

type LessonContext = {
  course_title: string; course_slug: string; module_title: string;
  topic_title: string; topic_body: string | null; transcript: string | null;
  project_brief: string | null; rubric: string | null;
};

/**
 * The system prompt is deliberately narrow. This assistant answers about the
 * catalogue and helps somebody find the right course. It does not write course
 * descriptions, module titles or rubrics — the whole credential rests on a
 * practitioner having written those.
 */
/**
 * What the assistant may say to a signed-in person, by role.
 *
 * Role comes from the session on the server, never from the request body —
 * otherwise anyone could ask for the instructor guidance by sending a string.
 * None of these relax the authoring rule below: the assistant explains how a
 * rubric works, it does not write one.
 */
const ROLE_NOTES: Record<string, string> = {
  learner:
    "They are a signed-in learner. You may explain how quizzes, projects, resubmissions and appeals work, and help them pick what to do next. You must not answer quiz questions or do any part of a project for them — the certificate says they did the work.",
  instructor:
    "They are an instructor. You may explain how course review, the review queue, SLAs, earnings, the pool and payouts work. You must not write course descriptions, module titles, project briefs, rubrics or learner feedback — those are what the certificate certifies, so they have to be theirs.",
  institution_admin:
    "They run an organisation. You may explain cohorts, class codes, seats, usernames and PINs, active-learner billing and verification. You must not disclose anything about a specific learner or cohort — you cannot see their data.",
  operator:
    "They are Your Brand staff. You may explain how the queues and admin surfaces work. You still cannot see any account's data.",
};

function systemPrompt(
  courses: Course[], roleNote?: string, path?: string, lesson?: LessonContext,
) {
  const catalogue = courses
    .map((c) =>
      `- ${c.title} (/courses/${c.slug})\n  Subject: ${c.subject}` +
      `${c.is_free ? " · Free" : ""}\n  ${c.summary ?? ""}` +
      `${c.topics ? `\n  Covers: ${c.topics}` : ""}`
    )
    .join("\n\n");

  return `You are Sara, Your Brand's AI assistant. You help people find the right course and answer questions about how Your Brand works. You are free to use and you are talking to somebody who may know nothing about the platform.

You are an AI, and you say so plainly if anyone asks or seems to assume otherwise. This matters more here than on most products: Your Brand's whole promise is that a human practitioner assesses the final project, so never let anyone come away thinking you are the one who marks their work, or that you are a person.

How Your Brand works, so you can answer accurately:
- Courses are bought one at a time, not by subscription. There is no plan, no renewal date and nothing to cancel. Prices are set by the practitioner who wrote the course, start at $30 and are shown in US dollars. Some courses are free.
- The price of a course includes one assessment of the final project. Nothing further is charged when a learner submits.
- The first topic of every course is free without an account. On a course that is for sale the wall comes at that point; on a free course there is no wall at all.
- Topic quizzes are marked automatically and need 80% to move on. Retakes are unlimited, with a 30-minute pause after two failures in a row.
- The final project is assessed by a working practitioner within four working days, against a rubric published before the learner starts. They get written feedback either way.
- A "changes needed" verdict comes with one free resubmission. A learner can appeal once, and a second reviewer reads it without seeing the first verdict.
- Certificates name the practitioner who assessed the work and can be verified by anyone with a code.
- Organisations enrol groups with a code and issued usernames — learners need no email address. They licence a course once for the whole cohort rather than paying per learner. A cohort learner cannot buy anything themselves; an unlicensed course is something their teacher or administrator has to arrange.
- Anyone can build a course. It is reviewed before publishing.
- Your Brand is for learners aged 18 and over.

The catalogue, which is the only content you may recommend:

${catalogue || "No courses are published yet."}

Rules:
- Recommend only courses in the list above. Never invent a course, a price, or a policy.
- Link courses as /courses/slug so they are clickable.
- If nothing in the catalogue fits what they want, say so plainly and suggest the nearest thing, or tell them it is not covered yet. Do not stretch.
- If you do not know, say you do not know and point them at hello@yourbrand.com.
- Do not write course descriptions, module titles, project briefs or rubrics. If asked, explain that those have to be written by the practitioner teaching the course, because that is what the certificate certifies.
- Keep answers short. Two or three sentences unless they ask for detail.
- Never claim a certificate is a licence or a state qualification.
- You cannot see anyone's account, progress, submissions, invoices or roster. If asked about their own data, say so and point them at the page that shows it.${roleNote ? `

Who you are talking to:
${roleNote}` : ""}${path ? `
They are currently on ${path}. Use that only to make an answer more relevant — do not comment on it unprompted.` : ""}${lesson ? `

THE LESSON THEY ARE READING RIGHT NOW

They are entitled to this course — that was checked in the database before
you were given any of it. You may quote, summarise and explain everything
below freely.

Course: ${lesson.course_title}
Module: ${lesson.module_title}
Topic: ${lesson.topic_title}

${lesson.topic_body ?? ""}
${lesson.transcript ? `
Transcript of the video on this topic:
${lesson.transcript}` : ""}
${lesson.project_brief ? `
The project for this course:
${lesson.project_brief}` : ""}
${lesson.rubric ? `
The rubric it will be assessed against:
${lesson.rubric}` : ""}

How to teach from it:
- Summarise it, break it into steps, or re-explain a part they name. Use the
  words above rather than general knowledge, so what you say matches what
  the practitioner actually wrote.
- Offer an example or an analogy of your own when it would help. Say plainly
  when you are going beyond the lesson, so they can tell the two apart.
- Answer follow-up questions on the same subject even where the topic does
  not cover them. Say which part came from the lesson and which did not.
- Quiz them if they ask: make up your own practice questions from the
  material. Never reproduce the real quiz or exam questions — you have not
  been given them, and you have not been given the answers either.
- If they ask what the quiz or exam answer is, tell them you do not have it
  and would not give it if you did, then offer to explain the concept until
  they can work it out. That is not you being unhelpful — an examined
  certificate is worthless if the exam was answered by an AI.
- Explain what the project is asking for, what the rubric rewards, and how
  to read a criterion. Do not draft, outline, structure or write any part of
  their submission, and do not review a draft they paste. A practitioner
  signs that certificate on the understanding the work is theirs.
- Keep it short unless they ask for depth. A summary is a few sentences, not
  a re-run of the topic.` : ""}`;
}

export async function POST(request: NextRequest) {
  if (!configuredProvider()) {
    return NextResponse.json(
      { error: "The assistant is not configured yet." },
      { status: 503 }
    );
  }

  let body: { question?: string; sessionId?: string; history?: unknown; path?: string };
  try {
    body = await request.json();
  } catch {
    return NextResponse.json({ error: "Bad request." }, { status: 400 });
  }

  const question = String(body.question ?? "").trim();
  const sessionId = String(body.sessionId ?? "").slice(0, 64);

  if (!question) return NextResponse.json({ error: "Ask a question." }, { status: 400 });
  if (question.length > MAX_QUESTION) {
    return NextResponse.json({ error: "That is a long one — can you shorten it?" }, { status: 400 });
  }

  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  // Only ever an in-app path, and only for context — never echoed back.
  const rawPath = String(body.path ?? "");
  const path = /^\/[A-Za-z0-9/_-]{0,80}$/.test(rawPath) ? rawPath : undefined;

  // The endpoint is open, so it is rate limited by identity or address.
  const ip = request.headers.get("x-forwarded-for")?.split(",")[0]?.trim() ?? "unknown";
  const bucket = user ? `user:${user.id}` : `ip:${ip}`;
  const limit = user ? HOURLY_LIMIT_USER : HOURLY_LIMIT_ANON;

  const admin = createAdminClient();
  const { data: allowed } = await admin.rpc("assistant_allow", {
    p_key: bucket, p_limit: limit,
  });

  if (!allowed) {
    return NextResponse.json(
      {
        error: user
          ? "You have asked a lot this hour. Try again shortly."
          : "That is the limit for now. Create an account and you get more.",
        rateLimited: true,
      },
      { status: 429 }
    );
  }

  const { data: courses } = await admin.rpc("assistant_catalogue");
  const catalogue = (courses ?? []) as Course[];

  /* Lesson context, when they are reading one.
   *
   * The topic id comes out of the path, which is client-supplied, so it
   * decides nothing on its own — assistant_topic_context asks
   * course_entitlement for this user and returns nothing when the answer
   * is no. Asking Sara to summarise a topic is therefore not a way around
   * the paywall or an institution's wall.
   *
   * It also cannot return quiz or exam answers: 0044 keeps the key
   * server-side and 0051 does not select it. */
  let lesson: LessonContext | undefined;
  if (user && path) {
    const topicId = path.match(
      /^\/learn\/[^/]+\/([0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12})$/i
    )?.[1];
    if (topicId) {
      const { data: ctx } = await admin.rpc("assistant_topic_context", {
        p_user_id: user.id, p_topic_id: topicId,
      });
      lesson = (ctx ?? [])[0] as LessonContext | undefined;
    }
  }

  let roleNote: string | undefined;
  if (user) {
    const { data: profile } = await admin
      .from("profiles").select("role").eq("id", user.id).maybeSingle();
    roleNote = profile?.role ? ROLE_NOTES[profile.role] : undefined;
  }

  const history = Array.isArray(body.history)
    ? (body.history as { role: string; content: string }[])
        .filter((m) => m.role === "user" || m.role === "assistant")
        .slice(-6)
        .map((m) => ({ role: m.role as "user" | "assistant", content: String(m.content).slice(0, 2000) }))
    : [];

  let answer: string;
  let outputTokens: number | null = null;

  try {
    const result = await askModel({
      system: systemPrompt(catalogue, roleNote, user ? path : undefined, lesson),
      history,
      question,
    });
    answer = result.text;
    outputTokens = result.outputTokens;

    // An empty completion is a real outcome — a safety filter or a hit
    // token ceiling — and shipping a blank bubble looks like a crash.
    if (!answer) {
      return NextResponse.json(
        { error: "No answer came back for that one. Try rephrasing it?" },
        { status: 502 }
      );
    }
  } catch (err) {
    const status = (err as { status?: number }).status;
    console.error("assistant failed", err);

    // The free tier has a daily cap. Saying so is more useful than
    // "something went wrong", which invites a retry that also fails.
    if (status === 429) {
      return NextResponse.json(
        { error: "Sara has hit her limit for today. She will be back tomorrow." },
        { status: 429 }
      );
    }
    return NextResponse.json(
      { error: "The assistant is having a moment. Try again shortly." },
      { status: 502 }
    );
  }

  // Which courses the answer actually pointed at, for measuring whether
  // the assistant routes people anywhere useful.
  const cited = catalogue
    .filter((c) => answer.includes(`/courses/${c.slug}`))
    .map((c) => c.slug);

  // Logged for improving the answers, not for profiling anyone. Wrapped
  // separately from the model call: the answer is already paid for, so a
  // failed insert must not turn a good reply into a 500.
  if (sessionId) {
    try {
      const { data: thread } = await admin
        .from("assistant_threads")
        .upsert(
          { session_id: sessionId, user_id: user?.id ?? null },
          { onConflict: "session_id", ignoreDuplicates: false }
        )
        .select("id")
        .maybeSingle();

      if (thread) {
        await admin.from("assistant_turns").insert([
          { thread_id: thread.id, role: "user", content: question },
          {
            thread_id: thread.id, role: "assistant", content: answer,
            cited, tokens: outputTokens,
          },
        ]);
      }
    } catch (err) {
      console.error("assistant logging failed", err);
    }
  }

  return NextResponse.json({ answer, cited });
}
