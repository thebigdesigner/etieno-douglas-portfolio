import Link from "next/link";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { slaLabel } from "@/lib/sla";
import AppealForm from "./AppealForm";

export const metadata = { title: "Your projects" };
export const dynamic = "force-dynamic";

export default async function SubmissionsPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  const admin = createAdminClient();

  const { data: enrolments } = await admin
    .from("enrolments").select("id, course_id, courses(slug, title)").eq("user_id", user!.id);

  const rows = enrolments ?? [];
  const ids = rows.map((e) => e.id);

  const { data: subs } = ids.length
    ? await admin.from("submissions")
        .select("id, enrolment_id, state, attempt_no, submitted_at, deadline_at")
        .in("enrolment_id", ids)
        .order("submitted_at", { ascending: false })
    : { data: [] };

  const subIds = (subs ?? []).map((s) => s.id);

  const { data: reviews } = subIds.length
    ? await admin.from("reviews")
        .select("submission_id, outcome, feedback, completed_at, reviewer_id")
        .in("submission_id", subIds)
        .order("completed_at", { ascending: false })
    : { data: [] };

  const { data: appeals } = subIds.length
    ? await admin.from("appeals").select("submission_id, outcome, resolved_at").in("submission_id", subIds)
    : { data: [] };

  const reviewerIds = [...new Set((reviews ?? []).map((r) => r.reviewer_id))];
  const { data: reviewers } = reviewerIds.length
    ? await admin.from("profiles").select("id, display_name").in("id", reviewerIds)
    : { data: [] };

  const nameOf = (id: string) =>
    (reviewers ?? []).find((r) => r.id === id)?.display_name ?? "Your reviewer";

  if (!subs || subs.length === 0) {
    return (
      <div className="empty" style={{ marginTop: 30 }}>
        <p className="empty__h">No projects submitted yet</p>
        <p className="empty__p">
          Finish every topic in a course and the final project opens. A working
          practitioner assesses it within four working days.
        </p>
        <Link className="btn btn--fill btn--lg" href="/dashboard" style={{ marginTop: 20 }}>
          See your courses
        </Link>
      </div>
    );
  }

  return (
    <div className="subs" style={{ marginTop: 30 }}>
      {subs.map((s) => {
        const e = rows.find((r) => r.id === s.enrolment_id);
        const course = e?.courses as unknown as { slug: string; title: string } | null;
        const review = (reviews ?? []).find((r) => r.submission_id === s.id);
        const appeal = (appeals ?? []).find((a) => a.submission_id === s.id);
        const pending = ["submitted", "assigned", "in_review"].includes(s.state);

        return (
          <article key={s.id} className={`subcard${s.state === "passed" ? " is-passed" : ""}`}>
            <header className="subcard__head">
              <div>
                <div className="subcard__course">{course?.title}</div>
                <div className="subcard__meta num">
                  Submitted {new Date(s.submitted_at).toLocaleDateString()}
                  {s.attempt_no > 1 && ` · attempt ${s.attempt_no}`}
                </div>
              </div>
              <span className={
                s.state === "passed" ? "pill pill--free"
                : pending ? "pill"
                : "pill pill--lock"
              }>
                {s.state === "passed" ? "Passed"
                  : pending ? "Being assessed"
                  : "Changes asked for"}
              </span>
            </header>

            {pending && (
              <p className="subcard__wait">
                A practitioner is reading it now. You will hear back{" "}
                <strong>
                  {new Date(s.deadline_at).toLocaleDateString(undefined, {
                    weekday: "long", day: "numeric", month: "long",
                  })}
                </strong>{" "}
                at the latest — {slaLabel(s.deadline_at)}.
              </p>
            )}

            {review && (
              <>
                <div className="subcard__from">
                  <span className="eyebrow">Feedback from {nameOf(review.reviewer_id)}</span>
                  <span className="subcard__on num">
                    {new Date(review.completed_at).toLocaleDateString()}
                  </span>
                </div>
                <div className="subcard__fb">{review.feedback}</div>
              </>
            )}

            {s.state === "revision_requested" && (
              <div className="subcard__actions">
                <Link className="btn btn--fill" href={`/courses/${course?.slug}/submit`}>
                  {s.attempt_no === 1 ? "Send a revised version — free" : "Send a revised version"}
                </Link>
                {!appeal && <AppealForm submissionId={s.id} />}
                {appeal && (
                  <p className="subcard__appealed">
                    {appeal.resolved_at
                      ? `Appeal reviewed — ${appeal.outcome === "pass" ? "overturned, you passed" : "the original verdict stands"}`
                      : "Your appeal is with a second reviewer."}
                  </p>
                )}
              </div>
            )}

            {s.state === "passed" && (
              <div className="subcard__actions">
                <Link className="btn btn--line" href="/dashboard/certificates">
                  See your certificate
                </Link>
              </div>
            )}
          </article>
        );
      })}
    </div>
  );
}
