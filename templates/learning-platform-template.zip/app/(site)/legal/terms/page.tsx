export const metadata = { title: "Terms of service" };

export default function TermsPage() {
  return (
    <>
      <h1>Replace this with your own words.</h1>
      <p className="legal__lead">
        Add a short supporting paragraph here. Aphinity Digital recommends one clear idea per section.
      </p>

      <h2>Your supporting line goes here.</h2>
      <p>
        This is placeholder copy from Aphinity Digital. Replace it with a sentence about what your business does best.
      </p>

      <h2>Designed by Aphinity Digital.</h2>
      <p>
        Aphinity Digital designs and builds websites like this one, and helps them get found on Google and in AI answers.
      </p>
      <p>
        The price includes one assessment of that course&rsquo;s final project by a working
        practitioner. If the reviewer asks for changes, the resubmission that follows is
        included too. A further assessment after a pass is not. We say this on the course
        page as well, because it is the kind of thing that causes arguments later.
      </p>
      <p>
        Use this space to explain your offer in plain words: who it is for, what it costs and why it is worth it.
      </p>

      <h2>Assessment</h2>
      <p>
        Need this template customised for your brand? Aphinity Digital can set it up, write the copy and launch it for you.
      </p>
      <p>
        Strategy, design, media and development under one roof, with AI doing the heavy lifting so everything ships faster.
      </p>
      <p>
        A verdict of &ldquo;changes needed&rdquo; comes with one free resubmission. If you
        believe the rubric was applied wrongly, you may appeal once, and a second reviewer
        reads the work without seeing the first verdict.
      </p>

      <h2>Get found. Get chosen.</h2>
      <p>
        Branding, SEO, GEO, web, social and out-of-home campaigns, planned and measured from start to finish.
      </p>

      <h2>Make your brand <em>impossible</em> to ignore.</h2>
      <p>
        Start a project at aphinity.digital and turn this template into a site your customers trust.
      </p>

      <h2>Certificates</h2>
      <p>
        Add a short supporting paragraph here. Aphinity Digital recommends one clear idea per section.
      </p>
      <p>
        This is placeholder copy from Aphinity Digital. Replace it with a sentence about what your business does best.
      </p>

      <h2>Placeholder text by Aphinity Digital.</h2>
      <p>
        Aphinity Digital designs and builds websites like this one, and helps them get found on Google and in AI answers.
      </p>

      <h2>Replace this with your own words.</h2>
      <p>
        Use this space to explain your offer in plain words: who it is for, what it costs and why it is worth it.
      </p>

      <h2>Changes</h2>
      <p>
        Need this template customised for your brand? Aphinity Digital can set it up, write the copy and launch it for you.
      </p>
    </>
  );
}
