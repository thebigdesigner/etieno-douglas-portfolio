type Item = {
  id: string; kind: string; title: string;
  href: string | null; size_bytes: number | null;
};

const ICONS: Record<string, string> = {
  pdf: "◫", slides: "◨", download: "↓", audio: "♪", link: "↗",
};

const VERBS: Record<string, string> = {
  pdf: "Open", slides: "Open", download: "Download", audio: "Listen", link: "Visit",
};

export default function TopicMaterials({ materials }: { materials: Item[] }) {
  return (
    <section className="tmats">
      <h2 className="tmats__h">Materials for this topic</h2>
      <div className="tmats__list">
        {materials.map((m) => (
          <a
            key={m.id}
            className="tmat"
            href={m.href ?? "#"}
            target="_blank"
            rel="noreferrer"
            download={m.kind === "download" ? "" : undefined}
          >
            <span className="tmat__ic">{ICONS[m.kind] ?? "•"}</span>
            <span className="tmat__body">
              <span className="tmat__t">{m.title}</span>
              <span className="tmat__m">
                {m.kind}
                {m.size_bytes ? ` · ${(m.size_bytes / 1024 / 1024).toFixed(1)}MB` : ""}
              </span>
            </span>
            <span className="tmat__go">{VERBS[m.kind] ?? "Open"}</span>
          </a>
        ))}
      </div>
    </section>
  );
}
