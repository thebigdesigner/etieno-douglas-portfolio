import Link from "next/link";
import { createAdminClient } from "@/lib/supabase/admin";

export const dynamic = "force-dynamic";

type Params = Promise<{ code: string }>;

export async function generateMetadata({ params }: { params: Params }) {
  const { code } = await params;
  return {
    title: `Verify certificate ${code}`,
    robots: { index: false, follow: false },
  };
}

export default async function VerifyPage({ params }: { params: Params }) {
  const { code } = await params;
  const admin = createAdminClient();

  const { data: cert } = await admin
    .from("certificates")
    .select("code, reviewer_name, kind, issued_at, revoked_at, enrolment_id, show_name")
    .eq("code", code.toUpperCase())
    .maybeSingle();

  let courseTitle: string | null = null;
  let learnerName: string | null = null;

  if (cert) {
    const { data: enrolment } = await admin
      .from("enrolments").select("user_id, course_id").eq("id", cert.enrolment_id).maybeSingle();

    if (enrolment) {
      const { data: course } = await admin
        .from("courses").select("title").eq("id", enrolment.course_id).maybeSingle();
      courseTitle = course?.title ?? null;

      /* show_name is false where the holder has minor protections.
         record_review and resolve_appeal have set it at issuance since
         0004, and nothing has ever read it — so the one safeguard built
         for this page was decided, stored, and then ignored by it. The
         certificate stays verifiable either way; only the name is
         withheld, which is the point of the flag. */
      if (cert.show_name !== false) {
        const { data: profile } = await admin
          .from("profiles").select("display_name").eq("id", enrolment.user_id).maybeSingle();
        learnerName = profile?.display_name ?? null;
      }
    }
  }

  const valid = !!cert && !cert.revoked_at;

  return (
    <main className="verifypage">
      <div className="verifycard">
        <Link className="logo" href="/">Your Brand<span>.</span></Link>

        {!cert ? (
          <>
            <div className="vstate vstate--none">Not found</div>
            <h1 className="verifycard__h">No certificate with that code</h1>
            <p className="verifycard__p">
              Check the code and try again. Codes look like SPL-4K2M-90XB.
            </p>
          </>
        ) : !valid ? (
          <>
            <div className="vstate vstate--revoked">Revoked</div>
            <h1 className="verifycard__h">This certificate has been revoked</h1>
            <p className="verifycard__p">
              It was issued on{" "}
              {new Date(cert.issued_at).toLocaleDateString(undefined, {
                day: "numeric", month: "long", year: "numeric",
              })}{" "}
              and later withdrawn. It should not be relied on.
            </p>
          </>
        ) : (
          <>
            <div className="vstate vstate--valid">Valid</div>
            <h1 className="verifycard__h">{courseTitle}</h1>

            <dl className="vdl">
              {learnerName && (
                <div><dt>Awarded to</dt><dd>{learnerName}</dd></div>
              )}
              {/* This is the page an employer reads, so the distinction has
                  to be unambiguous here above anywhere else. */}
              {cert.kind === "examined" ? (
                <div><dt>Awarded on</dt><dd>Passing the final examination</dd></div>
              ) : (
                <div><dt>Assessed by</dt><dd>{cert.reviewer_name}</dd></div>
              )}
              <div>
                <dt>Issued</dt>
                <dd>
                  {new Date(cert.issued_at).toLocaleDateString(undefined, {
                    day: "numeric", month: "long", year: "numeric",
                  })}
                </dd>
              </div>
              <div><dt>Code</dt><dd className="num">{cert.code}</dd></div>
            </dl>

            <p className="verifycard__note">
              The final project behind this certificate was read and assessed by a
              named practitioner working in the field, against a rubric published
              before the learner started.
            </p>
          </>
        )}

        <div className="verifycard__foot">
          <Link className="btn btn--line" href="/courses">See what Your Brand teaches</Link>
        </div>
      </div>
    </main>
  );
}
