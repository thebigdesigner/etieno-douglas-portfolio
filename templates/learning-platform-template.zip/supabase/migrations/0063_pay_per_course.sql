-- =====================================================================
-- 0063 — one economy: a course is bought, or it is free
--
-- The subscription goes. What replaces it already exists — 0030 gave
-- courses an owner and a price, 0031 built the cart, the purchase record
-- and course_entitlement, 0038 let institutions license a course for a
-- cohort, 0049 made fulfilment settle against the price the buyer agreed
-- to. All of it has been running alongside the plan rather than instead
-- of it. This migration removes the alongside.
--
-- Five things change, and only the first two are deletions.
--
-- 1. Entitlement stops asking about subscriptions. course_entitlement
--    fell through to has_live_subscription() for Your Brand-authored courses
--    and for instructor courses with no price. With no subscriptions to
--    find, that branch returns needs_plan against a plan nobody can buy,
--    which is a locked door with no handle.
--
-- 2. create_submission stops falling back to cert_allowances. The
--    purchase check already ran first — a buyer spends the assessment
--    their price paid for, and the yearly certification allowance was
--    only ever reached by somebody with a plan and no purchase. That
--    person no longer exists.
--
-- 3. Your Brand-authored courses become sellable. They were priced at null
--    on purpose, because null meant "the plan covers it". Nothing covers
--    it now, so the constraint that kept a price off them is relaxed and
--    they take a price like anything else. The revenue split differs:
--    there is no author to pay, so everything above the assessment is
--    the platform's. Whoever assesses is still paid per review, exactly
--    as before.
--
-- 4. A sale credits the instructor's ledger. See 0062 — instructor_cents
--    has been computed and stored since 0031 and never once reached
--    earnings_entries, so run_payouts has never paid a penny of it. Both
--    fulfilment functions now write the entry in the same transaction as
--    the purchase, which is the only way the two cannot disagree.
--
-- 5. Prices are quoted in USD, and fulfilment enforces it.
--    courses.price_cents was one integer with no currency attached, and
--    startCourseCheckout charged that number in whatever currency the
--    visitor's country resolved to. A $49 course billed a Nigerian buyer
--    ₦49 and a British one £49. This is the same defect that got
--    app/plans deleted; it survived here because the plan carried the
--    revenue and nobody was watching the course path. Course prices now
--    carry an explicit currency, defaulted to USD, and a purchase whose
--    payment currency does not match its price currency is refused
--    rather than recorded at a number nobody agreed to.
--
-- The application must ship with this. Pinning checkout to USD in
-- lib/pricing.ts is what stops rule 5 from turning a successful payment
-- into a refused fulfilment.
--
-- Left standing on purpose: subscriptions, cert_allowances,
-- activate_subscription and has_live_subscription keep their rows and
-- their definitions. They are the record of what people paid for under
-- the old rules, and deleting the evidence to tidy the schema is the
-- wrong instinct. Nothing calls them after this.
-- =====================================================================


-- ---------------------------------------------------------------------
-- 1. A price has a currency
--
-- Defaulted rather than nullable: every price already in the table was
-- authored as a dollar figure, so USD is not an assumption here, it is
-- what the numbers already are.
-- ---------------------------------------------------------------------
alter table courses
  add column if not exists price_currency text not null default 'USD';

comment on column courses.price_currency is
  'Currency courses.price_cents is quoted in. USD unless deliberately changed. Fulfilment refuses a payment taken in any other currency — see 0063.';

alter table course_purchases
  alter column currency set default 'USD';

alter table institution_licences
  alter column currency set default 'USD';


-- ---------------------------------------------------------------------
-- 2. Your Brand-authored courses may carry a price
--
-- The old constraint said a price belongs to an instructor course and
-- nothing else, because the other two economies were covered by a plan
-- and a seat bill. One of those economies has gone.
--
-- An institution course still cannot carry one: it is not for sale, it
-- is written by an organisation for its own people and reached through
-- membership.
-- ---------------------------------------------------------------------
do $$ begin
  if exists (select 1 from pg_constraint where conname = 'courses_price_only_instructor') then
    alter table courses drop constraint courses_price_only_instructor;
  end if;
  alter table courses add constraint courses_price_not_institution
    check (price_cents is null or owner_kind in ('splari','instructor'));
end $$;


-- ---------------------------------------------------------------------
-- 3. Can this person open this course?
--
-- Restated in full — create or replace cannot patch a body.
--
-- Reasons returned, and what the application does with each:
--   free                 open
--   institution          open — their own organisation wrote it
--   licensed             open — their institution bought it for them
--   purchased            open — they bought it
--   cohort               open — an unpriced course, seats cover it
--   needs_purchase       show the price and the buy button
--   needs_licence        tell the learner their institution has to buy it
--   not_your_institution another organisation's internal course
--   unpriced             a published course with no price and not free.
--                        0039 refuses to publish one, so this should be
--                        unreachable; it is named rather than silently
--                        allowed so that if it ever appears, it appears
--                        as itself instead of as a permission failure.
-- ---------------------------------------------------------------------
create or replace function public.course_entitlement(p_user_id uuid, p_course_id uuid)
returns table (
  allowed     boolean,
  reason      text,
  needs_price int
)
language plpgsql
stable
security definer set search_path = public
as $$
declare
  v_course      courses%rowtype;
  v_owned       boolean;
  v_cohort      boolean;
  v_institution uuid;
  v_licensed    boolean;
  v_member      boolean;
begin
  select * into v_course from courses where id = p_course_id;
  if not found then
    return query select false, 'no_course'::text, null::int; return;
  end if;

  -- Which institution this person belongs to, by seat or by staff
  -- membership. Resolved before the free check, because an institution
  -- course marked free is still only free to its own people.
  select coalesce(
    (select co.institution_id from cohort_seats s join cohorts co on co.id = s.cohort_id
      where s.user_id = p_user_id limit 1),
    (select m.institution_id from institution_members m where m.user_id = p_user_id limit 1)
  ) into v_institution;

  if v_course.owner_kind = 'institution' then
    v_member := v_institution is not null and v_institution = v_course.institution_id;
    if v_member then
      return query select true, 'institution'::text, null::int; return;
    end if;
    return query select false, 'not_your_institution'::text, null::int; return;
  end if;

  if v_course.is_free then
    return query select true, 'free'::text, null::int; return;
  end if;

  select exists (
    select 1 from enrolments e
     where e.user_id = p_user_id and e.course_id = p_course_id and e.source = 'cohort'
  ) into v_cohort;

  -- Anything with a price is bought, whoever wrote it. Your Brand-authored
  -- courses join instructor courses here; before this migration they
  -- fell past it to the subscription.
  if v_course.price_cents is not null then
    if v_cohort then
      select exists (
        select 1 from institution_licences l
         where l.institution_id = v_institution
           and l.course_id = p_course_id
           and l.refunded_at is null
      ) into v_licensed;

      if v_licensed then
        return query select true, 'licensed'::text, null::int; return;
      end if;
      return query select false, 'needs_licence'::text, v_course.price_cents; return;
    end if;

    select exists (
      select 1 from course_purchases cp
       where cp.user_id = p_user_id and cp.course_id = p_course_id and cp.refunded_at is null
    ) into v_owned;

    if v_owned then
      return query select true, 'purchased'::text, null::int; return;
    end if;
    return query select false, 'needs_purchase'::text, v_course.price_cents; return;
  end if;

  -- No price and not free. A cohort learner's seats still cover it,
  -- because their institution is billed for them either way.
  if v_cohort then
    return query select true, 'cohort'::text, null::int; return;
  end if;

  return query select false, 'unpriced'::text, null::int;
end;
$$;


-- ---------------------------------------------------------------------
-- 4. Submitting a project
--
-- Restated in full. One branch changes: where a learner with no purchase
-- used to spend a plan allowance, there is now nothing to spend.
--
-- The new refusals:
--   not_purchased      · a priced course they do not own. Unreachable
--                        through the UI, since entitlement already shut
--                        the door, but create_submission is called with
--                        an id and an id is not a permission.
--   free_no_assessment · a free course whose project nobody paid to have
--                        assessed. Under the plan this came out of the
--                        yearly allowance. It now has no funding source,
--                        and $18.85 per submission on an unlimited free
--                        course is a bill with no ceiling.
--
-- That second one is a product decision sitting in a function: a free
-- course should carry requires_project = false, or a price. Refusing at
-- submission is the honest failure — the alternative is issuing
-- certificates the platform loses money on, quietly.
-- ---------------------------------------------------------------------
create or replace function public.create_submission(
  p_user_id uuid,
  p_course_id uuid,
  p_body text,
  p_files text[]
)
returns table (submission_id uuid, deadline timestamptz, error text)
language plpgsql
security definer set search_path = public
as $$
declare
  v_enrolment    enrolments%rowtype;
  v_prev         submissions%rowtype;
  v_attempt      int := 1;
  v_consumes     boolean := true;
  v_purchase     course_purchases%rowtype;
  v_course       courses%rowtype;
  v_reviewer     uuid;
  v_deadline     timestamptz;
  v_id           uuid;
  v_topics_left  int;
  v_has_exam     int;
  v_exam_passed  boolean;
begin
  select * into v_enrolment
    from enrolments where user_id = p_user_id and course_id = p_course_id;

  if not found then
    return query select null::uuid, null::timestamptz, 'not_enrolled'::text; return;
  end if;

  select * into v_course from courses where id = p_course_id;

  select count(*) into v_topics_left
    from topics t join modules m on m.id = t.module_id
   where m.course_id = p_course_id
     and t.id not in (
       select tc.topic_id from topic_completions tc where tc.enrolment_id = v_enrolment.id
     );

  if v_topics_left > 0 then
    return query select null::uuid, null::timestamptz, 'topics_incomplete'::text; return;
  end if;

  select count(*) into v_has_exam from exam_items where course_id = p_course_id;
  if v_has_exam > 0 then
    select coalesce(bool_or(passed), false) into v_exam_passed
      from exam_attempts where enrolment_id = v_enrolment.id;
    if not v_exam_passed then
      return query select null::uuid, null::timestamptz, 'exam_not_passed'::text; return;
    end if;
  end if;

  select * into v_prev
    from submissions where enrolment_id = v_enrolment.id
    order by attempt_no desc limit 1;

  if found then
    if v_prev.state in ('submitted','assigned','in_review') then
      return query select null::uuid, null::timestamptz, 'already_under_review'::text; return;
    end if;
    if v_prev.state = 'passed' then
      return query select null::uuid, null::timestamptz, 'already_passed'::text; return;
    end if;
    v_attempt := v_prev.attempt_no + 1;
    -- The first resubmission after "changes needed" is free. Unchanged.
    if v_prev.state = 'revision_requested' and v_attempt = 2 then
      v_consumes := false;
    end if;
  end if;

  if v_consumes then
    if v_enrolment.source = 'cohort' then
      v_consumes := false;                       -- the institution's licence
    else
      select * into v_purchase
        from course_purchases
       where user_id = p_user_id and course_id = p_course_id and refunded_at is null
       limit 1;

      if found and not v_purchase.assessment_used then
        update course_purchases set assessment_used = true where id = v_purchase.id;
        v_consumes := false;
      elsif found and v_purchase.assessment_used then
        return query select null::uuid, null::timestamptz, 'assessment_used'::text; return;
      elsif v_course.is_free then
        return query select null::uuid, null::timestamptz, 'free_no_assessment'::text; return;
      else
        return query select null::uuid, null::timestamptz, 'not_purchased'::text; return;
      end if;
    end if;
  end if;

  select c.instructor_id into v_reviewer from courses c where c.id = p_course_id;
  v_deadline := add_working_days(now(), 4);

  insert into submissions (enrolment_id, attempt_no, body, file_paths, state,
                           assigned_reviewer_id, deadline_at, consumed_allowance)
  values (v_enrolment.id, v_attempt, p_body, p_files, 'submitted',
          v_reviewer, v_deadline, v_consumes)
  returning id into v_id;

  update enrolments set state = 'submitted' where id = v_enrolment.id;

  return query select v_id, v_deadline, null::text;
end;
$$;


-- ---------------------------------------------------------------------
-- 5. Turning a paid cart into purchases
--
-- Restated in full, keeping 0049's agreed-price settlement intact. Two
-- things are added.
--
-- The currency guard. An intent whose currency is not the currency the
-- course is priced in cannot be settled: the amount was verified against
-- Flutterwave, but the number verified is meaningless if it was quoted
-- in one currency and charged in another. Refusing leaves the payment
-- recorded and unfulfilled, which is visible and recoverable. Recording
-- it would be neither.
--
-- The earnings entry. Written only for an instructor-owned course with a
-- live instructors row — a Your Brand-authored course has no author to pay,
-- so everything above the assessment is platform revenue. The entry
-- carries the purchase id, so a payout can be traced back to the sale
-- that produced it.
-- ---------------------------------------------------------------------
create or replace function public.record_course_purchases(p_tx_ref text)
returns int
language plpgsql security definer set search_path = public as $$
declare
  v_intent      checkout_intents%rowtype;
  v_course      courses%rowtype;
  v_course_id   uuid;
  v_price       int;
  v_assess      int := 1885;      -- what an assessment costs to pay for
  v_rest        int;
  v_instructor  int;
  v_made        int := 0;
  v_idx         int;
  v_purchase_id uuid;
begin
  select * into v_intent from checkout_intents where tx_ref = p_tx_ref;
  if not found or v_intent.kind <> 'courses' then return 0; end if;

  v_idx := 0;
  foreach v_course_id in array v_intent.course_ids loop
    v_idx := v_idx + 1;

    select * into v_course from courses where id = v_course_id;
    if not found then
      raise warning 'record_course_purchases: no course % on %', v_course_id, p_tx_ref;
      continue;
    end if;

    -- Quoted in one currency, charged in another: refuse. See 0063.
    if v_intent.currency is distinct from v_course.price_currency then
      raise warning 'record_course_purchases: currency mismatch on % — paid %, priced %',
        p_tx_ref, v_intent.currency, v_course.price_currency;
      continue;
    end if;

    -- The agreed price, captured at checkout by 0049. Intents created
    -- before that migration have none and fall back to the live price.
    v_price := null;
    if v_intent.course_prices is not null
       and array_length(v_intent.course_prices, 1) >= v_idx then
      v_price := v_intent.course_prices[v_idx];
    end if;

    if v_price is null then
      v_price := v_course.price_cents;
    end if;

    if v_price is null then
      raise warning 'record_course_purchases: no price for course % on %', v_course_id, p_tx_ref;
      continue;
    end if;

    v_rest := greatest(v_price - v_assess, 0);

    -- Nobody to pay on a Your Brand-authored course. The assessor is paid
    -- per review, as they always were.
    v_instructor := case
      when v_course.owner_kind = 'instructor' then floor(v_rest * 0.70)::int
      else 0
    end;

    insert into course_purchases (
      user_id, course_id, price_cents, currency, tx_ref,
      assessment_cents, instructor_cents, platform_cents
    )
    values (
      v_intent.user_id, v_course_id, v_price, v_intent.currency, p_tx_ref,
      least(v_assess, v_price),
      v_instructor,
      v_rest - v_instructor
    )
    on conflict (user_id, course_id) do nothing
    returning id into v_purchase_id;

    -- Null means a replayed webhook hit the unique key. Nothing was
    -- bought a second time, so nothing is credited a second time.
    if v_purchase_id is not null then
      v_made := v_made + 1;

      if v_instructor > 0 and exists (
        select 1 from instructors i where i.id = v_course.instructor_id
      ) then
        insert into earnings_entries (instructor_id, type, amount_cents, ref_id, note)
        values (v_course.instructor_id, 'sale', v_instructor, v_purchase_id,
                'Sale of ' || v_course.title);
      end if;
    end if;
  end loop;

  delete from cart_items
   where user_id = v_intent.user_id and course_id = any(v_intent.course_ids);

  update checkout_intents set completed_at = now() where tx_ref = p_tx_ref;
  return v_made;
end; $$;


-- ---------------------------------------------------------------------
-- 6. Turning a paid licence order into licences
--
-- The same three corrections as above, which it never received: it still
-- read the live price at webhook time — the exact fault 0049 was written
-- to fix on the purchase path — had no currency guard, and credited
-- nobody.
--
-- Your Brand-authored courses are licensable now too, on the same terms.
-- ---------------------------------------------------------------------
create or replace function public.record_institution_licences(p_tx_ref text)
returns int
language plpgsql
security definer set search_path = public
as $$
declare
  v_intent     checkout_intents%rowtype;
  v_course     courses%rowtype;
  v_course_id  uuid;
  v_price      int;
  v_assess     int := 1885;
  v_rest       int;
  v_instructor int;
  v_made       int := 0;
  v_idx        int;
  v_licence_id uuid;
begin
  select * into v_intent from checkout_intents where tx_ref = p_tx_ref;
  if not found or v_intent.kind <> 'licences' then return 0; end if;

  v_idx := 0;
  foreach v_course_id in array v_intent.course_ids loop
    v_idx := v_idx + 1;

    select * into v_course from courses where id = v_course_id;
    if not found then
      raise warning 'record_institution_licences: no course % on %', v_course_id, p_tx_ref;
      continue;
    end if;

    if v_intent.currency is distinct from v_course.price_currency then
      raise warning 'record_institution_licences: currency mismatch on % — paid %, priced %',
        p_tx_ref, v_intent.currency, v_course.price_currency;
      continue;
    end if;

    v_price := null;
    if v_intent.course_prices is not null
       and array_length(v_intent.course_prices, 1) >= v_idx then
      v_price := v_intent.course_prices[v_idx];
    end if;

    if v_price is null then
      v_price := v_course.price_cents;
    end if;

    if v_price is null then
      raise warning 'record_institution_licences: no price for course % on %', v_course_id, p_tx_ref;
      continue;
    end if;

    v_rest := greatest(v_price - v_assess, 0);

    v_instructor := case
      when v_course.owner_kind = 'instructor' then floor(v_rest * 0.70)::int
      else 0
    end;

    insert into institution_licences (
      institution_id, course_id, price_cents, currency, tx_ref,
      assessment_cents, instructor_cents, platform_cents
    )
    values (
      v_intent.institution_id, v_course_id, v_price, v_intent.currency, p_tx_ref,
      least(v_assess, v_price),
      v_instructor,
      v_rest - v_instructor
    )
    on conflict (institution_id, course_id) do nothing
    returning id into v_licence_id;

    if v_licence_id is not null then
      v_made := v_made + 1;

      if v_instructor > 0 and exists (
        select 1 from instructors i where i.id = v_course.instructor_id
      ) then
        insert into earnings_entries (instructor_id, type, amount_cents, ref_id, note)
        values (v_course.instructor_id, 'licence', v_instructor, v_licence_id,
                'Institution licence for ' || v_course.title);
      end if;
    end if;
  end loop;

  update checkout_intents set completed_at = now() where tx_ref = p_tx_ref;
  return v_made;
end;
$$;


-- ---------------------------------------------------------------------
-- 7. What an institution can buy
--
-- Widened to match entitlement: anything priced, whoever wrote it, minus
-- an organisation's own internal courses.
-- ---------------------------------------------------------------------
create or replace function public.institution_catalogue(p_institution_id uuid)
returns table (
  course_id   uuid,
  slug        text,
  title       text,
  subject     text,
  price_cents int,
  licensed    boolean
)
language sql
stable
security definer set search_path = public
as $$
  select c.id, c.slug, c.title, c.subject, c.price_cents,
         exists (
           select 1 from institution_licences l
            where l.institution_id = p_institution_id
              and l.course_id = c.id and l.refunded_at is null
         )
    from courses c
   where c.state = 'published'
     and c.owner_kind in ('splari','instructor')
     and c.price_cents is not null
     and not c.is_free
   order by c.title;
$$;


-- ---------------------------------------------------------------------
-- 8. A plan is no longer a thing that can be bought
--
-- The constraint is the backstop, not the policy — the application stops
-- creating plan intents. It is here because an intent kind the fulfilment
-- path no longer handles would take money and grant nothing, silently,
-- and that failure is worth making impossible rather than unlikely.
--
-- Historic plan intents keep their rows. The check applies to what is
-- written from now on.
-- ---------------------------------------------------------------------
do $$ begin
  if exists (select 1 from pg_constraint where conname = 'checkout_intents_kind_shape') then
    alter table checkout_intents drop constraint checkout_intents_kind_shape;
  end if;
  alter table checkout_intents add constraint checkout_intents_kind_shape
    check (
      (kind = 'courses'   and plan is null and cardinality(course_ids) > 0) or
      (kind = 'licences'  and plan is null and cardinality(course_ids) > 0
                          and institution_id is not null) or
      -- Rows written before this migration. Not creatable: the
      -- application no longer offers a plan, and nothing fulfils one.
      (kind = 'plan'      and completed_at is not null)
    ) not valid;
end $$;


-- ---------------------------------------------------------------------
-- 9. People who already paid
--
-- Anyone holding a live subscription bought access to a catalogue that
-- is about to stop being sold that way. Letting the period lapse and
-- saying nothing would take something already paid for.
--
-- So every course they are enrolled in becomes a purchase they own, at
-- zero, tagged so it is never mistaken for revenue. assessment_used is
-- false, which gives them the one assessment their plan allowance would
-- have covered. No earnings entry: nothing was received, so nothing is
-- owed.
--
-- Courses they had not started are not granted. A subscription was
-- access to a catalogue, not ownership of it, and inventing purchases
-- for things nobody opened would put thousands of rows in the table to
-- no end.
-- ---------------------------------------------------------------------
insert into course_purchases (
  user_id, course_id, price_cents, currency, tx_ref,
  assessment_cents, instructor_cents, platform_cents, assessment_used
)
select distinct e.user_id, e.course_id, 0, 'USD', 'legacy_subscription_grant',
       0, 0, 0, false
  from enrolments e
  join courses c on c.id = e.course_id
 where e.source <> 'cohort'
   and c.owner_kind in ('splari','instructor')
   and not c.is_free
   and exists (
     select 1 from subscriptions s
      where s.user_id = e.user_id
        and s.status in ('active','past_due','cancelled')
        and s.current_period_end > now()
   )
on conflict (user_id, course_id) do nothing;


-- ---------------------------------------------------------------------
-- 10. What is left standing, and why
-- ---------------------------------------------------------------------
comment on function public.has_live_subscription(uuid) is
  'DEPRECATED as of 0063. Nothing calls it. Kept so historic subscription rows remain queryable and so any straggling caller fails loudly at review rather than silently at runtime.';

comment on table cert_allowances is
  'DEPRECATED as of 0063. The yearly certification allowance belonged to the subscription; an assessment is now paid for inside the price of the course. Rows are kept as the record of what plan holders were entitled to.';

comment on table subscriptions is
  'DEPRECATED as of 0063. No new rows. Retained as the record of what was sold under the plan, and read by the backfill in that migration.';
