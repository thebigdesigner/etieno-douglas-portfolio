import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import ExamPaper from "./ExamPaper";

export const dynamic = "force-dynamic";

type Params = Promise<{ slug: string }>;

export async function generateMetadata({ params }: { params: Params }) {
  const { slug } = await params;
  return { title: "Final exam" , alternates: { canonical: `/learn/${slug}/exam` } };
}

/**
 * The final exam.
 *
 * Everything that decides what to show comes from course_exam_state, the
 * same call the grading action makes — so the screen cannot offer an exam
 * the action would then refuse.
 *
 * The answer key is deliberately absent from the select. exam_items is
 * readable on a published course, so asking for `correct` here would put
 * the key in the page source.
 */
export default async function ExamPage({ params }: { params: Params }) {
  const { slug } = await params;
  const supabase = await createClient();

  const { data: course } = await supabase
    .from("courses").select("id, title, requires_project")
    .eq("slug", slug).eq("state", "published").maybeSingle();
  if (!course) notFound();

  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect(`/login?next=/learn/${slug}/exam`);

  const admin = createAdminClient();
  const { data: stateRows } = await admin.rpc("course_exam_state", {
    p_course_id: course.id, p_user_id: user.id,
  });
  const state = Array.isArray(stateRows) ? stateRows[0] : stateRows;

  if (!state?.enrolment_id) redirect(`/courses/${slug}`);

  const itemCount = Number(state.item_count ?? 0);
  const topicsLeft = Number(state.topics_left ?? 0);

  // A course published before exams existed has none. Send them where they
  // were always going rather than showing an empty paper.
  if (itemCount === 0) {
    redirect(course.requires_project ? `/courses/${slug}/submit` : `/courses/${slug}`);
  }

  const { data: items } = await admin
    .from("exam_items").select("id, prompt, options")
    .eq("course_id", course.id).order("position");

  const questions = (items ?? []).map((i) => ({
    id: i.id as string,
    prompt: i.prompt as string,
    options: (i.options ?? []) as { id: string; text: string }[],
  }));

  return (
    <main className="sec">
      <div className="wrap" style={{ maxWidth: 760 }}>
        <nav className="crumb">
          <Link href={`/courses/${slug}`}>{course.title}</Link> / Final exam
        </nav>

        {topicsLeft > 0 ? (
          <div className="quiz" style={{ marginTop: 22 }}>
            <div className="quiz__cool">
              <p className="quiz__coolh">Not open yet</p>
              <p className="quiz__coolp">
                {topicsLeft} topic{topicsLeft === 1 ? "" : "s"} left to finish first.
                The exam covers the whole course, so it waits until you have seen all
                of it.
              </p>
              <Link className="btn btn--fill" href={`/courses/${slug}`} style={{ marginTop: 16 }}>
                Back to the course
              </Link>
            </div>
          </div>
        ) : state.passed ? (
          <div className="quiz" style={{ marginTop: 22 }}>
            <div className="quiz__pass">
              <p className="quiz__passh">Already passed — best {state.best_pct}%</p>
              <p className="quiz__passp">
                {course.requires_project
                  ? "The final project is open."
                  : "This course is complete."}
              </p>
              <Link
                className="btn btn--fill btn--lg"
                href={course.requires_project ? `/courses/${slug}/submit` : "/dashboard/certificates"}
              >
                {course.requires_project ? "Go to the project" : "See your certificate"}
              </Link>
            </div>
          </div>
        ) : (
          <div style={{ marginTop: 22 }}>
            <ExamPaper
              slug={slug}
              questions={questions}
              requiresProject={Boolean(course.requires_project)}
              attempts={Number(state.attempts ?? 0)}
              bestPct={Number(state.best_pct ?? 0)}
            />
          </div>
        )}
      </div>
    </main>
  );
}
