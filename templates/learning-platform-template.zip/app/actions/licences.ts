"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { newReference, resolveProvider, startCheckout } from "@/lib/payments";
import { SALE_CURRENCY } from "@/lib/pricing";
import { siteUrl } from "@/lib/site";

/**
 * Licences: an institution buying an instructor course for its cohorts.
 *
 * Mirrors the learner cart deliberately — the amount is summed server-side
 * from the courses, an intent is written before the redirect, and one
 * fulfilment path records what was bought. The only real difference is who
 * ends up holding the thing.
 */
async function requireAdminInstitution(): Promise<{ userId: string; institutionId: string }> {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login?next=/institution/licences");

  const admin = createAdminClient();
  const { data: profile } = await admin
    .from("profiles").select("role").eq("id", user.id).maybeSingle();

  if (profile?.role !== "institution_admin" && profile?.role !== "operator") {
    redirect("/dashboard");
  }

  const { data: member } = await admin
    .from("institution_members").select("institution_id")
    .eq("user_id", user.id).maybeSingle();

  if (!member) redirect("/institution");
  return { userId: user.id, institutionId: member.institution_id as string };
}

export async function buyLicences(formData: FormData): Promise<void> {
  const { userId, institutionId } = await requireAdminInstitution();
  const admin = createAdminClient();

  const wanted = formData.getAll("course").map(String).filter(Boolean);
  if (wanted.length === 0) redirect("/institution/licences?error=none");

  // Priced, published, instructor-owned, and not already held. Checked here
  // rather than trusted from the form — the form is where the price would be
  // edited if it were sent from there.
  const { data: rows } = await admin
    .rpc("institution_catalogue", { p_institution_id: institutionId });

  const catalogue = (rows ?? []) as {
    course_id: string; price_cents: number; licensed: boolean;
  }[];

  const buying = catalogue.filter(
    (c) => wanted.includes(c.course_id) && !c.licensed
  );
  if (buying.length === 0) redirect("/institution/licences?error=none");

  const totalCents = buying.reduce((n, c) => n + Number(c.price_cents), 0);

  const { data: profile } = await admin
    .from("profiles").select("email, display_name").eq("id", userId).maybeSingle();
  if (!profile?.email) redirect("/institution?error=email");

  // Sales are quoted and charged in one currency. See SALE_CURRENCY.
  const ccy = SALE_CURRENCY;
  const txRef = newReference("licences");

  await admin.from("checkout_intents").insert({
    tx_ref: txRef,
    user_id: userId,
    kind: "licences",
    plan: null,
    institution_id: institutionId,
    course_ids: buying.map((c) => c.course_id),
    // The price of each line, in the same order, as the buyer sees it now.
    // record_institution_licences settles against these rather than
    // re-reading the course, which an author can edit while the finance
    // team is on the card form. The purchase path has done this since
    // 0049; this path never did.
    course_prices: buying.map((c) => Number(c.price_cents)),
    amount_cents: totalCents,
    currency: ccy,
    return_to: "/institution/licences",
  });

  let link: string;
  try {
    const started = await startCheckout({
      txRef,
      amount: totalCents / 100,
      currency: ccy,
      email: profile.email,
      name: profile.display_name,
      provider: resolveProvider(String(formData?.get?.("provider") ?? "")),
      description: "Your Brand licences",
      redirectUrl: `${siteUrl()}/institution/licences/complete`,
      meta: { institution_id: institutionId, kind: "licences" },
    });
    link = started.url;
    // Which provider took it, so fulfilment verifies with the same one.
    await admin.from("checkout_intents")
      .update({ provider: started.provider, provider_session: started.session })
      .eq("tx_ref", txRef);
  } catch {
    redirect("/institution/licences?error=checkout");
  }

  revalidatePath("/institution/licences");
  redirect(link);
}
