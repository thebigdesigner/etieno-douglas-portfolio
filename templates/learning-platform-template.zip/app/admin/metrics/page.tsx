import { createAdminClient } from "@/lib/supabase/admin";

export const metadata = { title: "Metrics" };
export const dynamic = "force-dynamic";

const GATES = [
  { key: "learners", label: "Registered learners", target: 500, note: "Phase 1 gate" },
  { key: "projects_passed", label: "Reviewed projects", target: 50, note: "Phase 1 gate" },
  { key: "sla_pct", label: "SLA adherence", target: 90, note: "Phase 1 gate", suffix: "%" },
  { key: "institutions_billed", label: "Paying institutions", target: 5, note: "Phase 2 gate" },
];

export default async function MetricsPage() {
  const admin = createAdminClient();

  const { data: m } = await admin.from("launch_metrics").select("*").maybeSingle();
  const { data: funnel } = await admin.from("funnel_daily").select("*").limit(14);
  const { data: dropoff } = await admin
    .from("topic_dropoff").select("*").order("failed_at_least_once", { ascending: false }).limit(10);

  const metrics = (m ?? {}) as Record<string, number | null>;

  return (
    <>
        <h1 className="sec__h" style={{ fontSize: 30, marginTop: 34 }}>Metrics</h1>
        <p className="sec__meta">
          The phase gates, measured. Do not pass one because the calendar says so.
        </p>

        <div className="gates">
          {GATES.map((g) => {
            const value = Number(metrics[g.key] ?? 0);
            const pct = Math.min(100, Math.round((value / g.target) * 100));
            const met = value >= g.target;
            return (
              <div key={g.key} className={`gate2${met ? " is-met" : ""}`}>
                <div className="eyebrow">{g.note}</div>
                <div className="gate2__v num">
                  {value}{g.suffix ?? ""} <span>of {g.target}{g.suffix ?? ""}</span>
                </div>
                <div className="gate2__label">{g.label}</div>
                <div className="dcrs__bar"><span style={{ width: `${pct}%` }} /></div>
              </div>
            );
          })}
        </div>

        <section style={{ marginTop: 46 }}>
          <h2 className="sub__h2">Where things stand</h2>
          <div className="dash__grid" style={{ marginTop: 20 }}>
            {[
              ["Courses live", metrics.courses_live],
              ["Active instructors", metrics.instructors],
              ["Enrolments", metrics.enrolments],
              ["Topics completed", metrics.topics_completed],
              ["Certificates held", metrics.certificates],
              ["Reviews completed", metrics.reviews_done],
            ].map(([label, value]) => (
              <div key={String(label)} className="dash__card">
                <div className="eyebrow">{String(label)}</div>
                <div className="dash__val num">{Number(value ?? 0)}</div>
              </div>
            ))}
          </div>
        </section>

        <section style={{ marginTop: 46 }}>
          <h2 className="sub__h2">Funnel, last 14 days</h2>
          <p className="studio__hint">Distinct people, not events.</p>
          {(!funnel || funnel.length === 0) ? (
            <p className="studio__hint" style={{ marginTop: 14 }}>No events recorded yet.</p>
          ) : (
            <table className="tbl" style={{ marginTop: 18 }}>
              <thead>
                <tr>
                  <th>Day</th><th>Started</th><th>Created</th><th>Enrolled</th>
                  <th>Paywall</th><th>Submitted</th><th>Certified</th>
                </tr>
              </thead>
              <tbody>
                {funnel.map((d) => (
                  <tr key={d.day}>
                    <td>{new Date(d.day).toLocaleDateString()}</td>
                    <td className="num">{d.signup_started}</td>
                    <td className="num">{d.account_created}</td>
                    <td className="num">{d.course_started}</td>
                    <td className="num">{d.paywall_shown}</td>
                    <td className="num">{d.project_submitted}</td>
                    <td className="num">{d.certified}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>

        <section style={{ margin: "46px 0 40px" }}>
          <h2 className="sub__h2">Where learners get stuck</h2>
          <p className="studio__hint">
            A high failure rate on one question is usually a badly written question, not a
            difficult topic.
          </p>
          {(!dropoff || dropoff.length === 0) ? (
            <p className="studio__hint" style={{ marginTop: 14 }}>Not enough attempts yet.</p>
          ) : (
            <table className="tbl" style={{ marginTop: 18 }}>
              <thead>
                <tr><th>Course</th><th>Topic</th><th>Completed</th><th>Failed once+</th><th>Avg score</th></tr>
              </thead>
              <tbody>
                {dropoff.map((t, i) => (
                  <tr key={i}>
                    <td>{t.course}</td>
                    <td>{t.topic}</td>
                    <td className="num">{t.completions}</td>
                    <td className="num">{t.failed_at_least_once}</td>
                    <td className="num">{t.avg_score ?? "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </section>
      </>
  );
}
