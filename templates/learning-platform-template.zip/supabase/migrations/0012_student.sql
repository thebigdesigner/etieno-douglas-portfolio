-- =====================================================================
-- Thumbnails, saved courses, notes, resume position
-- =====================================================================

-- ---------------------------------------------------------------------
-- Every course needs a thumbnail. A catalogue of text blocks does not get
-- browsed, and the gate below makes it a publication requirement rather
-- than a nice-to-have.
-- ---------------------------------------------------------------------
alter table courses
  add column thumbnail_path text,
  add column thumbnail_alt  text;

insert into storage.buckets (id, name, public, file_size_limit)
values ('thumbnails', 'thumbnails', true, 5242880)
on conflict (id) do nothing;

-- Public bucket: thumbnails appear on the marketing catalogue, which is
-- served to people who are not signed in.
create policy "anyone reads thumbnails"
  on storage.objects for select
  using (bucket_id = 'thumbnails');

create policy "instructors upload thumbnails"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'thumbnails' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "instructors replace thumbnails"
  on storage.objects for update to authenticated
  using (bucket_id = 'thumbnails' and (storage.foldername(name))[1] = auth.uid()::text);

-- ---------------------------------------------------------------------
-- Resume where they left off, to the second. Losing your place in a
-- twelve-minute video is a small thing that stops people coming back.
-- ---------------------------------------------------------------------
create table topic_progress (
  enrolment_id uuid not null references enrolments(id) on delete cascade,
  topic_id     uuid not null references topics(id) on delete cascade,
  seconds      int  not null default 0,
  duration     int,
  updated_at   timestamptz not null default now(),
  primary key (enrolment_id, topic_id)
);

alter table topic_progress enable row level security;

create policy own_topic_progress on topic_progress for all using (
  exists (select 1 from enrolments e
           where e.id = topic_progress.enrolment_id and e.user_id = auth.uid())
) with check (
  exists (select 1 from enrolments e
           where e.id = topic_progress.enrolment_id and e.user_id = auth.uid())
);

create or replace function public.save_position(
  p_user_id uuid, p_topic_id uuid, p_seconds int, p_duration int
)
returns void
language plpgsql security definer set search_path = public as $$
declare v_enrolment uuid;
begin
  select e.id into v_enrolment
    from enrolments e
    join modules m on m.course_id = e.course_id
    join topics t on t.module_id = m.id
   where t.id = p_topic_id and e.user_id = p_user_id
   limit 1;

  if v_enrolment is null then return; end if;

  insert into topic_progress (enrolment_id, topic_id, seconds, duration)
  values (v_enrolment, p_topic_id, p_seconds, p_duration)
  on conflict (enrolment_id, topic_id) do update
     set seconds = excluded.seconds,
         duration = coalesce(excluded.duration, topic_progress.duration),
         updated_at = now();
end; $$;

-- ---------------------------------------------------------------------
-- Saved courses. Somebody browsing before they subscribe needs somewhere
-- to put the ones they liked.
-- ---------------------------------------------------------------------
create table saved_courses (
  user_id   uuid not null references profiles(id) on delete cascade,
  course_id uuid not null references courses(id) on delete cascade,
  saved_at  timestamptz not null default now(),
  primary key (user_id, course_id)
);

alter table saved_courses enable row level security;
create policy own_saved on saved_courses for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- ---------------------------------------------------------------------
-- Notes, per topic. Everything a learner writes stays theirs; nobody
-- reviewing their project sees it.
-- ---------------------------------------------------------------------
create table topic_notes (
  id           uuid primary key default gen_random_uuid(),
  user_id      uuid not null references profiles(id) on delete cascade,
  topic_id     uuid not null references topics(id) on delete cascade,
  body         text not null,
  updated_at   timestamptz not null default now(),
  unique (user_id, topic_id)
);

alter table topic_notes enable row level security;
create policy own_notes on topic_notes for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- ---------------------------------------------------------------------
-- Catalogue search. Postgres full text is more than enough at this size,
-- and avoids a second service to run.
-- ---------------------------------------------------------------------
create or replace function public.search_courses(p_query text)
returns table (
  slug text, title text, summary text, subject text, segment text,
  is_free boolean, thumbnail_path text, rank real
)
language sql stable security definer set search_path = public as $$
  select c.slug, c.title, c.summary, c.subject, c.segment, c.is_free, c.thumbnail_path,
         ts_rank(
           to_tsvector('english',
             c.title || ' ' || coalesce(c.summary,'') || ' ' ||
             c.subject || ' ' || c.segment || ' ' ||
             coalesce((select string_agg(t.title, ' ')
                         from modules m join topics t on t.module_id = m.id
                        where m.course_id = c.id), '')),
           plainto_tsquery('english', p_query)
         ) as rank
    from courses c
   where c.state = 'published'
     and to_tsvector('english',
           c.title || ' ' || coalesce(c.summary,'') || ' ' ||
           c.subject || ' ' || c.segment || ' ' ||
           coalesce((select string_agg(t.title, ' ')
                       from modules m join topics t on t.module_id = m.id
                      where m.course_id = c.id), ''))
         @@ plainto_tsquery('english', p_query)
   order by rank desc
   limit 40;
$$;

-- ---------------------------------------------------------------------
-- Publication gate: a thumbnail is now required.
-- ---------------------------------------------------------------------
create or replace function public.submit_course_for_review(p_course_id uuid, p_instructor_id uuid)
returns table (ok boolean, reason text)
language plpgsql security definer set search_path = public as $$
declare
  v_course courses%rowtype;
  v_topics int; v_criteria int; v_quiz int; v_empty int;
begin
  select * into v_course from courses where id = p_course_id and instructor_id = p_instructor_id;
  if not found then return query select false, 'not_yours'; return; end if;
  if v_course.state not in ('draft','revision_requested') then
    return query select false, 'wrong_state'; return;
  end if;

  if v_course.thumbnail_path is null then
    return query select false, 'no_thumbnail'; return;
  end if;

  select count(*) into v_topics
    from topics t join modules m on m.id = t.module_id where m.course_id = p_course_id;
  if v_topics < 3 then return query select false, 'too_few_topics'; return; end if;

  select count(*) into v_empty
    from topics t join modules m on m.id = t.module_id
   where m.course_id = p_course_id
     and coalesce(length(trim(t.body)), 0) < 40
     and not exists (select 1 from topic_materials tm where tm.topic_id = t.id);
  if v_empty > 0 then return query select false, 'empty_topics'; return; end if;

  select count(*) into v_quiz
    from quiz_items q join topics t on t.id = q.topic_id
    join modules m on m.id = t.module_id where m.course_id = p_course_id;
  if v_quiz < 3 then return query select false, 'too_few_questions'; return; end if;

  if coalesce(length(trim(v_course.project_brief)), 0) < 120 then
    return query select false, 'brief_too_short'; return;
  end if;

  select count(*) into v_criteria from rubric_criteria where course_id = p_course_id;
  if v_criteria < 2 then return query select false, 'rubric_too_thin'; return; end if;

  update courses set state = 'in_review' where id = p_course_id;
  return query select true, null::text;
end; $$;

revoke all on function public.save_position(uuid, uuid, int, int) from public, anon, authenticated;
