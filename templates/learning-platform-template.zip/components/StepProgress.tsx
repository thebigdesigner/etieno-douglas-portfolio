/**
 * Shown on every signup screen. People abandon forms they cannot see the end
 * of; three dots and a label costs nothing and removes that.
 */
export default function StepProgress({
  step, total, labels,
}: { step: number; total: number; labels: string[] }) {
  return (
    <div className="steps" role="group" aria-label={`Step ${step} of ${total}`}>
      <div className="steps__row">
        {Array.from({ length: total }, (_, i) => i + 1).map((n) => (
          <div key={n} className={`steps__seg${n < step ? " is-done" : n === step ? " is-now" : ""}`}>
            <span className="steps__dot">
              {n < step ? "✓" : n}
            </span>
            <span className="steps__label">{labels[n - 1]}</span>
          </div>
        ))}
      </div>
      <div className="steps__bar" aria-hidden="true">
        <span style={{ width: `${((step - 1) / (total - 1)) * 100}%` }} />
      </div>
    </div>
  );
}
