"use client";

import { useActionState } from "react";
import { announceUpdate } from "@/app/actions/marketplace";
import type { FormState } from "@/lib/forms";

const EMPTY: FormState = {};

/**
 * Shown on a live item that has buyers. The note is the whole point: an
 * email saying only "this was updated" makes the reader open their
 * library to work out whether they care.
 */
export default function AnnounceUpdate({ id, owners }: { id: string; owners: number }) {
  const [state, action, pending] = useActionState(announceUpdate, EMPTY);
  return (
    <form action={action} className="st-announce">
      <input type="hidden" name="id" value={id} />
      <p className="st-field__hint">
        {owners} {owners === 1 ? "person owns" : "people own"} this. If you have replaced the
        file, tell them what changed.
      </p>
      <textarea name="note" rows={3} maxLength={600} className="mk-rev__text"
        placeholder="Added a dark version and fixed the spacing on the pricing page." />
      <button className="mk-btn mk-btn--line mk-btn--wide" disabled={pending}>
        {pending ? "Sending…" : "Tell buyers about the update"}
      </button>
      {state.error && <p className="st-field__err" role="alert">{state.error}</p>}
      {state.ok && state.message && <p className="st-field__ok">{state.message}</p>}
    </form>
  );
}
