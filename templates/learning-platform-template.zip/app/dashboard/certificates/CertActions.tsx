"use client";
import Link from "next/link";
import { useState } from "react";

export default function CertActions({ code, url }: { code: string; url: string }) {
  const [copied, setCopied] = useState(false);

  return (
    <div className="cert__acts">
      <Link className="btn btn--fill" href={`/certificate/${code}`}>Download</Link>
      {/* The public page is what the share link points at, so a button
          beside it was two routes to the same place — and the one a learner
          wants is the link they can send, not a page they look at
          themselves. */}
      <button
        className="btn btn--line"
        onClick={() => {
          navigator.clipboard.writeText(url);
          setCopied(true);
          setTimeout(() => setCopied(false), 1800);
        }}
      >
        {copied ? "Link copied" : "Copy share link"}
      </button>
    </div>
  );
}
