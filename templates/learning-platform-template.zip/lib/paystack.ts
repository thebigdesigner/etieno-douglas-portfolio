import { createHmac, timingSafeEqual } from "crypto";

/**
 * Paystack — Your Brand's payment provider.
 *
 * Everything provider-specific lives here; the rest of the app talks in
 * courses, licences and users. Three Paystack rules this file absorbs so
 * callers never meet them:
 *
 *   - Amounts go over the wire in the currency's smallest unit (kobo,
 *     cents, pesewas). Callers pass the normal amount; toSubunit() converts.
 *   - References may only contain letters, digits, "-", "." and "=".
 *     newReference() makes one that fits; an underscore would be refused.
 *   - Webhooks are signed: x-paystack-signature is an HMAC-SHA512 of the raw
 *     request body keyed with the secret key. verifyWebhook() checks it.
 *
 * Currencies depend on the Paystack account, not on this code. A Nigerian
 * business account takes NGN by default; USD has to be requested and
 * approved in the dashboard before a USD checkout will go through.
 */

function secret() {
  const key = process.env.PAYSTACK_SECRET_KEY;
  if (!key) throw new Error("PAYSTACK_SECRET_KEY is not set");
  return key;
}

const API = "https://api.paystack.co";

/** Every supported currency uses 100 subunits; kept as a function so an exception has one place to go. */
function toSubunit(amount: number): number {
  return Math.round(amount * 100);
}

/** A Paystack-safe unique reference, e.g. "splari-courses-3f2a…". */
export function newReference(kind: string): string {
  const id = globalThis.crypto.randomUUID();
  return `splari-${kind.replace(/[^a-z0-9]+/gi, "-")}-${id}`;
}

export type CheckoutArgs = {
  txRef: string;
  /** The normal amount, e.g. 19.99 — not subunits. */
  amount: number;
  currency: string;
  email: string;
  name?: string | null;
  redirectUrl: string;
  meta?: Record<string, string>;
};

/** Starts a transaction and returns the hosted checkout URL to send the buyer to. */
export async function createCheckout(a: CheckoutArgs): Promise<string> {
  const res = await fetch(`${API}/transaction/initialize`, {
    method: "POST",
    headers: { Authorization: `Bearer ${secret()}`, "Content-Type": "application/json" },
    body: JSON.stringify({
      reference: a.txRef,
      amount: toSubunit(a.amount),
      currency: a.currency,
      email: a.email,
      callback_url: a.redirectUrl,
      metadata: {
        ...a.meta,
        ...(a.name ? { customer_name: a.name } : {}),
        // Where Paystack's "Cancel payment" button sends them. Without it
        // a cancelled buyer is left on Paystack's page with nowhere to go.
        cancel_action: `${a.redirectUrl}${a.redirectUrl.includes("?") ? "&" : "?"}status=cancelled`,
      },
    }),
  });

  const data = await res.json().catch(() => null);
  if (!res.ok || !data?.status || !data.data?.authorization_url) {
    console.error("paystack initialize failed", res.status, data?.message ?? data);
    throw new Error("Could not start checkout");
  }
  return data.data.authorization_url as string;
}

export type Verified = {
  ok: boolean;
  txRef: string;
  /** The normal amount, converted back from subunits. */
  amount: number;
  currency: string;
  providerRef: string;
  email: string | null;
};

/**
 * Confirms with Paystack directly. The redirect back and the webhook body
 * are both attacker-reachable; this call is not, so it is the only thing
 * fulfilment trusts.
 */
export async function verifyByReference(txRef: string): Promise<Verified | null> {
  const res = await fetch(`${API}/transaction/verify/${encodeURIComponent(txRef)}`, {
    headers: { Authorization: `Bearer ${secret()}` },
    cache: "no-store",
  });
  const body = await res.json().catch(() => null);
  if (!res.ok || !body?.status || !body.data) return null;

  const d = body.data;
  return {
    ok: d.status === "success",
    txRef: String(d.reference),
    amount: Number(d.amount) / 100,
    currency: String(d.currency),
    providerRef: String(d.id),
    email: d.customer?.email ?? null,
  };
}

/** True when the body really came from Paystack. Compare against the raw body, before parsing. */
export function verifyWebhook(rawBody: string, signature: string | null): boolean {
  if (!signature) return false;
  const expected = createHmac("sha512", secret()).update(rawBody).digest("hex");
  const a = Buffer.from(signature, "utf8");
  const b = Buffer.from(expected, "utf8");
  return a.length === b.length && timingSafeEqual(a, b);
}
