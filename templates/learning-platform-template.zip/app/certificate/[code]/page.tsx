import { notFound } from "next/navigation";
import { siteUrl } from "@/lib/site";
import { createAdminClient } from "@/lib/supabase/admin";
import PrintButton from "./PrintButton";

export const dynamic = "force-dynamic";

type Params = Promise<{ code: string }>;

export async function generateMetadata({ params }: { params: Params }) {
  const { code } = await params;
  return { title: `Certificate ${code}`, robots: { index: false, follow: false } };
}

/**
 * A printable certificate. Deliberately not a generated PDF — the browser's
 * own print-to-PDF produces a better result on every platform than a server
 * renderer, with no extra dependency and no font embedding to go wrong.
 */
export default async function CertificatePage({ params }: { params: Params }) {
  const { code } = await params;
  const admin = createAdminClient();

  const { data: cert } = await admin
    .from("certificates")
    .select("code, reviewer_name, kind, issued_at, revoked_at, enrolment_id, show_name")
    .eq("code", code.toUpperCase()).maybeSingle();

  if (!cert || cert.revoked_at) notFound();

  const { data: enrolment } = await admin
    .from("enrolments").select("user_id, course_id").eq("id", cert.enrolment_id).maybeSingle();

  const { data: course } = await admin
    .from("courses").select("title, subject").eq("id", enrolment!.course_id).maybeSingle();

  const { data: profile } = await admin
    .from("profiles").select("display_name").eq("id", enrolment!.user_id).maybeSingle();

  // Withheld where the holder has minor protections — see the note on the
  // verify page. The certificate is still valid and still verifiable.
  const shownName = cert?.show_name === false
    ? "Name withheld"
    : (profile?.display_name ?? "—");

  const base = siteUrl();

  return (
    <>
      <PrintButton />

      <div className="certdoc">
        <div className="certdoc__sheet">
          {/* The band carries the same artwork as the dashboard banner, so a
              certificate looks like it came from the same place as the course
              it is for. Cropped to a wide strip; the arcs read at any width. */}
          <header className="certdoc__band">
            <div className="certdoc__brandrow">
              <span className="certdoc__mark" aria-hidden="true">S.</span>
              <span className="certdoc__brand">Your Brand</span>
            </div>

            <h1 className="certdoc__title">Certificate</h1>
            <p className="certdoc__of">
              {cert.kind === "examined" ? "of examination" : "of assessed competence"}
            </p>

            <p className="certdoc__presented">This certificate is presented to</p>

            {/* A ribbon rather than a badge: the reference's award flag, saying
                the one thing that actually distinguishes the two kinds. */}
            <div className={`certdoc__ribbon${cert.kind === "examined" ? " is-exam" : ""}`}>
              <span>{cert.kind === "examined" ? "Examined" : "Assessed"}</span>
              <span className="certdoc__ribbontag">
                {cert.kind === "examined" ? "by exam" : "by a practitioner"}
              </span>
            </div>
          </header>

          <div className="certdoc__body">
            <div className="certdoc__main">
              <h2 className="certdoc__name">{shownName}</h2>

              <p className="certdoc__course">
                {cert.kind === "examined"
                  ? "for completing and passing the final examination in"
                  : "for completing and being assessed on"}{" "}
                <strong>{course?.title}</strong>
              </p>

              <p className="certdoc__blurb">
                {cert.kind === "examined"
                  ? `A ${course?.subject ?? ""} course on Your Brand, finished in full and passed at 80% or above on a closed final examination. Marked automatically; no practitioner assessed this work.`
                  : `A ${course?.subject ?? ""} course on Your Brand, finished in full, with a final project read and passed by a working practitioner against a published rubric.`}
              </p>

              <div className="certdoc__sigs">
                <div className="certdoc__sig">
                  <div className="certdoc__sigval num">
                    {new Date(cert.issued_at).toLocaleDateString("en-GB", {
                      day: "numeric", month: "long", year: "numeric",
                    })}
                  </div>
                  <div className="certdoc__sigline" />
                  <div className="certdoc__sigk">Date</div>
                </div>

                <div className="certdoc__sig">
                  {/* Only an assessed certificate has somebody to sign it. The
                      examined one keeps the slot so the two print alike, and
                      says plainly that nothing was signed. */}
                  <div className={`certdoc__sigval${cert.kind === "examined" ? " is-none" : " is-name"}`}>
                    {cert.kind === "examined" ? "No signatory" : cert.reviewer_name}
                  </div>
                  <div className="certdoc__sigline" />
                  <div className="certdoc__sigk">
                    {cert.kind === "examined" ? "Marked automatically" : "Assessed by"}
                  </div>
                </div>
              </div>
            </div>

            <aside className="certdoc__side">
              <div className="certdoc__code">
                <div className="certdoc__codek">Certificate code</div>
                <div className="certdoc__codev num">{cert.code}</div>
              </div>
              <p className="certdoc__verify">
                Anyone can check this at<br />{base}/verify/{cert.code}
              </p>
            </aside>
          </div>
        </div>
      </div>
    </>
  );
}
