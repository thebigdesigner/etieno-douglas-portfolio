"use client";

import { useOptimistic, useTransition } from "react";
import { usePathname, useRouter, useSearchParams } from "next/navigation";

export type Tab = { label: string; value: string; count: number };

/**
 * Counts in the tab labels. Somebody with nothing saved should be able to see
 * that without clicking into an empty list.
 *
 * Switching used to be a plain <Link>. The page is force-dynamic and runs four
 * queries plus an RPC per row, so a tab click sat on the old tab with nothing
 * happening for as long as that took, then swapped. It read as a hang.
 *
 * Now the highlight moves the instant it is clicked (useOptimistic) while the
 * navigation runs inside a transition, so the old list stays on screen —
 * faded, not blank — until the new one is ready. Nothing unmounts and nothing
 * jumps.
 */
export default function DashTabs({ tabs }: { tabs: Tab[] }) {
  const pathname = usePathname();
  const params = useSearchParams();
  const router = useRouter();
  const [pending, startTransition] = useTransition();

  const current = params.get("view") ?? tabs[0].value;
  const [shown, setShown] = useOptimistic(current);

  function go(value: string) {
    if (value === current) return;
    const href = value === tabs[0].value ? pathname : `${pathname}?view=${value}`;
    startTransition(() => {
      setShown(value);
      router.push(href, { scroll: false });
    });
  }

  return (
    <nav className="dtabs" data-pending={pending ? "" : undefined}>
      {tabs.map((t) => (
        <button
          key={t.value}
          type="button"
          onClick={() => go(t.value)}
          className={`dtab${shown === t.value ? " is-on" : ""}`}
          aria-current={shown === t.value ? "page" : undefined}
        >
          {t.label} <span className="dtab__n num">({t.count})</span>
        </button>
      ))}
    </nav>
  );
}
