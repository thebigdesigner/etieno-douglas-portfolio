/**
 * How far through setting up their account somebody is.
 *
 * This lived inline in AccountForms. The dashboard needs the same answer,
 * and two copies of a checklist is two checklists that disagree by the third
 * time somebody edits one — so it moved here and both read it.
 *
 * Every step is computed from what is actually true of the account. A
 * checklist that can drift from reality is decoration, not progress.
 *
 * Note what this is NOT: it is not course progress. The dashboard card used
 * to show "80% of your topics done" under a "Complete profile" button, which
 * is two unrelated numbers wearing each other's labels.
 */

export type ProfileStep = {
  label: string;
  /** What finishing this step is worth, out of 100. */
  pct: number;
  done: boolean;
  /** Where to go to finish it. */
  href: string;
};

export type ProfileState = {
  displayName: string;
  email: string | null;
  avatarPath: string | null;
  enrolments: number;
  subscribed: boolean;
  certificates: number;
};

export function profileSteps(s: ProfileState): ProfileStep[] {
  return [
    { label: "Create your account", pct: 10, done: true, href: "/dashboard/account" },
    { label: "Set your name", pct: 10, done: s.displayName.trim().length > 1, href: "/dashboard/account" },
    { label: "Upload a photo", pct: 15, done: !!s.avatarPath, href: "/dashboard/account" },
    { label: "Email on the account", pct: 15, done: s.email !== null, href: "/dashboard/account" },
    { label: "Start a course", pct: 20, done: s.enrolments > 0, href: "/courses" },
    { label: "Buy your first course", pct: 20, done: s.subscribed, href: "/courses" },
    { label: "Earn a certificate", pct: 10, done: s.certificates > 0, href: "/dashboard/submissions" },
  ];
}

export function profileProgress(s: ProfileState) {
  const steps = profileSteps(s);
  const pct = steps.reduce((n, step) => n + (step.done ? step.pct : 0), 0);
  const remaining = steps.filter((step) => !step.done);

  return {
    steps,
    pct,
    remaining,
    /** Nothing left to prompt about, so the prompt should stop appearing. */
    complete: remaining.length === 0,
  };
}
