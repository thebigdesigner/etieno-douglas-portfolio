"use client";
import { useActionState, useState } from "react";
import { recordReview } from "@/app/actions/review";
import type { FormState } from "@/lib/forms";
import SubmitButton from "@/components/SubmitButton";
import Alert from "@/components/Alert";

type Criterion = { id: string; title: string; descriptor: string; max_score: number };

const initial: FormState = {};

export default function ReviewForm({
  submissionId, criteria,
}: { submissionId: string; criteria: Criterion[] }) {
  const bound = recordReview.bind(null, submissionId);
  const [state, action] = useActionState(bound, initial);
  const [outcome, setOutcome] = useState<string>("");

  return (
    <form action={action} className="rvw__form">
      <h2 className="sub__h2">Your assessment</h2>

      {criteria.length > 0 && (
        <div className="rvw__criteria">
          {criteria.map((c) => (
            <fieldset key={c.id} className="rvw__crit">
              <legend className="rvw__critt">{c.title}</legend>
              <p className="rvw__critd">{c.descriptor}</p>
              <div className="rvw__scale">
                {Array.from({ length: c.max_score }, (_, i) => i + 1).map((n) => (
                  <label key={n} className="rvw__score">
                    <input type="radio" name={`score_${c.id}`} value={n} required />
                    <span>{n}</span>
                  </label>
                ))}
              </div>
            </fieldset>
          ))}
        </div>
      )}

      <div className="rvw__verdict">
        <span className="field__label">Verdict</span>
        <div className="rvw__vopts">
          <label className={`rvw__v${outcome === "pass" ? " is-on" : ""}`}>
            <input type="radio" name="outcome" value="pass" required
              onChange={() => setOutcome("pass")} />
            <span>
              <strong>Pass</strong>
              <em>Certificate issues with your name on it</em>
            </span>
          </label>
          <label className={`rvw__v${outcome === "revise" ? " is-on" : ""}`}>
            <input type="radio" name="outcome" value="revise" required
              onChange={() => setOutcome("revise")} />
            <span>
              <strong>Needs changes</strong>
              <em>They get one free resubmission</em>
            </span>
          </label>
        </div>
      </div>

      <label className="field">
        <span className="field__label">Written feedback</span>
        <textarea name="feedback" rows={10} required minLength={80}
          placeholder={
            outcome === "revise"
              ? "List the specific changes needed, against the rubric."
              : "What was strong, and what would make it stronger next time."
          } />
        <span className="field__hint">
          Specific to the work in front of you. A generic paragraph is not a review.
        </span>
      </label>

      {state.error && <Alert kind="error">{state.error}</Alert>}

      <SubmitButton>Record assessment</SubmitButton>
    </form>
  );
}
