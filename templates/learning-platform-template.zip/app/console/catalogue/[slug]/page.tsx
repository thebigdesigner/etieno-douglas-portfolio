import { requireOwner } from "@/lib/owner";
import CourseScreen from "@/app/studio/[slug]/CourseScreen";

export const dynamic = "force-dynamic";
export const metadata = { robots: { index: false, follow: false } };

type Params = Promise<{ slug: string }>;

/**
 * The same editor, inside the console's shell.
 *
 * requireOwner rather than the studio's instructor guard: this route exists
 * for staff editing a course Your Brand owns, and the guard is what makes the
 * route different from the studio's, not the screen.
 */
export default async function ConsoleCoursePage({ params }: { params: Params }) {
  await requireOwner();
  const { slug } = await params;
  return <CourseScreen slug={slug} backHref="/console/catalogue" backLabel="Catalogue" />;
}
