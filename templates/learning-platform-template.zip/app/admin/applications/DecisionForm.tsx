"use client";
import { useActionState } from "react";
import { decideApplication } from "@/app/actions/studio";
import type { FormState } from "@/lib/forms";
import { useFormStatus } from "react-dom";
import Alert from "@/components/Alert";

const initial: FormState = {};

function Btn({ label, variant }: { label: string; variant: string }) {
  const { pending } = useFormStatus();
  return (
    <button className={`btn ${variant}`} disabled={pending}>
      {pending ? "…" : label}
    </button>
  );
}

export default function DecisionForm({ instructorId }: { instructorId: string }) {
  const [approveState, approve] = useActionState(
    decideApplication.bind(null, instructorId, true), initial
  );
  const [rejectState, reject] = useActionState(
    decideApplication.bind(null, instructorId, false), initial
  );
  const done = approveState.ok || rejectState.ok;

  if (done) {
    return (
      <Alert kind="success">
        {approveState.message ?? rejectState.message}
      </Alert>
    );
  }

  return (
    <div className="app__decide">
      <form action={approve}><Btn label="Approve" variant="btn--fill" /></form>
      <form action={reject} className="app__reject">
        <input name="note" placeholder="Reason (sent to them)" />
        <Btn label="Decline" variant="btn--line" />
      </form>
      {(approveState.error || rejectState.error) && (
        <Alert kind="error">{approveState.error ?? rejectState.error}</Alert>
      )}
    </div>
  );
}
