-- ============================================================================
-- One-off repair: seats left unsellable by the old unique (trip_id, seat_no)
-- ============================================================================
-- Run once, after db/schema.sql has replaced that constraint with
-- passengers_seat_live_idx. Safe to re-run: every statement only touches rows
-- that are already inconsistent, so a second run reports 0.
--
-- Why this is needed. Nothing ever deletes a passenger row. A booking that was
-- cancelled, refunded or left to expire freed its seat in trip_seats but kept a
-- passengers row, and until now that row owned (trip_id, seat_no) outright. The
-- new partial index only excludes rows already marked 'cancelled' -- and
-- expire_holds never marked them, it only moved the booking to 'expired'. So
-- every seat abandoned mid-booking before today is still spoken for by a
-- 'reserved' row belonging to a booking that no longer exists in any real sense.
--
-- The fixed expire_holds retires passenger rows going forward. This retires the
-- ones already stranded.

-- 1. Passenger rows still counted as live, on bookings that are not.
update passengers p
   set status = 'cancelled'
  from bookings b
 where p.booking_id = b.id
   and p.status in ('reserved', 'confirmed')
   and b.status in ('cancelled', 'expired', 'refunded', 'no_show');

-- 2. Passenger rows on a pending booking whose hold lapsed long ago. These are
--    the abandoned baskets: the customer picked a seat and never paid.
update passengers p
   set status = 'cancelled'
  from bookings b
 where p.booking_id = b.id
   and p.status = 'reserved'
   and b.status = 'pending'
   and b.hold_expires_at is not null
   and b.hold_expires_at < now();

-- 3. Seats still held or sold against a booking that is no longer live.
update trip_seats ts
   set state = 'free', booking_id = null, held_until = null, updated_at = now()
  from bookings b
 where ts.booking_id = b.id
   and ts.state in ('held', 'sold')
   and b.status in ('cancelled', 'expired', 'refunded');

-- 4. Holds that simply lapsed and were never swept.
update trip_seats
   set state = 'free', booking_id = null, held_until = null, updated_at = now()
 where state = 'held'
   and held_until is not null
   and held_until < now();

-- 5. Bookings whose hold lapsed but were never moved off 'pending'.
update bookings
   set status = 'expired', hold_expires_at = null
 where status = 'pending'
   and hold_expires_at is not null
   and hold_expires_at < now();

-- What is left unsellable, if anything. Expect no rows.
-- The predicate matches passengers_seat_live_idx: only these four statuses hold a seat.
-- 'no_show' and 'cancelled' are finished -- the row stays as the record of what happened,
-- but it no longer stops the seat being sold again.
select t.depart_date, t.depart_time, ts.seat_no, ts.state as seat_state,
       p.status as passenger_status, b.status as booking_status, b.reference
  from trip_seats ts
  join trips t       on t.id = ts.trip_id
  join passengers p  on p.trip_id = ts.trip_id and p.seat_no = ts.seat_no
  left join bookings b on b.id = p.booking_id
 where ts.state = 'free'
   and p.status in ('reserved', 'confirmed', 'checked_in', 'boarded')
   and t.depart_date >= current_date
 order by t.depart_date, t.depart_time, ts.seat_no;
