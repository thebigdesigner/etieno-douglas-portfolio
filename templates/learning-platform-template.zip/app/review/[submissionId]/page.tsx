import Link from "next/link";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { isOwnerEmail } from "@/lib/owner";
import { slaLabel } from "@/lib/sla";
import ReviewForm from "./ReviewForm";

export const metadata = { title: "Assess a project" };
export const dynamic = "force-dynamic";

type Params = Promise<{ submissionId: string }>;

export default async function ReviewPage({ params }: { params: Params }) {
  const { submissionId } = await params;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) notFound();

  const admin = createAdminClient();

  const { data: sub } = await admin
    .from("submissions")
    .select("id, body, file_paths, state, attempt_no, submitted_at, deadline_at, enrolment_id, assigned_reviewer_id")
    .eq("id", submissionId)
    .maybeSingle();
  if (!sub) notFound();

  // Role alone isn't enough: this is a specific learner's private work, and
  // the id in the URL is just a client-supplied identifier. Only the
  // instructor this was assigned to (or an operator) may open it.
  const { data: profile } = await admin
    .from("profiles").select("role").eq("id", user.id).maybeSingle();
  const operator = profile?.role === "operator" || isOwnerEmail(user.email);
  if (!operator && sub.assigned_reviewer_id !== user.id) notFound();

  const { data: enrolment } = await admin
    .from("enrolments").select("user_id, course_id").eq("id", sub.enrolment_id).maybeSingle();

  const { data: course } = await admin
    .from("courses").select("id, title, project_brief").eq("id", enrolment!.course_id).maybeSingle();

  const { data: learner } = await admin
    .from("profiles").select("display_name")
    .eq("id", enrolment!.user_id).maybeSingle();

  const { data: criteria } = await admin
    .from("rubric_criteria").select("id, title, descriptor, max_score")
    .eq("course_id", course!.id).order("position");

  // Previous attempt, so the reviewer can see what was asked for.
  const { data: prior } = await admin
    .from("reviews")
    .select("outcome, feedback, completed_at, submissions!inner(enrolment_id, attempt_no)")
    .eq("submissions.enrolment_id", sub.enrolment_id)
    .order("completed_at", { ascending: false })
    .limit(1);

  // Signed links, valid for an hour. The bucket itself is private.
  const files = await Promise.all(
    (sub.file_paths ?? []).map(async (path: string) => {
      const { data } = await admin.storage.from("submissions").createSignedUrl(path, 3600);
      return { name: path.split("/").pop() ?? "attachment", url: data?.signedUrl ?? null };
    })
  );

  const decided = sub.state === "passed" || sub.state === "revision_requested";

  return (
    <div className="rvw">
        <nav className="crumb"><Link href="/review">Review queue</Link> / Assessing</nav>

        <div className="rvw__head">
          <div>
            <h1 className="rvw__h">{course!.title}</h1>
            <p className="rvw__meta">
              {learner?.display_name ?? "Learner"}
              {sub.attempt_no > 1 && <span className="pill" style={{ marginLeft: 8 }}>Attempt {sub.attempt_no}</span>}
            </p>
          </div>
          <div className={`rvw__clock${new Date(sub.deadline_at) < new Date() ? " is-late" : ""}`}>
            {slaLabel(sub.deadline_at)}
          </div>
        </div>

        {prior && prior.length > 0 && (
          <div className="rvw__prior">
            <div className="eyebrow">What was asked for last time</div>
            <p className="rvw__priorp">{prior[0].feedback}</p>
          </div>
        )}

        <section className="rvw__brief">
          <div className="eyebrow">The brief they were given</div>
          <p className="rvw__briefp">{course!.project_brief}</p>
        </section>

        <section className="rvw__work">
          <h2 className="sub__h2">Their submission</h2>
          <div className="rvw__body">{sub.body}</div>

          {files.length > 0 && (
            <div className="rvw__files">
              {files.map((f) => (
                <a key={f.name} className="rvw__file" href={f.url ?? "#"} target="_blank" rel="noreferrer">
                  {f.name}
                </a>
              ))}
            </div>
          )}
        </section>

        {decided ? (
          <div className="underreview" style={{ marginTop: 30 }}>
            <p className="underreview__h">Already assessed</p>
            <p className="underreview__p">
              This submission has a verdict recorded. Nothing further to do.
            </p>
          </div>
        ) : (
          <ReviewForm submissionId={submissionId} criteria={criteria ?? []} />
        )}
    </div>
  );
}
