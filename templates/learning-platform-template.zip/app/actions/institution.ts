"use server";

import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import type { FormState } from "@/lib/forms";

async function requireRole(roles: string[]) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const admin = createAdminClient();
  const { data: profile } = await admin
    .from("profiles").select("role").eq("id", user.id).maybeSingle();

  if (!profile || !roles.includes(profile.role)) redirect("/dashboard");
  return { userId: user.id, role: profile.role };
}

/** The institution the signed-in admin belongs to. */
async function myInstitution(userId: string) {
  const admin = createAdminClient();
  const { data } = await admin
    .from("institution_members").select("institution_id").eq("user_id", userId).maybeSingle();
  return data?.institution_id ?? null;
}

/**
 * Role AND ownership. A role check alone lets any institution_admin act on
 * any cohort, since cohortId is just a client-supplied identifier once past
 * that gate. Operators can act on any institution's cohorts.
 */
async function requireCohortAccess(cohortId: string): Promise<{ userId: string; role: string }> {
  const { userId, role } = await requireRole(["institution_admin", "operator"]);
  if (role === "operator") return { userId, role };

  const institutionId = await myInstitution(userId);
  if (!institutionId) redirect("/institution");

  const admin = createAdminClient();
  const { data: cohort } = await admin
    .from("cohorts").select("id").eq("id", cohortId).eq("institution_id", institutionId).maybeSingle();

  if (!cohort) redirect("/institution");
  return { userId, role };
}

/* ------------------------------------------------------------------ */
/* Cohorts                                                             */
/* ------------------------------------------------------------------ */
export async function createCohort(_prev: FormState, formData: FormData): Promise<FormState> {
  const { userId } = await requireRole(["institution_admin", "operator"]);
  const institutionId = await myInstitution(userId);
  if (!institutionId) return { error: "Your account is not linked to an institution yet." };

  const gate = createAdminClient();
  const { data: canEnrol } = await gate.rpc("institution_can_enrol", {
    p_institution_id: institutionId,
  });
  if (!canEnrol) {
    return {
      error: "Your organisation needs to be verified before you can enrol learners. It usually takes two working days.",
    };
  }

  const name = String(formData.get("name") ?? "").trim();
  const startsOn = String(formData.get("starts_on") ?? "");
  const endsOn = String(formData.get("ends_on") ?? "");
  const ceiling = Number(formData.get("seat_ceiling") ?? 0);
  const courseIds = formData.getAll("courses").map(String);

  if (name.length < 3) return { error: "Give the cohort a name your staff will recognise." };
  if (!startsOn || !endsOn) return { error: "Set the start and end dates." };
  if (new Date(endsOn) <= new Date(startsOn)) return { error: "The end date must be after the start." };
  if (!Number.isInteger(ceiling) || ceiling < 1 || ceiling > 2000) {
    return { error: "Set a seat ceiling between 1 and 2000." };
  }
  if (courseIds.length === 0) return { error: "Choose at least one course." };

  const admin = createAdminClient();
  const code =
    "SPL-" + Math.random().toString(36).slice(2, 6).toUpperCase() +
    Math.random().toString(36).slice(2, 4).toUpperCase();

  const { data: institution } = await admin
    .from("institutions").select("plan").eq("id", institutionId).maybeSingle();

  const { data: cohort, error } = await admin
    .from("cohorts")
    .insert({
      institution_id: institutionId, name, class_code: code,
      plan: institution?.plan ?? "plus", seat_ceiling: ceiling,
      starts_on: startsOn, ends_on: endsOn, state: "active",
    })
    .select("id").maybeSingle();

  if (error || !cohort) return { error: "Could not create the cohort. Please try again." };

  await admin.from("cohort_courses").insert(
    courseIds.map((course_id) => ({ cohort_id: cohort.id, course_id }))
  );

  // Seats are provisioned up front: a class code alone gets nobody in.
  await admin.rpc("provision_seats", { p_cohort_id: cohort.id, p_count: ceiling });

  redirect(`/institution/cohorts/${cohort.id}`);
  return {};
}

export async function addSeats(
  cohortId: string, _prev: FormState, formData: FormData
): Promise<FormState> {
  await requireCohortAccess(cohortId);
  const count = Number(formData.get("count") ?? 0);
  if (!Number.isInteger(count) || count < 1 || count > 500) {
    return { error: "Between 1 and 500 at a time." };
  }

  const admin = createAdminClient();
  const { data: added } = await admin.rpc("provision_seats", {
    p_cohort_id: cohortId, p_count: count,
  });

  revalidatePath(`/institution/cohorts/${cohortId}`);
  if (!added) return { error: "The cohort is already at its seat ceiling. Raise it first." };
  return { ok: true, message: `${added} more username${added === 1 ? "" : "s"} issued.` };
}

export async function raiseCeiling(
  cohortId: string, _prev: FormState, formData: FormData
): Promise<FormState> {
  await requireCohortAccess(cohortId);
  const ceiling = Number(formData.get("seat_ceiling") ?? 0);
  if (!Number.isInteger(ceiling) || ceiling < 1 || ceiling > 2000) {
    return { error: "Between 1 and 2000." };
  }

  const admin = createAdminClient();
  await admin.from("cohorts").update({ seat_ceiling: ceiling }).eq("id", cohortId);
  revalidatePath(`/institution/cohorts/${cohortId}`);
  return { ok: true, message: "Ceiling updated." };
}

export async function regenerateCode(cohortId: string): Promise<void> {
  await requireCohortAccess(cohortId);
  const admin = createAdminClient();
  const code =
    "SPL-" + Math.random().toString(36).slice(2, 6).toUpperCase() +
    Math.random().toString(36).slice(2, 4).toUpperCase();
  await admin.from("cohorts").update({ class_code: code }).eq("id", cohortId);
  revalidatePath(`/institution/cohorts/${cohortId}`);
}

export async function resetPin(seatId: string, cohortId: string): Promise<void> {
  await requireCohortAccess(cohortId);
  const admin = createAdminClient();

  // The cohort check above only proves cohortId is theirs — confirm the
  // seat being reset actually belongs to that same cohort, not a mismatched
  // id for someone else's.
  const { data: seat } = await admin
    .from("cohort_seats").select("id").eq("id", seatId).eq("cohort_id", cohortId).maybeSingle();
  if (!seat) redirect("/institution");

  await admin.rpc("reset_seat_pin", { p_seat_id: seatId });
  revalidatePath(`/institution/cohorts/${cohortId}`);
}

export async function endCohort(cohortId: string): Promise<void> {
  await requireCohortAccess(cohortId);
  const admin = createAdminClient();
  await admin.from("cohorts").update({ state: "ended" }).eq("id", cohortId);
  revalidatePath("/institution");
}

/* ------------------------------------------------------------------ */
/* Operator                                                            */
/* ------------------------------------------------------------------ */
export async function reassignToReserve(
  submissionId: string, _prev: FormState, formData: FormData
): Promise<FormState> {
  const { userId } = await requireRole(["operator"]);
  const reserveId = String(formData.get("reserve_id") ?? "");
  if (!reserveId) return { error: "Choose a reserve reviewer." };

  const admin = createAdminClient();
  // The actor is passed so an operator can take the work themselves:
  // eligible_assessors reads the role column and cannot see the
  // OWNER_EMAILS allowlist, so it would not otherwise list them.
  const { data: ok } = await admin.rpc("reassign_to_reserve", {
    p_submission_id: submissionId, p_reserve_id: reserveId, p_actor: userId,
  });

  revalidatePath("/admin/sla");
  if (!ok) {
    return {
      error:
        "Could not reassign that. Either it has already been assessed, or that person cannot take this course — an institution's work stays inside the institution.",
    };
  }
  return { ok: true, message: "Reassigned. The learner is unaffected." };
}

export async function issueInvoice(
  institutionId: string, _prev: FormState, formData: FormData
): Promise<FormState> {
  await requireRole(["operator"]);
  const month = String(formData.get("month") ?? "");
  if (!month) return { error: "Choose a month." };

  const admin = createAdminClient();
  const { data, error } = await admin.rpc("generate_invoice", {
    p_institution_id: institutionId, p_month: `${month}-01`,
  });

  if (error) return { error: "Could not generate the invoice." };
  const row = (data ?? [])[0] as { active_count: number; amount_cents: number } | undefined;

  revalidatePath("/admin/institutions");
  return {
    ok: true,
    message: `Invoiced ${row?.active_count ?? 0} active learners — $${((row?.amount_cents ?? 0) / 100).toFixed(2)}.`,
  };
}

export async function runPoolCalculation(_prev: FormState, formData: FormData): Promise<FormState> {
  await requireRole(["operator"]);

  const month = String(formData.get("month") ?? "");
  const source = String(formData.get("source") ?? "");
  const revenue = Math.round(Number(formData.get("revenue") ?? 0) * 100);

  if (!month) return { error: "Choose a month." };
  if (source !== "individual" && source !== "institution") return { error: "Choose a revenue source." };
  if (!Number.isFinite(revenue) || revenue <= 0) return { error: "Enter the revenue for that month." };

  const admin = createAdminClient();
  const { error } = await admin.rpc("calculate_pool", {
    p_month: `${month}-01`, p_source: source, p_revenue_cents: revenue,
  });

  if (error) return { error: "Could not calculate the pool." };

  revalidatePath("/admin/payouts");
  return { ok: true, message: "Pool calculated and credited to instructors." };
}

export async function runPayouts(_prev: FormState, formData: FormData): Promise<FormState> {
  await requireRole(["operator"]);
  const week = String(formData.get("week") ?? "");
  if (!week) return { error: "Choose a week." };

  const admin = createAdminClient();
  const { data, error } = await admin.rpc("run_payouts", {
    p_week_start: week, p_threshold_cents: 2000,
  });

  if (error) return { error: "Could not run payouts." };

  revalidatePath("/admin/payouts");
  return { ok: true, message: `${data ?? 0} instructor balance${data === 1 ? "" : "s"} prepared.` };
}
