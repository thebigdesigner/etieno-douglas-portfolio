import Link from "next/link";
import { createAdminClient } from "@/lib/supabase/admin";
import { requireOwner } from "@/lib/owner";
import RevokeForm from "./RevokeForm";

export const metadata = { title: "Integrity" };
export const dynamic = "force-dynamic";

export default async function IntegrityPage() {
  await requireOwner();
  const admin = createAdminClient();

  const [{ data: health }, { data: reviewers }, { data: recent }, { data: revoked },
         { data: crons }] =
    await Promise.all([
      admin.from("review_health").select("*").maybeSingle(),
      admin.from("instructor_ledger").select("*")
        .order("reviews_late", { ascending: false }).limit(10),
      admin.from("certificates")
        .select("code, kind, reviewer_name, issued_at, enrolment_id")
        .is("revoked_at", null)
        .order("issued_at", { ascending: false }).limit(10),
      admin.from("certificates")
        .select("code, revoke_reason, revoked_at")
        .not("revoked_at", "is", null)
        .order("revoked_at", { ascending: false }).limit(10),
      admin.from("cron_health").select("*").order("job"),
    ]);

  const h = (health ?? {}) as Record<string, number | null>;
  const slaPct = Number(h.sla_pct ?? 0);
  const passRate = Number(h.reviews_total ?? 0) > 0
    ? Math.round((Number(h.passed ?? 0) / Number(h.reviews_total)) * 100)
    : null;

  const late = (reviewers ?? []).filter((r) => Number(r.reviews_late) > 0);

  return (
    <>
      <div className="con__head">
        <div>
          <h1 className="con__h">Integrity</h1>
          <p className="con__sub">
            The credential is the product. This page is whether it still means what we
            say it means.
          </p>
        </div>
      </div>

      <div className="kpis">
        <div className="kpi">
          <div className="eyebrow">Within four days</div>
          <div className={`kpi__v num${slaPct < 90 && Number(h.reviews_total ?? 0) > 5 ? " is-bad" : ""}`}>
            {h.sla_pct ?? "—"}%
          </div>
          <div className="kpi__s">{h.within_sla ?? 0} of {h.reviews_total ?? 0}</div>
        </div>
        <div className="kpi">
          <div className="eyebrow">Average turnaround</div>
          <div className="kpi__v num">{h.avg_hours ?? "—"}h</div>
          <div className="kpi__s">From submission to verdict</div>
        </div>
        <div className="kpi">
          <div className="eyebrow">Pass rate</div>
          <div className={`kpi__v num${passRate !== null && passRate > 95 ? " is-warn" : ""}`}>
            {passRate ?? "—"}%
          </div>
          <div className="kpi__s">{h.revised ?? 0} asked for changes</div>
        </div>
        <div className="kpi">
          <div className="eyebrow">Appeals</div>
          <div className="kpi__v num">{h.appeals ?? 0}</div>
          <div className="kpi__s">{h.appeals_upheld ?? 0} overturned</div>
        </div>
      </div>

      {passRate !== null && passRate > 95 && Number(h.reviews_total ?? 0) > 10 && (
        <div className="alerts">
          <div className="alert alert--warn">
            <span>
              Almost everything passes. Either the projects are too easy or reviewers are
              being generous — both make the certificate mean less.
            </span>
          </div>
        </div>
      )}

      {slaPct < 90 && Number(h.reviews_total ?? 0) > 5 && (
        <div className="alerts">
          <div className="alert alert--bad">
            <span>Under the 90% gate. The four-day promise is on every page of the site.</span>
            <Link className="alert__go" href="/admin/sla">Open the monitor &rarr;</Link>
          </div>
        </div>
      )}

        {/* Scheduled work.
          First on the page because silence is the failure this product has
          actually suffered: CRON_SECRET was unset, every run returned 401, and no
          certificate email, SLA warning or digest sent for months. Nothing
          looked wrong, because a cron with nothing to do and a cron being
          turned away are identical from outside. They are not identical
          here — "Rejected" means the scheduler is calling with the wrong
          secret, "Never run" means it is not calling at all. */}
      <section className="con__sec">
        <h2 className="con__h2">Scheduled work</h2>
        <table className="tbl" style={{ marginTop: 14 }}>
          <thead>
            <tr><th>Job</th><th>Expected</th><th>Last run</th><th>Result</th><th></th></tr>
          </thead>
          <tbody>
            {(crons ?? []).map((c) => {
              const never = !c.last_run_at;
              const bad = c.overdue || c.last_outcome === "failed" || c.last_outcome === "unauthorised";
              return (
                <tr key={c.job}>
                  <td>{c.label}</td>
                  <td className="num" style={{ opacity: 0.7 }}>{c.schedule}</td>
                  <td className="num">
                    {never ? "—" : new Date(c.last_run_at as string).toLocaleString()}
                  </td>
                  <td>
                    <span className={`pill${!bad ? " pill--free" : ""}`}
                          style={bad ? { background: "#FFE4EC", color: "#9B1B41" } : undefined}>
                      {never ? "Never run"
                        : c.last_outcome === "unauthorised" ? "Rejected — wrong secret"
                        : c.last_outcome === "failed" ? "Failed"
                        : c.overdue ? "Overdue" : "OK"}
                    </span>
                  </td>
                  <td className="num" style={{ opacity: 0.7, fontSize: 12 }}>
                    {c.error
                      ? c.error.slice(0, 60)
                      : c.detail
                        ? Object.entries(c.detail as Record<string, unknown>)
                            .map(([k, v]) => `${k} ${v}`).join(" · ")
                        : ""}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        {(crons ?? []).some((c) => !c.last_run_at) && (
          <p className="studio__hint" style={{ marginTop: 12 }}>
            A job that has never run means the scheduler is not reaching it at all —
            check the Vercel cron configuration. A job showing <em>Rejected</em> means it
            is reaching it, but <code>CRON_SECRET</code> does not match.
          </p>
        )}
      </section>

      {late.length > 0 && (
        <section className="con__sec">
          <h2 className="con__h2">Reviewers running late</h2>
          <p className="studio__hint">
            The promise is ours, not theirs. Cap their concurrent enrolments before it
            becomes a learner&rsquo;s problem.
          </p>
          <table className="tbl" style={{ marginTop: 16 }}>
            <thead><tr><th>Reviewer</th><th>Assessments</th><th>Late</th><th>Rate</th></tr></thead>
            <tbody>
              {late.map((r) => (
                <tr key={r.id}>
                  <td>{r.display_name ?? r.email}</td>
                  <td className="num">{r.reviews_done}</td>
                  <td className="num" style={{ color: "#9B2C22" }}>{r.reviews_late}</td>
                  <td className="num">
                    {Math.round((1 - Number(r.reviews_late) / Number(r.reviews_done || 1)) * 100)}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      )}

      <section className="con__sec">
        <h2 className="con__h2">Revoke a certificate</h2>
        <p className="studio__hint">
          For work that turns out not to have been theirs. The public verification page
          says revoked rather than going blank, and the reason is recorded.
        </p>
        <RevokeForm />
      </section>

      <section className="con__sec">
        <h2 className="con__h2">Recently issued</h2>
        {(!recent || recent.length === 0) ? (
          <p className="studio__hint">None yet.</p>
        ) : (
          <table className="tbl">
            <thead><tr><th>Code</th><th>Kind</th><th>Assessed by</th><th>Issued</th></tr></thead>
            <tbody>
              {recent.map((c) => (
                <tr key={c.code}>
                  <td className="num">
                    <Link href={`/verify/${c.code}`}>{c.code}</Link>
                  </td>
                  <td>
                    <span className={`pill${c.kind === "assessed" ? " pill--free" : ""}`}>
                      {c.kind === "assessed" ? "Assessed" : "Examined"}
                    </span>
                  </td>
                  {/* An examined certificate has no reviewer — nobody assessed
                      it, which is the whole distinction between the two kinds.
                      Printing the column unguarded left a blank cell that read
                      as missing data rather than as the intended answer. */}
                  <td>{c.kind === "assessed" ? (c.reviewer_name ?? "—") : "Nobody — exam only"}</td>
                  <td>{new Date(c.issued_at).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>

      {revoked && revoked.length > 0 && (
        <section className="con__sec">
          <h2 className="con__h2">Revoked</h2>
          <table className="tbl">
            <thead><tr><th>Code</th><th>Reason</th><th>When</th></tr></thead>
            <tbody>
              {revoked.map((c) => (
                <tr key={c.code}>
                  <td className="num">{c.code}</td>
                  <td>{c.revoke_reason}</td>
                  <td>{c.revoked_at && new Date(c.revoked_at).toLocaleDateString()}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </section>
      )}
    </>
  );
}
