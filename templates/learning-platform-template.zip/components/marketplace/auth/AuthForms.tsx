"use client";

import Link from "next/link";
import { useActionState, useState } from "react";
import { useFormStatus } from "react-dom";
import { mkGoogle, mkLogin, mkRequestReset, mkSetPassword, mkSignup } from "@/app/actions/marketplace-auth";
import type { FormState } from "@/lib/forms";

function Submit({ children }: { children: React.ReactNode }) {
  const { pending } = useFormStatus();
  return (
    <button type="submit" className="mk-btn mk-btn--fill mk-btn--wide" disabled={pending} aria-busy={pending}>
      {pending ? "One moment…" : children}
    </button>
  );
}

function Msg({ s }: { s: FormState }) {
  if (s.error) return <p className="au__msg au__msg--err" role="alert">{s.error}</p>;
  if (s.ok && s.message) return <p className="au__msg au__msg--ok" role="status">{s.message}</p>;
  return null;
}

function Password({ name = "password", label = "Password", auto, hint }: {
  name?: string; label?: string; auto: "current-password" | "new-password"; hint?: string;
}) {
  const [show, setShow] = useState(false);
  return (
    <label className="st-field">
      <span className="st-field__label au__labrow">
        {label}
        <button type="button" className="au__show" onClick={() => setShow((v) => !v)} aria-pressed={show}>
          {show ? "Hide" : "Show"}
        </button>
      </span>
      <input name={name} type={show ? "text" : "password"} required minLength={auto === "new-password" ? 8 : 1}
        autoComplete={auto} />
      {hint && <span className="st-field__hint">{hint}</span>}
    </label>
  );
}

export function GoogleButton({ next }: { next: string }) {
  return (
    <form action={mkGoogle}>
      <input type="hidden" name="next" value={next} />
      <button type="submit" className="mk-btn mk-btn--line mk-btn--wide au__google">
        <svg width="18" height="18" viewBox="0 0 48 48" aria-hidden="true">
          <path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9.1 3.6l6.8-6.8C35.8 2.4 30.3 0 24 0 14.6 0 6.6 5.4 2.7 13.3l7.9 6.1C12.5 13.6 17.8 9.5 24 9.5z"/>
          <path fill="#4285F4" d="M46.1 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.4c-.5 2.9-2.2 5.3-4.6 7l7.4 5.7c4.3-4 6.9-9.9 6.9-17.2z"/>
          <path fill="#FBBC05" d="M10.6 28.6c-.5-1.4-.8-3-.8-4.6s.3-3.2.8-4.6l-7.9-6.1C1 16.6 0 20.2 0 24s1 7.4 2.7 10.7l7.9-6.1z"/>
          <path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.4-5.7c-2.1 1.4-4.8 2.3-8.5 2.3-6.2 0-11.5-4.1-13.4-9.9l-7.9 6.1C6.6 42.6 14.6 48 24 48z"/>
        </svg>
        Continue with Google
      </button>
    </form>
  );
}

export function LoginForm({ next, forgotHref }: { next: string; forgotHref: string }) {
  const [s, action] = useActionState<FormState, FormData>(mkLogin, {});
  // Controlled, because React clears a form after its action runs: a wrong
  // password should not also cost them the email they typed.
  const [email, setEmail] = useState("");
  return (
    <form action={action} className="st-form">
      <input type="hidden" name="next" value={next} />
      <label className="st-field">
        <span className="st-field__label">Email</span>
        <input name="email" type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} />
      </label>
      <Password auto="current-password" />
      <Link href={forgotHref} className="au__link au__forgot">Forgot your password?</Link>
      <Msg s={s} />
      <Submit>Sign in</Submit>
    </form>
  );
}

export function SignupForm({ next, termsHref, privacyHref }: { next: string; termsHref: string; privacyHref: string }) {
  const [s, action] = useActionState<FormState, FormData>(mkSignup, {});
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [adult, setAdult] = useState(false);
  if (s.ok) return <Msg s={s} />;
  return (
    <form action={action} className="st-form">
      <input type="hidden" name="next" value={next} />
      <label className="st-field">
        <span className="st-field__label">Your name</span>
        <input name="display_name" required minLength={2} maxLength={60} autoComplete="name" value={name} onChange={(e) => setName(e.target.value)} />
      </label>
      <label className="st-field">
        <span className="st-field__label">Email</span>
        <input name="email" type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} />
      </label>
      <Password auto="new-password" hint="At least 8 characters." />
      <label className="au__check">
        <input type="checkbox" name="adult" required checked={adult} onChange={(e) => setAdult(e.target.checked)} />
        <span>I am 18 or over, and I agree to the <a href={termsHref} className="au__link" target="_blank" rel="noreferrer">terms</a> and <a href={privacyHref} className="au__link" target="_blank" rel="noreferrer">privacy policy</a>.</span>
      </label>
      <Msg s={s} />
      <Submit>Create account</Submit>
    </form>
  );
}

export function ForgotForm() {
  const [s, action] = useActionState<FormState, FormData>(mkRequestReset, {});
  if (s.ok) return <Msg s={s} />;
  return (
    <form action={action} className="st-form">
      <label className="st-field">
        <span className="st-field__label">Email</span>
        <input name="email" type="email" required autoComplete="email" />
      </label>
      <Msg s={s} />
      <Submit>Send reset link</Submit>
    </form>
  );
}

export function ResetForm() {
  const [s, action] = useActionState<FormState, FormData>(mkSetPassword, {});
  return (
    <form action={action} className="st-form">
      <Password auto="new-password" label="New password" hint="At least 8 characters." />
      <Password name="confirm" auto="new-password" label="Type it again" />
      <Msg s={s} />
      <Submit>Save new password</Submit>
    </form>
  );
}
