import { createAdminClient } from "@/lib/supabase/admin";
import { requireOwner, money } from "@/lib/owner";

export const metadata = { title: "Money" };
export const dynamic = "force-dynamic";

export default async function MoneyPage() {
  await requireOwner();
  const admin = createAdminClient();

  const [{ data: revenue }, { data: ledger }, { data: invoices }] = await Promise.all([
    admin.from("revenue_summary").select("*"),
    admin.from("instructor_ledger").select("*").order("accrued_cents", { ascending: false }),
    admin.from("invoices").select("*, institutions(name)").order("period_month", { ascending: false }).limit(20),
  ]);

  const months = revenue ?? [];
  const instructors = ledger ?? [];

  const totalAccrued = instructors.reduce((n, i) => n + Number(i.accrued_cents), 0);
  const totalPaid = instructors.reduce((n, i) => n + Number(i.paid_cents), 0);
  const outstanding = totalAccrued - totalPaid;
  const yearRevenue = months.reduce((n, m) => n + Number(m.institutional_cents), 0);

  return (
    <>
      <div className="con__head">
        <div>
          <h1 className="con__h">Money</h1>
          <p className="con__sub">
            Institutional invoicing and instructor cost. Subscription revenue arrives
            here once a payment provider is connected — until then this is a partial
            picture, and treating it as complete would be misleading.
          </p>
        </div>
      </div>

      <div className="kpis">
        <div className="kpi">
          <div className="eyebrow">Invoiced, 12 months</div>
          <div className="kpi__v num">{money(yearRevenue)}</div>
          <div className="kpi__s">Institutions only</div>
        </div>
        <div className="kpi">
          <div className="eyebrow">Accrued to instructors</div>
          <div className="kpi__v num">{money(totalAccrued)}</div>
          <div className="kpi__s">All time</div>
        </div>
        <div className="kpi">
          <div className="eyebrow">Paid out</div>
          <div className="kpi__v num">{money(totalPaid)}</div>
          <div className="kpi__s">Weekly runs</div>
        </div>
        <div className="kpi">
          <div className="eyebrow">Outstanding</div>
          <div className={`kpi__v num${outstanding > 50000 ? " is-warn" : ""}`}>
            {money(outstanding)}
          </div>
          <div className="kpi__s">Owed but not yet run</div>
        </div>
      </div>

      <section className="con__sec">
        <h2 className="con__h2">By month</h2>
        <table className="tbl">
          <thead>
            <tr>
              <th>Month</th><th>Signups</th><th>Certificates</th>
              <th>Institutional</th><th>Instructor cost</th><th>Difference</th>
            </tr>
          </thead>
          <tbody>
            {months.map((m) => {
              const diff = Number(m.institutional_cents) - Number(m.instructor_cost_cents);
              return (
                <tr key={m.month}>
                  <td>{new Date(m.month).toLocaleDateString(undefined, { month: "short", year: "numeric" })}</td>
                  <td className="num">{m.signups}</td>
                  <td className="num">{m.certificates_issued}</td>
                  <td className="num">{money(Number(m.institutional_cents))}</td>
                  <td className="num">{money(Number(m.instructor_cost_cents))}</td>
                  <td className="num" style={{ color: diff < 0 ? "#9B2C22" : undefined }}>
                    {money(diff)}
                  </td>
                </tr>
              );
            })}
          </tbody>
        </table>
        <p className="studio__hint" style={{ marginTop: 12 }}>
          Difference excludes subscription revenue and infrastructure. It is not margin.
        </p>
      </section>

      <section className="con__sec">
        <h2 className="con__h2">Instructors</h2>
        {instructors.length === 0 ? (
          <p className="studio__hint">Nobody has earned anything yet.</p>
        ) : (
          <table className="tbl">
            <thead>
              <tr>
                <th>Name</th><th>Courses</th><th>Reviews</th><th>Late</th>
                <th>Reviews</th><th>Pool</th><th>Owed</th>
              </tr>
            </thead>
            <tbody>
              {instructors.map((i) => (
                <tr key={i.id}>
                  <td>{i.display_name ?? i.email}</td>
                  <td className="num">{i.courses_live}</td>
                  <td className="num">{i.reviews_done}</td>
                  <td className="num" style={{ color: Number(i.reviews_late) > 0 ? "#9B2C22" : undefined }}>
                    {i.reviews_late}
                  </td>
                  <td className="num">{money(Number(i.review_cents))}</td>
                  <td className="num">{money(Number(i.pool_cents))}</td>
                  <td className="num">
                    {money(Number(i.accrued_cents) - Number(i.paid_cents))}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>

      <section className="con__sec">
        <h2 className="con__h2">Recent invoices</h2>
        {(!invoices || invoices.length === 0) ? (
          <p className="studio__hint">Nothing invoiced yet.</p>
        ) : (
          <table className="tbl">
            <thead>
              <tr><th>Institution</th><th>Month</th><th>Active</th><th>Unused</th><th>Amount</th><th>State</th></tr>
            </thead>
            <tbody>
              {invoices.map((i) => {
                const inst = i.institutions as unknown as { name: string } | null;
                return (
                  <tr key={i.id}>
                    <td>{inst?.name ?? "—"}</td>
                    <td>{new Date(i.period_month).toLocaleDateString(undefined, { month: "short", year: "numeric" })}</td>
                    <td className="num">{i.active_count}</td>
                    <td className="num">{i.seats_unused}</td>
                    <td className="num">{money(i.amount_cents)}</td>
                    <td>{i.state}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </section>
    </>
  );
}
