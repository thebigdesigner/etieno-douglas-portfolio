/**
 * Your Brand is an 18+ platform. Adults confirm at signup; nothing else about
 * age is collected or stored.
 *
 * Institutions enrolling learners are responsible for those learners being
 * adults — it is in the data processing terms, and it is why we no longer
 * carry consent machinery.
 */

export const ADULT_AGE = 18;

export type AccountType = "adult" | "institution_learner";
