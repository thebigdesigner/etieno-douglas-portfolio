/**
 * Thin Supabase client over fetch — no dependencies, works on Vercel's Node runtime.
 * Uses the service role key, so it must only ever be imported by server code in /api.
 *
 *   SUPABASE_URL                 https://xxxx.supabase.co
 *   SUPABASE_SERVICE_ROLE_KEY    Settings → API → service_role (secret)
 *   TENANT_SLUG                  which operator this deployment serves, e.g. ace-trail
 */
const URL_ = () => process.env.SUPABASE_URL;
const KEY = () => process.env.SUPABASE_SERVICE_ROLE_KEY;

export function configured() { return Boolean(URL_() && KEY()); }

async function call(path, opts = {}) {
  const res = await fetch(`${URL_()}/rest/v1/${path}`, {
    ...opts,
    headers: {
      apikey: KEY(),
      Authorization: `Bearer ${KEY()}`,
      'Content-Type': 'application/json',
      ...(opts.headers || {})
    }
  });
  const text = await res.text();
  const body = text ? JSON.parse(text) : null;
  if (!res.ok) {
    const err = new Error(body?.message || `supabase ${res.status}`);
    err.status = res.status; err.details = body; throw err;
  }
  return body;
}

export const select = (table, query = '') => call(`${table}?${query}`);
export const insert = (table, rows, prefer = 'return=representation') =>
  call(table, { method: 'POST', body: JSON.stringify(rows), headers: { Prefer: prefer } });
export const update = (table, query, patch) =>
  call(`${table}?${query}`, { method: 'PATCH', body: JSON.stringify(patch), headers: { Prefer: 'return=representation' } });
/** Calls a Postgres function (claim_seats, confirm_booking, expire_holds …). */
export const rpc = (fn, args = {}) =>
  call(`rpc/${fn}`, { method: 'POST', body: JSON.stringify(args) }).catch(err => {
    // Surface our own raise exception messages ('seat_taken') rather than a generic 500.
    const msg = err.details?.message || '';
    if (msg.includes('seat_taken')) { const e = new Error('seat_taken'); e.code = 'seat_taken'; throw e; }
    if (msg.includes('seat_missing')) { const e = new Error('seat_missing'); e.code = 'seat_missing'; throw e; }
    throw err;
  });

let tenantCache = null;
/* The tenant row is cached for the life of the serverless instance, which is right — it is read
   on nearly every request and almost never changes. But "almost never" is not never: a manager
   editing settings would otherwise keep seeing the old values from whichever instance served
   them, for as long as that instance lived. Anything that writes to tenants must call this. */
export function clearTenantCache() { tenantCache = null; }
export async function tenant() {
  if (tenantCache) return tenantCache;
  const slug = process.env.TENANT_SLUG || 'ace-trail';
  const rows = await select('tenants', `slug=eq.${encodeURIComponent(slug)}&select=*&limit=1`);
  if (!rows?.length) throw new Error(`tenant "${slug}" not found — run db/seed.sql`);
  tenantCache = rows[0];
  return tenantCache;
}

export async function audit(entry) {
  try { await insert('audit_log', [entry], 'return=minimal'); } catch { /* never block the request */ }
}

const ALPHABET = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';   // no I, O, 0, 1 — read aloud over the phone
/**
 * A booking reference a clerk can read the trip off.
 *
 *     ATX-UP1509-1K7MQ2
 *      │   │ │    ││
 *      │   │ │    │└─ serial, unique within that departure
 *      │   │ │    └── which departure of the day: 1st, 2nd, 3rd
 *      │   │ └─────── date, day and month
 *      │   └───────── route: North City → Coast City
 *      └───────────── the company
 *
 * Called without trip context it falls back to the old random form, so nothing breaks if a
 * booking is created somewhere that does not know the trip yet. Old references stay valid —
 * every lookup accepts both shapes.
 */
export function makeReference(prefix, trip) {
  const pick = n => {
    const bytes = crypto.getRandomValues(new Uint8Array(n));
    let out = '';
    for (const b of bytes) out += ALPHABET[b % ALPHABET.length];
    return out;
  };

  if (!trip || !trip.fromCode || !trip.toCode || !trip.date) return `${prefix}-${pick(6)}`;

  const initials = (trip.fromCode[0] + trip.toCode[0]).toUpperCase();
  const [, mm, dd] = String(trip.date).split('-');
  const ride = Math.min(Math.max(Number(trip.rideNo) || 1, 1), 9);
  /* Five random characters, not three. The route, date and ride number are guessable, so the
     random tail is the whole secret: three characters was 32,768 guesses per departure, which a
     script walks in minutes. Five is 33.5 million, and lookups are rate-limited per phone too.
     Still fits the ^…-[A-Z0-9]{2,6}$ shape every validator already checks. */
  return `${prefix}-${initials}${dd}${mm}-${ride}${pick(5)}`;
}

export function fail(res, status, code, message) {
  return res.status(status).json({ error: code, message });
}

/**
 * Works out what a reference needs to describe a trip: the two terminal codes and which
 * departure of the day it is on that route. Returns null if anything is missing, and
 * makeReference falls back to the old random form rather than guessing.
 */
export async function tripContext(tenantId, tripId) {
  try {
    const rows = await select('trips',
      `id=eq.${tripId}&tenant_id=eq.${tenantId}&select=depart_date,depart_time,route_id,` +
      `route:routes(from_terminal,to_terminal)`);
    const trip = rows[0];
    if (!trip || !trip.route) return null;

    const terms = await select('terminals', `tenant_id=eq.${tenantId}&select=id,code`);
    const codeOf = id => (terms.find(x => x.id === id) || {}).code;
    const fromCode = codeOf(trip.route.from_terminal), toCode = codeOf(trip.route.to_terminal);
    if (!fromCode || !toCode) return null;

    /* Ride number is the departure's position in that day's timetable for the route, so the
       07:00 run is 1 and the 14:00 run is 2 — the way the desk already talks about them. */
    const sameDay = await select('trips',
      `tenant_id=eq.${tenantId}&route_id=eq.${trip.route_id}&depart_date=eq.${trip.depart_date}` +
      `&select=id,depart_time&order=depart_time.asc`);
    const rideNo = Math.max(1, sameDay.findIndex(x => x.id === tripId) + 1);

    return { fromCode, toCode, date: trip.depart_date, rideNo };
  } catch (err) {
    console.error('trip context failed:', err.message);
    return null;
  }
}

/* ---------------------------------------------------------------- rate limits
   Counted in Postgres, not in memory. Serverless instances are many and short-lived, so an
   in-memory counter gives an attacker a fresh allowance on every cold start — the reason the
   staff login moved to login_gate. Every public endpoint that can be scripted uses this now.

   Returns true when the caller is OVER the limit. If the counter itself is unreachable it
   answers false (let the request through) and logs: a broken limiter must not take the
   booking site down with it. */
export async function limited(key, max, windowSecs) {
  try {
    return Boolean(await rpc('rate_hit', { p_key: String(key).slice(0, 200), p_max: max, p_window_secs: windowSecs }));
  } catch (err) {
    console.error('rate limiter unavailable:', err.message);
    return false;
  }
}

/** The caller's IP as Vercel reports it. Vercel overwrites X-Forwarded-For, so the first entry
    is the real client, not something the client chose. */
export function clientIp(req) {
  return String(req.headers['x-real-ip'] || req.headers['x-forwarded-for'] || '').split(',')[0].trim() || 'unknown';
}

/* ---------------------------------------------------------------- Lagos time
   The servers run on UTC; the business runs on West Africa Time (UTC+1, no daylight saving).
   A timetable time such as 07:00 means 07:00 in Lagos, so it must never be parsed as a bare
   local time — on Vercel that silently reads it as 07:00 UTC, an hour late. */
export const WAT = '+01:00';
/** Today's date in Lagos, YYYY-MM-DD. */
export const lagosToday = () => new Date(Date.now() + 3600e3).toISOString().slice(0, 10);
/** A departure's absolute instant from its date and timetable time. */
export const departsAt = (date, time) => new Date(`${date}T${String(time).slice(0, 8)}${WAT}`);

/* Reference + phone is what proves a booking is yours, so guessing it is rate-limited. Every
   endpoint that accepts the pair — Find my booking, ticket resend, receipt upload — shares one
   budget of WRONG answers, per connection and per phone number, so moving between them buys
   nothing. Right answers are never counted: a passenger's tracking page re-checks their own
   booking every thirty seconds for the whole journey. */
const LOOKUP = [['ip', 30], ['phone', 10]];            // misses allowed per 10 minutes
const lookupKeys = (req, phone) => ({
  ip: `lookup-miss:ip:${clientIp(req)}`,
  phone: `lookup-miss:phone:${String(phone || '').replace(/\D/g, '').slice(-7)}`
});
export async function lookupBlocked(req, phone) {
  const keys = lookupKeys(req, phone);
  try {
    for (const [k, max] of LOOKUP) if (await rpc('rate_blocked', { p_key: keys[k], p_max: max, p_window_secs: 600 })) return true;
  } catch (err) { console.error('rate limiter unavailable:', err.message); }
  return false;
}
export async function lookupMissed(req, phone) {
  const keys = lookupKeys(req, phone);
  try { await Promise.all(LOOKUP.map(([k]) => rpc('rate_note', { p_key: keys[k] }))); }
  catch (err) { console.error('rate limiter unavailable:', err.message); }
}
