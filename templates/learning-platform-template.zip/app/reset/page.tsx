import { redirect } from "next/navigation";
import AuthShell from "@/components/AuthShell";
import ResetForm from "./ResetForm";
import { createClient } from "@/lib/supabase/server";

export const metadata = { title: "Set a new password" };
export const dynamic = "force-dynamic";

export default async function ResetPage() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  // Arriving here without a valid session means the link expired or was reused.
  if (!user) redirect("/forgot?expired=1");

  return (
    <AuthShell
      title="Set a new password"
      intro="Choose something you have not used elsewhere. At least 8 characters."
    >
      <ResetForm />
    </AuthShell>
  );
}
