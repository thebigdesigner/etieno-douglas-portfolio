-- =====================================================================
-- 0053 — account deletion: a queue, and erasure that anonymises
--
-- requestDeletion suspended the profile, revoked the certificates, wrote
-- one row into `events`, and told the person:
--
--   "We complete the erasure within 30 days and will confirm by email."
--
-- Nothing reads that event. No queue, no panel, no email, no operator
-- surface of any kind. The promise could not be kept because nobody was
-- ever told the request existed — the same silent-failure shape as the
-- crons, but the thing failing silently is a data-protection commitment
-- made to a person in writing.
--
-- Two halves, then: a request somebody can see, and an erasure that can
-- actually be performed.
--
-- ---------------------------------------------------------------------
-- WHY ERASURE ANONYMISES RATHER THAN DELETES
-- ---------------------------------------------------------------------
-- Deleting a profile row cascades to:
--
--   enrolments        -> certificates, submissions, topic_completions,
--                        quiz_attempts, exam_attempts
--   course_purchases    financial records
--   earnings_entries    what instructors were paid
--   payout_runs         and when
--
-- Three of those are other people's records, not the leaver's:
--
--   · topic_completions divide the royalty pool. Removing a learner's
--     completions retrospectively changes what every instructor earned
--     in the months they studied. Their pay is not the leaver's to edit.
--   · course_purchases and earnings_entries are financial records that
--     have to survive for accounting regardless of who asks.
--   · a certificate names the practitioner who signed it. Erasing the
--     row erases part of their professional record too.
--
-- So erasure removes the person, not the history. Every column that
-- identifies them is cleared or tombstoned; the rows that count things
-- stay, now attached to nobody. This is what "erasure" means in
-- practice for a system with shared financial and credential records,
-- and it is defensible precisely because the alternative would damage
-- third parties.
-- =====================================================================

create table if not exists deletion_requests (
  id            uuid primary key default gen_random_uuid(),
  user_id       uuid not null references profiles(id) on delete cascade,
  requested_at  timestamptz not null default now(),
  reason        text,
  state         text not null default 'pending'
                  check (state in ('pending','completed','cancelled')),
  -- The 30 days the account page promises. Stored rather than computed
  -- in the page so the deadline cannot drift between surfaces.
  due_at        timestamptz not null default now() + interval '30 days',
  completed_at  timestamptz,
  completed_by  uuid references profiles(id),
  note          text
);

create unique index if not exists deletion_requests_one_open
  on deletion_requests (user_id) where state = 'pending';

create index if not exists deletion_requests_due on deletion_requests (state, due_at);

alter table deletion_requests enable row level security;

-- ---------------------------------------------------------------------
-- Making the request.
-- ---------------------------------------------------------------------
create or replace function public.request_account_deletion(
  p_user_id uuid, p_reason text default null
) returns table (ok boolean, reason text, due_at timestamptz)
language plpgsql security definer set search_path = public as $$
declare
  v_due timestamptz;
begin
  if exists (select 1 from deletion_requests d
              where d.user_id = p_user_id and d.state = 'pending') then
    select d.due_at into v_due from deletion_requests d
     where d.user_id = p_user_id and d.state = 'pending';
    return query select false, 'already_requested', v_due; return;
  end if;

  -- An owner cannot delete themselves out of the console. Locking the
  -- only account that can reach /console is not recoverable from inside
  -- the product.
  if exists (select 1 from profiles where id = p_user_id and role = 'operator') then
    return query select false, 'operator_account', null::timestamptz; return;
  end if;

  insert into deletion_requests (user_id, reason)
  values (p_user_id, nullif(trim(coalesce(p_reason, '')), ''))
  returning deletion_requests.due_at into v_due;

  -- Locked immediately: the request is the decision, the 30 days are
  -- only for completing it.
  update profiles set status = 'suspended' where id = p_user_id;

  update certificates c
     set revoked_at = now(),
         revoke_reason = 'Account deleted at the holder''s request'
    from enrolments e
   where e.id = c.enrolment_id
     and e.user_id = p_user_id
     and c.revoked_at is null;

  return query select true, null::text, v_due;
end; $$;

-- ---------------------------------------------------------------------
-- Performing the erasure.
-- ---------------------------------------------------------------------
create or replace function public.erase_account(p_user_id uuid, p_actor uuid)
returns table (ok boolean, reason text)
language plpgsql security definer set search_path = public as $$
begin
  if not exists (select 1 from profiles where id = p_user_id) then
    return query select false, 'no_account'; return;
  end if;

  -- The person.
  update profiles set
    display_name       = 'Deleted account',
    email              = null,
    date_of_birth      = null,
    guardian_email     = null,
    segment            = null,
    avatar_path        = null,
    avatar_alt         = null,
    marketing_opt_in   = false,
    status             = 'deleted'
  where id = p_user_id;

  -- Their name comes off every public certificate page. The certificate
  -- itself stays: it was revoked when the request was made, and a code
  -- that used to resolve should say "withdrawn" rather than vanish.
  update certificates c set show_name = false
    from enrolments e
   where e.id = c.enrolment_id and e.user_id = p_user_id;

  -- Work they submitted is theirs. The submission row stays so the
  -- review and the assessment fee still reconcile; the contents go.
  update submissions s set body = null, file_paths = '{}'
    from enrolments e
   where e.id = s.enrolment_id and e.user_id = p_user_id;

  -- Things that are only ever personal: notes, conversations, rate-limit
  -- counters, browsing state. No counting depends on any of them.
  --
  -- No notifications table to clear: 0020 derives notifications from rows
  -- that already exist rather than storing a second copy, so anonymising
  -- those rows is what clears the panel. (A delete against a
  -- `notifications` table was written here first and failed on the first
  -- run — valid at creation, fatal at execution, exactly as ever.)
  delete from topic_notes where user_id = p_user_id;
  delete from assistant_turns t using assistant_threads th
   where th.id = t.thread_id and th.user_id = p_user_id;
  delete from assistant_threads where user_id = p_user_id;
  delete from assistant_usage where bucket_key = 'user:' || p_user_id::text;
  delete from saved_courses where user_id = p_user_id;
  delete from dismissed_suggestions where user_id = p_user_id;
  delete from cart_items where user_id = p_user_id;

  -- The analytics stream keeps its shape, attached to nobody.
  update events set user_id = null where user_id = p_user_id;

  -- Frees the seat without rewriting the roster's history.
  update cohort_seats set user_id = null where user_id = p_user_id;

  update deletion_requests
     set state = 'completed', completed_at = now(), completed_by = p_actor
   where user_id = p_user_id and state = 'pending';

  perform log_admin_action(p_actor, 'erase_account', 'profile', p_user_id::text,
                           'Erasure completed; records anonymised', null);

  return query select true, null::text;
end; $$;

-- ---------------------------------------------------------------------
-- What the console panel reads.
-- ---------------------------------------------------------------------
create or replace view public.deletion_queue as
select
  d.id,
  d.user_id,
  d.requested_at,
  d.due_at,
  d.reason,
  d.state,
  d.completed_at,
  p.display_name,
  p.email,
  now() > d.due_at as overdue,
  (select count(*) from enrolments e where e.user_id = d.user_id)      as enrolments,
  (select count(*) from certificates c join enrolments e on e.id = c.enrolment_id
    where e.user_id = d.user_id)                                        as certificates,
  (select count(*) from course_purchases cp where cp.user_id = d.user_id) as purchases
from deletion_requests d
join profiles p on p.id = d.user_id;

revoke all on function public.request_account_deletion(uuid, text) from public, anon, authenticated;
revoke all on function public.erase_account(uuid, uuid) from public, anon, authenticated;
grant execute on function public.request_account_deletion(uuid, text) to service_role;
grant execute on function public.erase_account(uuid, uuid) to service_role;
