import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { myItem, ownerCount } from "@/lib/marketplace/studio";
import { EditItemView, OpenShopView } from "@/components/marketplace/studio/views";
import { studioGate } from "../../gate";

export const metadata: Metadata = { title: "Edit item · Studio", robots: { index: false } };

type Props = { params: Promise<{ id: string }>; searchParams: Promise<{ created?: string }> };

export default async function EditItemPage({ params, searchParams }: Props) {
  const [{ id }, sp] = await Promise.all([params, searchParams]);
  const g = await studioGate(`/studio/items/${id}`);
  if ("block" in g) return g.block;
  if (!g.viewer.shop) return <OpenShopView suggestedName={g.viewer.email?.split("@")[0] ?? ""} />;
  const item = await myItem(g.viewer.shop.id, id);
  if (!item) notFound();
  const owners = item.state === "published" ? await ownerCount(item.id) : 0;
  return <EditItemView item={item} shop={g.viewer.shop} userId={g.viewer.userId} base={g.base}
                       created={sp.created === "1"} owners={owners} />;
}
