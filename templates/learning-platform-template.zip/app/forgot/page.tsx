import Link from "next/link";
import AuthShell from "@/components/AuthShell";
import ForgotForm from "./ForgotForm";

export const metadata = { title: "Reset your password" };

export default function ForgotPage() {
  return (
    <AuthShell
      title="Forgotten your password?"
      intro="Enter the email address you signed up with and we will send you a link to set a new one."
      footer={
        <>
          Remembered it? <Link href="/login">Log in</Link>
          <br />
          Joining with a class code? <Link href="/join/forgot-pin">Forgotten your PIN</Link>
        </>
      }
    >
      <ForgotForm />
    </AuthShell>
  );
}
