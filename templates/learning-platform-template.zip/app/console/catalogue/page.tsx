import Link from "next/link";
import { createAdminClient } from "@/lib/supabase/admin";
import { requireOwner } from "@/lib/owner";
import FilterBar from "@/components/FilterBar";
import { SUBJECTS } from "@/lib/subjects";

export const metadata = { title: "Catalogue" };
export const dynamic = "force-dynamic";

type SearchParams = Promise<{ q?: string; state?: string; subject?: string; sort?: string }>;

export default async function CataloguePage(
  { searchParams }: { searchParams: SearchParams }
) {
  await requireOwner();
  const { q, state, subject, sort } = await searchParams;
  const admin = createAdminClient();

  // Filtered in the query, not after it. The page used to pull every course
  // and slice it in JavaScript, which is fine at forty courses and useless at
  // four hundred — the row you want may not be in the ones that arrived.
  // Your Brand's catalogue management: its own courses and practitioners'.
  // An organisation's private material is not part of this catalogue —
  // it is overseen from integrity, not curated from here.
  let query = admin.from("course_health").select("*").neq("owner_kind", "institution");

  if (q) query = query.ilike("title", `%${q.replace(/[\\%_]/g, (c) => `\\${c}`)}%`);
  if (state) query = query.eq("state", state);
  if (subject) query = query.eq("subject", subject);

  const SORTS: Record<string, { col: string; asc: boolean }> = {
    enrolments: { col: "enrolments", asc: false },
    completions: { col: "completions", asc: false },
    title: { col: "title", asc: true },
  };
  const chosen = SORTS[sort ?? "enrolments"] ?? SORTS.enrolments;

  const [{ data: courses }, { data: dropoff }, { count: totalCourses }] = await Promise.all([
    query.order(chosen.col, { ascending: chosen.asc }).limit(200),
    admin.from("topic_dropoff").select("*")
      .order("failed_at_least_once", { ascending: false }).limit(12),
    // What exists, against what is on screen — the console's real problem is
    // not knowing whether you are looking at everything.
    // slug, not course_id — the view has no course_id column, so this
    // count had silently failed since the day it was written.
    admin.from("course_health").select("slug", { count: "exact", head: true })
      .neq("owner_kind", "institution"),
  ]);

  const all = courses ?? [];
  const live = all.filter((c) => c.state === "published");
  const drafts = all.filter((c) => c.state === "draft");
  const waiting = all.filter((c) => c.state === "in_review");

  const bySubject = live.reduce<Record<string, number>>((acc, c) => {
    acc[c.subject] = (acc[c.subject] ?? 0) + 1;
    return acc;
  }, {});
  const thin = Object.entries(bySubject).filter(([, n]) => n < 3);

  return (
    <>
      <FilterBar
        search={{ name: "q", placeholder: "Course title", value: q }}
        selects={[
          {
            name: "state", label: "Any state", value: state,
            options: [
              { value: "published", label: "Live" },
              { value: "in_review", label: "In review" },
              { value: "draft", label: "Draft" },
              { value: "revision_requested", label: "Changes asked for" },
            ],
          },
          {
            name: "subject", label: "Any subject", value: subject,
            options: SUBJECTS.map((x) => ({ value: x, label: x })),
          },
          {
            name: "sort", label: "Most enrolled", value: sort,
            options: [
              { value: "completions", label: "Most completed" },
              { value: "title", label: "By title" },
            ],
          },
        ]}
        total={totalCourses ?? all.length}
        showing={all.length}
        clearHref="/console/catalogue"
      />

      <div className="con__head">
        <div>
          <h1 className="con__h">Catalogue</h1>
          <p className="con__sub">
            What is live, what is stuck in draft, and where learners give up.
          </p>
        </div>
        {/* The page an operator is on when they decide the catalogue is
            missing something. Same editor as an instructor uses; the
            ownership choice appears because of the role, not the route. */}
        <Link className="btn btn--fill" href="/console/catalogue/new">Write a course</Link>
      </div>

      <div className="kpis">
        <div className="kpi">
          <div className="eyebrow">Live</div>
          <div className="kpi__v num">{live.length}</div>
          <div className="kpi__s">{live.filter((c) => c.is_free).length} free</div>
        </div>
        <div className="kpi">
          <div className="eyebrow">Awaiting review</div>
          <div className={`kpi__v num${waiting.length > 0 ? " is-warn" : ""}`}>{waiting.length}</div>
          <div className="kpi__s">
            {waiting.length > 0
              ? <Link href="/admin/courses">Review them</Link>
              : "Nothing waiting"}
          </div>
        </div>
        <div className="kpi">
          <div className="eyebrow">In draft</div>
          <div className="kpi__v num">{drafts.length}</div>
          <div className="kpi__s">Started, not submitted</div>
        </div>
        <div className="kpi">
          <div className="eyebrow">Thin subjects</div>
          <div className="kpi__v num">{thin.length}</div>
          <div className="kpi__s">Fewer than three courses</div>
        </div>
      </div>

      {thin.length > 0 && (
        <div className="alerts">
          <div className="alert alert--warn">
            <span>
              Thin on {thin.map(([s, n]) => `${s} (${n})`).join(", ")} — a subject with one
              course reads as a placeholder
            </span>
          </div>
        </div>
      )}

      <section className="con__sec">
        <h2 className="con__h2">Every course</h2>
        {all.length === 0 ? (
          <p className="studio__hint">Nothing built yet.</p>
        ) : (
          <table className="tbl">
            <thead>
              <tr>
                <th>Course</th><th>Instructor</th><th>Subject</th>
                <th>State</th><th>Enrolled</th><th>Certified</th><th>Completion</th>
              </tr>
            </thead>
            <tbody>
              {all.map((c) => (
                <tr key={c.slug}>
                  <td>
                    {/* The console's own view of a course, not the public
                        page. A draft was previously plain text, so a course
                        written here could be created and then never reopened
                        from the surface that created it. */}
                    <Link href={`/console/catalogue/${c.slug}`}>{c.title}</Link>
                    {c.state === "published" && (
                      <Link
                        href={`/courses/${c.slug}`}
                        className="tlink"
                        style={{ marginLeft: 8, fontSize: 12, opacity: 0.7 }}
                      >
                        public page
                      </Link>
                    )}
                    {c.is_free && (
                      <span className="pill pill--free" style={{ marginLeft: 8 }}>Free</span>
                    )}
                  </td>
                  <td>{c.instructor ?? "—"}</td>
                  <td>{c.subject}</td>
                  <td>{String(c.state).replace("_", " ")}</td>
                  <td className="num">{c.enrolments}</td>
                  <td className="num">{c.certified}</td>
                  <td className="num">{c.completion_pct ?? "—"}%</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>

      <section className="con__sec">
        <h2 className="con__h2">Where learners fail</h2>
        <p className="studio__hint">
          A question most people get wrong is usually a badly written question. Worth a
          word with the instructor before assuming the topic is hard.
        </p>
        {(!dropoff || dropoff.length === 0) ? (
          <p className="studio__hint" style={{ marginTop: 14 }}>Not enough attempts yet.</p>
        ) : (
          <table className="tbl" style={{ marginTop: 16 }}>
            <thead>
              <tr><th>Course</th><th>Topic</th><th>Completed</th><th>Failed once+</th><th>Avg score</th></tr>
            </thead>
            <tbody>
              {dropoff.map((t, i) => (
                <tr key={i}>
                  <td>{t.course}</td>
                  <td>{t.topic}</td>
                  <td className="num">{t.completions}</td>
                  <td className="num">{t.failed_at_least_once}</td>
                  <td className="num">{t.avg_score ?? "—"}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </section>
    </>
  );
}
