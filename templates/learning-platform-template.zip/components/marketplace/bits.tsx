import Link from "next/link";
import type { Author, Product } from "@/lib/marketplace/types";
import { categoryBySlug } from "@/lib/marketplace/categories";
import { compact, initials, price } from "@/lib/marketplace/format";
import { DEFAULT_CCY, type Ccy } from "@/lib/money";
import { mk } from "@/lib/marketplace/href";
import MkIcon from "@/components/marketplace/MkIcon";
import ProductPreview from "@/components/marketplace/ProductPreview";

/** Avatar disc. The six tints are the theme's saturated tile pairs. */
export function Avatar({ name, hue = 0, size = 36 }: { name: string; hue?: number; size?: number }) {
  return (
    <span className="mk-av" data-hue={hue % 6} style={{ width: size, height: size, fontSize: Math.round(size * 0.38) }} aria-hidden="true">
      {initials(name)}
    </span>
  );
}

/**
 * Five small stars, as the reference draws them. The rounded rating decides
 * how many are filled; the exact figure is in the label and, where there
 * is room, printed beside them.
 */
/**
 * Nothing at all until somebody has actually rated the item.
 *
 * Five grey stars under a new listing reads as a score of zero, which is
 * both wrong and discouraging — worse than saying nothing, and the shop is
 * about to be full of items nobody has rated yet.
 */
export function Stars({ rating, count, showValue }: { rating: number; count?: number; showValue?: boolean }) {
  if (!rating && !count) return null;
  const filled = Math.round(rating);
  const label = rating ? `Rated ${rating.toFixed(1)} out of 5${count ? ` from ${count.toLocaleString("en-US")} reviews` : ""}` : "No ratings yet";
  return (
    <span className="mk-stars" role="img" aria-label={label} title={label}>
      <span className="mk-stars__row" aria-hidden="true">
        {[1, 2, 3, 4, 5].map((n) => (
          <MkIcon key={n} name="star" size={11} className={n <= filled ? "is-on" : undefined} />
        ))}
      </span>
      {showValue && rating > 0 && (
        <span className="mk-stars__v num" aria-hidden="true">
          {rating.toFixed(1)}{count !== undefined && <span className="mk-stars__n"> ({compact(count)})</span>}
        </span>
      )}
    </span>
  );
}

export function PriceTag({ cents, ccy = DEFAULT_CCY }: { cents: number; ccy?: Ccy }) {
  return <span className={`mk-price num${cents === 0 ? " is-free" : ""}`}>{price(cents, ccy)}</span>;
}

/**
 * The store card from the reference: the item's cover as a rounded tile,
 * then name, stars and price. The author and category live on the item
 * page; the card stays as quiet as the reference's.
 */
export function ProductCard({ p, base, author }: { p: Product; base: string; author?: Author }) {
  const href = mk(base, `/item/${p.slug}`);
  const cat = categoryBySlug(p.category);
  return (
    <article className="mkc">
      <Link href={href} className="mkc__link">
        <span className="mkc__media">
          <ProductPreview product={p} className="mkc__img" label="" />
        </span>
        <span className="mkc__title" title={`${p.title}${author ? ` by ${author.name}` : ""}${cat ? `, ${cat.name}` : ""}`}>{p.title}</span>
      </Link>
      <Stars rating={p.rating} count={p.ratings} />
      <PriceTag cents={p.priceCents} ccy={p.currency} />
    </article>
  );
}

export function ProductGrid({ items, base, authors }: { items: Product[]; base: string; authors: Map<string, Author> }) {
  return (
    <div className="mk-grid">
      {items.map((p) => <ProductCard key={p.id} p={p} base={base} author={authors.get(p.author)} />)}
    </div>
  );
}

/** One row of cards, like "App specials". Scrolls sideways when narrow. */
export function ProductShelf({ items, base, authors }: { items: Product[]; base: string; authors: Map<string, Author> }) {
  return (
    <div className="mk-shelf">
      {items.map((p) => <ProductCard key={p.id} p={p} base={base} author={authors.get(p.author)} />)}
    </div>
  );
}

/**
 * The list row, after the reference's "Most popular video": a thumbnail,
 * the title given room, and the numbers pushed to the right edge.
 */
export function ProductRow({ p, base, author, rank }: { p: Product; base: string; author?: Author; rank?: number }) {
  const href = mk(base, `/item/${p.slug}`);
  return (
    <li className="mkr">
      {rank !== undefined && <span className="mkr__rank num" aria-label={`Number ${rank}`}>{rank}</span>}
      <Link href={href} className="mkr__thumb" tabIndex={-1} aria-hidden="true">
        <ProductPreview product={p} className="mkr__img" />
      </Link>
      <div className="mkr__main">
        <Link href={href} className="mkr__title">{p.title}</Link>
        <span className="mkr__by">{author?.name ?? p.author}</span>
      </div>
      <div className="mkr__stats">
        <span className="mkr__stat num" title="Downloads"><MkIcon name="download" size={16} />{compact(p.downloads)}</span>
        <span className="mkr__stat num" title="Reviews"><MkIcon name="star" size={15} />{p.rating.toFixed(1)}</span>
      </div>
      <PriceTag cents={p.priceCents} ccy={p.currency} />
    </li>
  );
}

export function SectionHead({ title, icon, href, linkLabel = "View all" }: {
  title: string; icon?: Parameters<typeof MkIcon>[0]["name"]; href?: string; linkLabel?: string;
}) {
  return (
    <div className="mk-sh">
      <h2 className="mk-sh__t">
        {icon && <span className="mk-sh__ico"><MkIcon name={icon} size={16} /></span>}
        {title}
      </h2>
      {href && (
        <Link href={href} className="mk-sh__link">{linkLabel}<MkIcon name="arrow-right" size={16} /></Link>
      )}
    </div>
  );
}

/** Shown only when the demo catalogue is serving. Never in a real shop. */
export function DemoNote() {
  return (
    <p className="mk-demo" role="note">
      <MkIcon name="sparkle" size={15} />
      Sample catalogue. These items are placeholders until creators upload real ones; nothing here can be bought.
    </p>
  );
}

/** The rosette from the reference's verification card, in the theme's blues. */
export function Rosette({ className }: { className?: string }) {
  const points = Array.from({ length: 16 }, (_, i) => {
    const a = (i / 16) * Math.PI * 2;
    const r = i % 2 ? 44 : 50;
    return `${60 + Math.cos(a) * r},${56 + Math.sin(a) * r}`;
  }).join(" ");
  return (
    <svg className={className} viewBox="0 0 120 150" aria-hidden="true">
      <path d="M36 88 22 140l18-8 10 16 12-52z" fill="#253C96" />
      <path d="M84 88l14 52-18-8-10 16-12-52z" fill="#3A55C0" />
      <polygon points={points} fill="#5FC9E8" />
      <circle cx="60" cy="56" r="34" fill="#3A55C0" />
      <circle cx="60" cy="56" r="26" fill="#253C96" />
      <path d="M48 57l8 8 16-17" fill="none" stroke="#fff" strokeWidth="5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}
