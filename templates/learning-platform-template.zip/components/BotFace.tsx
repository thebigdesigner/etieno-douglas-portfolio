/**
 * The bot, as artwork.
 *
 * Pulled out of AiChatBot so the launcher and the panel's opening screen are
 * the same face rather than two drawings that can drift apart. The animation
 * classes travel with it, but every keyframe is scoped under `.ai-bot`, so it
 * floats and blinks in the launcher and sits still in the panel without
 * needing two versions of the markup.
 *
 * Gradient ids are prefixed because SVG defs are global to the document: two
 * of these on one page with the same ids and the second would paint itself
 * with the first one's fills.
 */
export default function BotFace({ idPrefix = "bot" }: { idPrefix?: string }) {
  const id = (name: string) => `${idPrefix}-${name}`;

  return (
    <svg viewBox="0 0 224 240" xmlns="http://www.w3.org/2000/svg" aria-hidden="true">
      <defs>
        <radialGradient id={id("body")} cx="38%" cy="30%" r="80%">
          <stop offset="0%" stopColor="#ffc06a" />
          <stop offset="45%" stopColor="#f78f2e" />
          <stop offset="80%" stopColor="#e56a16" />
          <stop offset="100%" stopColor="#c9530c" />
        </radialGradient>
        <linearGradient id={id("visor")} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#3a241c" />
          <stop offset="100%" stopColor="#150c09" />
        </linearGradient>
        <linearGradient id={id("gloss")} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#ffffff" stopOpacity=".55" />
          <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
        </linearGradient>
        <linearGradient id={id("bubble")} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#f492ae" />
          <stop offset="100%" stopColor="#e76d92" />
        </linearGradient>
        <filter id={id("soft")} x="-50%" y="-50%" width="200%" height="200%">
          <feGaussianBlur stdDeviation="3" />
        </filter>
      </defs>

      {/* Ground shadow stays put while the body floats. */}
      <ellipse className="ai-bot__shadow" cx="112" cy="228" rx="46" ry="8"
        fill="#000" filter={`url(#${id("soft")})`} />

      <g className="ai-bot__lift">
        <circle cx="112" cy="120" r="80" fill={`url(#${id("body")})`} />
        <path d="M 44 152 Q 112 176 180 152" fill="none" stroke="#a34a08"
          strokeOpacity=".35" strokeWidth="2" />
        <ellipse cx="112" cy="190" rx="24" ry="8.5" fill="#2a1812" />
        <ellipse cx="68" cy="56" rx="30" ry="15" fill={`url(#${id("gloss")})`}
          transform="rotate(-25 68 56)" />

        <rect x="52" y="64" width="120" height="78" rx="34" fill={`url(#${id("visor")})`}
          stroke="#0e0806" strokeWidth="5" />
        <rect x="64" y="72" width="64" height="12" rx="6" fill="#ffffff" opacity=".10" />

        <g className="ai-bot__eyes">
          <g>
            <circle cx="89" cy="104" r="13" fill="#57a9dd" />
            <circle cx="89" cy="104" r="8.5" fill="#2c6fa8" />
            <circle cx="89" cy="104" r="4" fill="#123a5c" />
            <circle cx="85.5" cy="100" r="2.4" fill="#e9f6ff" />
          </g>
          <g>
            <circle cx="136" cy="104" r="13" fill="#57a9dd" />
            <circle cx="136" cy="104" r="8.5" fill="#2c6fa8" />
            <circle cx="136" cy="104" r="4" fill="#123a5c" />
            <circle cx="132.5" cy="100" r="2.4" fill="#e9f6ff" />
          </g>
        </g>

        <g className="ai-bot__bubble" transform="translate(34,4)">
          <path d="M 16 40 L 26 40 L 13 52 Z" fill={`url(#${id("bubble")})`} />
          <rect x="0" y="0" width="46" height="41" rx="11" fill={`url(#${id("bubble")})`} />
          <path d="M23 30 C 23 30 11.5 23 11.5 15.5 C11.5 11.2 14.8 8.6 17.9 8.6 C20.1 8.6 22 9.9 23 11.8 C24 9.9 25.9 8.6 28.1 8.6 C31.2 8.6 34.5 11.2 34.5 15.5 C34.5 23 23 30 23 30 Z"
            fill="#fff8f5" />
        </g>
      </g>
    </svg>
  );
}
