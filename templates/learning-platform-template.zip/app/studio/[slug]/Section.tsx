"use client";

import { useEffect, useState } from "react";

/**
 * A collapsible section. The editor has five of these, and open by default
 * meant a course page ran to several screens of inputs before an instructor
 * had typed anything — which is how people abandon a form.
 *
 * Each carries a summary of its own state, so a collapsed section still tells
 * you whether it needs attention.
 */
export default function Section({
  title, summary, done, defaultOpen = false, anchor, children,
}: {
  title: string;
  summary: string;
  done?: boolean;
  defaultOpen?: boolean;
  /** Lets the progress strip at the top of the editor scroll here and open
   *  the section, so "what is left" is one click from the thing that fixes
   *  it rather than a hunt down the page. */
  anchor?: string;
  children: React.ReactNode;
}) {
  const [open, setOpen] = useState(defaultOpen);

  // Opened from the progress strip: it sets the hash, we listen for it.
  useEffect(() => {
    if (!anchor) return;
    const openIfMine = () => {
      if (window.location.hash === `#${anchor}`) setOpen(true);
    };
    openIfMine();
    window.addEventListener("hashchange", openIfMine);
    return () => window.removeEventListener("hashchange", openIfMine);
  }, [anchor]);

  return (
    <section
      id={anchor}
      className={`sect${open ? " is-open" : ""}${done ? " is-done" : ""}`}
      style={{ scrollMarginTop: 90 }}
    >
      <button
        className="sect__head"
        onClick={() => setOpen(!open)}
        aria-expanded={open}
      >
        <span className={`sect__mark${done ? " is-done" : ""}`}>{done ? "✓" : ""}</span>
        <span className="sect__body">
          <span className="sect__t">{title}</span>
          <span className="sect__s">{summary}</span>
        </span>
        <span className="sect__chev" aria-hidden="true">
          <svg viewBox="0 0 20 20" fill="none">
            <path d="M5.5 8L10 12.5L14.5 8" stroke="currentColor" strokeWidth="1.8"
              strokeLinecap="round" strokeLinejoin="round" />
          </svg>
        </span>
      </button>

      {open && <div className="sect__panel">{children}</div>}
    </section>
  );
}
