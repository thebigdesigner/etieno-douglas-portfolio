"use client";
import { useActionState } from "react";
import { decideVerification } from "@/app/actions/verification";
import type { FormState } from "@/lib/forms";
import { useFormStatus } from "react-dom";
import Alert from "@/components/Alert";

const initial: FormState = {};

function Btn({ label, variant }: { label: string; variant: string }) {
  const { pending } = useFormStatus();
  return <button className={`btn ${variant}`} disabled={pending}>{pending ? "…" : label}</button>;
}

export default function VerificationDecision({ institutionId }: { institutionId: string }) {
  const [okState, approve] = useActionState(
    decideVerification.bind(null, institutionId, true), initial
  );
  const [noState, reject] = useActionState(
    decideVerification.bind(null, institutionId, false), initial
  );

  if (okState.ok || noState.ok) {
    return <Alert kind="success">{okState.message ?? noState.message}</Alert>;
  }

  return (
    <div className="app__decide">
      <form action={approve}>
        <input type="hidden" name="note" value="" />
        <Btn label="Verify" variant="btn--fill" />
      </form>
      <form action={reject} className="app__reject">
        <input name="note" placeholder="What they need to send instead" required />
        <Btn label="Send back" variant="btn--line" />
      </form>
      {(okState.error || noState.error) && (
        <Alert kind="error">{okState.error ?? noState.error}</Alert>
      )}
    </div>
  );
}
