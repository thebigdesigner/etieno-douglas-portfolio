import Link from "next/link";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import CourseEditor from "./CourseEditor";
import CourseRemoval from "./CourseRemoval";
import { isOwnerEmail } from "@/lib/owner";

export const dynamic = "force-dynamic";

type MaterialRow = {
  id: string; topic_id: string; kind: string; title: string;
  path: string | null; url: string | null; size_bytes: number | null;
};

/** Explicitly typed: inferring from the query gives a nullable element type. */
function groupByTopic(rows: MaterialRow[]): Record<string, MaterialRow[]> {
  const out: Record<string, MaterialRow[]> = {};
  for (const row of rows) {
    (out[row.topic_id] ||= []).push(row);
  }
  return out;
}

/**
 * The course editor screen, without a route.
 *
 * An operator writing a Your Brand course used to be sent to /studio/[slug] —
 * the instructor's surface, with the instructor rail, the "Instructor"
 * brand and a "My courses" breadcrumb, to edit a course that is not theirs.
 * Sharing the component is right; sharing the route was not, because the
 * route carries the shell.
 *
 * So the screen lives here and two routes render it: the studio's, and the
 * console's.
 */
export default async function CourseScreen(
  { slug, backHref = "/studio", backLabel = "Studio" }:
  { slug: string; backHref?: string; backLabel?: string }
) {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();

  const admin = createAdminClient();
  const { data: course } = await admin
    .from("courses")
    .select("id, slug, title, summary, subject, level, hours_low, hours_high, project_brief, state, thumbnail_path, thumbnail_alt, requires_project, price_cents, is_free, outcomes, includes, owner_kind, institution_id, instructor_id")
    .eq("slug", slug).maybeSingle();

  if (!course) notFound();

  /* Who may open the editor. Four answers, matching requireCourseAccess:
   * the named assessor; an operator by role; an allowlisted owner, whose
   * operator-ness lives in OWNER_EMAILS rather than the role column and
   * who was 404ing here on any course they had not self-assessed; and an
   * institution admin on their own organisation's course — who could
   * never open it at all, since they are the course's owner without
   * being its assessor. */
  const { data: profile } = await admin
    .from("profiles").select("role").eq("id", user!.id).maybeSingle();
  const { data: owned } = await admin
    .from("courses").select("id").eq("id", course.id).eq("instructor_id", user!.id).maybeSingle();

  let allowed = !!owned || profile?.role === "operator" || isOwnerEmail(user?.email);
  if (!allowed && profile?.role === "institution_admin" && course.institution_id) {
    const { data: member } = await admin
      .from("institution_members").select("institution_id")
      .eq("user_id", user!.id).maybeSingle();
    allowed = member?.institution_id === course.institution_id;
  }
  if (!allowed) notFound();

  const { data: modules } = await admin
    .from("modules").select("id, title, position").eq("course_id", course.id).order("position");

  const moduleIds = (modules ?? []).map((m) => m.id);
  const { data: topics } = moduleIds.length
    ? await admin.from("topics")
        .select("id, module_id, title, body, video_uid, transcript, position, is_free")
        .in("module_id", moduleIds).order("position")
    : { data: [] };

  const topicIds = (topics ?? []).map((t) => t.id);
  const { data: quiz } = topicIds.length
    ? await admin.from("quiz_items").select("id, topic_id, prompt").in("topic_id", topicIds)
    : { data: [] };

  let materials: MaterialRow[] = [];
  if (topicIds.length) {
    const { data } = await admin
      .from("topic_materials")
      .select("id, topic_id, kind, title, path, url, size_bytes")
      .in("topic_id", topicIds)
      .order("position");
    materials = (data ?? []) as MaterialRow[];
  }

  const { data: criteria } = await admin
    .from("rubric_criteria").select("id, title, descriptor, position")
    .eq("course_id", course.id).order("position");

  // The answer key is fine here — this page is the instructor's own course,
  // behind requireCourseAccess. It is the learner's exam page that must
  // never select `correct`.
  const { data: examItems } = await admin
    .from("exam_items").select("id, position, prompt, options, correct, explanation")
    .eq("course_id", course.id).order("position");

  return (
    <>
        <nav className="crumb" style={{ paddingTop: 28 }}>
          <Link href={backHref}>{backLabel}</Link> / {course.title}
        </nav>

        <CourseEditor
          course={course}
          modules={modules ?? []}
          topics={topics ?? []}
          quizCounts={(quiz ?? []).reduce<Record<string, number>>((acc, q) => {
            acc[q.topic_id] = (acc[q.topic_id] ?? 0) + 1;
            return acc;
          }, {})}
          criteria={criteria ?? []}
          examItems={(examItems ?? []) as never}
          materials={groupByTopic(materials)}
          /* An operator publishing their own instructor course has no
             reviewer but themselves, so the review hop would be theatre.
             publishOwnCourse re-checks this server-side; this only picks
             which button the editor draws. */
          canPublishDirectly={
            (profile?.role === "operator" || isOwnerEmail(user?.email)) &&
            course.instructor_id === user!.id
          }
        />

        {/* Deliberately last and visually quiet: it is the one control on
            this page that destroys work. */}
        <CourseRemoval courseId={course.id} state={course.state} backHref={backHref} />
      </>
  );
}
