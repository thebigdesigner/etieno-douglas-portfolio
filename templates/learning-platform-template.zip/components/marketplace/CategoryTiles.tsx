import Link from "next/link";
import { CATEGORIES } from "@/lib/marketplace/categories";
import { mk } from "@/lib/marketplace/href";
import { compact } from "@/lib/marketplace/format";
import MkIcon from "@/components/marketplace/MkIcon";

/**
 * The twelve categories, on the browse page.
 *
 * This was a row of identical pills: twelve equal shapes, nothing to look
 * at and nothing to choose between, duplicating the rail with less
 * information. A tile carries the category's own icon and how much is in
 * it, which is the thing that actually helps someone pick — an empty
 * category is worth knowing about before you click it.
 */
export default function CategoryTiles({ base, counts }: { base: string; counts: Record<string, number> }) {
  return (
    <nav className="mk-cats" aria-label="Categories">
      {CATEGORIES.map((c) => {
        const n = counts[c.slug] ?? 0;
        return (
          <Link key={c.slug} href={mk(base, `/${c.slug}`)} className="mk-cats__t" data-hue={c.slug.length % 6}>
            <MkIcon name={c.icon} size={18} className="mk-cats__i" />
            <span className="mk-cats__n">{c.name}</span>
            <span className="mk-cats__c" title={n === 1 ? "1 item" : `${n} items`}>{n === 0 ? "—" : compact(n)}</span>
          </Link>
        );
      })}
    </nav>
  );
}
