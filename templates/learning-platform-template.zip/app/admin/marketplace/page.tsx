import { createAdminClient } from "@/lib/supabase/admin";
import { reviewQueue } from "@/lib/marketplace/studio";
import { categoryBySlug } from "@/lib/marketplace/categories";
import { price } from "@/lib/marketplace/format";
import ItemDecision from "./ItemDecision";

export const metadata = { title: "Marketplace items awaiting review" };
export const dynamic = "force-dynamic";

/**
 * What to check before publishing: the creator owns what they are
 * selling (no resold kits, no ripped fonts), the file is what the listing
 * says, and it opens. The download link lasts ten minutes.
 */
export default async function AdminMarketplacePage() {
  const rows = await reviewQueue();
  const admin = createAdminClient();
  const links = new Map<string, string>();
  await Promise.all(rows.map(async (r) => {
    const { data: f } = await admin.from("mk_product_files").select("path").eq("product_id", r.id).maybeSingle();
    if (!f?.path) return;
    const { data } = await admin.storage.from("mk-files").createSignedUrl(f.path, 600, { download: true });
    if (data?.signedUrl) links.set(r.id, data.signedUrl);
  }));

  return (
    <>
      <h1 className="sec__h" style={{ fontSize: 30, marginTop: 34 }}>
        {rows.length} marketplace item{rows.length === 1 ? "" : "s"} awaiting review
      </h1>
      <p className="sec__meta">
        Publish when the creator plausibly owns it, the file matches the listing, and it opens.
        Send it back with a note they can act on.
      </p>
      {rows.length === 0 ? (
        <div className="empty" style={{ marginTop: 28 }}>
          <p className="empty__h">Nothing waiting</p>
          <p className="empty__p">Items appear here when a creator submits them from the marketplace studio.</p>
        </div>
      ) : (
        <div className="apps">
          {rows.map((r) => (
            <article key={r.id} className="app">
              <div className="app__head">
                <div style={{ display: "flex", gap: 14, alignItems: "center" }}>
                  {r.coverUrl && <img src={r.coverUrl} alt="" width={96} height={72} style={{ objectFit: "cover", borderRadius: 6 }} />}
                  <div>
                    <div className="app__name">{r.title}</div>
                    <div className="app__hl">
                      {r.creator?.display_name ?? "Creator"} · {categoryBySlug(r.category)?.name} ·{" "}
                      {r.priceCents === 0 ? "Free" : price(r.priceCents)}
                      {r.commercialCents ? ` / ${price(r.commercialCents)} commercial` : ""}
                    </div>
                  </div>
                </div>
                {links.get(r.id) && <a className="sec__link" href={links.get(r.id)}>Download file</a>}
              </div>
              <div className="app__field">
                <div className="eyebrow">Description</div>
                <p>{r.summary}</p>
              </div>
              <div className="app__field">
                <div className="eyebrow">Formats · file</div>
                <p>{r.formats.join(", ") || "None"} · {r.file?.name ?? "no file"}</p>
              </div>
              <ItemDecision id={r.id} />
            </article>
          ))}
        </div>
      )}
    </>
  );
}
