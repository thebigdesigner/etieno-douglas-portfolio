"use client";

import { useEffect } from "react";

/**
 * A plain GET form that applies itself.
 *
 * Filters are URL state: shareable, back-button friendly, and rendered on
 * the server. The form works with no JavaScript at all (the Apply button
 * is the fallback); this only saves the click. It also catches controls
 * that sit outside the <form> but point at it with form="…", which is how
 * the sort menu in the results toolbar joins in.
 */
export default function FilterForm({ id, action, children, className }: {
  id: string; action: string; children: React.ReactNode; className?: string;
}) {
  useEffect(() => {
    const onChange = (e: Event) => {
      const el = e.target as HTMLInputElement | HTMLSelectElement;
      if (el.form?.id !== id) return;
      // A changed filter invalidates the page number it was on.
      const page = el.form.elements.namedItem("page") as HTMLInputElement | null;
      if (page) page.value = "";
      el.form.requestSubmit();
    };
    document.addEventListener("change", onChange);
    return () => document.removeEventListener("change", onChange);
  }, [id]);

  return <form id={id} action={action} method="get" className={className}>{children}</form>;
}
