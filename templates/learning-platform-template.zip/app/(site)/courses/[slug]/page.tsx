import Link from "next/link";
import { siteUrl } from "@/lib/site";
import { LEVEL_LABEL, hoursLabel } from "@/lib/subjects";
import CourseThumb from "@/components/CourseThumb";
import SaveButton from "@/components/SaveButton";
import { notFound } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import EnrolButton from "./EnrolButton";
import CourseOutline from "@/components/CourseOutline";
import NavIcon from "@/components/NavIcon";
import FlatIcon from "@/components/FlatIcon";
import { addToCart } from "@/app/actions/cart";

export const dynamic = "force-dynamic";

type Params = Promise<{ slug: string }>;

export async function generateMetadata({ params }: { params: Params }) {
  const { slug } = await params;
  const supabase = await createClient();
  // Same visibility as the page itself: published, and never an
  // institution's private course. Without the filters this leaked draft
  // titles and private material through page metadata.
  const { data } = await supabase
    .from("courses").select("title, summary").eq("slug", slug)
    .eq("state", "published").neq("owner_kind", "institution").maybeSingle();
  return {
    title: data?.title ?? "Course",
    description: data?.summary ?? undefined,
    openGraph: {
      title: data?.title ?? "Course",
      description: data?.summary ?? undefined,
      type: "article",
    },
  };
}

type OutlineRow = {
  topic_id: string;
  module_title: string;
  topic_title: string;
  pos: number;
  is_free: boolean;
  has_quiz: boolean;
  completed: boolean;
  unlocked: boolean;
};

export default async function CoursePage({ params }: { params: Params }) {
  const { slug } = await params;
  const supabase = await createClient();

  const { data: course } = await supabase
    .from("courses")
    .select("id, title, summary, subject, level, hours_low, hours_high, is_free, project_brief, thumbnail_path, requires_project, owner_kind, price_cents")
    .eq("slug", slug).eq("state", "published")
    // An institution's course has no public page. Their people reach it
    // through their dashboard; course_entitlement guards the lessons.
    .neq("owner_kind", "institution").maybeSingle();

  if (!course) notFound();

  const { data: { user } } = await supabase.auth.getUser();

  const admin = createAdminClient();
  const { data: outlineRaw } = await admin.rpc("course_outline", {
    p_course_id: course.id,
    p_user_id: user?.id ?? "00000000-0000-0000-0000-000000000000",
  });
  const outline = (outlineRaw ?? []) as OutlineRow[];

  const { data: saved } = user
    ? await admin.from("saved_courses").select("course_id")
        .eq("user_id", user.id).eq("course_id", course.id).maybeSingle()
    : { data: null };

  const { data: card } = await admin
    .from("course_cards")
    .select("instructor, learners, graduates, topics")
    .eq("slug", slug).maybeSingle();

  const { data: criteria } = await admin
    .from("rubric_criteria").select("title, descriptor")
    .eq("course_id", course.id).order("position");

  const done = outline.filter((t) => t.completed).length;
  const pct = outline.length ? Math.round((done / outline.length) * 100) : 0;

  const modules = outline.reduce<Record<string, OutlineRow[]>>((acc, row) => {
    (acc[row.module_title] ||= []).push(row);
    return acc;
  }, {});

  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Course",
    name: course.title,
    description: course.summary,
    provider: { "@type": "Organization", name: "Your Brand", sameAs: siteUrl() },
    educationalCredentialAwarded: "Your Brand verified certificate",
    hasCourseInstance: {
      "@type": "CourseInstance",
      courseMode: "online",
      courseWorkload: `PT${outline.length}H`,
    },
  };

  // Sellable, and whether this person already owns it. Both are read here
  // rather than in the panel so the page has one answer to "is this bought".
  const forSale =
    course.price_cents != null && !course.is_free;

  const { data: ownedRow } = forSale && user
    ? await admin.from("course_purchases").select("id")
        .eq("user_id", user.id).eq("course_id", course.id).is("refunded_at", null).maybeSingle()
    : { data: null };
  const owned = !!ownedRow;

  return (
    <>
      <script
        type="application/ld+json"
        // JSON.stringify does not escape "<", so an instructor-authored
        // title/summary containing "</script>" could otherwise break out of
        // this tag and inject markup into a public, unauthenticated page.
        dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd).replace(/</g, "\\u003c") }}
      />
      <main className="cpage">
        <div className="wrap">
          <nav className="crumb cpage__crumb">
            <Link href="/courses">Courses</Link>
            <span aria-hidden="true">/</span>
            <Link href={`/courses?subject=${encodeURIComponent(course.subject)}`}>
              {course.subject}
            </Link>
            <span aria-hidden="true">/</span>
            <span>{course.title}</span>
          </nav>

          <div className="cpage__grid">
            {/* ---- main column ---- */}
            <div className="cpage__main">
              <div className="card ctitle">
                <div className="ctitle__top">
                  <div className="crs__tags" style={{ marginTop: 0 }}>
                    <span className="tag tag--cool">{course.subject}</span>
                    <span className="tag">{LEVEL_LABEL[course.level] ?? course.level}</span>
                    {hoursLabel(course.hours_low, course.hours_high) && (
                      <span className="tag num">{hoursLabel(course.hours_low, course.hours_high)}</span>
                    )}
                  </div>
                  {user && <SaveButton slug={slug} saved={!!saved} />}
                </div>

                <h1 className="ctitle__h">{course.title}</h1>
                <p className="ctitle__p">{course.summary}</p>

                <div className="ctitle__by">
                  {card?.instructor && (
                    <span className="ctitle__who">
                      <NavIcon name="user" size={15} />
                      Taught by <strong>{card.instructor}</strong>
                    </span>
                  )}
                  {(card?.learners ?? 0) > 0 && (
                    <span className="ctitle__stat">
                      <NavIcon name="users" size={15} />
                      <span className="num">{card?.learners}</span> learning this
                    </span>
                  )}
                  {(card?.graduates ?? 0) > 0 && (
                    <span className="ctitle__stat">
                      <NavIcon name="award" size={15} />
                      <span className="num">{card?.graduates}</span> certified
                    </span>
                  )}
                </div>
              </div>

              <div className="card">
                <CourseOutline rows={outline} slug={slug} />
              </div>

              <div className="card">
                <h2 className="cout__h">Your final project</h2>
                <p className="cbody__p" style={{ marginTop: 10 }}>{course.project_brief}</p>
                {user && done === outline.length && outline.length > 0 && (
                  <p style={{ marginTop: 20 }}>
                    <Link className="btn btn--fill btn--lg" href={`/courses/${slug}/submit`}>
                      Submit your project
                    </Link>
                  </p>
                )}

                {criteria && criteria.length > 0 && (
                  <>
                    <h3 className="cbody__h3">How it will be assessed</h3>
                    <p className="cbody__p" style={{ marginBottom: 16 }}>
                      Published in advance, because you should know what you are being
                      marked on.
                    </p>
                    <div className="cmt" style={{ marginTop: 0 }}>
                      {criteria.map((c, i) => (
                        <div key={c.title} className="cmt__i">
                          <span className="cmt__k">{i + 1}</span>
                          <div>
                            <div className="cmt__t">{c.title}</div>
                            <div className="cmt__d">{c.descriptor}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </>
                )}
              </div>
            </div>

            {/* ---- sticky rail ---- */}
            <aside className="cpage__rail">
              <div className="card enrol2">
                <div className="enrol2__thumb">
                  <CourseThumb
                    path={course.thumbnail_path}
                    title={course.title}
                    subject={course.subject}
                    priority
                  />
                </div>

                {user && done > 0 && (
                  <div className="enrol2__prog">
                    <div className="enrol__bar"><span style={{ width: `${pct}%` }} /></div>
                    <div className="enrol__pct num">{pct}% complete</div>
                  </div>
                )}

                {/* Bought, or free. Those are the only two states since
                    0063, and the panel says which — it is the first thing
                    somebody needs to know here. A published course can only
                    be one of them: 0064 refuses to publish a course that is
                    neither, so the free branch below really does mean free. */}
                {forSale ? (
                  <>
                    <div className="enrol2__price">
                      ${(Number(course.price_cents) / 100).toFixed(2)}
                      <span className="enrol2__from">
                        bought once · includes your assessment
                      </span>
                    </div>

                    {owned ? (
                      <EnrolButton slug={slug} started={done > 0} signedIn={!!user} />
                    ) : (
                      <form action={addToCart.bind(null, slug)}>
                        <button className="btn btn--fill btn--lg" style={{ width: "100%" }}>
                          Add to cart
                        </button>
                      </form>
                    )}
                  </>
                ) : (
                  <>
                    <div className="enrol2__price">
                      Free
                      <span className="enrol2__from">
                        {course.requires_project
                          ? "no charge to read · assessment not included"
                          : "no charge, nothing to buy"}
                      </span>
                    </div>

                    <EnrolButton slug={slug} started={done > 0} signedIn={!!user} />
                  </>
                )}

                <div className="incl">
                  <div className="incl__h">This course includes</div>
                  <ul>
                    <li><FlatIcon name="book" size={17} /> {outline.length} topics across {new Set(outline.map((t) => t.module_title)).size} modules</li>
                    <li><FlatIcon name="inbox" size={17} /> {outline.filter((t) => t.has_quiz).length} quizzes, retake as often as you need</li>
                    <li><FlatIcon name="clock" size={17} /> A final exam, 80% to pass</li>
                    {/* Which credential this course leads to. Now that a
                        certificate means one of two different things, saying
                        which one belongs before enrolling, not after. */}
                    {course.requires_project ? (
                      <>
                        <li><FlatIcon name="user" size={17} /> A final project read by a working practitioner</li>
                        <li><FlatIcon name="clock" size={17} /> Assessed within four working days</li>
                        <li><FlatIcon name="award" size={17} /> A certificate naming the practitioner who assessed it</li>
                        <li><FlatIcon name="shield" size={17} /> One free resubmission if changes are asked for</li>
                      </>
                    ) : (
                      <li><FlatIcon name="award" size={17} /> A certificate for passing the exam, verifiable by code</li>
                    )}
                  </ul>
                </div>
              </div>

              {/* The free topic, framed as the trial it is. */}
              {outline.find((t) => t.is_free) && (
                <div className="trial">
                  <div className="trial__h">Start free</div>
                  <p className="trial__p">
                    The first topic is open before you buy — enough to judge the
                    teaching before paying for it.
                  </p>
                  <Link
                    className="trial__go"
                    href={`/learn/${slug}/${outline.find((t) => t.is_free)!.topic_id}`}
                  >
                    Open it
                  </Link>
                </div>
              )}
            </aside>
          </div>
        </div>
      </main>
    </>
  );
}
