-- =====================================================================
-- Profile pictures.
--
-- Public bucket, like thumbnails: an avatar shows on a certificate page
-- and next to a review verdict, both of which are read by people who are
-- not signed in. Nothing private goes in here.
--
-- Writes are still scoped to the owner's own folder, so one account
-- cannot overwrite another's picture.
-- =====================================================================

alter table profiles
  add column avatar_path text,
  add column avatar_alt  text;

comment on column profiles.avatar_path is
  'Path in the avatars bucket. Null means fall back to initials.';

insert into storage.buckets (id, name, public, file_size_limit)
values ('avatars', 'avatars', true, 3145728)
on conflict (id) do nothing;

create policy "anyone reads avatars"
  on storage.objects for select
  using (bucket_id = 'avatars');

create policy "users upload own avatar"
  on storage.objects for insert to authenticated
  with check (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "users replace own avatar"
  on storage.objects for update to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

create policy "users remove own avatar"
  on storage.objects for delete to authenticated
  using (bucket_id = 'avatars' and (storage.foldername(name))[1] = auth.uid()::text);

-- OAuth providers hand us a picture URL. Carry it through as metadata so
-- a Google or LinkedIn signup is not faceless on first load; the column
-- above still wins once they upload their own.
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (
    id, email, display_name, date_of_birth, account_type,
    segment, guardian_email, status, minor_protections, consent_required, intent,
    avatar_path
  )
  values (
    new.id,
    new.email,
    coalesce(
      nullif(new.raw_user_meta_data->>'display_name', ''),
      nullif(new.raw_user_meta_data->>'full_name', ''),
      nullif(new.raw_user_meta_data->>'name', '')
    ),
    nullif(new.raw_user_meta_data->>'date_of_birth', '')::date,
    coalesce((new.raw_user_meta_data->>'account_type')::account_type, 'adult'),
    nullif(new.raw_user_meta_data->>'segment', ''),
    nullif(new.raw_user_meta_data->>'guardian_email', ''),
    case when (new.raw_user_meta_data->>'consent_required')::boolean
         then 'pending_consent'::profile_status
         else 'active'::profile_status end,
    coalesce((new.raw_user_meta_data->>'minor_protections')::boolean, false),
    coalesce((new.raw_user_meta_data->>'consent_required')::boolean, false),
    coalesce((new.raw_user_meta_data->>'intent')::signup_intent, 'learner'),
    -- A full URL rather than a bucket path; the reader below handles both.
    nullif(new.raw_user_meta_data->>'avatar_url', '')
  );
  return new;
end;
$$;
