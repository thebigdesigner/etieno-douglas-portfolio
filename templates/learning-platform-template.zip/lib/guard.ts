import { redirect } from "next/navigation";
import { isOwnerEmail } from "@/lib/owner";
import { createClient } from "@/lib/supabase/server";

/**
 * The signed-in-layout preamble, once.
 *
 * Five layouts each opened with the same nine lines: get the user, bounce to
 * login with a next param, read the profile, bounce again on the wrong role.
 * Repeating an access check is how one copy ends up subtly different from the
 * others.
 */

/** Signed in, nothing more. For surfaces every role may open. */
export async function requireUser() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login?next=/dashboard");

  // select("*") rather than a column list: a named column that does not exist
  // yet (a migration not run) makes PostgREST error and return null, which a
  // caller cannot tell apart from "no such profile". That difference used to
  // turn a pending migration into an infinite redirect.
  const { data: profile } = await supabase
    .from("profiles").select("*").eq("id", user.id).maybeSingle();

  return { user, profile };
}

/**
 * Signed in AND holding one of `roles`.
 *
 * `to` is where a signed-in user with the wrong role goes — not a 403,
 * because every one of these surfaces has a correct home for that person.
 */
export async function requireProfile(
  roles: string[],
  { next, to = "/dashboard" }: { next: string; to?: string }
) {
  const { user, profile } = await requireUser();

  // Same rule as requireRole in the studio actions: an allowlisted address
  // is an operator wherever one is asked for. requireOwner already lets them
  // through the console door, and a second gate that disagrees with the
  // first is a bounce to the learner dashboard with no explanation.
  const owner = isOwnerEmail(user.email) && roles.includes("operator");
  const effective = owner ? "operator" : profile?.role;

  if (!effective || !roles.includes(effective)) {
    // Never bounce to the page being guarded — that is a redirect loop, and
    // it presents as a tab that simply never finishes loading.
    redirect(to === next ? "/" : to);
  }

  return { user, profile: owner ? { ...(profile ?? {}), role: "operator" } : profile };
}
