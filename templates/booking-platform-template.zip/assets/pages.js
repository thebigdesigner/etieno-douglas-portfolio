/**
 * Shared behaviour for the standalone pages (/routes, /terminals, /about, /contact, /terms, /refunds).
 *
 * Rebuilt with the dashboard shell: sidebar, top bar with booking search, panels.
 *
 * The booking flow stays on the homepage — these pages only read. Everything shown here comes
 * from /api/trips?routes=1, so a fare edited in the dashboard changes every page at once and
 * none of it has to be kept in sync by hand.
 */
(() => {
  const $ = s => document.querySelector(s);
  const $$ = s => [...document.querySelectorAll(s)];
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const money = n => '₦' + Number(n || 0).toLocaleString('en-NG');

  /* Kept in step with the homepage: three or more consecutive days reads as a range, and the
     week starts on Monday so the weekend is not split by 0 = Sunday. */
  const DAY_NAMES = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
  const WEEK_ORDER = [1, 2, 3, 4, 5, 6, 0];
  const listDays = list => {
    const chosen = WEEK_ORDER.filter(i => (list || []).includes(i));
    if (!chosen.length) return '';
    const runs = [];
    chosen.forEach(day => {
      const last = runs[runs.length - 1];
      const prev = WEEK_ORDER.indexOf(day) - 1;
      if (last && prev >= 0 && last[last.length - 1] === WEEK_ORDER[prev]) last.push(day);
      else runs.push([day]);
    });
    const parts = runs.map(r => r.length >= 3
      ? `${DAY_NAMES[r[0]]} to ${DAY_NAMES[r[r.length - 1]]}`
      : r.map(i => DAY_NAMES[i]).join(', '));
    const flat = parts.join(', ').split(', ');
    return flat.length === 1 ? flat[0] : flat.slice(0, -1).join(', ') + ' and ' + flat[flat.length - 1];
  };

  const CITY = { uyo: 'North City', phc: 'Coast City', cal: 'Central City' };
  const cityOf = id => CITY[id] || id;
  const icon = id => `<svg><use href="#${id}"/></svg>`;

  /* The shipped copy, used until the API answers and whenever it cannot. Addresses are still
     placeholders here; the live payload carries the real ones once a manager enters them. */
  const TERMINALS = [
    { id: 'uyo', city: 'North City', name: 'North City terminal', phone: '0800 000 0000',
      address: 'North City, North Region — full address to be confirmed', photo: '/assets/terminal-uyo.jpg' },
    { id: 'phc', city: 'Coast City', name: 'Coast City terminal', phone: '0800 000 0000',
      address: 'Coast City, Coast Region — full address to be confirmed', photo: '/assets/terminal-port-harcourt.jpg' },
    { id: 'cal', city: 'Central City', name: 'Central City terminal', phone: '0800 000 0000',
      address: 'Central City, Central Region — full address to be confirmed', photo: '/assets/terminal-calabar.jpg' }
  ];
  /* Same defaults as the homepage, so the routes page is never empty when the API is down. */
  const ALL_WEEK = [0, 1, 2, 3, 4, 5, 6];
  const FALLBACK_ROUTES = [
    { from: 'uyo', to: 'phc', fare: 18000, durationMin: 180, departures: ['07:00', '14:00'], days: ALL_WEEK },
    { from: 'phc', to: 'uyo', fare: 18000, durationMin: 180, departures: ['07:00', '14:00'], days: ALL_WEEK },
    { from: 'uyo', to: 'cal', fare: 12000, durationMin: 120, departures: ['07:30', '15:00'], days: ALL_WEEK },
    { from: 'cal', to: 'uyo', fare: 12000, durationMin: 120, departures: ['07:30', '15:00'], days: ALL_WEEK },
    { from: 'phc', to: 'cal', fare: 15000, durationMin: 150, departures: ['08:00'], days: ALL_WEEK },
    { from: 'cal', to: 'phc', fare: 15000, durationMin: 150, departures: ['15:00'], days: ALL_WEEK }
  ];
  const daysText = d => (d || []).length === 7 ? 'Every day' : (listDays(d) || 'Days to be confirmed');
  const hours = min => { const h = Math.round(min / 60 * 10) / 10; return `about ${h} hour${h === 1 ? '' : 's'}`; };

  /* ---------------------------------------------------------------- shell */
  const side = $('#side'), scrim = $('#scrim'), burger = $('#burger');
  const setMenu = open => {
    side?.classList.toggle('open', open); scrim?.classList.toggle('open', open);
    burger?.setAttribute('aria-expanded', String(open));
  };
  burger?.addEventListener('click', () => setMenu(!side.classList.contains('open')));
  scrim?.addEventListener('click', () => setMenu(false));
  document.addEventListener('keydown', e => { if (e.key === 'Escape') setMenu(false); });

  /* The search box in the top bar opens a booking on the homepage, which already knows how to
     read ?lookup= — the same door a customer comes through after paying. */
  const lookup = $('#lookupForm');
  lookup?.addEventListener('submit', e => {
    e.preventDefault();
    const ref = ($('#lookupRef').value || '').trim().toUpperCase();
    location.href = ref ? '/?lookup=' + encodeURIComponent(ref) : '/find-booking';
  });

  /* ---------------------------------------------------------------- data */
  let LIVE = null;
  async function liveRoutes() {
    try {
      const res = await fetch('/api/trips?routes=1', { headers: { Accept: 'application/json' } });
      if (!res.ok) return null;
      const data = await res.json();
      LIVE = data;
      return Array.isArray(data.routes) && data.routes.length ? data.routes : null;
    } catch (e) { return null; }
  }

  /* One entry per corridor — but only while both directions cost the same. Where they differ,
     one → entry each, so nobody is quoted one direction's fare and charged the other's. */
  const corridors = routes => {
    const out = [], seen = new Map();
    for (const r of routes) {
      const r2 = { ...r };
      const key = [r.from, r.to].sort().join('-');
      const twin = seen.get(key);
      if (!twin) { seen.set(key, r2); out.push(r2); continue; }
      if (Number(twin.fare) !== Number(r.fare)) { twin.oneWay = true; r2.oneWay = true; out.push(r2); }
      else twin.back = r2;
    }
    return out;
  };
  const corridorLabel = r => `${cityOf(r.from)} ${r.oneWay ? '→' : '⇄'} ${cityOf(r.to)}`;
  const childPct = () => Math.round(((LIVE && LIVE.policy && LIVE.policy.childFareRatio) || 0.75) * 100);

  const terminalList = () => {
    const live = LIVE && Array.isArray(LIVE.terminals) && LIVE.terminals.length ? LIVE.terminals : null;
    if (!live) return TERMINALS;
    return TERMINALS.map(t => {
      const m = live.find(x => x.code === t.id || x.city === t.city);
      return m ? { ...t, name: m.name || t.name, address: m.address || t.address,
        phone: m.phone || t.phone, whatsapp: m.whatsapp ?? t.whatsapp, opensAt: m.opensAt } : t;
    });
  };
  const opens = t => t.opensAt ? t.opensAt : '6:00 AM';
  const tel = p => 'tel:' + String(p || '').replace(/\s/g, '');

  /* ---------------------------------------------------------------- routes */
  function fillRoutes(routes) {
    const box = $('#routeCards'); if (!box) return;
    const list = corridors(routes);
    const arrive = (LIVE && LIVE.policy && LIVE.policy.arriveBeforeMin) || 30;
    /* The destination's photo, unless another route already shows it. */
    const used = new Set();
    box.innerHTML = list.map(r => {
      const pick = [r.to, r.from].map(id => (TERMINALS.find(t => t.id === id) || {}).photo).find(p => p && !used.has(p))
        || '/assets/hero-sequoias-1000.jpg';
      used.add(pick);
      const photo = pick;
      const back = r.back ? ` · back ${r.back.departures.map(esc).join(', ')}` : '';
      return `
      <article class="panel">
        <div class="panel-head">
          <h2>${icon('i-route')}${esc(corridorLabel(r))}</h2>
          <a class="chip-btn" href="/book">Book this route${icon('i-arrow')}</a>
        </div>
        <div class="route-main">
          <div class="route-photo"><img src="${photo}" alt="${esc(cityOf(r.to))}" loading="lazy" width="900" height="560"></div>
          <div class="route-info">
            <div class="route-top">
              <h3>Toyota Sequoia<small>Non-stop</small></h3>
              <div class="price"><b>${money(r.fare)}</b><small>/ adult seat</small></div>
            </div>
            <dl class="route-meta">
              <div><dt>Leaves from</dt><dd>${esc(cityOf(r.from))} terminal</dd></div>
              <div><dt>Departure times</dt><dd>${r.departures.map(esc).join(', ')}${back}</dd></div>
            </dl>
            <div class="route-acts">
              <a class="icon-btn" href="/terminals#${esc(r.from)}" aria-label="The ${esc(cityOf(r.from))} terminal">${icon('i-pin')}</a>
              <a class="icon-btn" href="/about#faq" aria-label="Questions about travelling">${icon('i-help')}</a>
              <a class="icon-btn" href="/book" aria-label="Book ${esc(corridorLabel(r))}">${icon('i-ticket')}</a>
            </div>
          </div>
        </div>
        <dl class="specs">
          <div><dt>${icon('i-clock')}Journey</dt><dd>${hours(r.durationMin)}</dd></div>
          <div><dt>${icon('i-people')}Seating</dt><dd>5 passengers</dd></div>
          <div><dt>${icon('i-calendar')}Runs</dt><dd>${esc(daysText(r.days))}</dd></div>
          <div><dt>${icon('i-ticket')}Child fare</dt><dd>${money(Math.round(r.fare * childPct() / 100))}</dd></div>
          <div><dt>${icon('i-bag')}Luggage</dt><dd>1 bag + 1 small item</dd></div>
          <div><dt>${icon('i-clock')}Arrive</dt><dd>${arrive} min before</dd></div>
        </dl>
      </article>`;
    }).join('');
  }

  function fillFares(routes) {
    const table = $('#fareTable'); if (!table) return;
    table.querySelector('tbody').innerHTML = corridors(routes).map(r => `
      <tr>
        <td><b>${esc(corridorLabel(r))}</b></td>
        <td class="right money">${money(r.fare)}</td>
        <td class="right num">${money(Math.round(r.fare * childPct() / 100))}</td>
        <td class="num">${r.departures.map(esc).join(', ')}</td>
        <td><span class="pill ${(r.days || []).length === 7 ? 'green' : 'blue'}">${esc(daysText(r.days))}</span></td>
      </tr>`).join('');
  }

  function fillTiles(routes) {
    const box = $('#routeTiles'); if (!box) return;
    const n = corridors(routes).length, low = Math.min(...routes.map(r => r.fare));
    const b = box.querySelectorAll('.tile-k b');
    b[0].textContent = n; b[1].textContent = money(low);
  }

  function fillFromFare(routes) {
    const el = $('#fromFare'); if (!el || !routes.length) return;
    el.textContent = money(Math.min(...routes.map(r => r.fare)));
  }

  /* ---------------------------------------------------------------- terminals */
  function drawTerminal(id, routes) {
    const panel = $('#termPanel'); if (!panel) return;
    const list = terminalList();
    const t = list.find(x => x.id === id) || list[0];
    const from = routes.filter(r => r.from === t.id);
    const deps = from.reduce((a, r) => a + r.departures.length, 0);
    const dots = (n, of) => `<span class="dots">${Array.from({ length: of }, (_, i) => `<i class="${i < n ? '' : 'off'}"></i>`).join('')}</span>`;
    panel.setAttribute('aria-labelledby', 'tab-' + t.id);
    panel.innerHTML = `
      <div class="term-head">
        <div class="shot"><img src="${t.photo}" alt="${esc(t.city)}" width="900" height="560"></div>
        <div>
          <small>Your Brand</small>
          <h2>${esc(t.name)}</h2>
          <p>${esc(t.address)}</p>
          <div class="acts">
            <a class="btn btn-sm" href="${tel(t.phone)}">${icon('i-phone')}Call ${esc(t.phone)}</a>
            ${t.whatsapp ? `<a class="btn btn-sm btn-ghost" href="https://wa.me/${esc(String(t.whatsapp).replace(/\D/g, '').replace(/^0/, '234'))}">${icon('i-whatsapp')}WhatsApp</a>` : ''}
            <a class="btn btn-sm btn-ghost" href="/book">Depart from ${esc(t.city)}</a>
          </div>
        </div>
      </div>
      <div class="scores">
        <div class="score"><span>Opens on departure days</span><b>${esc(opens(t))}</b><span class="meter"><i style="width:100%"></i></span></div>
        <div class="score"><span>Routes from here</span><b>${from.length}</b>${dots(from.length, 3)}</div>
        <div class="score"><span>Departures a day</span><b>${deps}</b><span class="meter ${deps < 2 ? 'low' : deps < 4 ? 'mid' : ''}"><i style="width:${Math.min(deps / 4, 1) * 100}%"></i></span></div>
      </div>
      <div class="panel-body flush" style="border-top:1px solid var(--line)">
        <table>
          <thead><tr><th>Going to</th><th>Departures</th><th>Journey</th><th class="right">Adult fare</th></tr></thead>
          <tbody>${from.length ? from.map(r => `<tr><td><b>${esc(cityOf(r.to))}</b></td><td class="num">${r.departures.map(esc).join(', ')}</td>
            <td>${hours(r.durationMin)}</td><td class="right money">${money(r.fare)}</td></tr>`).join('')
            : '<tr><td colspan="4" class="muted">No routes leave from here at the moment.</td></tr>'}</tbody>
        </table>
      </div>`;
    $$('#termTabs [data-term]').forEach(b => b.setAttribute('aria-selected', String(b.dataset.term === t.id)));
  }

  function fillTerminals(routes) {
    const tabs = $('#termTabs'); if (!tabs) return;
    const counts = id => routes.filter(r => r.from === id).length;
    tabs.innerHTML = terminalList().map(t => `<button type="button" role="tab" id="tab-${t.id}" aria-controls="termPanel"
      aria-selected="false" data-term="${t.id}">${esc(t.city)}<span class="count">${counts(t.id)}</span></button>`).join('');
    const start = (location.hash || '').slice(1);
    drawTerminal(TERMINALS.some(t => t.id === start) ? start : 'uyo', routes);
    tabs.addEventListener('click', e => {
      const b = e.target.closest('[data-term]'); if (!b) return;
      history.replaceState(null, '', '#' + b.dataset.term);
      drawTerminal(b.dataset.term, routes);
    });
    /* Arrow keys move between tabs, as a tab list should. */
    tabs.addEventListener('keydown', e => {
      if (!['ArrowLeft', 'ArrowRight'].includes(e.key)) return;
      const all = $$('#termTabs [data-term]'), i = all.indexOf(document.activeElement);
      if (i < 0) return;
      const next = all[(i + (e.key === 'ArrowRight' ? 1 : all.length - 1)) % all.length];
      next.focus(); next.click();
    });
  }

  /* The traveller's own checklist. Ticks are kept on this device only. */
  function checklist() {
    const list = $('#beforeList'); if (!list) return;
    const boxes = [...list.querySelectorAll('input[type=checkbox]')];
    let saved = [];
    try { saved = JSON.parse(localStorage.getItem('atxBefore') || '[]'); } catch (e) {}
    boxes.forEach((b, i) => { b.checked = !!saved[i]; });
    const count = () => {
      const n = boxes.filter(b => b.checked).length;
      $('#beforeCount').textContent = n === boxes.length ? 'Ready to travel' : `${n} of ${boxes.length} ready`;
      $('#beforeCount').className = n === boxes.length ? 'pill green' : 'chip';
      try { localStorage.setItem('atxBefore', JSON.stringify(boxes.map(b => b.checked))); } catch (e) {}
    };
    boxes.forEach(b => b.addEventListener('change', count));
    count();
  }

  /* ---------------------------------------------------------------- contact */
  function fillContacts() {
    const box = $('#contactCards'); if (!box) return;
    box.innerHTML = terminalList().map(t => `
      <a class="rowx" href="${tel(t.phone)}"><span class="ic"><img src="${t.photo}" alt=""></span>
        <span><b>${esc(t.name)}</b><small>${esc(t.phone)}</small></span>
        <span class="pill green"><i></i>From ${esc(opens(t))}</span></a>`).join('');
  }

  /* ---------------------------------------------------------------- policy */
  function fillPolicy() {
    const p = LIVE && LIVE.policy; if (!p) return;
    const value = {
      holdMinutes: p.holdMinutes,
      childPct: Math.round((p.childFareRatio || 0.75) * 100),
      arriveBeforeMin: p.arriveBeforeMin,
      checkInCloseMin: p.checkInCloseMin,
      cancelFreeHours: p.cancelFreeHours,
      cancelFeePct: p.cancelFeePct,
      noRefundHours: p.noRefundHours
    };
    document.querySelectorAll('[data-policy]').forEach(el => {
      const v = value[el.dataset.policy];
      if (v !== undefined && v !== null) el.textContent = String(v);
    });
    /* The middle refund bar is whatever the fee leaves. */
    if (p.cancelFeePct != null) {
      const back = Math.max(0, 100 - Number(p.cancelFeePct));
      $$('[data-refund="part"]').forEach(el => { el.textContent = back + '%'; });
      $$('[data-refund-bar]').forEach(el => { el.style.width = back + '%'; });
    }
  }

  /* "Link to this page" boxes. */
  $$('[data-here]').forEach(el => { el.value = location.href.split('#')[0]; });
  document.addEventListener('click', async e => {
    const b = e.target.closest('[data-copy]'); if (!b) return;
    const input = b.parentElement.querySelector('input');
    try { await navigator.clipboard.writeText(input.value); } catch (err) { input.select(); document.execCommand && document.execCommand('copy'); }
    b.textContent = 'Copied'; setTimeout(() => { b.textContent = 'Copy'; }, 1800);
  });

  /* Contact form. The message is saved server-side before it is emailed, so a delivery
     problem cannot lose it — the button only reports success once that has happened. */
  const form = $('#feedbackForm');
  if (form) {
    form.addEventListener('submit', async e => {
      e.preventDefault();
      const out = $('#fbResult'), btn = form.querySelector('button[type=submit]');
      const body = Object.fromEntries(new FormData(form).entries());
      form.querySelectorAll('[aria-invalid]').forEach(el => el.removeAttribute('aria-invalid'));

      const fail = (msg, field) => {
        out.innerHTML = `<p class="fb-msg bad">${esc(msg)}</p>`;
        const el = field && form.querySelector(`[name=${field}]`);
        if (el) { el.setAttribute('aria-invalid', 'true'); el.focus(); }
      };
      if ((body.name || '').trim().length < 2) return fail('Tell us your name.', 'name');
      if ((body.message || '').trim().length < 10) return fail('Tell us a little more so we can help.', 'message');
      if (!(body.email || '').trim() && !(body.phone || '').trim())
        return fail('Leave a phone number or an email so we can reply.', 'email');

      btn.disabled = true; btn.textContent = 'Sending…';
      out.innerHTML = '';
      try {
        const res = await fetch('/api/feedback', {
          method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body)
        });
        const data = await res.json().catch(() => ({}));
        if (!res.ok) throw new Error(data.message || 'Could not send your message');
        form.reset();
        out.innerHTML = `<p class="fb-msg ok">Thank you — we have your message and will reply within one working day.</p>`;
      } catch (err) {
        out.innerHTML = `<p class="fb-msg bad">${esc(err.message)} You can also call any terminal.</p>`;
      } finally { btn.disabled = false; btn.textContent = 'Send message'; }
    });
  }

  /* Draw with the shipped figures straight away, then again once the live payload lands. */
  const draw = routes => {
    fillFromFare(routes); fillTiles(routes); fillRoutes(routes); fillFares(routes);
    fillTerminals(routes); fillContacts(); fillPolicy();
  };
  checklist();
  draw(FALLBACK_ROUTES);
  liveRoutes().then(live => { if (live || LIVE) draw(live || FALLBACK_ROUTES); }).catch(() => {});
})();
