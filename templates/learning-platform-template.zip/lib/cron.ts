import { NextResponse } from "next/server";
import { timingSafeEqual } from "node:crypto";
import { createAdminClient } from "@/lib/supabase/admin";

/**
 * Scheduled routes are public URLs. Without a shared secret anyone could
 * trigger a mail-out by guessing the path.
 */
export function authorised(request: Request): boolean {
  const secret = process.env.CRON_SECRET;
  if (!secret) return false;

  const header = request.headers.get("authorization") ?? "";
  const expected = `Bearer ${secret}`;

  // Constant-time comparison — a plain === leaks how many leading
  // characters matched via response timing.
  const a = Buffer.from(header);
  const b = Buffer.from(expected);
  return a.length === b.length && timingSafeEqual(a, b);
}

export function unauthorised() {
  return NextResponse.json({ error: "unauthorised" }, { status: 401 });
}

/**
 * Run a scheduled job and leave a trace either way.
 *
 * The reason to wrap rather than to log inside each route: the outcome
 * that mattered was never reached by route code at all. CRON_SECRET was
 * unset for months, every request 401'd at the guard, and nothing past
 * it ever executed — so any amount of logging inside the handler would
 * still have recorded nothing, and "no rows" would still have been
 * ambiguous between a broken secret and a scheduler that was not
 * calling.
 *
 * So the rejection is recorded too, before the guard returns. Rows
 * saying `unauthorised` mean Vercel is calling and the secret is wrong;
 * no rows at all mean Vercel is not calling. Different problems,
 * different fixes, and previously indistinguishable.
 */
/** Recording must never be the reason a job fails, so this swallows. */
async function stamp(
  job: string, outcome: string, ms: number,
  detail: unknown = null, error: string | null = null,
): Promise<void> {
  try {
    await createAdminClient().rpc("record_cron_run", {
      p_job: job, p_outcome: outcome, p_ms: ms,
      p_detail: detail as never, p_error: error,
    });
  } catch (err) {
    console.error("could not record cron run", job, outcome, err);
  }
}

export async function runJob<T>(
  job: string,
  request: Request,
  work: () => Promise<T>,
): Promise<NextResponse> {
  const started = Date.now();

  if (!authorised(request)) {
    // Recorded, then rejected. The response itself says nothing about why.
    await stamp(job, "unauthorised", Date.now() - started);
    return unauthorised();
  }

  try {
    const result = await work();
    await stamp(job, "ok", Date.now() - started, result ?? null);
    return NextResponse.json({ ok: true, ...(result as object) });
  } catch (err) {
    const message = err instanceof Error ? err.message : String(err);
    console.error(`cron ${job} threw`, err);
    await stamp(job, "failed", Date.now() - started, null, message);
    // 500 so the scheduler's own dashboard shows it as failed too.
    return NextResponse.json({ ok: false, error: message }, { status: 500 });
  }
}
