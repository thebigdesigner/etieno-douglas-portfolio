"use client";

import Link from "next/link";
import { usePathname, useSearchParams } from "next/navigation";
import { useEffect, useState } from "react";
import NavIcon from "@/components/NavIcon";
import SplariMark from "@/components/SplariMark";
import type { NavGroup } from "@/lib/app-nav";

export type { NavGroup, NavItem } from "@/lib/app-nav";

/**
 * One rail, two widths.
 *
 * Slim by default, widening on hover so labels are there when you are looking
 * for them and out of the way when you are not. Previously the icon rail and
 * the labelled panel were both on screen at once, which meant every item was
 * rendered twice — the same list, side by side.
 *
 * The expansion overlays rather than pushes. Reflowing the page on hover is
 * jarring and moves the thing you were about to click.
 *
 * Touch has no hover, so the button toggles it, and it closes on navigation
 * and on Escape.
 */
export default function AppSidebar({
  groups, brand, settingsHref,
}: {
  groups: NavGroup[];
  brand: string;
  /**
   * Where the pinned Settings item points. No default on purpose: only the
   * learner surface has an account page today, and /dashboard/account sits
   * under a layout that bounces instructors, institution admins and
   * operators straight back out. A surface with nowhere to send them shows
   * no Settings rather than a link that ejects them.
   */
  settingsHref?: string;
}) {
  const pathname = usePathname();
  const params = useSearchParams();
  const [open, setOpen] = useState(false);

  // Navigating closes the sheet. The class is set by NavToggle in the top
  // bar, so this tells it to reset rather than flipping local state that
  // the button would not hear about.
  useEffect(() => {
    setOpen(false);
    document.querySelector(".nv")?.classList.remove("is-open");
    window.dispatchEvent(new Event("splari:nav-close"));
  }, [pathname, params]);

  useEffect(() => {
    if (!open) return;
    const esc = (e: KeyboardEvent) => { if (e.key === "Escape") setOpen(false); };
    document.addEventListener("keydown", esc);
    return () => document.removeEventListener("keydown", esc);
  }, [open]);

  const active = (href: string) => {
    const base = href.split("#")[0].split("?")[0];
    if (!base) return false;

    // Without this a parent lights up alongside every one of its children.
    if (["/dashboard", "/studio", "/institution", "/console"].includes(base)) {
      const view = href.includes("?view=") ? href.split("?view=")[1] : null;
      if (pathname !== base) return false;
      return view ? params.get("view") === view : !params.get("view");
    }
    return pathname === base || pathname.startsWith(base + "/");
  };

  return (
    <>

      <aside className={`nv${open ? " is-open" : ""}`} aria-label={`${brand} navigation`}>
        <div className="nv__inner">
          <div className="nv__head">
            <button
              type="button"
              className="nv__toggle"
              onClick={() => setOpen(!open)}
              aria-expanded={open}
            >
              {/* The mark, not a panel glyph. Slim, this button is the only
                  thing at the top of the rail, so it was carrying the brand's
                  position without carrying the brand. */}
              <SplariMark />
              <span className="sr">{open ? "Close navigation" : "Open navigation"}</span>
            </button>
            {/* The surface, not the company, and not a link — it reads
                STUDENT here and INSTRUCTOR or ADMIN elsewhere, so it is a
                label saying where you are, with nowhere of its own to go. */}
            <span className="nv__word">{brand}</span>
          </div>

          {/* The profile badge lived here — avatar, name, "View profile" — and
              duplicated the account button in the top bar two inches away.
              The rail is for going places; the account lives in one spot. */}

          <nav className="nv__nav">
            {groups.map((group, gi) => (
              <div key={group.heading ?? gi} className="nv__group">
                {group.heading && <div className="nv__heading">{group.heading}</div>}

                {group.items.map((item, ii) => (
                  /* The row is a link with an optional second link inside it,
                     so it cannot be one anchor. NavItem has carried an
                     `action` since the rail was written and nothing ever drew
                     it — the studio's "New course" has been dead the whole
                     time. */
                  <div key={item.href} className="nv__row">
                    <Link
                      href={item.href}
                      className={`nv__item${active(item.href) ? " is-on" : ""}`}
                      aria-current={active(item.href) ? "page" : undefined}
                      data-tint={(gi * 3 + ii) % 6}
                    >
                      <span className="nv__ico">
                        <NavIcon name={item.icon} size={18} />
                      </span>
                      <span className="nv__label">{item.label}</span>

                      {item.badge !== undefined && Number(item.badge) > 0 && (
                        <>
                          <span className="nv__badge num">{item.badge}</span>
                          <span className="nv__dot" aria-hidden="true" />
                        </>
                      )}

                      <span className="nv__tip">{item.label}</span>
                    </Link>

                    {item.action && (
                      <Link
                        className="nv__act"
                        href={item.action.href}
                        aria-label={item.action.label}
                        title={item.action.label}
                      >
                        <NavIcon name={item.action.icon} size={15} />
                      </Link>
                    )}
                  </div>
                ))}
              </div>
            ))}
          </nav>

          {/* Pinned to the bottom rather than added to the last group. Settings
              is somewhere you go occasionally and always want to find in the
              same place, so it sits below the list and does not scroll with
              it — .nv__nav takes the free space, this sits under it. */}
          {settingsHref && (
          <div className="nv__foot">
            <Link
              href={settingsHref}
              className={`nv__item${active(settingsHref) ? " is-on" : ""}`}
              aria-current={active(settingsHref) ? "page" : undefined}
            >
              <span className="nv__ico"><NavIcon name="gear" size={18} /></span>
              <span className="nv__label">Settings</span>
              <span className="nv__tip">Settings</span>
            </Link>
          </div>
          )}

        </div>
      </aside>

      {/* Tapping away closes it. Rendered whenever the sheet is open,
          which on mobile is the only time it exists. */}
      <div
        className="nv__scrim"
        aria-hidden="true"
        onClick={() => {
          setOpen(false);
          document.querySelector(".nv")?.classList.remove("is-open");
          window.dispatchEvent(new Event("splari:nav-close"));
        }}
      />
    </>
  );
}
