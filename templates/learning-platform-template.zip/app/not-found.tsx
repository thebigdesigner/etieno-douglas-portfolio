import Link from "next/link";
import SiteHeader from "@/components/SiteHeader";
import SiteFooter from "@/components/SiteFooter";

export const metadata = { title: "Page not found" };

export default function NotFound() {
  return (
    <>
      <SiteHeader />
      <main className="oops">
        <div className="oops__card">
          <span className="oops__ring oops__ring--calm" aria-hidden="true">
            <span className="oops__disc">?</span>
          </span>
          <h1 className="oops__h">We cannot find that page</h1>
          <p className="oops__p">
            The link may be out of date, or the page may have moved. Nothing is
            broken on your side.
          </p>
          <div className="oops__btns">
            <Link className="btn btn--fill btn--lg" href="/courses">
              Browse courses <span aria-hidden="true">→</span>
            </Link>
            <Link className="oops__quiet" href="/">
              <span aria-hidden="true">✕</span> Back to the homepage
            </Link>
          </div>
        </div>
      </main>
      <SiteFooter />
    </>
  );
}
