import type { Category } from "./types";

/**
 * The categories are code, not rows.
 *
 * They decide the rail, the URL space and which preview an item gets, so a
 * category someone added in a table would arrive with no icon, no preview
 * and no formats to filter by. Same reasoning as lib/subjects.ts. Adding
 * one is an entry here; the migration's check constraint lists the slugs so
 * the database refuses anything this file does not know about.
 */
export const CATEGORIES: Category[] = [
  {
    slug: "ui-kits", name: "UI kits", noun: ["UI kit", "UI kits"], icon: "layout", preview: "ui", hot: true,
    blurb: "Screens, components and design systems ready to open in your design tool.",
    subcategories: [
      { slug: "mobile", name: "Mobile apps" },
      { slug: "dashboards", name: "Dashboards" },
      { slug: "design-systems", name: "Design systems" },
    ],
    formats: ["Figma", "Sketch", "Adobe XD"],
  },
  {
    slug: "web-templates", name: "Website templates", noun: ["website template", "website templates"], icon: "browser", preview: "ui",
    blurb: "Built, responsive sites you can publish this afternoon.",
    subcategories: [
      { slug: "landing-pages", name: "Landing pages" },
      { slug: "ecommerce", name: "Online shops" },
      { slug: "portfolio", name: "Portfolios" },
    ],
    formats: ["HTML", "React", "Webflow", "WordPress"],
  },
  {
    slug: "presentations", name: "Presentations", noun: ["presentation", "presentations"], icon: "slides", preview: "slides",
    blurb: "Decks with the layouts already solved, so the slides are only your content.",
    subcategories: [
      { slug: "pitch-decks", name: "Pitch decks" },
      { slug: "education", name: "Teaching" },
      { slug: "reports", name: "Reports" },
    ],
    formats: ["PowerPoint", "Keynote", "Google Slides"],
  },
  {
    slug: "graphics", name: "Graphics", noun: ["graphic", "graphics"], icon: "palette", preview: "graphic",
    blurb: "Illustrations, patterns and textures, in vector where it matters.",
    subcategories: [
      { slug: "illustrations", name: "Illustrations" },
      { slug: "patterns", name: "Patterns" },
      { slug: "textures", name: "Textures" },
    ],
    formats: ["AI", "SVG", "PNG", "PSD"],
  },
  {
    slug: "icons", name: "Icons", noun: ["icon set", "icon sets"], icon: "shapes", preview: "icons",
    blurb: "Sets drawn on one grid, so they sit together on a screen.",
    subcategories: [
      { slug: "line", name: "Line" },
      { slug: "filled", name: "Filled" },
      { slug: "animated", name: "Animated" },
    ],
    formats: ["SVG", "Figma", "Lottie"],
  },
  {
    slug: "fonts", name: "Fonts", noun: ["font", "fonts"], icon: "type", preview: "font", hot: true,
    blurb: "Typefaces with the licence for the work you are actually doing.",
    subcategories: [
      { slug: "serif", name: "Serif" },
      { slug: "sans-serif", name: "Sans serif" },
      { slug: "display", name: "Display" },
      { slug: "script", name: "Script" },
    ],
    formats: ["OTF", "TTF", "WOFF2"],
  },
  {
    slug: "music", name: "Music", noun: ["track", "tracks"], icon: "music", preview: "audio",
    blurb: "Tracks cleared for videos, podcasts and ads, with stems where you need them.",
    subcategories: [
      { slug: "afrobeats", name: "Afrobeats" },
      { slug: "lo-fi", name: "Lo-fi" },
      { slug: "cinematic", name: "Cinematic" },
      { slug: "corporate", name: "Corporate" },
    ],
    formats: ["WAV", "MP3", "Stems"],
  },
  {
    slug: "sound-effects", name: "Sound effects", noun: ["sound pack", "sound packs"], icon: "wave", preview: "audio",
    blurb: "Interface clicks, room tone and transitions, trimmed and levelled.",
    subcategories: [
      { slug: "ui-sounds", name: "Interface" },
      { slug: "ambience", name: "Ambience" },
      { slug: "transitions", name: "Transitions" },
    ],
    formats: ["WAV", "MP3"],
  },
  {
    slug: "video-templates", name: "Video templates", noun: ["video template", "video templates"], icon: "film", preview: "video",
    blurb: "Titles, openers and social cuts you edit rather than animate.",
    subcategories: [
      { slug: "titles", name: "Titles" },
      { slug: "social", name: "Social" },
      { slug: "logo-reveals", name: "Logo reveals" },
    ],
    formats: ["After Effects", "Premiere Pro", "CapCut"],
  },
  {
    slug: "3d", name: "3D", noun: ["3D asset", "3D assets"], icon: "cube", preview: "3d",
    blurb: "Models and scenes, textured and ready to light.",
    subcategories: [
      { slug: "models", name: "Models" },
      { slug: "scenes", name: "Scenes" },
      { slug: "characters", name: "Characters" },
    ],
    formats: ["Blender", "GLB", "FBX"],
  },
  {
    slug: "ebooks", name: "Guides & workbooks", noun: ["guide", "guides"], icon: "book", preview: "book",
    blurb: "Written by people who do the work, for people learning it.",
    subcategories: [
      { slug: "guides", name: "Guides" },
      { slug: "workbooks", name: "Workbooks" },
      { slug: "planners", name: "Planners" },
    ],
    formats: ["PDF", "EPUB", "Notion"],
  },
  {
    slug: "code", name: "Code & plugins", noun: ["code item", "code items"], icon: "code", preview: "code",
    blurb: "Components, plugins and scripts with the source included.",
    subcategories: [
      { slug: "components", name: "Components" },
      { slug: "plugins", name: "Plugins" },
      { slug: "scripts", name: "Scripts" },
    ],
    formats: ["JavaScript", "TypeScript", "PHP", "Python"],
  },
  {
    slug: "ai-automation", name: "AI & automation", noun: ["automation", "automations"], icon: "sparkle", preview: "code", hot: true,
    blurb: "Workflows, agents and prompt systems that do the work, not just describe it.",
    subcategories: [
      { slug: "workflows", name: "n8n & Make workflows" },
      { slug: "agents", name: "AI agents" },
      { slug: "chatbots", name: "Chatbots" },
      { slug: "prompt-systems", name: "Prompt systems" },
    ],
    formats: ["JSON", "Notion", "PDF", "ZIP"],
  },
  {
    slug: "business", name: "Business kits", noun: ["business kit", "business kits"], icon: "file", preview: "slides",
    blurb: "Plans, models and documents that stand up to a bank, a board or a client.",
    subcategories: [
      { slug: "plans", name: "Plans & proposals" },
      { slug: "finance", name: "Financial models" },
      { slug: "crm", name: "CRM & pipelines" },
      { slug: "operations", name: "SOPs & onboarding" },
    ],
    formats: ["Excel", "Google Sheets", "Word", "Notion", "PDF"],
  },
  {
    slug: "career", name: "Career", noun: ["career kit", "career kits"], icon: "users", preview: "book",
    blurb: "For the search itself: applications, interviews and the portfolio behind them.",
    subcategories: [
      { slug: "cvs", name: "CVs & résumés" },
      { slug: "interviews", name: "Interviews" },
      { slug: "portfolios", name: "Portfolios" },
      { slug: "job-search", name: "Job search" },
    ],
    formats: ["Word", "PDF", "Notion", "Figma"],
  },
  {
    slug: "creator", name: "Creator kits", noun: ["creator kit", "creator kits"], icon: "play", preview: "video",
    blurb: "The unglamorous half of making things: planning, packaging and getting paid.",
    subcategories: [
      { slug: "youtube", name: "YouTube" },
      { slug: "short-form", name: "Short-form" },
      { slug: "newsletters", name: "Newsletters" },
      { slug: "sponsorship", name: "Sponsorship" },
    ],
    formats: ["Notion", "PDF", "Canva", "Premiere Pro"],
  },
];

const BY_SLUG = new Map(CATEGORIES.map((c) => [c.slug, c]));

export function categoryBySlug(slug: string): Category | undefined {
  return BY_SLUG.get(slug);
}

export function countLabel(cat: Category | undefined, n: number): string {
  const [one, many] = cat?.noun ?? ["item", "items"];
  return `${n.toLocaleString("en-US")} ${n === 1 ? one : many}`;
}
