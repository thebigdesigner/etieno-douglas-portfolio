import { redirect } from "next/navigation";
import { createAdminClient } from "@/lib/supabase/admin";
import { requireUser } from "@/lib/guard";
import { isOwnerEmail } from "@/lib/owner";
import { studioNav } from "@/lib/app-nav";
import AppShell from "@/components/AppShell";

/** Same surface as /studio, reached from the queue — so the same rail.
 *
 * Who reviews is decided per course: any person named as its assessor —
 * a practitioner, a member of staff, or somebody in an institution. The
 * old instructor|operator gate contradicted that, so an institution's
 * named assessor was bounced off the door of their own queue and the
 * organisation's submissions could never be reviewed by anybody. The
 * door now opens for the reviewing roles, for the allowlisted owner,
 * and for anyone who actually holds an assigned submission; each page
 * inside still checks the specific submission against the caller. */
export default async function ReviewLayout({ children }: { children: React.ReactNode }) {
  const { user, profile } = await requireUser();

  const admin = createAdminClient();
  const { count: queue } = await admin
    .from("review_queue_status").select("submission_id", { count: "exact", head: true })
    .eq("assigned_reviewer_id", user.id);

  const roleOk =
    ["instructor", "operator", "institution_admin"].includes(profile?.role ?? "") ||
    isOwnerEmail(user.email);
  if (!roleOk && (queue ?? 0) === 0) redirect("/dashboard");

  return (
    <AppShell
      brand="Instructor"
      name={profile.display_name}
      profile={{ name: profile.display_name ?? "Instructor", id: user.id, avatarPath: profile.avatar_path }}
      email={profile.email}
      homeHref="/review"
      helpHref="/studio/help"
      groups={studioNav(queue ?? 0)}
    >
      {children}
    </AppShell>
  );
}
