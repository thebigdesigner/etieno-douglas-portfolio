import type { MetadataRoute } from "next";
import { siteUrl } from "@/lib/site";
import { createAdminClient } from "@/lib/supabase/admin";

export const revalidate = 3600;

export default async function sitemap(): Promise<MetadataRoute.Sitemap> {
  const base = siteUrl();

  const staticRoutes = ["", "/courses", "/institutions", "/teach", "/signup", "/login", "/join",
    "/contact", "/legal/privacy", "/legal/terms", "/legal/data-processing", "/legal/security"]
    .map((path) => ({
      url: `${base}${path}`,
      lastModified: new Date(),
      changeFrequency: "weekly" as const,
      priority: path === "" ? 1 : 0.7,
    }));

  try {
    const admin = createAdminClient();
    const { data } = await admin
      .from("courses").select("slug, published_at").eq("state", "published");

    const courseRoutes = (data ?? []).map((c) => ({
      url: `${base}/courses/${c.slug}`,
      lastModified: c.published_at ? new Date(c.published_at) : new Date(),
      changeFrequency: "weekly" as const,
      priority: 0.9,
    }));

    return [...staticRoutes, ...courseRoutes];
  } catch {
    return staticRoutes;   // database not configured yet
  }
}
