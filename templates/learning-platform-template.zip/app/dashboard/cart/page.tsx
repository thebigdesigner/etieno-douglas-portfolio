import Link from "next/link";
import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import { removeFromCart, checkoutCart } from "@/app/actions/cart";
import PayChoice from "@/components/PayChoice";
import { availableProviders } from "@/lib/payments";
import NavIcon from "@/components/NavIcon";

export const metadata = { title: "Cart" };
export const dynamic = "force-dynamic";

type Params = Promise<{ error?: string }>;

const ERRORS: Record<string, string> = {
  empty: "There was nothing left to buy — the courses may have been unpublished.",
  checkout: "The payment page would not open. Nothing has been charged.",
};

function money(cents: number) {
  return `$${(cents / 100).toFixed(2)}`;
}

export default async function CartPage({ searchParams }: { searchParams: Params }) {
  const { error } = await searchParams;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login?next=/dashboard/cart");

  const admin = createAdminClient();
  const { data: items } = await admin
    .from("cart_items").select("course_id, added_at")
    .eq("user_id", user.id).order("added_at", { ascending: false });

  const ids = (items ?? []).map((i) => i.course_id as string);
  const { data: courses } = ids.length
    ? await admin.from("courses")
        .select("id, slug, title, subject, level, price_cents, hours_low, hours_high")
        .in("id", ids)
    : { data: [] };

  const rows = (courses ?? []);
  const total = rows.reduce((n, c) => n + Number(c.price_cents ?? 0), 0);

  return (
    <>
      <div className="dash__bar">
        <div>
          <div className="eyebrow">Your learning</div>
          <h1 className="dash__title">Cart</h1>
        </div>
      </div>

      {error && ERRORS[error] && (
        <div className="insight insight--warn" style={{ marginBottom: 18 }}>
          <span className="insight__ico" aria-hidden="true">!</span>
          <span className="insight__body">{ERRORS[error]}</span>
        </div>
      )}

      {rows.length === 0 ? (
        <div className="card">
          <div className="empty2" style={{ padding: "40px 0" }}>
            <p className="card__h" style={{ marginBottom: 8 }}>Nothing in the cart</p>
            <p className="card__meta" style={{ maxWidth: "44ch", margin: "0 auto" }}>
              Courses written by practitioners are bought once, and the price includes
              the assessment of your project. Everything written by Your Brand comes with a
              plan instead.
            </p>
            <Link className="btn btn--fill" href="/courses" style={{ marginTop: 20 }}>
              Browse courses
            </Link>
          </div>
        </div>
      ) : (
        <div className="cart">
          <div className="card">
            <div className="crows">
              {rows.map((c) => (
                <div key={c.id} className="crow cart__row">
                  <div className="cart__body">
                    <Link className="crow__h" href={`/courses/${c.slug}`}>{c.title}</Link>
                    <div className="crow__meta">
                      {c.subject}
                      {c.hours_low && c.hours_high ? ` · ${c.hours_low}-${c.hours_high} hours` : ""}
                      {" · includes the assessment"}
                    </div>
                  </div>
                  <div className="cart__price num">{money(Number(c.price_cents ?? 0))}</div>
                  <form action={removeFromCart.bind(null, c.id as string)}>
                    <button className="cart__x" aria-label={`Remove ${c.title}`}>Remove</button>
                  </form>
                </div>
              ))}
            </div>
          </div>

          <aside className="card cart__sum">
            <div className="card__h">Summary</div>
            <dl className="cart__dl">
              <div>
                <dt>{rows.length} course{rows.length === 1 ? "" : "s"}</dt>
                <dd className="num">{money(total)}</dd>
              </div>
              <div className="cart__total">
                <dt>Total</dt>
                <dd className="num">{money(total)}</dd>
              </div>
            </dl>

            <form action={checkoutCart}>
              <PayChoice options={availableProviders()} />
              <button className="btn btn--fill btn--lg" style={{ width: "100%" }}>
                Checkout
              </button>
            </form>

            <ul className="cart__notes">
              <li>
                <NavIcon name="award" size={14} /> Each course includes one assessment of
                your final project by a working practitioner.
              </li>
              <li>
                <NavIcon name="lock" size={14} /> Yours to keep. No subscription needed for
                anything you buy here.
              </li>
            </ul>
          </aside>
        </div>
      )}
    </>
  );
}
