import { createAdminClient } from "@/lib/supabase/admin";

/**
 * Event names are a closed set on purpose. Free-text names drift, and then the
 * phase gates cannot be measured because half the events are spelled two ways.
 */
export type EventName =
  | "signup_started"
  | "age_gate_blocked"
  | "account_created"
  | "consent_requested"
  | "consent_confirmed"
  | "cohort_joined"
  | "course_started"
  | "topic_completed"
  | "quiz_failed"
  | "quiz_cooldown"
  | "exam_failed"
  | "exam_passed"
  | "exam_cooldown"
  | "paywall_shown"
  | "project_submitted"
  | "review_completed"
  | "sla_breached"
  | "certificate_issued"
  | "appeal_opened"
  | "deletion_requested";

/**
 * Fire and forget. Instrumentation must never be able to break a user flow —
 * if the insert fails, the person still gets what they came for.
 */
export async function track(
  name: EventName,
  userId: string | null,
  props: Record<string, unknown> = {}
): Promise<void> {
  try {
    const admin = createAdminClient();
    await admin.from("events").insert({ user_id: userId, name, props });
  } catch (err) {
    console.error("track failed", name, err);
  }
}
