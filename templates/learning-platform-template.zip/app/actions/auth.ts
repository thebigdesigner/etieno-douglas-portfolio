"use server";

import { redirect } from "next/navigation";
import { safeNext } from "@/lib/safe-next";
import { siteUrl } from "@/lib/site";
import { headers, cookies } from "next/headers";
import { markArrival } from "@/lib/arrival";
import { randomUUID, randomBytes } from "node:crypto";
import { createClient } from "@/lib/supabase/server";
import { createAdminClient } from "@/lib/supabase/admin";
import type { FormState } from "@/lib/forms";
import { sendEmail } from "@/lib/email";
import { track } from "@/lib/track";
import { DELETED_ACCOUNT } from "@/lib/account-messages";



const DEVICE_COOKIE = "splari_device";
const INTENT_COOKIE = "splari_intent";

async function deviceToken(): Promise<string> {
  const store = await cookies();
  let token = store.get(DEVICE_COOKIE)?.value;
  if (!token) {
    token = randomUUID();
    store.set(DEVICE_COOKIE, token, {
      httpOnly: true,
      sameSite: "lax",
      secure: process.env.NODE_ENV === "production",
      maxAge: 60 * 60 * 24 * 365,
      path: "/",
    });
  }
  return token;
}


/* ------------------------------------------------------------------ */
/* Step 1 — what they are here for. Each path asks different questions, */
/* so this decides the shape of everything after it.                    */
/* ------------------------------------------------------------------ */
export async function chooseIntent(_prev: FormState, formData: FormData): Promise<FormState> {
  const intent = String(formData.get("intent") ?? "");
  if (!["learner", "instructor", "institution"].includes(intent)) {
    return { error: "Choose one to carry on." };
  }

  const store = await cookies();
  store.set(INTENT_COOKIE, intent, {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 60 * 60 * 2,
    path: "/",
  });

  redirect("/signup/age");
  return {};
}

/* ------------------------------------------------------------------ */
/* Step 2 — Your Brand is 18+. One confirmation, no date collected.        */
/* ------------------------------------------------------------------ */
export async function confirmAdult(_prev: FormState, formData: FormData): Promise<FormState> {
  const store = await cookies();
  const intent = store.get(INTENT_COOKIE)?.value ?? "learner";

  if (formData.get("adult") !== "yes") {
    return { error: "Your Brand is for learners aged 18 and over." };
  }

  const token = await deviceToken();
  const admin = createAdminClient();

  await admin.from("age_checks").update({ consumed_at: new Date().toISOString() })
    .eq("device_token", token).is("consumed_at", null);

  const { error } = await admin.from("age_checks").insert({
    device_token: token,
    date_of_birth: "1900-01-01",   // sentinel; nothing reads it
    derived_type: "adult",
    blocked: false,
    intent,
  });
  if (error) return { error: "Something went wrong. Try again." };

  await track("signup_started", null, { intent });
  redirect("/signup/details");
  return {};
}

/* ------------------------------------------------------------------ */
/* Step 2 — create the account against the recorded age check.          */
/* ------------------------------------------------------------------ */
export async function createAccount(_prev: FormState, formData: FormData): Promise<FormState> {
  const token = await deviceToken();
  const admin = createAdminClient();

  const { data: check } = await admin
    .from("age_checks")
    .select("*")
    .eq("device_token", token)
    .is("consumed_at", null)
    .order("created_at", { ascending: false })
    .limit(1)
    .maybeSingle();

  if (!check) return { error: "Your session expired. Please start again." };
  if (check.blocked) redirect("/signup/too-young");

  const intent = (check.intent ?? "learner") as "learner" | "instructor" | "institution";

  const name = String(formData.get("display_name") ?? "").trim();
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  const password = String(formData.get("password") ?? "");
  const headline = String(formData.get("headline") ?? "").trim();

  const orgName = String(formData.get("org_name") ?? "").trim();
  const orgCountry = String(formData.get("org_country") ?? "").trim();
  const orgWebsite = String(formData.get("org_website") ?? "").trim();

  if (name.length < 2) return { error: "Please enter your name." };
  if (intent === "institution") {
    if (orgName.length < 2) return { error: "What is the organisation called?" };
    if (!orgCountry) return { error: "Which country is it in?" };
  }
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) return { error: "Please enter a valid email address." };
  if (password.length < 8) return { error: "Your password needs to be at least 8 characters." };

  if (intent === "instructor" && headline.length < 5) {
    return { error: "Tell us what you do — a job title is enough." };
  }

  const supabase = await createClient();
  const { data: signUp, error: signUpError } = await supabase.auth.signUp({
    email,
    password,
    options: {
      emailRedirectTo: `${siteUrl()}/auth/callback`,
      data: {
        display_name: name,
        account_type: "adult",
        intent,
      },
    },
  });

  if (signUpError) {
    if (signUpError.message.toLowerCase().includes("already")) {
      return { error: "There is already an account with that email. Try logging in." };
    }
    return { error: signUpError.message };
  }

  await admin.from("age_checks")
    .update({ consumed_at: new Date().toISOString() })
    .eq("id", check.id);

  if (signUp.user && intent === "instructor") {
    await admin.rpc("register_instructor", { p_user_id: signUp.user.id });
    await admin.from("instructors").update({ headline }).eq("id", signUp.user.id);
  }

  if (signUp.user && intent === "institution") {
    await admin.rpc("register_institution", {
      p_owner_id: signUp.user.id,
      p_name: orgName,
      p_contact_email: email,
      p_country: orgCountry,
      p_website: orgWebsite,
    });
  }

  (await cookies()).delete(INTENT_COOKIE);

  await track("account_created", signUp.user?.id ?? null, { intent });
  redirect("/signup/check-email");
  return {};
}

/* ------------------------------------------------------------------ */
/* Google / LinkedIn.                                                   */
/*                                                                       */
/* This is an alternative to the email flow above, not a replacement    */
/* for it — it only ever creates a learner account. Instructor and      */
/* institution signup need fields (a headline; an organisation name     */
/* and country) that have to be collected before the account exists,    */
/* and an OAuth redirect leaves the app before any of that is on        */
/* screen. Those two intents still go through /signup.                  */
/*                                                                       */
/* No age gate to run here: handle_new_user() defaults account_type to  */
/* 'adult' for any row it did not receive explicit signup metadata for,  */
/* which is what an OAuth-created auth.users row looks like. The "18 or */
/* over" confirmation is surfaced as a notice next to the buttons        */
/* instead of a form field, the same way it is surfaced once, plainly,  */
/* rather than re-litigated per provider.                                */
/* ------------------------------------------------------------------ */
async function startOAuth(provider: "google" | "linkedin_oidc"): Promise<void> {
  const supabase = await createClient();
  const { data, error } = await supabase.auth.signInWithOAuth({
    provider,
    options: { redirectTo: `${siteUrl()}/auth/callback?next=/dashboard` },
  });

  if (error || !data.url) redirect("/login?error=oauth");
  redirect(data.url);
}

export async function signInWithGoogle(): Promise<void> {
  await startOAuth("google");
}

export async function signInWithLinkedIn(): Promise<void> {
  await startOAuth("linkedin_oidc");
}

/* ------------------------------------------------------------------ */
/* Login                                                                */
/* ------------------------------------------------------------------ */
export async function login(_prev: FormState, formData: FormData): Promise<FormState> {
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  const password = String(formData.get("password") ?? "");

  const supabase = await createClient();
  const { data, error } = await supabase.auth.signInWithPassword({ email, password });

  if (error) return { error: "That email and password do not match. Please try again." };

  const { data: profile } = await supabase
    .from("profiles").select("status, role").eq("id", data.user.id).maybeSingle();

  /* Refused for either state, and refused when the row cannot be read.
   *
   * `profile?.status === "suspended"` is false when the read returns
   * nothing, so a missing or unreadable profile used to mean "let them
   * in". And 'deleted' was never checked at all: erasure sets it, and
   * eraseAccount reports a case where the sign-in address could not be
   * tombstoned — in that state this was the only thing standing between
   * an erased account and a working login. */
  if (!profile) {
    await supabase.auth.signOut();
    return { error: "We could not open that account. Please contact hello@yourbrand.com." };
  }

  /* Two different situations, and they were sharing one message.
   *
   * Somebody who deleted their account and later tried to sign up again
   * was told it was "suspended" — while looking at a signup form, about
   * an account they had asked us to erase. Wrong, and impossible to act
   * on. Suspension is something support can lift; deletion is not. */
  if (profile.status === "deleted") {
    await supabase.auth.signOut();
    return { error: DELETED_ACCOUNT };
  }
  if (profile.status === "suspended") {
    await supabase.auth.signOut();
    return { error: "This account is suspended. Contact support if you think that is wrong." };
  }

  await markArrival();

  // Sent here from somewhere specific (the marketplace studio, a guarded
  // page): go back there. Checked, because this is an open redirect otherwise.
  const next = safeNext(formData.get("next"));
  if (next) redirect(next);

  if (profile.role === "instructor") redirect("/studio");
  if (profile.role === "institution_admin") redirect("/institution");
  if (profile.role === "operator") redirect("/admin/sla");

  redirect("/dashboard");
  return {};
}

export async function logout() {
  const supabase = await createClient();
  await supabase.auth.signOut();
  redirect("/");
}

/* ------------------------------------------------------------------ */
/* Cohort join — class code, issued username, PIN. No email involved.   */
/* ------------------------------------------------------------------ */
export async function joinCohort(_prev: FormState, formData: FormData): Promise<FormState> {
  const classCode = String(formData.get("class_code") ?? "").trim().toUpperCase();
  const username = String(formData.get("username") ?? "").trim().toLowerCase();
  const pin = String(formData.get("pin") ?? "").trim();

  if (!classCode) return { error: "Enter the class code your school gave you." };
  if (!username) return { error: "Enter your username." };
  if (!/^\d{6}$/.test(pin)) return { error: "Your PIN must be 6 digits." };

  const admin = createAdminClient();

  // One answer whether the class code, username or PIN is the wrong part —
  // splitting these out (as this used to) lets anyone holding a class code
  // enumerate valid usernames in it before ever guessing a PIN.
  const WRONG: FormState = {
    error: "That code, username or PIN is not right. Check them with whoever set up your group.",
  };

  const { data: cohort } = await admin
    .from("cohorts").select("id, state").eq("class_code", classCode).maybeSingle();
  if (!cohort || cohort.state !== "active") return WRONG;

  const { data: seat } = await admin
    .from("cohort_seats").select("id, user_id")
    .eq("cohort_id", cohort.id).ilike("username", username).maybeSingle();
  if (!seat) return WRONG;

  // Synthetic address: cohort learners never supply an email of their own.
  const syntheticEmail = `${cohort.id}.${username}@cohort.splari.internal`;
  const supabase = await createClient();

  if (seat.user_id) {
    // A 6-digit PIN is brute-forceable without a lockout — the same reason
    // quiz retakes get a cooldown after two wrong answers in a row.
    const { data: lockedUntil } = await admin.rpc("cohort_pin_locked_until", {
      p_seat_id: seat.id,
    });
    if (lockedUntil && new Date(lockedUntil) > new Date()) {
      return {
        error: "Too many wrong attempts. Try again in a few minutes, or ask your organisation to reset your PIN.",
      };
    }

    const { error } = await supabase.auth.signInWithPassword({
      email: syntheticEmail, password: pin,
    });
    if (error) {
      await admin.rpc("record_pin_failure", { p_seat_id: seat.id });
      return WRONG;
    }

    /* The same status check the other two doors make.
     *
     * login() refuses a suspended or deleted account and the OAuth
     * callback refuses one, and this — the third way into the product —
     * signed in and redirected without looking. A cohort learner
     * suspended by their organisation, or one whose account had been
     * erased, could walk back in through /join. Read with the
     * service-role client and fail closed, for the same reason as the
     * others: `profile?.status === ...` is false when the row does not
     * come back, so a read that fails is a door that opens. */
    const { data: joiner } = await admin
      .from("profiles").select("status").eq("id", seat.user_id).maybeSingle();

    if (joiner?.status === "deleted") {
      await supabase.auth.signOut();
      return { error: DELETED_ACCOUNT };
    }

    if (!joiner || joiner.status === "suspended") {
      await supabase.auth.signOut();
      return {
        error: "This account is not active. Ask whoever set up your group.",
      };
    }

    await markArrival();
    redirect("/dashboard");
  }

  const { data: created, error: createError } = await admin.auth.admin.createUser({
    email: syntheticEmail,
    password: pin,
    email_confirm: true,
    user_metadata: {
      display_name: username,
      account_type: "adult",
    },
  });
  if (createError || !created.user) return { error: "Could not set up your account. Ask your organisation." };

  const { data: claimed } = await admin.rpc("claim_cohort_seat", {
    p_class_code: classCode, p_username: username, p_user_id: created.user.id,
  });
  if (!claimed) {
    await admin.auth.admin.deleteUser(created.user.id);
    return { error: "That place has already been taken, or the class is full." };
  }

  await track("cohort_joined", created.user.id, { classCode });

  const { error: signInError } = await supabase.auth.signInWithPassword({
    email: syntheticEmail, password: pin,
  });
  if (signInError) return { error: "Account created, but sign-in failed. Try again." };

  await markArrival();
  redirect("/dashboard");
  return {};
}

/* ------------------------------------------------------------------ */
/* Password reset                                                       */
/* ------------------------------------------------------------------ */
export async function requestReset(_prev: FormState, formData: FormData): Promise<FormState> {
  const email = String(formData.get("email") ?? "").trim().toLowerCase();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) {
    return { error: "Please enter a valid email address." };
  }

  const supabase = await createClient();
  await supabase.auth.resetPasswordForEmail(email, {
    redirectTo: `${siteUrl()}/auth/callback?next=/reset`,
  });

  // Always the same answer, whether or not the address exists. Otherwise this
  // page becomes a way to discover who has an account.
  return {
    ok: true,
    message: "If there is an account with that address, a reset link is on its way.",
  };
}

export async function setNewPassword(_prev: FormState, formData: FormData): Promise<FormState> {
  const password = String(formData.get("password") ?? "");
  const confirm = String(formData.get("confirm") ?? "");

  if (password.length < 8) return { error: "Your password needs to be at least 8 characters." };
  if (password !== confirm) return { error: "Those two passwords do not match." };

  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) {
    return { error: "That reset link has expired. Please request a new one." };
  }

  const { error } = await supabase.auth.updateUser({ password });
  if (error) return { error: error.message };

  await markArrival();
  redirect("/dashboard");
  return {};
}
