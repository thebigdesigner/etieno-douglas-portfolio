import type { Metadata } from "next";
import { balances, entries, payoutAccounts, payouts, recentSales, HOLD_DAYS, MIN_PAYOUT } from "@/lib/marketplace/wallet";
import { EarningsView, OpenShopView } from "@/components/marketplace/studio/views";
import { studioGate } from "../gate";

export const metadata: Metadata = { title: "Earnings · Studio", robots: { index: false } };

export default async function EarningsPage() {
  const g = await studioGate("/studio/earnings");
  if ("block" in g) return g.block;
  if (!g.viewer.shop) return <OpenShopView suggestedName={g.viewer.email?.split("@")[0] ?? ""} />;
  const shop = g.viewer.shop;

  const [bals, ledger, outs, accounts, sales] = await Promise.all([
    balances(shop.id), entries(shop.id), payouts(shop.id), payoutAccounts(shop.id), recentSales(shop.id),
  ]);

  return (
    <EarningsView shop={shop} base={g.base} balances={bals} entries={ledger} payouts={outs}
      accounts={accounts} sales={sales} minPayout={MIN_PAYOUT} holdDays={HOLD_DAYS} />
  );
}
